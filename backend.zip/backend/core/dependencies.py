"""
FastAPI dependency injection helpers.

Usage in routes:
    @router.get("/foo")
    def foo(db: Session = Depends(get_db)):
        ...
"""
from typing import Generator

from sqlalchemy.orm import Session

from db.connection import SessionLocal


def get_db() -> Generator[Session, None, None]:
    """Yield a SQLAlchemy session; auto-closes on request teardown."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
