"""
Pydantic schemas for Agent Query endpoints.
"""
from typing import List, Optional

from pydantic import BaseModel, Field


# ── Request ──────────────────────────────────────────────────────────────────

class QueryRequest(BaseModel):
    application_number: str = Field(
        ...,
        description="Application number to query (e.g. F11248249 or 9217523)",
        examples=["F11248249"],
    )
    question: str = Field(
        ...,
        min_length=3,
        description="Underwriting question about this application",
        examples=["Does the applicant have a history of diabetes?"],
    )
    session_id: Optional[str] = Field(
        None,
        description="Pass an existing session_id to continue a conversation. Leave null for a new session.",
    )
    user_id: Optional[str] = Field(
        "api_user",
        description="Optional user identifier for tracking purposes",
    )


# ── Response ─────────────────────────────────────────────────────────────────

class QueryResponse(BaseModel):
    session_id: str
    application_number: str
    question: str
    thought: Optional[str] = None
    answer: Optional[str] = None
    confidence_score: Optional[str] = None   # e.g. "92%"
    steps_completed: List[str] = []
    conversation_id: Optional[str] = None


class MessageSchema(BaseModel):
    id: str
    role: str                                 # user | assistant
    step: Optional[str] = None
    content: str
    thought: Optional[str] = None
    confidence_score: Optional[float] = None  # float 0.0–1.0
    created_at: str

    model_config = {"from_attributes": True}


class ConversationHistoryResponse(BaseModel):
    session_id: str
    messages: List[MessageSchema]
