"""
EXL Domain Scale.ai — LDS Life Underwriting LLM Backend

FastAPI wrapper around the existing LangGraph multi-agent pipeline.
No authentication required — internal service.

Run:
    uvicorn main:app --reload --host 0.0.0.0 --port 8000

Swagger UI : http://localhost:8000/docs
ReDoc      : http://localhost:8000/redoc
Health     : http://localhost:8000/health
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from config import settings
from core.exceptions import register_exception_handlers
from core.middleware import LoggingMiddleware
from db.connection import engine
from db.schema import Base
from api.v1 import query, applications, upload


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Auto-create conversations + messages tables on first boot (safe to run every restart)
    Base.metadata.create_all(bind=engine)
    yield
    engine.dispose()


app = FastAPI(
    title="EXL LDS Underwriting AI API",
    version="1.0.0",
    description=(
        "EXL Domain Scale.ai — Life Insurance Underwriting LLM backend.\n\n"
        "Wraps the LangGraph multi-agent pipeline (Intent Classification → "
        "Extract Data Sources → Query Processing → Extract Text → "
        "Relevancy Checker → Chief Reasoning Agent) as clean REST endpoints.\n\n"
        "**No authentication required.**"
    ),
    lifespan=lifespan,
)

# CORS — allow all origins (restrict in production via ALLOWED_ORIGINS env var)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(LoggingMiddleware)
register_exception_handlers(app)

# Routers
app.include_router(query.router,        prefix="/api/v1/query",        tags=["Agent Query"])
app.include_router(applications.router, prefix="/api/v1/applications", tags=["Applications"])
app.include_router(upload.router,       prefix="/api/v1/upload",       tags=["File Upload"])


@app.get("/health", tags=["Health"])
def health():
    """Server health check — returns ok when the service is running."""
    return {"status": "ok", "version": "1.0.0"}
