"""
SQLAlchemy ORM — only the tables managed by this API.

The agent tables (applications, data_sources, pages, documents) already
exist in the AWS RDS database and are NOT re-defined here to avoid schema
conflicts. We query those tables via raw SQL when needed.

Tables created by this API:
  conversations  — chat sessions (one per session_id)
  messages       — individual Q&A turns per session
"""
import uuid
from datetime import datetime

from sqlalchemy import Column, DateTime, Float, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id = Column(String(100), unique=True, nullable=False, index=True)
    application_number = Column(String(50), nullable=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    messages = relationship(
        "Message",
        back_populates="conversation",
        cascade="all, delete-orphan",
        order_by="Message.created_at",
    )


class Message(Base):
    __tablename__ = "messages"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id = Column(
        UUID(as_uuid=True),
        ForeignKey("conversations.id", ondelete="CASCADE"),
        nullable=False,
    )
    role = Column(String(20), nullable=False)        # user | assistant
    step = Column(String(100), nullable=True)        # e.g. "Chief Reasoning Agent"
    content = Column(Text, nullable=False)
    thought = Column(Text, nullable=True)            # Claude's reasoning chain
    confidence_score = Column(Float, nullable=True)  # float 0.0–1.0
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    conversation = relationship("Conversation", back_populates="messages")
