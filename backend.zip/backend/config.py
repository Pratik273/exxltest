"""
Central configuration — all settings loaded from .env via pydantic-settings.
Never read os.environ directly in other modules; import `settings` from here.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # ── PostgreSQL (AWS RDS — same DB used by the agents) ───────────────────
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    POSTGRES_DB: str = "lds_db"
    DB_USERNAME: str = "postgres"
    DB_PASSWORD: str = "postgres"

    # ── AWS ─────────────────────────────────────────────────────────────────
    AWS_REGION: str = "us-east-1"
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""
    BEDROCK_MODEL_ID: str = ""     # Bedrock CRI / ARN (same as BrAipClaude35SonnetV2Cri)
    S3_BUCKET_NAME: str = ""

    # ── Agent flags (mirror the POC env vars used inside the agents) ────────
    IS_GENERATING_DATA: bool = False
    GENERATING_SUMMARY: bool = False

    # ── API ─────────────────────────────────────────────────────────────────
    ALLOWED_ORIGINS: list[str] = ["*"]

    model_config = SettingsConfigDict(env_file=".env", extra="allow")

    @property
    def DATABASE_URL(self) -> str:
        return (
            f"postgresql+psycopg2://{self.DB_USERNAME}:{self.DB_PASSWORD}"
            f"@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
        )


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
