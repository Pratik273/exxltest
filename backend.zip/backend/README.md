# EXL Domain Scale.ai — LDS Underwriting AI Backend

FastAPI backend for the **Life Insurance Underwriting LLM** system.
Wraps the existing LangGraph multi-agent pipeline as clean REST endpoints.
**No authentication required.**

---

## Architecture Overview

```
User / Frontend
      │
      ▼
Application Load Balancer (NGINX)
      │
      ▼
FastAPI Backend  ←──  AWS RDS PostgreSQL (same DB the agents use)
      │
      ▼
LangGraph Multi-Agent Pipeline
  1. Intent Classification Agent
  2. Extract Data Sources        ──── AWS RDS (pages / documents / embeddings)
  3. Query Processing Agent
  4. Extract Text from DB        ──── AWS RDS (semantic search)
  5. Relevancy Checker Agent     ──── AWS Bedrock (Claude 3.5 Sonnet)
  6. Chief Reasoning Agent       ──── AWS Bedrock (Claude 3.5 Sonnet)
      │
      ▼
   Answer + Thought + Confidence Score
```

---

## Folder Structure

```
backend/
├── main.py                    ← FastAPI app entry point
├── config.py                  ← All settings loaded from .env
├── requirements.txt
├── .env.example               ← Copy to .env and fill values
├── README.md                  ← This file
├── EXL_LDS_API.postman_collection.json
│
├── api/v1/
│   ├── query.py               ← POST /query, GET /query/history/{id}
│   ├── applications.py        ← GET /applications, GET /applications/{num}
│   └── upload.py              ← POST /upload/pdf, POST /upload/xml
│
├── models/
│   └── query.py               ← Pydantic request/response schemas
│
├── db/
│   ├── connection.py          ← SQLAlchemy engine + session
│   └── schema.py              ← ORM: conversations + messages tables only
│
├── services/
│   └── query_service.py       ← Calls LangGraph agents, stores history
│
└── core/
    ├── dependencies.py        ← get_db dependency
    ├── middleware.py          ← Request/response logging
    └── exceptions.py         ← Custom error handlers
```

> The agent tables (`applications`, `data_sources`, `pages`, `documents`) already
> exist in AWS RDS — this API does **not** recreate them. It only creates
> `conversations` and `messages` tables for tracking Q&A history.

---

## Prerequisites

- Python 3.10+
- Access to the **AWS RDS PostgreSQL** instance used by the agents
- AWS credentials with access to Bedrock + S3
- The `AIAgents-LDS` folder present at `../AIAgents-LDS/` relative to `backend/`

---

## Setup

### Step 1 — Navigate to backend folder

```bash
cd bu-digital-llmlds-uwassist-app-main/backend
```

### Step 2 — Create virtual environment

```bash
python -m venv venv

# Activate — Linux/Mac
source venv/bin/activate

# Activate — Windows
venv\Scripts\activate
```

### Step 3 — Install dependencies

```bash
# Backend API dependencies
pip install -r requirements.txt

# Agent dependencies (LangGraph, transformers, etc.)
pip install -r ../AIAgents-LDS/requirements.txt
```

### Step 4 — Configure environment variables

```bash
cp .env.example .env
nano .env      # Linux
notepad .env   # Windows
```

Fill in these values (see [Environment Variables](#environment-variables) below):

| Variable | Description |
|----------|-------------|
| `POSTGRES_HOST` | AWS RDS endpoint (same as agents use) |
| `POSTGRES_DB` | Database name |
| `DB_USERNAME` | RDS username |
| `DB_PASSWORD` | RDS password |
| `AWS_ACCESS_KEY_ID` | AWS access key (leave blank on EKS — IAM role used) |
| `AWS_SECRET_ACCESS_KEY` | AWS secret key |
| `BEDROCK_MODEL_ID` | Claude model CRI / ARN |
| `S3_BUCKET_NAME` | S3 bucket for file uploads |

### Step 5 — PostgreSQL: No separate setup needed

The agents' tables (`applications`, `data_sources`, `pages`, `documents`) are
**already in AWS RDS**. The backend will auto-create only `conversations` and
`messages` tables on first startup.

```
tables auto-created by this API on startup:
  ✓ conversations
  ✓ messages

tables already exist in AWS RDS (managed by agents, not touched):
  - applications
  - data_sources
  - pages
  - documents
```

### Step 6 — Run the server

```bash
# Development (auto-reload on code changes)
uvicorn main:app --reload --host 0.0.0.0 --port 8000

# Production
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

Open Swagger UI: **http://localhost:8000/docs**

---

## Environment Variables

Full `.env` example:

```env
# AWS RDS PostgreSQL (same DB as AIAgents-LDS)
POSTGRES_HOST=dev-db-domainscale-instance-1.cyvm2m48yh8o.us-east-1.rds.amazonaws.com
POSTGRES_PORT=5432
POSTGRES_DB=your_database_name
DB_USERNAME=admin_serverless
DB_PASSWORD=your_rds_password

# AWS (leave blank on EKS — IAM role used automatically)
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
BEDROCK_MODEL_ID=anthropic.claude-3-5-sonnet-20241022-v2:0
S3_BUCKET_NAME=your-s3-bucket

# Agent Flags (must match AIAgents-LDS env)
IS_GENERATING_DATA=false
GENERATING_SUMMARY=false
```

---

## API Reference

### Health Check

#### `GET /health`
```json
{"status": "ok", "version": "1.0.0"}
```

---

### Applications

#### `GET /api/v1/applications`
Returns all application numbers available in the database (same as Streamlit dropdown).

```json
{
  "total": 15,
  "application_numbers": ["9217523", "9217639", "F11248249", "F14612930"]
}
```

#### `GET /api/v1/applications/{application_number}`
Returns application metadata + available data sources.

```json
{
  "application_number": "F11248249",
  "data_sources": ["Part A", "Part B", "Rx", "Lab Tests", "MIB", "MVR"]
}
```

#### `GET /api/v1/applications/{application_number}/data-sources`
Returns just the list of data source names.

```json
["Part A", "Part B", "Rx", "Lab Tests", "MIB", "MVR"]
```

---

### File Upload

#### `POST /api/v1/upload/pdf`
Upload a PDF insurance application to S3.

**Form data:**
| Field | Type | Description |
|-------|------|-------------|
| `application_number` | string | e.g. `F11248249` |
| `file` | file | PDF file |

**Response `202 Accepted`:**
```json
{
  "application_number": "F11248249",
  "s3_key": "applications/F11248249/F11248249.pdf",
  "status": "uploaded",
  "message": "File uploaded to S3 successfully. Pre-processing pipeline will index it shortly."
}
```

#### `POST /api/v1/upload/xml`
Same as PDF but accepts `text/xml` or `application/xml` files.

#### `GET /api/v1/upload/status/{application_number}`
Check if the file exists in S3. For indexing status (embeddings ready), use the data-sources endpoint.

---

### Agent Query

#### `POST /api/v1/query`

Run the full 6-step LangGraph pipeline on an underwriting question.

**Request body:**
```json
{
  "application_number": "F11248249",
  "question": "Does the applicant have any history of diabetes or insulin use?",
  "session_id": null,
  "user_id": "api_user"
}
```

| Field | Required | Description |
|-------|----------|-------------|
| `application_number` | Yes | Must exist in the DB |
| `question` | Yes | Min 3 characters |
| `session_id` | No | Pass existing session to continue conversation; null = new session |
| `user_id` | No | Optional identifier, defaults to `"api_user"` |

**Response `200 OK`:**
```json
{
  "session_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "application_number": "F11248249",
  "question": "Does the applicant have any history of diabetes or insulin use?",
  "thought": "Analyzed Part B, Rx, and Lab Tests. HbA1c is 5.4% (normal range). No insulin or metformin in Rx records. MIB shows no diabetes-related codes...",
  "answer": "Based on available records, the applicant does not have a history of diabetes or insulin use. HbA1c 5.4% (normal), no diabetes medications in Rx, and Part B shows no relevant diagnosis.",
  "confidence_score": "94%",
  "steps_completed": [
    "Intent Classification",
    "Extract Data Sources",
    "Query Processing",
    "Extracting Relevant Text",
    "Relevancy Checker",
    "Reasoning & Refining the answer"
  ],
  "conversation_id": "ff0e8400-e29b-41d4-a716-446655440099"
}
```

**Confidence Score:**
| Score | Colour | Meaning |
|-------|--------|---------|
| ≥ 85% | Green | Strong evidence, reliable answer |
| 70–84% | Orange | Partial evidence, review recommended |
| < 70% | Red | Insufficient data, manual review needed |

**Continue a conversation** — pass `session_id` from previous response:
```json
{
  "application_number": "F11248249",
  "question": "What medications is the applicant currently taking?",
  "session_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}
```

#### `GET /api/v1/query/history/{session_id}`

Get full conversation history for a session.

```json
{
  "session_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "messages": [
    {
      "id": "...",
      "role": "user",
      "content": "Does the applicant have any history of diabetes?",
      "thought": null,
      "confidence_score": null,
      "created_at": "2026-03-19T10:30:00"
    },
    {
      "id": "...",
      "role": "assistant",
      "step": "Chief Reasoning Agent",
      "content": "No history of diabetes found.",
      "thought": "Analyzed Part B, Rx, Lab Tests — all clear.",
      "confidence_score": 0.94,
      "created_at": "2026-03-19T10:30:15"
    }
  ]
}
```

---

## Postman Collection

Import `EXL_LDS_API.postman_collection.json` into Postman.

**Steps:**
1. Postman → Import → select `EXL_LDS_API.postman_collection.json`
2. Set collection variable `base_url` = `http://localhost:8000`
3. Use the **Agent Query** request — fill in `application_number` and `question`
4. The `session_id` is auto-saved from the response for follow-up questions

---

## How the Pipeline Works

```
POST /api/v1/query
        │
        ▼
┌──────────────────────┐
│ 1. Intent            │  → Classify: Underwriting App / General / Unrelated
│    Classification    │    If unrelated → answer immediately, skip rest
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ 2. Extract Data      │  → Query AWS RDS: which data parts exist for this app?
│    Sources           │    (Part A, Part B, Rx, Lab Tests, MIB, MVR, Dx, Other)
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ 3. Query Processing  │  → Break question into sub-queries
│                      │    Map each sub-query → relevant data source
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ 4. Extract Text      │  → Semantic search using BAAI embeddings in AWS RDS
│    from DB           │    Deduplication (SHA-256) + context reduction (sliding window)
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ 5. Relevancy         │  → Filter: keep only truly relevant text chunks
│    Checker           │    Uses Claude via AWS Bedrock
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ 6. Chief Reasoning   │  → Synthesise final answer using credibility weights:
│    Agent             │    Lab Tests > Rx > MVR > MIB > Part B > Part A > Other
│                      │    Output: Thought + Answer + Confidence Score (0–100%)
└──────────────────────┘
```

---

## Common Issues

### `No module named 'agents'`
The backend cannot find `AIAgents-LDS`. Check folder structure:
```
bu-digital-llmlds-uwassist-app-main/
├── AIAgents-LDS/    ← must be here
└── backend/         ← you are here
```

### `could not connect to server` (PostgreSQL)
Check your `.env` — `POSTGRES_HOST` must point to the AWS RDS endpoint.
Test connection:
```bash
psql -h $POSTGRES_HOST -U $DB_USERNAME -d $POSTGRES_DB -c "SELECT 1"
```

### `NoneType object is not subscriptable`
The application exists in the database but the `applications` or `data_sources`
table has no data for that application number. The application needs to be
pre-processed first (text extracted + embeddings generated).

### Agent takes long time (60–120 seconds)
This is normal. The pipeline does 6 LLM calls + vector search. First call also
loads heavy ML models into memory. Subsequent calls are faster.
