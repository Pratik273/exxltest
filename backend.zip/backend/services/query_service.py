"""
Query service — bridges FastAPI routes to the LangGraph multi-agent pipeline.

The POC agent code lives at:
  bu-digital-llmlds-uwassist-app-main/AIAgents-LDS/

We import those agents directly so NO agent logic needs to be rewritten.
Blocking LangGraph calls are offloaded to a thread-pool executor so they
don't block the FastAPI async event loop.

Path layout:
  backend/services/query_service.py  (this file)
  AIAgents-LDS/agents/workflow.py    (imported via sys.path patch below)
"""
import asyncio
import sys
import uuid
from pathlib import Path
from typing import Optional

from loguru import logger
from sqlalchemy.orm import Session

from core.exceptions import AppException, NotFoundError
from db.schema import Conversation, Message
from fastapi import status

# ── Patch sys.path so we can import the original AIAgents-LDS code ──────────
# Path calculation:
#   __file__ → backend/services/query_service.py
#   parent   → backend/services/
#   parent.parent → backend/
#   parent.parent.parent → bu-digital-llmlds-uwassist-app-main/
#   / "AIAgents-LDS" → bu-digital-llmlds-uwassist-app-main/AIAgents-LDS/
_POC_ROOT = Path(__file__).resolve().parent.parent.parent / "AIAgents-LDS"
if str(_POC_ROOT) not in sys.path:
    sys.path.insert(0, str(_POC_ROOT))


def _run_agent(
    application_number: str,
    question: str,
    session_id: str,
    user_id: str = "api_user",
) -> dict:
    """
    Synchronous wrapper around the LangGraph workflow.
    Runs inside run_in_executor() so the async event loop stays free.

    Returns: dict with thought, answer, confidence_score, steps_completed
    """
    # Lazy import — avoids loading heavy ML models at server startup
    from agents.workflow import graph      # noqa: PLC0415
    from agents.state import AgentState   # noqa: PLC0415

    initial_state = AgentState(
        messages=[],
        input_message=question,
        application_number=application_number,
        session_id=session_id,
        user_id=user_id,
        available_data_sources=[],
        interim_response=None,
        current_step="start",
        steps_completed=[],
        ai_thought=None,
        ai_response=None,
        confidence_score=None,
        conversation_id="",
        demographics_summary="",
        medical_summary="",
        overall_summary="",
    )

    result = graph.invoke(initial_state)

    return {
        "thought": result.ai_thought,
        "answer": result.ai_response,
        "confidence_score": result.confidence_score,
        "steps_completed": result.steps_completed or [],
        "conversation_id": result.conversation_id or "",
    }


class QueryService:
    def __init__(self, db: Session):
        self.db = db

    # ── Internal DB helpers ───────────────────────────────────────────────────

    def _get_or_create_conversation(
        self, session_id: str, application_number: str
    ) -> Conversation:
        conv = (
            self.db.query(Conversation)
            .filter(Conversation.session_id == session_id)
            .first()
        )
        if not conv:
            conv = Conversation(
                session_id=session_id,
                application_number=application_number,
            )
            self.db.add(conv)
            self.db.commit()
            self.db.refresh(conv)
        return conv

    def _add_message(
        self,
        conversation_id,
        role: str,
        content: str,
        step: Optional[str] = None,
        thought: Optional[str] = None,
        confidence_score: Optional[float] = None,
    ) -> None:
        msg = Message(
            conversation_id=conversation_id,
            role=role,
            content=content,
            step=step,
            thought=thought,
            confidence_score=confidence_score,
        )
        self.db.add(msg)
        self.db.commit()

    # ── Public methods ────────────────────────────────────────────────────────

    async def run_query(
        self,
        application_number: str,
        question: str,
        session_id: Optional[str],
        user_id: str = "api_user",
    ) -> dict:
        if not session_id:
            session_id = str(uuid.uuid4())

        conv = self._get_or_create_conversation(session_id, application_number)
        self._add_message(conv.id, role="user", content=question)

        logger.info(f"Agent query: app={application_number} session={session_id}")

        try:
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                _run_agent,
                application_number,
                question,
                session_id,
                user_id,
            )
        except Exception as exc:
            logger.error(f"Agent execution failed: {exc}")
            raise AppException(
                status.HTTP_500_INTERNAL_SERVER_ERROR, f"Agent error: {exc}"
            )

        # Convert confidence score to float for DB storage
        confidence_float = None
        if result.get("confidence_score"):
            try:
                confidence_float = (
                    float(str(result["confidence_score"]).replace("%", "")) / 100
                )
            except (ValueError, AttributeError):
                pass

        self._add_message(
            conv.id,
            role="assistant",
            content=result.get("answer") or "",
            step="Chief Reasoning Agent",
            thought=result.get("thought"),
            confidence_score=confidence_float,
        )

        return {
            "session_id": session_id,
            "application_number": application_number,
            "question": question,
            "thought": result.get("thought"),
            "answer": result.get("answer"),
            "confidence_score": result.get("confidence_score"),
            "steps_completed": result.get("steps_completed", []),
            "conversation_id": str(conv.id),
        }

    def get_history(self, session_id: str) -> dict:
        conv = (
            self.db.query(Conversation)
            .filter(Conversation.session_id == session_id)
            .first()
        )
        if not conv:
            raise NotFoundError(f"Session '{session_id}'")
        return {"session_id": session_id, "messages": conv.messages}
