"""
File Upload routes.

POST /api/v1/upload/pdf             — Upload PDF application to S3
POST /api/v1/upload/xml             — Upload XML application to S3
GET  /api/v1/upload/status/{app_no} — Check S3 upload status
"""
import io

import boto3
from botocore.exceptions import ClientError
from fastapi import APIRouter, File, Form, UploadFile, status
from loguru import logger

from config import settings
from core.exceptions import AppException

router = APIRouter()

ALLOWED_TYPES = {
    "application/pdf": "PDF",
    "text/xml": "XML",
    "application/xml": "XML",
}


def _get_s3_client():
    return boto3.client(
        "s3",
        region_name=settings.AWS_REGION,
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID or None,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY or None,
    )


async def _upload_to_s3(
    application_number: str,
    file: UploadFile,
    expected_type: str,
) -> dict:
    content_type = file.content_type or ""
    app_type = ALLOWED_TYPES.get(content_type)
    if not app_type or app_type != expected_type:
        raise AppException(
            status.HTTP_400_BAD_REQUEST,
            f"Invalid file type '{content_type}'. Expected {expected_type}.",
        )

    filename = file.filename or f"{application_number}.{expected_type.lower()}"
    s3_key = f"applications/{application_number}/{filename}"

    try:
        file_bytes = await file.read()
        s3 = _get_s3_client()
        s3.upload_fileobj(
            io.BytesIO(file_bytes),
            settings.S3_BUCKET_NAME,
            s3_key,
            ExtraArgs={"ContentType": content_type},
        )
        logger.info(f"Uploaded {filename} → s3://{settings.S3_BUCKET_NAME}/{s3_key}")
    except ClientError as exc:
        logger.error(f"S3 upload failed: {exc}")
        raise AppException(status.HTTP_502_BAD_GATEWAY, "Failed to upload file to S3")

    return {
        "application_number": application_number,
        "s3_key": s3_key,
        "status": "uploaded",
        "message": (
            "File uploaded to S3 successfully. "
            "The pre-processing pipeline will extract text and embeddings shortly. "
            f"Poll GET /api/v1/applications/{application_number}/data-sources to check readiness."
        ),
    }


@router.post(
    "/pdf",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Upload PDF insurance application to S3",
)
async def upload_pdf(
    application_number: str = Form(..., description="Unique application ID e.g. F11248249"),
    file: UploadFile = File(..., description="PDF file of the insurance application"),
):
    """
    Upload a PDF application to S3.

    **What happens:**
    1. Validates the file is a PDF (by Content-Type header)
    2. Uploads to S3 at `applications/{application_number}/{filename}`
    3. The pre-processing pipeline (separate service) will then:
       - Extract text from each page
       - Generate BAAI embeddings
       - Store pages + data_sources in AWS RDS

    **Poll** `GET /api/v1/applications/{application_number}/data-sources` to know
    when the application is ready for querying.
    """
    return await _upload_to_s3(application_number, file, "PDF")


@router.post(
    "/xml",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Upload XML insurance application to S3",
)
async def upload_xml(
    application_number: str = Form(..., description="Unique application ID"),
    file: UploadFile = File(..., description="XML file of the insurance application"),
):
    """
    Upload an XML application to S3.

    Same flow as PDF upload but accepts `text/xml` or `application/xml`.
    """
    return await _upload_to_s3(application_number, file, "XML")


@router.get(
    "/status/{application_number}",
    summary="Check if an application is ready for querying",
)
def get_upload_status(application_number: str):
    """
    Quick status check — tells you whether the application exists in S3.

    For full readiness (text extracted + embeddings generated), use:
    `GET /api/v1/applications/{application_number}/data-sources`
    """
    if not settings.S3_BUCKET_NAME:
        return {
            "application_number": application_number,
            "status": "unknown",
            "message": "S3_BUCKET_NAME not configured",
        }

    try:
        s3 = _get_s3_client()
        prefix = f"applications/{application_number}/"
        resp = s3.list_objects_v2(Bucket=settings.S3_BUCKET_NAME, Prefix=prefix, MaxKeys=1)
        exists = resp.get("KeyCount", 0) > 0
        return {
            "application_number": application_number,
            "status": "uploaded" if exists else "not_found",
            "message": (
                "File exists in S3. Check /api/v1/applications/{}/data-sources for indexing status."
                .format(application_number)
                if exists
                else "No files found in S3 for this application number."
            ),
        }
    except ClientError as exc:
        raise AppException(status.HTTP_502_BAD_GATEWAY, f"S3 check failed: {exc}")
