"""
Applications routes.

GET /api/v1/applications                            — List all application numbers
GET /api/v1/applications/{application_number}       — Get application details
GET /api/v1/applications/{application_number}/data-sources — Available data sources
"""
from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from core.dependencies import get_db
from core.exceptions import NotFoundError

router = APIRouter()


@router.get(
    "",
    summary="List all application numbers",
)
def list_applications(db: Session = Depends(get_db)):
    """
    Returns all application numbers that exist in the AWS RDS database.

    These are the same values shown in the Streamlit dropdown sidebar.
    Applications are only listed once they have been pre-processed and indexed.
    """
    try:
        result = db.execute(
            text("SELECT DISTINCT application_number FROM applications ORDER BY application_number")
        )
        app_numbers = [row[0] for row in result.fetchall()]
        return {"total": len(app_numbers), "application_numbers": app_numbers}
    except Exception as exc:
        return {"total": 0, "application_numbers": [], "error": str(exc)}


@router.get(
    "/{application_number}",
    summary="Get application details",
)
def get_application(application_number: str, db: Session = Depends(get_db)):
    """
    Returns metadata for a single application including its available data sources.

    Raises 404 if the application number does not exist in the database.
    """
    try:
        result = db.execute(
            text("SELECT id, application_number FROM applications WHERE application_number = :num"),
            {"num": application_number},
        )
        row = result.fetchone()
    except Exception as exc:
        raise NotFoundError(f"Application '{application_number}' (DB error: {exc})")

    if not row:
        raise NotFoundError(f"Application '{application_number}'")

    app_id = row[0]

    # Fetch data sources
    try:
        ds_result = db.execute(
            text(
                "SELECT name FROM data_sources "
                "WHERE application_id = :app_id AND is_available = true"
            ),
            {"app_id": str(app_id)},
        )
        data_sources = [r[0] for r in ds_result.fetchall()]
    except Exception:
        data_sources = []

    return {
        "application_number": application_number,
        "data_sources": data_sources,
    }


@router.get(
    "/{application_number}/data-sources",
    response_model=list[str],
    summary="List available data sources for an application",
)
def get_data_sources(application_number: str, db: Session = Depends(get_db)):
    """
    Returns the list of indexed data source names for an application.

    Example response: `["Part A", "Part B", "Rx", "Lab Tests", "MIB", "MVR"]`

    These are the data parts the agents will search when you run a query.
    """
    try:
        result = db.execute(
            text(
                "SELECT ds.name FROM data_sources ds "
                "JOIN applications a ON ds.application_id = a.id "
                "WHERE a.application_number = :num AND ds.is_available = true"
            ),
            {"num": application_number},
        )
        sources = [row[0] for row in result.fetchall()]
    except Exception as exc:
        return []

    if not sources:
        raise NotFoundError(f"Application '{application_number}'")

    return sources
