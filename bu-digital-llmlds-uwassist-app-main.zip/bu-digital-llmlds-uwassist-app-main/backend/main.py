"""
FastAPI application entry point.

Run locally:
    uvicorn main:app --reload --host 0.0.0.0 --port 8000

Swagger UI:  http://localhost:8000/docs
ReDoc:       http://localhost:8000/redoc
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from config import settings
from core.exceptions import register_exception_handlers
from core.middleware import LoggingMiddleware
from db.connection import engine
from db.schema import Base

# ── routers ─────────────────────────────────────────────────────────────────
from api.v1 import auth, upload, applications, query


# ── lifespan (startup / shutdown) ────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Create all tables on first boot (idempotent — safe to run every restart)
    Base.metadata.create_all(bind=engine)
    yield
    engine.dispose()


# ── app factory ──────────────────────────────────────────────────────────────
app = FastAPI(
    title=settings.API_TITLE,
    version=settings.API_VERSION,
    description=(
        "EXL Domain Scale.ai — Life Insurance Underwriting LLM backend.\n\n"
        "Provides PDF/XML ingestion, JWT authentication, agent query execution, "
        "and application management endpoints."
    ),
    lifespan=lifespan,
)

# ── middleware ────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(LoggingMiddleware)

# ── exception handlers ────────────────────────────────────────────────────────
register_exception_handlers(app)

# ── routers ───────────────────────────────────────────────────────────────────
app.include_router(auth.router,         prefix="/api/v1/auth",         tags=["Authentication"])
app.include_router(upload.router,       prefix="/api/v1/upload",       tags=["File Upload"])
app.include_router(applications.router, prefix="/api/v1/applications", tags=["Applications"])
app.include_router(query.router,        prefix="/api/v1/query",        tags=["Agent Query"])


# ── health check ──────────────────────────────────────────────────────────────
@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok", "version": settings.API_VERSION}
