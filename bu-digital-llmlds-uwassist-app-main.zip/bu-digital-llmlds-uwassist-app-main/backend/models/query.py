"""
Pydantic schemas for Agent Query endpoint.
"""
from typing import List, Optional
from pydantic import BaseModel, Field


# ── Request ──────────────────────────────────────────────────────────────────

class QueryRequest(BaseModel):
    application_number: str = Field(..., description="Application to query against")
    question: str = Field(..., min_length=3, description="Underwriting question")
    session_id: Optional[str] = Field(None, description="Pass existing session to continue conversation")


# ── Response ─────────────────────────────────────────────────────────────────

class StepUpdate(BaseModel):
    step: str
    status: str    # completed | in_progress | failed


class QueryResponse(BaseModel):
    session_id: str
    application_number: str
    question: str
    thought: Optional[str]
    answer: Optional[str]
    confidence_score: Optional[str]      # e.g. "92%"
    steps_completed: List[str]
    conversation_id: Optional[str]


class MessageSchema(BaseModel):
    id: str
    role: str
    step: Optional[str]
    content: str
    thought: Optional[str]
    confidence_score: Optional[float]
    created_at: str

    model_config = {"from_attributes": True}


class ConversationHistoryResponse(BaseModel):
    session_id: str
    messages: List[MessageSchema]
