"""
Pydantic schemas for Authentication endpoints.
"""
from pydantic import BaseModel, EmailStr, Field


# ── Requests ─────────────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=100)
    email: EmailStr
    password: str = Field(..., min_length=8)


class LoginRequest(BaseModel):
    username: str
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


# ── Responses ────────────────────────────────────────────────────────────────

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int          # seconds until access token expires


class UserResponse(BaseModel):
    id: str
    username: str
    email: str
    is_admin: bool

    model_config = {"from_attributes": True}
