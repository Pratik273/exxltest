"""
Pydantic schemas for File Upload endpoints.
"""
from typing import Optional
from pydantic import BaseModel, Field


# ── Requests ─────────────────────────────────────────────────────────────────

class UploadInitRequest(BaseModel):
    """Optional metadata sent alongside the file."""
    application_number: str = Field(..., description="Unique application ID e.g. F11248249")
    application_type: str = Field("PDF", pattern="^(PDF|XML)$")


# ── Responses ────────────────────────────────────────────────────────────────

class UploadResponse(BaseModel):
    application_id: str
    application_number: str
    s3_key: str
    status: str
    message: str


class ProcessingStatusResponse(BaseModel):
    application_id: str
    application_number: str
    status: str           # pending | processing | ready | failed
    data_sources: list[str]
