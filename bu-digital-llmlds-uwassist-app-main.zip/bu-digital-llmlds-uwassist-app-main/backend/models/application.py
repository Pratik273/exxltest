"""
Pydantic schemas for Application endpoints.
"""
from typing import List, Optional
from pydantic import BaseModel


class DataSourceSchema(BaseModel):
    id: str
    name: str
    is_available: bool

    model_config = {"from_attributes": True}


class ApplicationSchema(BaseModel):
    id: str
    application_number: str
    status: str
    application_type: str
    s3_key: Optional[str]
    data_sources: List[DataSourceSchema] = []

    model_config = {"from_attributes": True}


class ApplicationListResponse(BaseModel):
    total: int
    applications: List[ApplicationSchema]
