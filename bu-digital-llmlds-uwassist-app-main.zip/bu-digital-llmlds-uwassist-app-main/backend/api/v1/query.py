"""
Agent Query routes.

POST /api/v1/query                       – Run LangGraph agent on a question
GET  /api/v1/query/history/{session_id}  – Fetch conversation history
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from core.dependencies import get_current_user, get_db
from db.schema import User
from models.query import ConversationHistoryResponse, MessageSchema, QueryRequest, QueryResponse
from services.query_service import QueryService

router = APIRouter()


@router.post(
    "",
    response_model=QueryResponse,
    summary="Ask a question about an insurance application",
)
async def run_query(
    payload: QueryRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Execute the full multi-agent LangGraph pipeline for an underwriting question.

    **Pipeline steps** (in order):
    1. Intent Classification — validates the query is application-specific
    2. Extract Data Sources — checks which data parts exist for this application
    3. Query Processing — breaks query into sub-queries mapped to data sources
    4. Extract Text from DB — semantic retrieval + deduplication + context reduction
    5. Relevancy Checker — filters to the most relevant chunks
    6. Chief Reasoning Agent — synthesises answer with confidence score

    **Response includes:**
    - `answer` — final underwriting answer
    - `thought` — Claude's reasoning chain
    - `confidence_score` — e.g. `"92%"` (green ≥85%, orange ≥70%, red <70%)
    - `steps_completed` — ordered list of completed pipeline steps
    - `session_id` — use in next request to continue the conversation
    """
    service = QueryService(db)
    result = await service.run_query(
        application_number=payload.application_number,
        question=payload.question,
        session_id=payload.session_id,
        user_id=str(current_user.id),
    )
    return QueryResponse(**result)


@router.get(
    "/history/{session_id}",
    response_model=ConversationHistoryResponse,
    summary="Get conversation history for a session",
)
def get_history(
    session_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Returns all messages (user + assistant) for an existing session.

    Messages are ordered chronologically and include:
    - `role` — `user` or `assistant`
    - `content` — the question or answer text
    - `thought` — Claude's reasoning (assistant messages only)
    - `confidence_score` — float 0–1 (assistant messages only)
    - `step` — agent step name (e.g. `"Chief Reasoning Agent"`)
    """
    service = QueryService(db)
    history = service.get_history(session_id)
    messages = [
        MessageSchema(
            id=str(m.id),
            role=m.role,
            step=m.step,
            content=m.content,
            thought=m.thought,
            confidence_score=m.confidence_score,
            created_at=m.created_at.isoformat(),
        )
        for m in history["messages"]
    ]
    return ConversationHistoryResponse(session_id=session_id, messages=messages)
