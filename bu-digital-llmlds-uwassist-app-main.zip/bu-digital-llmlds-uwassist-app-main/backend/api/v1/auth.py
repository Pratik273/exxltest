"""
Authentication routes.

POST /api/v1/auth/register   – Create a new user account
POST /api/v1/auth/login      – Exchange credentials for JWT tokens
POST /api/v1/auth/refresh    – Get a new access token using refresh token
GET  /api/v1/auth/me         – Return current authenticated user info
"""
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from core.dependencies import get_current_user, get_db
from db.schema import User
from models.auth import LoginRequest, RefreshRequest, RegisterRequest, TokenResponse, UserResponse
from services.auth_service import AuthService

router = APIRouter()


@router.post(
    "/register",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register a new user",
)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    """
    Create a new user account.

    - **username**: 3–100 chars, must be unique
    - **email**: valid email, must be unique
    - **password**: minimum 8 characters (stored as bcrypt hash)
    """
    user = AuthService(db).register(
        username=payload.username,
        email=payload.email,
        password=payload.password,
    )
    return UserResponse(
        id=str(user.id),
        username=user.username,
        email=user.email,
        is_admin=user.is_admin,
    )


@router.post(
    "/login",
    response_model=TokenResponse,
    summary="Login and receive JWT tokens",
)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    """
    Authenticate with username + password.

    Returns:
    - **access_token**: short-lived JWT (60 min default), use in `Authorization: Bearer <token>`
    - **refresh_token**: long-lived JWT (7 days), use to get a new access token
    """
    tokens = AuthService(db).login(payload.username, payload.password)
    return TokenResponse(**tokens)


@router.post(
    "/refresh",
    response_model=TokenResponse,
    summary="Refresh access token",
)
def refresh(payload: RefreshRequest, db: Session = Depends(get_db)):
    """
    Exchange a valid refresh token for a new access + refresh token pair.
    Old refresh token is invalidated after use (rotation).
    """
    tokens = AuthService(db).refresh(payload.refresh_token)
    return TokenResponse(**tokens)


@router.get(
    "/me",
    response_model=UserResponse,
    summary="Get current user",
)
def me(current_user: User = Depends(get_current_user)):
    """Return the profile of the currently authenticated user."""
    return UserResponse(
        id=str(current_user.id),
        username=current_user.username,
        email=current_user.email,
        is_admin=current_user.is_admin,
    )
