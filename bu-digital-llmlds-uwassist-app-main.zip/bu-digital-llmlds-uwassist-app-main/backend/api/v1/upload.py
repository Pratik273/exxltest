"""
File Upload routes.

POST /api/v1/upload/pdf              – Upload a PDF application to S3
POST /api/v1/upload/xml              – Upload an XML application to S3
GET  /api/v1/upload/status/{app_no}  – Poll processing status
"""
from fastapi import APIRouter, Depends, File, Form, UploadFile, status
from sqlalchemy.orm import Session

from core.dependencies import get_current_user, get_db
from db.schema import Application, User
from models.upload import ProcessingStatusResponse, UploadResponse
from services.upload_service import UploadService

router = APIRouter()


def _build_upload_response(app: Application) -> UploadResponse:
    return UploadResponse(
        application_id=str(app.id),
        application_number=app.application_number,
        s3_key=app.s3_key or "",
        status=app.status,
        message=(
            "File uploaded successfully. Pre-processing has been queued."
            if app.status == "pending"
            else f"Application already exists with status '{app.status}'"
        ),
    )


@router.post(
    "/pdf",
    response_model=UploadResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Upload a PDF insurance application",
)
async def upload_pdf(
    application_number: str = Form(..., description="Unique application ID, e.g. F11248249"),
    file: UploadFile = File(..., description="PDF file of the insurance application"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Upload a PDF application file to S3.

    - Validates the file is a PDF (by content-type).
    - Stores the file at `applications/{application_number}/{filename}` in S3.
    - Creates an `Application` record in PostgreSQL with status `pending`.
    - Pre-processing (page extraction, embedding generation) is triggered asynchronously.

    **Poll** `/api/v1/upload/status/{application_number}` for processing progress.
    """
    service = UploadService(db)
    app = service.upload_file(
        file_obj=file.file,
        filename=file.filename or f"{application_number}.pdf",
        content_type=file.content_type or "application/pdf",
        application_number=application_number,
    )
    return _build_upload_response(app)


@router.post(
    "/xml",
    response_model=UploadResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Upload an XML insurance application",
)
async def upload_xml(
    application_number: str = Form(..., description="Unique application ID"),
    file: UploadFile = File(..., description="XML file of the insurance application"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Upload an XML application file to S3.

    Same flow as PDF upload but accepts `text/xml` or `application/xml`.
    """
    service = UploadService(db)
    app = service.upload_file(
        file_obj=file.file,
        filename=file.filename or f"{application_number}.xml",
        content_type=file.content_type or "application/xml",
        application_number=application_number,
    )
    return _build_upload_response(app)


@router.get(
    "/status/{application_number}",
    response_model=ProcessingStatusResponse,
    summary="Get application processing status",
)
def get_upload_status(
    application_number: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Poll the processing status of an uploaded application.

    **Status values:**
    - `pending`    — uploaded, waiting for pre-processor
    - `processing` — pre-processor is extracting text / embeddings
    - `ready`      — all data extracted, agents can query
    - `failed`     — pre-processing failed (check logs)
    """
    service = UploadService(db)
    app = service.get_status(application_number)
    data_sources = [ds.name for ds in app.data_sources if ds.is_available]

    return ProcessingStatusResponse(
        application_id=str(app.id),
        application_number=app.application_number,
        status=app.status,
        data_sources=data_sources,
    )
