"""
Application management routes.

GET  /api/v1/applications                       – List all applications
GET  /api/v1/applications/{application_number}  – Get single application details
GET  /api/v1/applications/{application_number}/data-sources  – List available data sources
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from core.dependencies import get_current_user, get_db
from db.schema import User
from models.application import ApplicationListResponse, ApplicationSchema, DataSourceSchema
from services.application_service import ApplicationService

router = APIRouter()


@router.get(
    "",
    response_model=ApplicationListResponse,
    summary="List all applications",
)
def list_applications(
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(50, ge=1, le=200, description="Max records to return"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Returns a paginated list of all registered insurance applications.

    Each application includes:
    - `id`, `application_number`, `status`, `application_type`
    - `data_sources` — which data parts are available (Part A, Rx, Lab Tests, etc.)
    """
    service = ApplicationService(db)
    total, apps = service.list_applications(skip=skip, limit=limit)

    return ApplicationListResponse(
        total=total,
        applications=[
            ApplicationSchema(
                id=str(a.id),
                application_number=a.application_number,
                status=a.status,
                application_type=a.application_type,
                s3_key=a.s3_key,
                data_sources=[
                    DataSourceSchema(id=str(ds.id), name=ds.name, is_available=ds.is_available)
                    for ds in a.data_sources
                ],
            )
            for a in apps
        ],
    )


@router.get(
    "/{application_number}",
    response_model=ApplicationSchema,
    summary="Get application by number",
)
def get_application(
    application_number: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Retrieve full details for a single application.

    Returns 404 if the `application_number` does not exist.
    """
    app = ApplicationService(db).get_application(application_number)
    return ApplicationSchema(
        id=str(app.id),
        application_number=app.application_number,
        status=app.status,
        application_type=app.application_type,
        s3_key=app.s3_key,
        data_sources=[
            DataSourceSchema(id=str(ds.id), name=ds.name, is_available=ds.is_available)
            for ds in app.data_sources
        ],
    )


@router.get(
    "/{application_number}/data-sources",
    response_model=list[str],
    summary="List available data sources for an application",
)
def get_data_sources(
    application_number: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Returns the list of data source names that have been extracted and indexed
    for the given application.

    Example: `["Part A", "Part B", "Rx", "Lab Tests", "MIB"]`
    """
    return ApplicationService(db).get_data_sources(application_number)
