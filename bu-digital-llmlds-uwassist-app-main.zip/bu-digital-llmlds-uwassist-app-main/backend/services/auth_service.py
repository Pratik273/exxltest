"""
Authentication service — register, login, refresh.
"""
from sqlalchemy.orm import Session

from core.exceptions import ConflictError, AppException
from core.security import (
    hash_password, verify_password,
    create_access_token, create_refresh_token, decode_token,
)
from config import settings
from db.repositories.user_repo import UserRepository
from db.schema import User
from fastapi import status


class AuthService:
    def __init__(self, db: Session):
        self.repo = UserRepository(db)

    def register(self, username: str, email: str, password: str) -> User:
        if self.repo.get_by_username(username):
            raise ConflictError(f"Username '{username}' already taken")
        if self.repo.get_by_email(email):
            raise ConflictError(f"Email '{email}' already registered")

        return self.repo.create(
            username=username,
            email=email,
            hashed_password=hash_password(password),
        )

    def login(self, username: str, password: str) -> dict:
        user = self.repo.get_by_username(username)
        if not user or not verify_password(password, user.hashed_password):
            raise AppException(status.HTTP_401_UNAUTHORIZED, "Invalid credentials")
        if not user.is_active:
            raise AppException(status.HTTP_403_FORBIDDEN, "Account is inactive")

        return {
            "access_token": create_access_token(user.id, user.username),
            "refresh_token": create_refresh_token(user.id),
            "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        }

    def refresh(self, refresh_token: str) -> dict:
        payload = decode_token(refresh_token)
        if not payload or payload.get("type") != "refresh":
            raise AppException(status.HTTP_401_UNAUTHORIZED, "Invalid refresh token")

        user = self.repo.get_by_id(payload["sub"])
        if not user or not user.is_active:
            raise AppException(status.HTTP_401_UNAUTHORIZED, "User not found")

        return {
            "access_token": create_access_token(user.id, user.username),
            "refresh_token": create_refresh_token(user.id),
            "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        }
