"""
Application service — list, get, data-source management.
"""
from typing import List
from uuid import UUID

from sqlalchemy.orm import Session

from core.exceptions import NotFoundError
from db.repositories.application_repo import ApplicationRepository
from db.schema import Application


class ApplicationService:
    def __init__(self, db: Session):
        self.repo = ApplicationRepository(db)

    def list_applications(self, skip: int = 0, limit: int = 50) -> tuple[int, List[Application]]:
        apps = self.repo.list_all(skip=skip, limit=limit)
        # Return total count + page for the response model
        total = len(self.repo.list_all(skip=0, limit=9999))  # simple total
        return total, apps

    def get_application(self, application_number: str) -> Application:
        app = self.repo.get_by_number(application_number)
        if not app:
            raise NotFoundError(f"Application '{application_number}'")
        return app

    def get_data_sources(self, application_number: str) -> List[str]:
        app = self.get_application(application_number)
        sources = self.repo.get_data_sources(app.id)
        return [s.name for s in sources]
