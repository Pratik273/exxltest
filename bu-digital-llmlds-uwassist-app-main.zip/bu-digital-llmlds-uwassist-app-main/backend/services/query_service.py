"""
Query service — bridges FastAPI routes to the existing POC LangGraph agents.

The POC agent code lives in the original repo:
  bu-digital-llmlds-uwassist-app-main/AIAgents-LDS/

We import those agents directly so NO agent code needs to be rewritten.
Heavy CPU/blocking calls are offloaded to a thread-pool via run_in_executor
so they don't block the FastAPI event loop.

Directory layout (add both to PYTHONPATH or install as packages):
  sys.path is patched at the bottom of this file for convenience.
"""
import asyncio
import sys
import uuid
from pathlib import Path

from loguru import logger
from sqlalchemy.orm import Session

from config import settings
from core.exceptions import AppException, NotFoundError
from db.repositories.application_repo import ApplicationRepository
from db.repositories.conversation_repo import ConversationRepository
from fastapi import status

# ── Patch sys.path so we can import the original POC agent code ───────────────
_POC_ROOT = Path(__file__).resolve().parent.parent.parent / \
    "bu-digital-llmlds-uwassist-app-main" / "AIAgents-LDS"
if str(_POC_ROOT) not in sys.path:
    sys.path.insert(0, str(_POC_ROOT))


def _run_agent(application_number: str, question: str, session_id: str, user_id: str) -> dict:
    """
    Synchronous wrapper around the POC LangGraph workflow.
    Runs inside a thread-pool executor so the event loop stays free.

    Returns a dict with: thought, answer, confidence_score, steps_completed
    """
    # Lazy import — avoids loading heavy ML models at startup
    from agents.workflow import graph          # noqa: PLC0415
    from agents.state import AgentState        # noqa: PLC0415

    initial_state = AgentState(
        messages=[],
        input_message=question,
        application_number=application_number,
        session_id=session_id,
        user_id=user_id,
        available_data_sources=[],
        interim_response=None,
        current_step="start",
        steps_completed=[],
        ai_thought=None,
        ai_response=None,
        confidence_score=None,
        conversation_id="",
        demographics_summary="",
        medical_summary="",
        overall_summary="",
    )

    result: AgentState = graph.invoke(initial_state)

    return {
        "thought": result.ai_thought,
        "answer": result.ai_response,
        "confidence_score": result.confidence_score,
        "steps_completed": result.steps_completed,
        "conversation_id": result.conversation_id,
    }


class QueryService:
    def __init__(self, db: Session):
        self.db = db
        self.app_repo = ApplicationRepository(db)
        self.conv_repo = ConversationRepository(db)

    async def run_query(
        self,
        application_number: str,
        question: str,
        session_id: str | None,
        user_id: str,
    ) -> dict:
        # ── Validate application exists and is ready ──────────────────────────
        app = self.app_repo.get_by_number(application_number)
        if not app:
            raise NotFoundError(f"Application '{application_number}'")
        if app.status != "ready":
            raise AppException(
                status.HTTP_422_UNPROCESSABLE_ENTITY,
                f"Application '{application_number}' is not ready (status: {app.status}). "
                "Wait for pre-processing to complete.",
            )

        if not session_id:
            session_id = str(uuid.uuid4())

        # ── Ensure conversation exists in DB ──────────────────────────────────
        conv = self.conv_repo.get_or_create(
            session_id=session_id,
            application_id=app.id,
        )

        # ── Store the user question ───────────────────────────────────────────
        self.conv_repo.add_message(
            conversation_id=conv.id,
            role="user",
            content=question,
        )

        # ── Run agent in thread pool (blocking LangGraph call) ────────────────
        logger.info(f"Running agent for app={application_number} session={session_id}")
        try:
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                _run_agent,
                application_number,
                question,
                session_id,
                user_id,
            )
        except Exception as exc:
            logger.error(f"Agent execution failed: {exc}")
            raise AppException(status.HTTP_500_INTERNAL_SERVER_ERROR, f"Agent error: {exc}")

        # ── Persist agent response ────────────────────────────────────────────
        confidence_float = None
        if result["confidence_score"]:
            try:
                confidence_float = float(result["confidence_score"].replace("%", "")) / 100
            except (ValueError, AttributeError):
                pass

        self.conv_repo.add_message(
            conversation_id=conv.id,
            role="assistant",
            content=result["answer"] or "",
            step="Chief Reasoning Agent",
            thought=result["thought"],
            confidence_score=confidence_float,
        )

        return {
            "session_id": session_id,
            "application_number": application_number,
            "question": question,
            "thought": result["thought"],
            "answer": result["answer"],
            "confidence_score": result["confidence_score"],
            "steps_completed": result["steps_completed"],
            "conversation_id": str(conv.id),
        }

    def get_history(self, session_id: str) -> dict:
        conv = self.conv_repo.get_by_session(session_id)
        if not conv:
            raise NotFoundError(f"Session '{session_id}'")
        messages = self.conv_repo.get_messages(conv.id)
        return {"session_id": session_id, "messages": messages}
