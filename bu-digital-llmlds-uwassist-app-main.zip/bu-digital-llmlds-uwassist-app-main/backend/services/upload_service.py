"""
Upload service — streams file to S3 then registers the application in PostgreSQL.

Flow:
    1. Validate file type (PDF or XML).
    2. Upload to S3 under  applications/{app_number}/{filename}.
    3. Create (or return existing) Application record in DB.
    4. Return metadata — the pre-processing job is triggered separately
       (e.g. via Celery / Lambda SNS trigger from S3 event).
"""
import io
from typing import BinaryIO

import boto3
from botocore.exceptions import ClientError
from loguru import logger
from sqlalchemy.orm import Session

from config import settings
from core.exceptions import AppException, ConflictError
from db.repositories.application_repo import ApplicationRepository
from db.schema import Application
from fastapi import status


ALLOWED_CONTENT_TYPES = {
    "application/pdf": "PDF",
    "text/xml": "XML",
    "application/xml": "XML",
}


class UploadService:
    def __init__(self, db: Session):
        self.repo = ApplicationRepository(db)
        self._s3 = None   # lazy init — avoids error if AWS creds not configured locally

    @property
    def s3(self):
        if self._s3 is None:
            self._s3 = boto3.client(
                "s3",
                region_name=settings.AWS_REGION,
                aws_access_key_id=settings.AWS_ACCESS_KEY_ID or None,
                aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY or None,
            )
        return self._s3

    def upload_file(
        self,
        file_obj: BinaryIO,
        filename: str,
        content_type: str,
        application_number: str,
    ) -> Application:
        # ── Validate file type ────────────────────────────────────────────────
        app_type = ALLOWED_CONTENT_TYPES.get(content_type)
        if not app_type:
            raise AppException(
                status.HTTP_400_BAD_REQUEST,
                f"Unsupported file type '{content_type}'. Must be PDF or XML.",
            )

        # ── Check for duplicate ──────────────────────────────────────────────
        existing = self.repo.get_by_number(application_number)
        if existing and existing.status not in ("failed",):
            raise ConflictError(
                f"Application '{application_number}' already exists with status '{existing.status}'"
            )

        # ── Upload to S3 ──────────────────────────────────────────────────────
        s3_key = f"applications/{application_number}/{filename}"
        try:
            file_bytes = file_obj.read()
            self.s3.upload_fileobj(
                io.BytesIO(file_bytes),
                settings.S3_BUCKET_NAME,
                s3_key,
                ExtraArgs={"ContentType": content_type},
            )
            logger.info(f"Uploaded {filename} → s3://{settings.S3_BUCKET_NAME}/{s3_key}")
        except ClientError as exc:
            logger.error(f"S3 upload failed: {exc}")
            raise AppException(status.HTTP_502_BAD_GATEWAY, "Failed to upload file to S3")

        # ── Create or update DB record ────────────────────────────────────────
        if existing:
            self.repo.update_s3_key(existing.id, s3_key)
            self.repo.update_status(existing.id, "pending")
            self.repo.get_by_id(existing.id)  # refresh
            return existing

        app = self.repo.create(
            application_number=application_number,
            application_type=app_type,
            s3_key=s3_key,
            status="pending",
        )
        return app

    def get_status(self, application_number: str) -> Application:
        app = self.repo.get_by_number(application_number)
        if not app:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Application '{application_number}' not found")
        return app
