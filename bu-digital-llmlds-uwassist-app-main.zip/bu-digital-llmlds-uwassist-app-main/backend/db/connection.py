"""
SQLAlchemy engine + session factory.

All FastAPI route handlers get a DB session via the `get_db` dependency
defined in core/dependencies.py.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

from config import settings

engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,      # detect stale connections before use
    pool_size=10,
    max_overflow=20,
    echo=False,              # set True to log every SQL (dev only)
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)


def get_db_session() -> Session:
    """Return a raw session — used outside FastAPI (scripts, agents)."""
    return SessionLocal()
