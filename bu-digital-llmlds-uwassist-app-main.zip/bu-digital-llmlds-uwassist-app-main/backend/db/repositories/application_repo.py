"""
Application repository — all DB operations for `applications` and `data_sources`.
"""
from typing import List, Optional
from uuid import UUID

from sqlalchemy.orm import Session

from db.schema import Application, DataSource


class ApplicationRepository:
    def __init__(self, db: Session):
        self.db = db

    # ── Applications ─────────────────────────────────────────────────────────

    def get_by_id(self, app_id: UUID) -> Optional[Application]:
        return self.db.query(Application).filter(Application.id == app_id).first()

    def get_by_number(self, application_number: str) -> Optional[Application]:
        return (
            self.db.query(Application)
            .filter(Application.application_number == application_number)
            .first()
        )

    def list_all(self, skip: int = 0, limit: int = 50) -> List[Application]:
        return self.db.query(Application).offset(skip).limit(limit).all()

    def create(
        self,
        application_number: str,
        application_type: str = "PDF",
        s3_key: Optional[str] = None,
        status: str = "pending",
    ) -> Application:
        app = Application(
            application_number=application_number,
            application_type=application_type,
            s3_key=s3_key,
            status=status,
        )
        self.db.add(app)
        self.db.commit()
        self.db.refresh(app)
        return app

    def update_status(self, app_id: UUID, status: str) -> None:
        self.db.query(Application).filter(Application.id == app_id).update({"status": status})
        self.db.commit()

    def update_s3_key(self, app_id: UUID, s3_key: str) -> None:
        self.db.query(Application).filter(Application.id == app_id).update({"s3_key": s3_key})
        self.db.commit()

    # ── Data Sources ─────────────────────────────────────────────────────────

    def get_data_sources(self, app_id: UUID) -> List[DataSource]:
        return (
            self.db.query(DataSource)
            .filter(DataSource.application_id == app_id, DataSource.is_available.is_(True))
            .all()
        )

    def upsert_data_source(self, app_id: UUID, source_name: str) -> DataSource:
        existing = (
            self.db.query(DataSource)
            .filter(DataSource.application_id == app_id, DataSource.name == source_name)
            .first()
        )
        if existing:
            existing.is_available = True
            self.db.commit()
            return existing

        ds = DataSource(application_id=app_id, name=source_name)
        self.db.add(ds)
        self.db.commit()
        self.db.refresh(ds)
        return ds
