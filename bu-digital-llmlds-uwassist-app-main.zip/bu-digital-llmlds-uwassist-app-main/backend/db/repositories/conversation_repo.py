"""
Conversation + Message repository.
"""
from typing import List, Optional
from uuid import UUID

from sqlalchemy.orm import Session

from db.schema import Conversation, Message


class ConversationRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_by_session(self, session_id: str) -> Optional[Conversation]:
        return self.db.query(Conversation).filter(Conversation.session_id == session_id).first()

    def create(
        self,
        session_id: str,
        application_id: Optional[UUID] = None,
        user_id: Optional[UUID] = None,
    ) -> Conversation:
        conv = Conversation(
            session_id=session_id,
            application_id=application_id,
            user_id=user_id,
        )
        self.db.add(conv)
        self.db.commit()
        self.db.refresh(conv)
        return conv

    def get_or_create(
        self,
        session_id: str,
        application_id: Optional[UUID] = None,
        user_id: Optional[UUID] = None,
    ) -> Conversation:
        conv = self.get_by_session(session_id)
        if not conv:
            conv = self.create(session_id, application_id, user_id)
        return conv

    # ── Messages ─────────────────────────────────────────────────────────────

    def add_message(
        self,
        conversation_id: UUID,
        role: str,
        content: str,
        step: Optional[str] = None,
        thought: Optional[str] = None,
        confidence_score: Optional[float] = None,
    ) -> Message:
        msg = Message(
            conversation_id=conversation_id,
            role=role,
            content=content,
            step=step,
            thought=thought,
            confidence_score=confidence_score,
        )
        self.db.add(msg)
        self.db.commit()
        self.db.refresh(msg)
        return msg

    def get_messages(self, conversation_id: UUID, limit: int = 50) -> List[Message]:
        return (
            self.db.query(Message)
            .filter(Message.conversation_id == conversation_id)
            .order_by(Message.created_at)
            .limit(limit)
            .all()
        )
