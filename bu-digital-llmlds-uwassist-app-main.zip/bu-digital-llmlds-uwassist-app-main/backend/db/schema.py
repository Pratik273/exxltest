"""
SQLAlchemy ORM table definitions.

These map 1-to-1 to the PostgreSQL tables already used by the POC agents.
Running Base.metadata.create_all() at startup creates missing tables safely.

Tables
------
users               – API users (JWT auth)
applications        – Insurance application registry
data_sources        – Available data sources per application (Part A/B, Rx…)
pages               – Extracted text pages from PDF applications
documents           – Extracted content from XML applications
conversations       – Agent conversation sessions
messages            – Individual agent turns (intermediate + final)
"""
import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean, Column, DateTime, Float, ForeignKey,
    Integer, String, Text, UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


# ─────────────────────────────────────────────────────────────────────────────
# Users
# ─────────────────────────────────────────────────────────────────────────────
class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = Column(String(100), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_admin = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    conversations = relationship("Conversation", back_populates="user")


# ─────────────────────────────────────────────────────────────────────────────
# Applications
# ─────────────────────────────────────────────────────────────────────────────
class Application(Base):
    __tablename__ = "applications"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    application_number = Column(String(50), unique=True, nullable=False, index=True)
    status = Column(String(50), default="pending", nullable=False)   # pending | processing | ready | failed
    application_type = Column(String(10), default="PDF", nullable=False)  # PDF | XML
    s3_key = Column(String(500), nullable=True)                       # original file path in S3
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    data_sources = relationship("DataSource", back_populates="application", cascade="all, delete-orphan")
    pages = relationship("Page", back_populates="application", cascade="all, delete-orphan")
    documents = relationship("Document", back_populates="application", cascade="all, delete-orphan")
    conversations = relationship("Conversation", back_populates="application")


# ─────────────────────────────────────────────────────────────────────────────
# Data Sources
# ─────────────────────────────────────────────────────────────────────────────
class DataSource(Base):
    """Tracks which data parts are available for an application."""
    __tablename__ = "data_sources"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    application_id = Column(UUID(as_uuid=True), ForeignKey("applications.id", ondelete="CASCADE"), nullable=False)
    # Possible names: Part A, Part B, Rx, Lab Tests, MIB, MVR, Dx, Other
    name = Column(String(100), nullable=False)
    is_available = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("application_id", "name", name="uq_app_datasource"),
    )

    application = relationship("Application", back_populates="data_sources")


# ─────────────────────────────────────────────────────────────────────────────
# Pages  (PDF applications)
# ─────────────────────────────────────────────────────────────────────────────
class Page(Base):
    """One row per page extracted from a PDF application."""
    __tablename__ = "pages"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    application_id = Column(UUID(as_uuid=True), ForeignKey("applications.id", ondelete="CASCADE"), nullable=False)
    page_number = Column(Integer, nullable=False)
    content = Column(Text, nullable=True)
    data_source_name = Column(String(100), nullable=True)   # e.g. "Part A"
    extracted_date = Column(String(50), nullable=True)
    embedding = Column(Text, nullable=True)                  # JSON-serialised float list
    created_at = Column(DateTime, default=datetime.utcnow)

    application = relationship("Application", back_populates="pages")


# ─────────────────────────────────────────────────────────────────────────────
# Documents  (XML applications)
# ─────────────────────────────────────────────────────────────────────────────
class Document(Base):
    """One row per logical section extracted from an XML application."""
    __tablename__ = "documents"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    application_id = Column(UUID(as_uuid=True), ForeignKey("applications.id", ondelete="CASCADE"), nullable=False)
    data_source_name = Column(String(100), nullable=True)
    content = Column(Text, nullable=True)
    extracted_date = Column(String(50), nullable=True)
    embedding = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    application = relationship("Application", back_populates="documents")


# ─────────────────────────────────────────────────────────────────────────────
# Conversations
# ─────────────────────────────────────────────────────────────────────────────
class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id = Column(String(100), unique=True, nullable=False, index=True)
    application_id = Column(UUID(as_uuid=True), ForeignKey("applications.id"), nullable=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    application = relationship("Application", back_populates="conversations")
    user = relationship("User", back_populates="conversations")
    messages = relationship("Message", back_populates="conversation", cascade="all, delete-orphan",
                            order_by="Message.created_at")


# ─────────────────────────────────────────────────────────────────────────────
# Messages
# ─────────────────────────────────────────────────────────────────────────────
class Message(Base):
    __tablename__ = "messages"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False)
    role = Column(String(20), nullable=False)           # user | assistant | system
    step = Column(String(100), nullable=True)           # agent step name (e.g. "Chief Reasoning")
    content = Column(Text, nullable=False)
    thought = Column(Text, nullable=True)
    confidence_score = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    conversation = relationship("Conversation", back_populates="messages")
