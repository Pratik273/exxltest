# EXL Domain Scale.ai — LDS Underwriting AI Backend

FastAPI backend for the **Life Insurance Underwriting LLM** system.
Converts the Streamlit POC into a production-ready API that connects to AWS Bedrock, S3, and PostgreSQL.

---

## Table of Contents

- [Project Structure](#project-structure)
- [Tech Stack](#tech-stack)
- [Setup & Installation](#setup--installation)
- [Environment Variables](#environment-variables)
- [Running the Server](#running-the-server)
- [API Reference](#api-reference)
  - [Health Check](#1-health-check)
  - [Authentication](#2-authentication)
  - [File Upload](#3-file-upload)
  - [Applications](#4-applications)
  - [Agent Query](#5-agent-query)
- [Postman Collection](#postman-collection)
- [How the Agent Pipeline Works](#how-the-agent-pipeline-works)
- [Database Schema](#database-schema)
- [Folder Structure](#folder-structure)

---

## Project Structure

```
bu-digital-llmlds-uwassist-app-main/
├── AIAgents-LDS/               ← Original Streamlit POC (untouched)
│   ├── app.py
│   ├── agents/
│   ├── utils/
│   └── ...
│
└── backend/                    ← NEW FastAPI backend (this folder)
    ├── main.py
    ├── config.py
    ├── requirements.txt
    ├── .env.example
    ├── README.md
    ├── EXL_LDS_API.postman_collection.json
    ├── api/v1/
    ├── models/
    ├── db/
    ├── services/
    └── core/
```

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Web Framework | FastAPI + Uvicorn |
| Database | PostgreSQL + SQLAlchemy (psycopg2) |
| Auth | JWT (python-jose) + bcrypt (passlib) |
| File Storage | AWS S3 (boto3) |
| LLM | AWS Bedrock (Claude 3.5 Sonnet) |
| Agents | LangGraph (from POC — zero changes) |
| Logging | Loguru |
| Config | pydantic-settings (.env file) |

---

## Setup & Installation

### Step 1 — Prerequisites

Make sure these are installed on your machine:

- Python 3.10+
- PostgreSQL 14+ (running locally or on RDS)
- AWS credentials configured (for S3 + Bedrock)

---

### Step 2 — Clone / Navigate to backend folder

```bash
cd bu-digital-llmlds-uwassist-app-main/backend
```

---

### Step 3 — Create virtual environment

```bash
# Create venv
python -m venv venv

# Activate on Windows
venv\Scripts\activate

# Activate on Mac/Linux
source venv/bin/activate
```

---

### Step 4 — Install dependencies

```bash
# Backend API dependencies
pip install -r requirements.txt

# Also install POC agent dependencies (for LangGraph agents)
pip install -r ../AIAgents-LDS/requirements.txt
```

---

### Step 5 — Setup environment variables

```bash
# Copy example file
cp .env.example .env

# Open .env and fill in your values
notepad .env       # Windows
nano .env          # Linux/Mac
```

See [Environment Variables](#environment-variables) section for all required values.

---

### Step 6 — Create PostgreSQL database

```sql
-- Run in psql or pgAdmin
CREATE DATABASE lds_db;
CREATE USER lds_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE lds_db TO lds_user;
```

Tables are **auto-created** on server startup — no manual migration needed.

---

### Step 7 — Run the server

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Open in browser:
- **Swagger UI** → http://localhost:8000/docs
- **ReDoc** → http://localhost:8000/redoc
- **Health Check** → http://localhost:8000/health

---

## Environment Variables

Copy `.env.example` → `.env` and fill in these values:

```env
# ── PostgreSQL ──────────────────────────────────────────────────────────────
POSTGRES_HOST=localhost          # DB host (use RDS endpoint in production)
POSTGRES_PORT=5432
POSTGRES_DB=lds_db               # Database name
DB_USERNAME=lds_user             # DB username
DB_PASSWORD=your_password        # DB password

# ── AWS ─────────────────────────────────────────────────────────────────────
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=               # Leave blank on EKS (uses IAM role)
AWS_SECRET_ACCESS_KEY=           # Leave blank on EKS (uses IAM role)
BEDROCK_MODEL_ID=anthropic.claude-3-5-sonnet-20241022-v2:0
S3_BUCKET_NAME=your-bucket-name

# ── JWT ──────────────────────────────────────────────────────────────────────
# Generate with: python -c "import secrets; print(secrets.token_hex(32))"
JWT_SECRET_KEY=replace-with-64-char-hex-secret
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=60
REFRESH_TOKEN_EXPIRE_DAYS=7

# ── Agent Flags ──────────────────────────────────────────────────────────────
IS_GENERATING_DATA=false
GENERATING_SUMMARY=false
```

---

## Running the Server

```bash
# Development (with auto-reload)
uvicorn main:app --reload --host 0.0.0.0 --port 8000

# Production
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

---

## API Reference

> All endpoints except `/health` and `/api/v1/auth/login` and `/api/v1/auth/register`
> require `Authorization: Bearer <access_token>` header.

---

### 1. Health Check

#### `GET /health`

Check if the server is running.

**No authentication required.**

**Response:**
```json
{
  "status": "ok",
  "version": "1.0.0"
}
```

---

### 2. Authentication

#### `POST /api/v1/auth/register`

Create a new user account.

**Request Body:**
```json
{
  "username": "underwriter_john",
  "email": "john.doe@exlservice.com",
  "password": "SecurePass@123"
}
```

| Field | Type | Required | Rules |
|-------|------|----------|-------|
| username | string | Yes | 3–100 chars, unique |
| email | string | Yes | valid email, unique |
| password | string | Yes | minimum 8 characters |

**Response `201 Created`:**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "username": "underwriter_john",
  "email": "john.doe@exlservice.com",
  "is_admin": false
}
```

**Errors:**
- `409` — Username or email already taken

---

#### `POST /api/v1/auth/login`

Login with username and password. Returns JWT tokens.

**Request Body:**
```json
{
  "username": "underwriter_john",
  "password": "SecurePass@123"
}
```

**Response `200 OK`:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "expires_in": 3600
}
```

> Use `access_token` in every request header:
> `Authorization: Bearer <access_token>`

**Errors:**
- `401` — Invalid credentials
- `403` — Account is inactive

---

#### `POST /api/v1/auth/refresh`

Get a new access token when the old one expires (after 60 min).

**Request Body:**
```json
{
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response `200 OK`:** Same as login response with new tokens.

**Errors:**
- `401` — Invalid or expired refresh token

---

#### `GET /api/v1/auth/me`

Get the currently logged-in user's profile.

**Headers:** `Authorization: Bearer <access_token>`

**Response `200 OK`:**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "username": "underwriter_john",
  "email": "john.doe@exlservice.com",
  "is_admin": false
}
```

---

### 3. File Upload

#### `POST /api/v1/upload/pdf`

Upload a PDF insurance application to S3.

**Headers:**
```
Authorization: Bearer <access_token>
Content-Type: multipart/form-data
```

**Form Data:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| application_number | string | Yes | Unique application ID e.g. `F11248249` |
| file | file | Yes | PDF file of the insurance application |

**What happens internally:**
1. Validates file is a PDF (by content-type)
2. Uploads to S3 at `applications/{app_number}/{filename}`
3. Creates `Application` record in PostgreSQL with status `pending`
4. Pre-processing job is triggered (page extraction + embeddings)

**Response `202 Accepted`:**
```json
{
  "application_id": "550e8400-e29b-41d4-a716-446655440000",
  "application_number": "F11248249",
  "s3_key": "applications/F11248249/F11248249.pdf",
  "status": "pending",
  "message": "File uploaded successfully. Pre-processing has been queued."
}
```

**Errors:**
- `400` — File is not a PDF
- `409` — Application already exists and is not in `failed` state

---

#### `POST /api/v1/upload/xml`

Upload an XML insurance application to S3.

Same as PDF upload but accepts `text/xml` or `application/xml` files.

**Form Data:** Same fields as PDF upload.

**Response `202 Accepted`:**
```json
{
  "application_id": "660e8400-e29b-41d4-a716-446655440001",
  "application_number": "9217523",
  "s3_key": "applications/9217523/9217523.xml",
  "status": "pending",
  "message": "File uploaded successfully. Pre-processing has been queued."
}
```

---

#### `GET /api/v1/upload/status/{application_number}`

Poll the processing status of an uploaded application.

**URL Params:** `application_number` — e.g. `F11248249`

**Status values:**

| Status | Meaning |
|--------|---------|
| `pending` | Uploaded, waiting for pre-processor to start |
| `processing` | Pre-processor is extracting pages + generating embeddings |
| `ready` | All data indexed, agents can now query this application |
| `failed` | Pre-processing failed — check logs and re-upload |

**Response `200 OK`:**
```json
{
  "application_id": "550e8400-e29b-41d4-a716-446655440000",
  "application_number": "F11248249",
  "status": "ready",
  "data_sources": ["Part A", "Part B", "Rx", "Lab Tests", "MIB", "MVR"]
}
```

**Errors:**
- `404` — Application not found

---

### 4. Applications

#### `GET /api/v1/applications`

List all registered applications with pagination.

**Query Params:**

| Param | Default | Description |
|-------|---------|-------------|
| skip | 0 | Records to skip |
| limit | 50 | Max records (1–200) |

**Response `200 OK`:**
```json
{
  "total": 15,
  "applications": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "application_number": "F11248249",
      "status": "ready",
      "application_type": "PDF",
      "s3_key": "applications/F11248249/F11248249.pdf",
      "data_sources": [
        { "id": "aa1e...", "name": "Part A", "is_available": true },
        { "id": "bb1e...", "name": "Part B", "is_available": true },
        { "id": "cc1e...", "name": "Rx",     "is_available": true },
        { "id": "dd1e...", "name": "Lab Tests", "is_available": true },
        { "id": "ee1e...", "name": "MIB",    "is_available": true },
        { "id": "ff1e...", "name": "MVR",    "is_available": true }
      ]
    }
  ]
}
```

---

#### `GET /api/v1/applications/{application_number}`

Get full details for a single application.

**URL Params:** `application_number` — e.g. `F11248249`

**Response `200 OK`:** Single application object (same structure as list item above)

**Errors:**
- `404` — Application not found

---

#### `GET /api/v1/applications/{application_number}/data-sources`

Get just the list of available data source names for quick lookup.

**Response `200 OK`:**
```json
["Part A", "Part B", "Rx", "Lab Tests", "MIB", "MVR"]
```

> These are the data parts the agents will search when you run a query.

---

### 5. Agent Query

#### `POST /api/v1/query`

Run the full **6-step LangGraph agent pipeline** on an underwriting question.

**Headers:**
```
Authorization: Bearer <access_token>
Content-Type: application/json
```

**Request Body:**
```json
{
  "application_number": "F11248249",
  "question": "Does the applicant have any history of diabetes or insulin use?",
  "session_id": null
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| application_number | string | Yes | Must have status `ready` |
| question | string | Yes | Your underwriting question (min 3 chars) |
| session_id | string | No | Pass existing session ID to continue conversation. Set `null` for new session. |

**Response `200 OK`:**
```json
{
  "session_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "application_number": "F11248249",
  "question": "Does the applicant have any history of diabetes or insulin use?",
  "thought": "I analyzed Part B, Rx, and Lab Tests. HbA1c is 5.4% (normal). No diabetes medications found in Rx. MIB codes show no diabetes-related entries...",
  "answer": "Based on available medical records, the applicant does not have a history of diabetes or insulin use. Lab HbA1c is 5.4% (normal range), no insulin or metformin in Rx, and Part B shows no diabetes diagnosis.",
  "confidence_score": "94%",
  "steps_completed": [
    "Intent Classification",
    "Extract Data Sources",
    "Query Processing",
    "Extracting Relevant Text",
    "Relevancy Checker",
    "Reasoning & Refining the answer"
  ],
  "conversation_id": "ff0e8400-e29b-41d4-a716-446655440099"
}
```

**Confidence Score Guide:**

| Score | Colour | Meaning |
|-------|--------|---------|
| ≥ 85% | 🟢 Green | Strong evidence, reliable answer |
| 70–84% | 🟡 Orange | Partial evidence, use with caution |
| < 70% | 🔴 Red | Insufficient data, manual review needed |

**Errors:**
- `404` — Application not found
- `422` — Application not ready (still processing)
- `500` — Agent execution failed

---

#### `GET /api/v1/query/history/{session_id}`

Get full conversation history for a session.

**URL Params:** `session_id` — from a previous query response

**Response `200 OK`:**
```json
{
  "session_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "messages": [
    {
      "id": "msg-001",
      "role": "user",
      "step": null,
      "content": "Does the applicant have any history of diabetes?",
      "thought": null,
      "confidence_score": null,
      "created_at": "2026-03-17T10:30:00"
    },
    {
      "id": "msg-002",
      "role": "assistant",
      "step": "Chief Reasoning Agent",
      "content": "No history of diabetes found in available records.",
      "thought": "Analyzed Part B, Rx, Lab Tests — all clear.",
      "confidence_score": 0.94,
      "created_at": "2026-03-17T10:30:15"
    }
  ]
}
```

**Errors:**
- `404` — Session not found

---

## Postman Collection

Import `EXL_LDS_API.postman_collection.json` into Postman.

### Steps to use:

1. **Import** → Postman → Import → select `EXL_LDS_API.postman_collection.json`
2. Set **collection variable** `base_url` = `http://localhost:8000`
3. Run **Register** request → creates your account
4. Run **Login** request → `access_token` and `refresh_token` are **auto-saved**
5. All other requests use `{{access_token}}` automatically

### Auto-save scripts:
- **Login** → saves `access_token` + `refresh_token`
- **Refresh Token** → updates `access_token` + `refresh_token`
- **Run Query** → saves `session_id` for follow-up questions
- **Upload PDF/XML** → saves `application_number`

---

## How the Agent Pipeline Works

When you call `POST /api/v1/query`, this 6-step pipeline runs:

```
User Question
      │
      ▼
┌─────────────────────┐
│ 1. Intent           │  → Is this an underwriting query? General? Unrelated?
│    Classification   │    If unrelated → answer immediately, skip rest.
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│ 2. Extract Data     │  → Queries PostgreSQL for available data sources
│    Sources          │    (Part A, Part B, Rx, Lab Tests, MIB, MVR, Dx)
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│ 3. Query Processing │  → Breaks question into sub-queries
│                     │    Maps each sub-query to relevant data sources
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│ 4. Extract Text     │  → Semantic search in PostgreSQL (BAAI embeddings)
│    from DB          │    Deduplication + context reduction (sliding window)
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│ 5. Relevancy        │  → Filters chunks: keeps only truly relevant content
│    Checker          │
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│ 6. Chief Reasoning  │  → Synthesises final answer using credibility weights:
│    Agent            │    Lab Tests > Rx > MVR > MIB > Part B > Part A > Other
│                     │    Outputs: Thought + Answer + Confidence Score
└─────────────────────┘
```

---

## Database Schema

7 tables are auto-created on server startup:

| Table | Purpose |
|-------|---------|
| `users` | API user accounts (underwriters) |
| `applications` | Insurance application registry |
| `data_sources` | Available data parts per application |
| `pages` | Extracted text pages from PDF applications |
| `documents` | Extracted content from XML applications |
| `conversations` | Agent conversation sessions |
| `messages` | Individual question/answer turns with reasoning |

---

## Folder Structure

```
backend/
├── main.py                     ← FastAPI app entry point
├── config.py                   ← All settings via .env (pydantic-settings)
├── requirements.txt
├── .env.example                ← Copy to .env and fill values
├── README.md                   ← This file
├── EXL_LDS_API.postman_collection.json
│
├── api/
│   └── v1/
│       ├── auth.py             ← Register, Login, Refresh, Me
│       ├── upload.py           ← PDF upload, XML upload, Status
│       ├── applications.py     ← List, Get, Data Sources
│       └── query.py            ← Run query, Conversation history
│
├── models/                     ← Pydantic request/response schemas
│   ├── auth.py
│   ├── upload.py
│   ├── application.py
│   └── query.py
│
├── db/
│   ├── connection.py           ← SQLAlchemy engine + session
│   ├── schema.py               ← ORM table definitions (7 tables)
│   └── repositories/
│       ├── user_repo.py
│       ├── application_repo.py
│       └── conversation_repo.py
│
├── services/                   ← Business logic layer
│   ├── auth_service.py
│   ├── upload_service.py       ← S3 upload + DB registration
│   ├── application_service.py
│   └── query_service.py        ← Calls POC LangGraph agents
│
└── core/
    ├── security.py             ← JWT + bcrypt
    ├── dependencies.py         ← FastAPI Depends (get_db, get_current_user)
    ├── middleware.py           ← Request logging
    └── exceptions.py          ← Custom error handlers
```
