MIB_SUMMARIZE_PROMPT = """
Summarize the given lines about MIB code in 1-3 lines only, in a way that it can be understood by
an LLM like you easily. Do not write about each character or code. Just given an overview.
The recommendation part can be written at the end.
Do not add any extra information.

Information:
"""