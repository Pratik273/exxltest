EXTRACT_METADATA_PROMPT = """
        Please categorize the following document based on ONLY these strict rules:

        1. If the barcode or header contains "PART 1" or "PART A" or if the document has demographic data questionnaire or policy related questions (regardless of page number) → categorize as "Part A"
        2. If the barcode or header contains "PART 2" or "PART B" or if the document has medical data questionnaire (regardless of page number) → categorize as "Part B"
        3. If the document contains "MIB Code" anywhere → categorize as "MIB"
        4. If the document contains laboratory test results and vitals → categorize as "Lab Tests"
        5. If the document contains prescriptions or medication lists → categorize as "Rx"
        6. If the document contains Motor Vehicle Report (MVR) data → categorize as "MVR"
        7. If none of the above conditions are met or a manifest document is present → categorize as "Other"

        Important rules:
        - Page numbers should be ignored when determining the document type
        - Look at the complete barcode text/header text (e.g., "PART1 02" means Part A, not Part B)
        - If the date of the document is given with day, month and year, then populate the extracted_date field in the JSON. Otherwise, leave it empty.
        - Only output in this exact JSON format which is a valid JSON object: {"categories": ["category_name"], "extracted_date": "YYYY-MM-DD"}
        - Do not provide any explanation or additional text
"""

EXTRACT_CONTENT_PROMPT = """
 Extract all the text content from the document in the form of a JSON object.
        All the details are important to be extracted.
        Important rules:
        - Only output a valid JSON object
        - Do not provide any explanation or additional text
"""