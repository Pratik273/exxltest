import json
import os
import copy
from context_subset2 import prepare_context_subset2, get_Rx_content

def clean_rx_raw_content(raw_text):
    """
    Cleans Rx raw_content by:
    - Removing 'PrescriptionSideEffect' from each Drug in Risk->DrugDetail->Drug
    - Keeping only top 5 items in 'DiseaseDescription' list
    Handles both list and dict cases for DrugDetail['Drug'].
    Returns cleaned JSON string if input is JSON, else returns original text.
    """
    try:
        data = json.loads(raw_text)
        data = copy.deepcopy(data)  # Avoid mutating original
        
        # Clean Risk->DrugDetail->Drug section
        if "Content" in data and "Risk" in data["Content"]:
            risk = data["Content"]["Risk"]
            if "DrugDetail" in risk and "Drug" in risk["DrugDetail"]:
                drugs = risk["DrugDetail"]["Drug"]
                
                # Handle both list and dict cases
                if isinstance(drugs, list):
                    for drug in drugs:
                        if isinstance(drug, dict):
                            # Remove PrescriptionSideEffect
                            if 'PrescriptionSideEffect' in drug:
                                del drug['PrescriptionSideEffect']
                            # Limit DiseaseDescription to 5 items
                            if 'DiseaseDescription' in drug and isinstance(drug['DiseaseDescription'], list):
                                drug['DiseaseDescription'] = drug['DiseaseDescription'][:5]
                elif isinstance(drugs, dict):
                    # Remove PrescriptionSideEffect
                    if 'PrescriptionSideEffect' in drugs:
                        del drugs['PrescriptionSideEffect']
                    # Limit DiseaseDescription to 5 items
                    if 'DiseaseDescription' in drugs and isinstance(drugs['DiseaseDescription'], list):
                        drugs['DiseaseDescription'] = drugs['DiseaseDescription'][:5]

        # Extract and store refills/last filled info
        rx_prescription_summary = extract_rx_refills_and_last_filled(data)
        
        data["IndividualPrescriptionInformation"] = rx_prescription_summary
                
        return json.dumps(data, ensure_ascii=False)
    except Exception as e:
        print(f"Rx cleaning failed or not JSON: {e}")
        return raw_text

def clean_rx_data_structure(rx_data):
    """
    Clean Rx data structure by removing PrescriptionSideEffect and limiting DiseaseDescription to 5 items.
    This function works on the processed Rx data structure returned by get_Rx_content.
    """
    if isinstance(rx_data, list):
        cleaned_data = []
        for item in rx_data:
            if isinstance(item, dict):
                cleaned_item = item.copy()
                # Remove PrescriptionSideEffect if present
                if 'PrescriptionSideEffect' in cleaned_item:
                    del cleaned_item['PrescriptionSideEffect']
                # Limit DiseaseDescription to 5 items if it's a list
                if 'DiseaseDescription' in cleaned_item and isinstance(cleaned_item['DiseaseDescription'], list):
                    cleaned_item['DiseaseDescription'] = cleaned_item['DiseaseDescription'][:5]
                cleaned_data.append(cleaned_item)
            else:
                cleaned_data.append(item)
        return cleaned_data
    return rx_data

def extract_rx_refills_and_last_filled(data):
    """
    For each prescription in Rx data, extract number of refills and fill dates using PrescriptionLabel and PrescriptionFillDate.
    Handles both list and dict cases for DrugDetail['Drug'].
    Returns a list of dicts with prescription info.
    """
    try:
        if "Content" not in data or "Risk" not in data["Content"]:
            print("No Content or Risk section found in Rx data.")
            return []
            
        risk = data["Content"]["Risk"]
        if "PrescriptionDrug" not in risk:
            print("No PrescriptionDrug section found in Rx data.")
            return []
            
        drug_detail = risk.get('PrescriptionDrug')
        if isinstance(drug_detail, list):
            drugs = drug_detail
        elif isinstance(drug_detail, dict):
            drugs = [drug_detail]
        else:
            print("No PrescriptionDrug section found in Rx data.")
            return []
        
        # Group fill dates by PrescriptionLabel
        prescription_fills = {}
        drug_details = {}
        for drug in drugs:
            label = drug.get('PrescriptionLabel')
            fills = drug.get('PrescriptionFill', {})
            fill_date = fills.get('PrescriptionFillDate') if isinstance(fills, dict) else None
            if label:
                if label not in prescription_fills:
                    prescription_fills[label] = []
                    drug_details[label] = fills
                if fill_date:
                    prescription_fills[label].append(fill_date)
        result = []
        for prescription_label, fill_dates in prescription_fills.items():
            results = {}
            drug = drug_details[prescription_label]
            results["PrescriptionLabel"] = prescription_label
            results["TotalNumberOfRefillsTaken"] = len(fill_dates)
            if isinstance(drug, dict):
                if "PrescriptionTotalRefillsAllowed" in drug:
                    results["TotalNumberOfRefillsAllowed"] = drug["PrescriptionTotalRefillsAllowed"]
                if "PrescriptionDaysSupply" in drug:
                    results["PrescriptionDaysSupply"] = drug["PrescriptionDaysSupply"]
            fill_dates_sorted = sorted(fill_dates)
            results["DateFirstFilled"] = fill_dates_sorted[0]
            if len(fill_dates_sorted) > 1:
                results["DateLastFilled"] = fill_dates_sorted[-1]
            else:
                results["DateLastFilled"] = fill_dates_sorted[0]
            result.append(results)
        return result
    except Exception as e:
        print(f"Error parsing Rx data for refills/last filled: {e}")
        return []

def prepare_context_medical_enhanced(partAfile, partBfile, Rxfile, Dxfile, Labfile, mibfile):
    """
    Enhanced medical context preparation that uses the new get_enhanced_Rx_content function.
    This combines original Rx data processing with cleaning features and prescription summary.
    """
    try:
        from context_subset2 import date_App, get_partB_content, get_Dx_content, get_Lab_content, get_mib_content
        
        # Get all components using original functions except for Rx
        app_date = date_App(partAfile)
        partB_content = get_partB_content(partBfile)
        
        # Use enhanced Rx processing that includes cleaning and summary
        enhanced_Rx_content = get_enhanced_Rx_content(Rxfile)
        
        Dx_content = get_Dx_content(Dxfile)
        Lab_content = get_Lab_content(Labfile)
        mib_content = get_mib_content(mibfile)
        
        # Format the enhanced Rx content for display
        if isinstance(enhanced_Rx_content, list) and enhanced_Rx_content:
            formatted_rx_content = format_rx_data_for_context(enhanced_Rx_content)
        else:
            formatted_rx_content = str(enhanced_Rx_content)
        
        # Build the complete context
        output = (
            f"Application Date: {app_date}\n"
            "Part B\n"
            f"{partB_content}\n\n"
            "\nPrescription (Rx)\n"
            f"{formatted_rx_content}\n\n"
            "Diagnosis (Dx)\n"
            f"{Dx_content}\n\n"
            "Lab Results\n"
            f"{Lab_content}\n\n"
            "MIB\n"
            f"{mib_content}"
        )
        
        return output
        
    except Exception as e:
        print(f"Error preparing enhanced medical context: {e}")
        return f"Error processing enhanced medical context: {str(e)}"

def prepare_context_medical(partAfile, partBfile, Rxfile, Dxfile, Labfile, mibfile):
    """
    Prepare medical context using context_subset2 functions and enhanced Rx processing.
    Focuses on medical information for risk assessment.
    """
    try:
        # Use the existing context_subset2 function as base
        base_context = prepare_context_subset2(partAfile, partBfile, Rxfile, Dxfile, Labfile, mibfile)
        
        # Enhanced Rx processing for large files
        if os.path.exists(Rxfile):
            try:
                with open(Rxfile, 'r', encoding='utf-8') as f:
                    raw_content = f.read()
                
                # If file is too large, use enhanced processing
                if len(raw_content) > 500_000:  # 500KB limit
                    try:
                        # Get raw prescription data
                        raw_rx_content = get_raw_rx_content(Rxfile)
                        
                        # Get enhanced refills information
                        enhanced_refills = extract_rx_refills_and_last_filled(json.loads(raw_content))
                        
                        # Create prescription summary
                        prescription_summary = create_prescription_summary(enhanced_refills)
                        
                        # Combine raw data with summary
                        combined_rx_content = raw_rx_content + "\n\nPrescription Summary:\n" + prescription_summary
                        
                        # Replace the Rx section in base_context
                        if "Prescription (Rx)" in base_context:
                            parts = base_context.split("Prescription (Rx)")
                            if len(parts) >= 2:
                                rx_end = parts[1].find("\n\nDiagnosis (Dx)")
                                if rx_end != -1:
                                    enhanced_context = (
                                        parts[0] + 
                                        "Prescription (Rx)\n" + 
                                        combined_rx_content + 
                                        parts[1][rx_end:]
                                    )
                                    return enhanced_context
                    except Exception as e:
                        print(f"Error processing enhanced Rx data: {e}")
                else:
                    # For smaller files, use raw prescription data
                    raw_rx_content = get_raw_rx_content(Rxfile)
                    
                    # Get enhanced refills information
                    enhanced_refills = extract_rx_refills_and_last_filled(json.loads(raw_content))
                    
                    # Create prescription summary
                    prescription_summary = create_prescription_summary(enhanced_refills)
                    
                    # Combine raw data with summary
                    combined_rx_content = raw_rx_content + "\n\nPrescription Summary:\n" + prescription_summary
                    
                    # Replace the Rx section in base_context
                    if "Prescription (Rx)" in base_context:
                        parts = base_context.split("Prescription (Rx)")
                        if len(parts) >= 2:
                            rx_end = parts[1].find("\n\nDiagnosis (Dx)")
                            if rx_end != -1:
                                enhanced_context = (
                                    parts[0] + 
                                    "Prescription (Rx)\n" + 
                                    combined_rx_content + 
                                    parts[1][rx_end:]
                                )
                                return enhanced_context
                
            except Exception as e:
                print(f"Error enhancing Rx processing: {e}")
        
        return base_context
        
    except Exception as e:
        print(f"Error preparing medical context: {e}")
        return f"Error processing medical context: {str(e)}"

def format_rx_data_for_context(rx_data):
    """
    Format Rx data for context display with original format plus prescription summary.
    """
    if not isinstance(rx_data, list):
        return "No prescription data available"
    
    rx_info = []
    
    # First, add the original prescription data in the original format
    for i, prescription in enumerate(rx_data, 1):
        if isinstance(prescription, dict):
            rx_info.append(f"Prescription {i}:")
            rx_info.append(f"  Label: {prescription.get('PrescriptionLabel', 'Not available')}")
            rx_info.append(f"  Refills Allowed: {prescription.get('RefillsAllowed', 'Not available')}")
            if 'DateFirstFilled' in prescription:
                rx_info.append(f"  First Filled: {prescription['DateFirstFilled']}")
            if 'DateLastFilled' in prescription:
                rx_info.append(f"  Last Filled: {prescription['DateLastFilled']}")
            if 'Dose' in prescription:
                rx_info.append(f"  Dose: {prescription['Dose']}")
            if 'DrugClass' in prescription:
                rx_info.append(f"  Drug Class: {prescription['DrugClass']}")
            if 'DiseaseDescription' in prescription:
                disease_desc = prescription['DiseaseDescription']
                if isinstance(disease_desc, list):
                    # Limit to 5 items and format as string
                    limited_desc = disease_desc[:5]
                    rx_info.append(f"  Indication: {limited_desc}")
                else:
                    rx_info.append(f"  Indication: {disease_desc}")
            if 'PhysicianTitle' in prescription:
                rx_info.append(f"  Physician: {prescription['PhysicianTitle']}")
            if 'PhysicianSpecialties' in prescription:
                specialties = prescription['PhysicianSpecialties']
                if isinstance(specialties, list):
                    rx_info.append(f"  Specialties: {', '.join(specialties)}")
            rx_info.append("")  # Empty line for readability
    
    # Then add prescription summary at the end
    rx_info.append("Prescription Summary:")
    rx_info.append("  Refills and Fill Information:")
    
    for prescription in rx_data:
        if isinstance(prescription, dict):
            label = prescription.get('PrescriptionLabel', 'Not available')
            rx_info.append(f"    {label}:")
            
            # Enhanced refills information
            if 'TotalNumberOfRefillsTaken' in prescription:
                rx_info.append(f"      Refills Taken: {prescription['TotalNumberOfRefillsTaken']}")
            if 'TotalNumberOfRefillsAllowed' in prescription:
                rx_info.append(f"      Refills Allowed: {prescription['TotalNumberOfRefillsAllowed']}")
            elif 'RefillsAllowed' in prescription:
                rx_info.append(f"      Refills Allowed: {prescription['RefillsAllowed']}")
            
            # Fill dates
            if 'DateFirstFilled' in prescription:
                rx_info.append(f"      First Filled: {prescription['DateFirstFilled']}")
            if 'DateLastFilled' in prescription:
                rx_info.append(f"      Last Filled: {prescription['DateLastFilled']}")
            
            # Additional prescription details
            if 'PrescriptionDaysSupply' in prescription:
                rx_info.append(f"      Days Supply: {prescription['PrescriptionDaysSupply']}")
            if 'PhysicianID' in prescription:
                rx_info.append(f"      Physician ID: {prescription['PhysicianID']}")
            
            rx_info.append("")  # Empty line for readability
    
    return "\n".join(rx_info)

def enhance_rx_data_with_refills(original_rx_data, raw_content):
    """
    Enhance original Rx data with additional refills and fill information.
    Combines the original prescription data with enhanced refills tracking.
    """
    try:
        # Parse the raw content to get enhanced refills information
        data = json.loads(raw_content)
        enhanced_refills = extract_rx_refills_and_last_filled(data)
        
        # Create a mapping of prescription labels to enhanced refills data
        refills_map = {}
        for refill_info in enhanced_refills:
            label = refill_info.get('PrescriptionLabel')
            if label:
                refills_map[label] = refill_info
        
        # Enhance the original Rx data with refills information
        enhanced_data = []
        for prescription in original_rx_data:
            if isinstance(prescription, dict):
                label = prescription.get('PrescriptionLabel')
                enhanced_prescription = prescription.copy()
                
                # Add enhanced refills information if available
                if label and label in refills_map:
                    refill_info = refills_map[label]
                    enhanced_prescription.update({
                        'TotalNumberOfRefillsTaken': refill_info.get('TotalNumberOfRefillsTaken'),
                        'TotalNumberOfRefillsAllowed': refill_info.get('TotalNumberOfRefillsAllowed'),
                        'PrescriptionDaysSupply': refill_info.get('PrescriptionDaysSupply'),
                        'DateFirstFilled': refill_info.get('DateFirstFilled'),
                        'DateLastFilled': refill_info.get('DateLastFilled')
                    })
                else:
                    # If no enhanced refills data, use original refills data
                    if 'RefillsAllowed' not in enhanced_prescription:
                        enhanced_prescription['RefillsAllowed'] = 1
                    if 'DateFirstFilled' not in enhanced_prescription and 'DateLastFilled' not in enhanced_prescription:
                        # Try to get dates from original data structure
                        if 'PrescriptionFill' in enhanced_prescription:
                            fill_data = enhanced_prescription['PrescriptionFill']
                            if isinstance(fill_data, dict) and 'PrescriptionFillDate' in fill_data:
                                enhanced_prescription['DateFirstFilled'] = fill_data['PrescriptionFillDate']
                                enhanced_prescription['DateLastFilled'] = fill_data['PrescriptionFillDate']
                
                enhanced_data.append(enhanced_prescription)
            else:
                enhanced_data.append(prescription)
        
        return enhanced_data
        
    except Exception as e:
        print(f"Error enhancing Rx data with refills: {e}")
        return original_rx_data

def get_raw_rx_content(Rxfile):
    """
    Extract raw prescription data from Rx file without any processing or formatting.
    Returns the raw prescription data structure as it appears in the original JSON.
    """
    try:
        if not os.path.exists(Rxfile):
            print(f"Rx file not found: {Rxfile}")
            return "No prescription data available"
            
        with open(Rxfile, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            if not content:
                print(f"Rx file is empty: {Rxfile}")
                return "No prescription data available"
            data = json.loads(content)
            data_dict = data["Content"]
            
        # Return the raw prescription data structure
        if "Risk" in data_dict and "PrescriptionDrug" in data_dict["Risk"]:
            prescription_data = data_dict["Risk"]["PrescriptionDrug"]
            # Clean only PrescriptionSideEffect and limit DiseaseDescription to 5 items
            cleaned_data = clean_raw_rx_data(prescription_data)
            return json.dumps(cleaned_data, indent=2, ensure_ascii=False)
        else:
            return "No prescription data found in file"
            
    except Exception as e:
        print(f"Error reading raw Rx file: {e}")
        return f"Error processing prescription data: {str(e)}"

def clean_raw_rx_data(prescription_data):
    """
    Clean raw prescription data by removing PrescriptionSideEffect and limiting DiseaseDescription to 5 items.
    """
    if isinstance(prescription_data, list):
        cleaned_data = []
        for item in prescription_data:
            if isinstance(item, dict):
                cleaned_item = item.copy()
                # Remove PrescriptionSideEffect if present
                if 'PrescriptionSideEffect' in cleaned_item:
                    del cleaned_item['PrescriptionSideEffect']
                # Limit DiseaseDescription to 5 items if it's a list
                if 'DiseaseDescription' in cleaned_item and isinstance(cleaned_item['DiseaseDescription'], list):
                    cleaned_item['DiseaseDescription'] = cleaned_item['DiseaseDescription'][:5]
                cleaned_data.append(cleaned_item)
            else:
                cleaned_data.append(item)
        return cleaned_data
    elif isinstance(prescription_data, dict):
        cleaned_item = prescription_data.copy()
        # Remove PrescriptionSideEffect if present
        if 'PrescriptionSideEffect' in cleaned_item:
            del cleaned_item['PrescriptionSideEffect']
        # Limit DiseaseDescription to 5 items if it's a list
        if 'DiseaseDescription' in cleaned_item and isinstance(cleaned_item['DiseaseDescription'], list):
            cleaned_item['DiseaseDescription'] = cleaned_item['DiseaseDescription'][:5]
        return cleaned_item
    return prescription_data

def create_prescription_summary(enhanced_refills):
    """
    Create a prescription summary with refills and fill information.
    """
    if not enhanced_refills:
        return "No prescription summary available"
    
    summary_lines = []
    summary_lines.append("  Refills and Fill Information:")
    
    for refill_info in enhanced_refills:
        label = refill_info.get('PrescriptionLabel', 'Not available')
        summary_lines.append(f"    {label}:")
        
        if 'TotalNumberOfRefillsTaken' in refill_info:
            summary_lines.append(f"      Refills Taken: {refill_info['TotalNumberOfRefillsTaken']}")
        if 'TotalNumberOfRefillsAllowed' in refill_info:
            summary_lines.append(f"      Refills Allowed: {refill_info['TotalNumberOfRefillsAllowed']}")
        if 'DateFirstFilled' in refill_info:
            summary_lines.append(f"      First Filled: {refill_info['DateFirstFilled']}")
        if 'DateLastFilled' in refill_info:
            summary_lines.append(f"      Last Filled: {refill_info['DateLastFilled']}")
        if 'PrescriptionDaysSupply' in refill_info:
            summary_lines.append(f"      Days Supply: {refill_info['PrescriptionDaysSupply']}")
        
        summary_lines.append("")  # Empty line for readability
    
    return "\n".join(summary_lines)

def get_enhanced_Rx_content(input_file_name):
    """
    Enhanced Rx content extraction that combines original context_subset2 processing 
    with cleaning features (removing PrescriptionSideEffect, limiting DiseaseDescription)
    and adds prescription summary at the end.
    """
    try:
        if not os.path.exists(input_file_name):
            print(f"Rx file not found: {input_file_name}")
            return []
            
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            if not content:
                print(f"Rx file is empty: {input_file_name}")
                return []
            data = json.loads(content)
            data_dict = data["Content"]

        # Check if 'Risk' and 'Physicians' keys exist in the data_dict
        if "Risk" in data_dict:
              risk = data_dict["Risk"]
        else:
            print("No Risk data found in the file")
            return []
        
        physicians = []
        if "Physicians" in data_dict:
            # Ensure Physicians is a list
            if not isinstance(data_dict["Physicians"], list):
                data_dict["Physicians"] = [data_dict["Physicians"]]
            physicians = data_dict["Physicians"]

        if "PrescriptionDrug" in risk:
            health = risk['PrescriptionDrug']
        else:
            print("No PrescriptionDrug data found in the file")
            health = []
        
        if "DrugDetail" in risk:
            meds = risk['DrugDetail']['Drug']
            if not isinstance(meds, list):
                meds = [meds]
            # Clean the meds: Remove PrescriptionSideEffect and limit DiseaseDescription
            for med in meds:
                if isinstance(med, dict):
                    # Remove PrescriptionSideEffect
                    if 'PrescriptionSideEffect' in med:
                        del med['PrescriptionSideEffect']
                    # Limit DiseaseDescription to first 5 items
                    if 'DiseaseDescription' in med and isinstance(med['DiseaseDescription'], list):
                        med['DiseaseDescription'] = med['DiseaseDescription'][:5]
        else:
            print("No DrugDetail data found in the file")
            meds = []

        # Create a dictionary to quickly look up physician information
        physician_dict = {phy.get('@id'): phy for phy in physicians}
        if not physician_dict:
            physician_dict = {}

        payload_json = []
        processed_labels = set()
        total_therapeutic_class_score = 0
        
        if not isinstance(health, list):
            health = [health]
        
        if not isinstance(meds, list):
            meds = [meds]
        
        if not isinstance(physicians, list):
            physicians = [physicians]

        # Process prescriptions using original context_subset2 logic
        for drug in health:
            if "PrescriptionLabel" not in drug:
                continue  # Skip entries without a label

            prescription_label = str(drug["PrescriptionLabel"])
            fill_date = None

            if "PrescriptionFill" in drug and "PrescriptionFillDate" in drug["PrescriptionFill"]:
                fill_date = drug["PrescriptionFill"]["PrescriptionFillDate"]

            if prescription_label in processed_labels:
                if fill_date:
                    for entry in payload_json:
                        if entry.get("PrescriptionLabel") == prescription_label:
                            if "DateLastFilled" not in entry or fill_date > entry["DateLastFilled"]:
                                entry["DateLastFilled"] = fill_date
                            if "RefillsAllowed" in entry:
                                entry["RefillsAllowed"] = int(entry["RefillsAllowed"]) + 1
                            break
                continue  # Skip to next drug — we've already processed this label

            # First-time processing of this label
            processed_labels.add(prescription_label)

            results = {
                "PrescriptionLabel": prescription_label,
                "RefillsAllowed": 1
            }

            if "PrescriptionDaysSupply" in drug:
                results["PrescriptionDaysSupply"] = drug["PrescriptionDaysSupply"]

            if fill_date:
                results["DateFirstFilled"] = fill_date

            if ("PrescriptionFill" in drug and 
                "OLifEExtension" in drug["PrescriptionFill"] and 
                "PrescriptionStrength" in drug["PrescriptionFill"]["OLifEExtension"]):
                results["Dose"] = drug["PrescriptionFill"]["OLifEExtension"]["PrescriptionStrength"]

            if "TherapeuticClass" in drug and "#text" in drug["TherapeuticClass"]:
                results["DrugClass"] = drug["TherapeuticClass"]["#text"]

            # Add physician information
            if "PrescriptionFill" in drug and "@PhysicianID" in drug["PrescriptionFill"]:
                physician_id = drug["PrescriptionFill"]["@PhysicianID"]
                physician = physician_dict.get(physician_id)
                if physician:
                    results["PhysicianID"] = physician_id
                    if "Person" in physician:
                        results["PhysicianTitle"] = physician['Person'].get('Title', '')
                    if "Physician" in physician:
                        if "PhysicianInfo" in physician["Physician"]:
                            if "OLifEExtension" in physician["Physician"]["PhysicianInfo"]:
                                specialities = []
                                if isinstance(physician["Physician"]["PhysicianInfo"]["OLifEExtension"], list):
                                    for phy in range(len(physician["Physician"]["PhysicianInfo"]["OLifEExtension"])):
                                        specialities.append(physician["Physician"]["PhysicianInfo"]["OLifEExtension"][phy]["PhysicianSpecialty"])
                                    results["PhysicianSpecialties"] = specialities
                                elif isinstance(physician["Physician"]["PhysicianInfo"]["OLifEExtension"], dict):
                                    if isinstance(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"], dict):
                                        specialities.append(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"])
                                        results["PhysicianSpecialties"] = specialities
                                    elif isinstance(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"], list):
                                        for phy in range(len(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"])):
                                            specialities.append(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"][phy])
                                        results["PhysicianSpecialties"] = specialities

            # Add DiseaseDescription from cleaned meds data
            for cause in meds:
                if cause.get("DrugLabel") == prescription_label and "DiseaseDescription" in cause:
                    disease_desc = cause["DiseaseDescription"]
                    # DiseaseDescription is already limited to 5 items in the cleaning step above
                    results["DiseaseDescription"] = str(disease_desc)
                    break

            payload_json.append(results)

        # Calculate total TherapeuticClassScore
        has_therapeutic_class_score = False
        for med in meds:
            if "TherapeuticClassScore" in med:
                total_therapeutic_class_score += float(med["TherapeuticClassScore"])
                has_therapeutic_class_score = True

        if has_therapeutic_class_score:
            payload_json.append({"TherapeuticClassScore": total_therapeutic_class_score})

        # Add prescription summary using the enhanced refills function
        try:
            enhanced_refills = extract_rx_refills_and_last_filled(data)
            if enhanced_refills:
                # Enhance original data with refills information
                enhanced_payload = enhance_rx_data_with_refills(payload_json, content)
                return enhanced_payload
        except Exception as e:
            print(f"Error adding prescription summary: {e}")

        # Check if payload_json is empty
        if not payload_json:
            print("No Rx data found in the provided file.")
            return data_dict
        else:
            return payload_json

    except json.JSONDecodeError as e:
        print(f"Rx JSON decode error: {e}")
        import traceback
        traceback.print_exc()
        return {}

def get_Rx_content_from_data(data):
    """
    Extract Rx content from cleaned data structure.
    This is a simplified version of the Rx extraction for enhanced processing.
    """
    try:
        rx_info = []
        
        # Get prescription information from IndividualPrescriptionInformation
        if "IndividualPrescriptionInformation" in data:
            prescriptions = data["IndividualPrescriptionInformation"]
            if isinstance(prescriptions, list):
                rx_info.append(f"Number of Prescriptions: {len(prescriptions)}")
                for i, prescription in enumerate(prescriptions, 1):
                    rx_info.append(f"\nPrescription {i}:")
                    rx_info.append(f"  Label: {prescription.get('PrescriptionLabel', 'Not available')}")
                    rx_info.append(f"  Refills Taken: {prescription.get('TotalNumberOfRefillsTaken', 'Not available')}")
                    rx_info.append(f"  Refills Allowed: {prescription.get('TotalNumberOfRefillsAllowed', 'Not available')}")
                    rx_info.append(f"  Days Supply: {prescription.get('PrescriptionDaysSupply', 'Not available')}")
                    rx_info.append(f"  First Filled: {prescription.get('DateFirstFilled', 'Not available')}")
                    rx_info.append(f"  Last Filled: {prescription.get('DateLastFilled', 'Not available')}")
        
        # Get additional drug details from Risk section
        if "Content" in data and "Risk" in data["Content"]:
            risk = data["Content"]["Risk"]
            if "DrugDetail" in risk and "Drug" in risk["DrugDetail"]:
                drugs = risk["DrugDetail"]["Drug"]
                if isinstance(drugs, list):
                    rx_info.append(f"\nDrug Details:")
                    for i, drug in enumerate(drugs[:5], 1):  # Limit to first 5
                        rx_info.append(f"  Drug {i}: {drug.get('DrugLabel', 'Not available')}")
                        if "DiseaseDescription" in drug:
                            disease_desc = drug['DiseaseDescription']
                            if isinstance(disease_desc, list):
                                # Limit to 5 items
                                limited_desc = disease_desc[:5]
                                rx_info.append(f"    Indication: {', '.join(limited_desc)}")
                            else:
                                rx_info.append(f"    Indication: {disease_desc}")
                        if "TherapeuticClass" in drug:
                            rx_info.append(f"    Class: {drug['TherapeuticClass']}")
                elif isinstance(drugs, dict):
                    rx_info.append(f"\nDrug Details:")
                    rx_info.append(f"  Drug: {drugs.get('DrugLabel', 'Not available')}")
                    if "DiseaseDescription" in drugs:
                        disease_desc = drugs['DiseaseDescription']
                        if isinstance(disease_desc, list):
                            # Limit to 5 items
                            limited_desc = disease_desc[:5]
                            rx_info.append(f"    Indication: {', '.join(limited_desc)}")
                        else:
                            rx_info.append(f"    Indication: {disease_desc}")
                    if "TherapeuticClass" in drugs:
                        rx_info.append(f"    Class: {drugs['TherapeuticClass']}")
        
        if rx_info:
            return "\n".join(rx_info)
        else:
            return "No prescription data available"
            
    except Exception as e:
        print(f"Error extracting Rx content from data: {e}")
        return "Error processing prescription data" 