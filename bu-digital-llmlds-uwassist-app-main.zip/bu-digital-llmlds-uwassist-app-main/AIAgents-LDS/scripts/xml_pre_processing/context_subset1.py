import os
import json
from datetime import datetime
# from main import mib_parsing

def extract_keys(data, keys):
    """
    Extracts specific keys from a dictionary and returns them as a new dictionary.
    """
    extracted_data = {}
    for key in keys:
        if key in data:
            extracted_data[key] = data[key]
    return extracted_data

# Part A : Application Date
def date_App(input_file_name):
    try:
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            if not content:
                return None
            data = json.loads(content)
            data_dict = data["Content"]
            date = data_dict['AppWrittenDate']
            date = datetime.strptime(date, '%m-%d-%Y')
            return date.strftime('%m-%d-%Y')
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}")
        return None

# Part A: Content
def get_partA_content(input_file_name):
    """
    Extracts data from a JSON file and returns it as a list of dictionaries.
    """
    try:
        payload_json = {}
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            if not content:
                return {}  # Return empty dict for empty file
            data = json.loads(content)
            data_dict = data["Content"]
            payload_json = extract_keys(data_dict, ["Gender", "USCitizen", "AgeAtWrittenDate", "Age", "Occupation", "ResidenceCountry", "BirthCountry", "BirthState", "InsuranceIssuedPastYear", "LiabilityAmount", "ExistingMwaInsuranceAmount", "ExistingMwaInsuranceReplaced","ExistingExternalInsuranceAmount", "ExistingExternalInsuranceReplaced", "BeneficiaryTypes", "ThirdPartyApplication",
        "PowerOfAttorney",
        "PaperApplication",
        "Assignment",
        "NicotineDiscrepancy",
        "JetControlCode",
        "InsuranceIssuedPastYear",
        "CumulativeAuAmount",
        "TrialApplication",
        "PlanCode",
        "PlanDescription",
        "BaseAmount",
        "DataVersion",
        "CaseSequence", "InitialPremiumReceived",
        "InitialPremiumReturnedAmount",
        "InitialPremiumReturned", "AULiabilityAmount", "Riders", "AnnualPremium",
        "PremiumSemiAnnual",
        "PremiumQuarterly",
        "PremiumMonthly",
        "PremiumSuperPreferredModal",
        "ModalPremiumPreferred",
        "PremiumMode"])
            payload_json["Impairment"] = data_dict["EAppJson"]["Impairment1"]
            print(payload_json)
            return payload_json
    except json.JSONDecodeError as e:
        print(f" Part A JSON decode error: {e}")
        return {}
    

# Part B: Content
def get_partB_content(input_file_name):
    """
    Extracts data from a JSON file and returns it as a list of dictionaries.
    """
    try:
        # requirements = []
        payload_json = {}
        if not os.path.exists(input_file_name):
            return {}
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            # print(f"Content: {content}")
            if not content:
                return {} # Return empty dict for empty file
            data = json.loads(content)
            data_dict = data["Content"]
            payload_json = extract_keys(data_dict, ["Weight", "WeightLoss", "WeightLossReason", "HeightInchesTotal", "BMI"])
            payload_json["Height"] = f"{data_dict['HeightFeetInteger']} feet {data_dict['HeightInchesRemainder']} inches"
            payload_json["TobaccoUse"] = f"{data_dict['TobaccoStatus']}, 12 months: {data_dict['Nicotine12Months']}, 36 months: {data_dict['Nicotine36Months']}"
            payload_json["Requirements"] = data_dict["Requirements"]
            
            return payload_json
    except json.JSONDecodeError as e:
        print(f"Part B JSON decode error: {e}")
        return {}

# MVR: Content
def get_mvr_json(input_file_name):
    """
    Extracts data from a JSON file and returns it as a list of dictionaries.
    """
    try:
        payload_json = {}
        violations = []
        mvr_violations = []
        if not os.path.exists(input_file_name):
            return {}
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            #print("Successfully read MVR file")
            # print(f"Content: {content}")
            if not content:
                return {}  # Return empty dict for empty file
            data = json.loads(content)
            data_dict = data["Content"]
            # print(f"Data Dict: {data_dict}")

            if "ScoreResult" in data_dict["ProductResults"]:
                for i in range(len(data_dict["ProductResults"]["ScoreResult"]["Result"])):
                    if "Models" in data_dict["ProductResults"]["ScoreResult"]["Result"][0][i]:
                        for j in range(len(data_dict["ProductResults"]["ScoreResult"]["Result"][0][i]["Models"])):
                            if "Score" in data_dict["ProductResults"]["ScoreResult"]["Result"][0][i]["Models"][j]:
                                payload_json["RiskClassScore"] = data_dict["ProductResults"]["ScoreResult"]["Result"][0][i]["Models"][j]["Score"]
                                break
                        break
            
            
            if "MVRResults" in data_dict["ProductResults"]:
                for i in range(len(data_dict["ProductResults"]["MVRResults"]["Result"])):
                    if "MVRReport" in data_dict["ProductResults"]["MVRResults"]["Result"][0][i]:
                        payload_json["MVRStatus"] = data_dict["ProductResults"]["MVRResults"]["Result"][0][i]["MVRReport"]["ProcessingInfo"]["MVRStatus"]

                        payload_json["DLExpirationDate"] = data_dict["ProductResults"]["MVRResults"]["Result"][0][i]["MVRReport"]["ProcessingInfo"]["DriversLicense"]["ExpirationDate"]
                        
                        violations = data_dict["ProductResults"]["MVRResults"]["Result"][0][i]["MVRReport"]["Response"]["MVRViolations"]

                        break
            
            if "NationalCreditFileResults" in data_dict["ProductResults"]:
                for index in range(len(data_dict["ProductResults"]["NationalCreditFileResults"]["Result"])):
                    if "NcfReport" in data_dict["ProductResults"]["NationalCreditFileResults"]["Result"][0][index]:
                        payload_json["CreditScore"] = data_dict["ProductResults"]["NationalCreditFileResults"]["Result"][0][index]["NcfReport"]["NcfProductReport"]["AlertsScoring"]["Scores"]
                        break
            
            for i in range(len(violations)):
                temp_dict = {}
                if "ViolationSuspensionDate" in violations[i] and violations[i]["ViolationSuspensionDate"] is not None:
                    temp_dict["MVRViolationDate"] = f"{violations[i]['ViolationSuspensionDate']['Month']}/{violations[i]['ViolationSuspensionDate']['Day']}/{violations[i]['ViolationSuspensionDate']['Year']}"
                if "Description" in violations[i] and violations[i]["Description"] is not None:
                    temp_dict["ViolationDescription"] = violations[i]["Description"]
                if "StandardViolations" in violations[i] and violations[i]["StandardViolations"] is not None:
                    temp_dict["StandardViolationType"] = violations[i]["StandardViolations"][0]['CustomerSpecificCode']
                
                
                mvr_violations.append(temp_dict)

            # payload_json["MVRViolations"] = mvr_violations
                    
        def remove_duplicate_dictionaries(dict_list):
                """
                Removes duplicate dictionaries from a list based on 'ViolationDescription', date, and other fields.
                """
                seen = set()
                unique_dicts = []
                for d in dict_list:
                    # Create a tuple of the values to check for uniqueness
                    identifier = (d.get("ViolationDescription"), d.get("MVRViolationDate"), d.get("StandardViolationType"))
                    if identifier not in seen:
                        seen.add(identifier)
                        unique_dicts.append(d)
                return unique_dicts

                # Remove duplicates based on 'ViolationDescription', 'MVRViolationDate' and 'StandardViolationType'
            
            
        payload_json["MVRViolations"] = remove_duplicate_dictionaries(mvr_violations)
        return payload_json
    except json.JSONDecodeError as e:
        print(f"MVR JSON decode error: {e}")
        return {}
    

# MIB Content
def get_mib_content(input_file_name):
    """
    Extracts data from JSON and returns a dictionary
    """
    try:
        mib_fields = {}
        codes = []
        if not os.path.exists(input_file_name):
            return {}
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            if not content:
                return {}
            data = json.loads(content)
            data_dict = data["Content"]

            if "Relation" in data_dict["OLifE"]:
                for i in range(len(data_dict["OLifE"]["Relation"])):
                    if "RelationRoleCode" in data_dict["OLifE"]["Relation"][i]:
                        if "#text" in data_dict["OLifE"]["Relation"][i]["RelationRoleCode"]:
                            mib_fields["Hit/Try"] = data_dict["OLifE"]["Relation"][i]["RelationRoleCode"]["#text"]
                            break
            
            mib_fields["Face_Amount"] = 0  # Default to zero
            if "Holding" in data_dict["OLifE"]:
                if isinstance(data_dict["OLifE"]["Holding"], list):
                    for i in range(len(data_dict["OLifE"]["Holding"])):
                        if "Policy" in data_dict["OLifE"]["Holding"][i]:
                            if "Life" in data_dict["OLifE"]["Holding"][i]["Policy"]:
                                if "FaceAmt" in data_dict["OLifE"]["Holding"][i]["Policy"]["Life"]:
                                    mib_fields["Face_Amount"] = data_dict["OLifE"]["Holding"][i]["Policy"]["Life"]["FaceAmt"]
                                    break
                elif isinstance(data_dict["OLifE"]["Holding"], dict):
                    if "Policy" in data_dict["OLifE"]["Holding"]:
                        if "Life" in data_dict["OLifE"]["Holding"]["Policy"]:
                            if "FaceAmt" in data_dict["OLifE"]["Holding"]["Policy"]["Life"]:
                                mib_fields["Face_Amount"] = data_dict["OLifE"]["Holding"]["Policy"]["Life"]["FaceAmt"]  

            if "FormInstance" in data_dict["OLifE"]:
                #print("Found FormInstance")
                if not isinstance(data_dict["OLifE"]["FormInstance"], list):
                    if "FormResponse" in data_dict["OLifE"]["FormInstance"]:
                        #print("Found FormResponse")
                        mib_fields["SubmitDate"] = data_dict["OLifE"]["FormInstance"]["SubmitDate"]
                        if isinstance(data_dict["OLifE"]["FormInstance"]["FormResponse"], list):
                            for i in range(len(data_dict["OLifE"]["FormInstance"]["FormResponse"])):
                                #print("Found FormResponse") 
                                mib_temp = {}  
                                if "ResponseData" in data_dict["OLifE"]["FormInstance"]["FormResponse"][i]:
                                    mib_temp["MIBCode"] = data_dict["OLifE"]["FormInstance"]["FormResponse"][i]["ResponseData"]
                                if "MiBCodeMeaning" in data_dict["OLifE"]["FormInstance"]["FormResponse"][i]:
                                    mib_temp["MiBCodeMeaning"] = data_dict["OLifE"]["FormInstance"]["FormResponse"][i]["MiBCodeMeaning"]

                                codes.append(mib_temp)
                        else:
                            mib_temp = {} 
                            if "ResponseData" in data_dict["OLifE"]["FormInstance"]["FormResponse"]:
                                mib_temp["MIBCode"] = data_dict["OLifE"]["FormInstance"]["FormResponse"]["ResponseData"]
                                
                            if "MiBCodeMeaning" in data_dict["OLifE"]["FormInstance"]["FormResponse"]:
                                mib_temp["MiBCodeMeaning"] = data_dict["OLifE"]["FormInstance"]["FormResponse"]["MiBCodeMeaning"]

                            if mib_temp:
                                codes.append(mib_temp)
                                
                else:
                    for i in range(len(data_dict["OLifE"]["FormInstance"])):
                        if "FormResponse" in data_dict["OLifE"]["FormInstance"][i]:
                            #print("Found FormResponse")
                            if "SubmitDate" in data_dict["OLifE"]["FormInstance"][i]:
                                mib_fields["SubmitDate"] = data_dict["OLifE"]["FormInstance"][i]["SubmitDate"]
                            if isinstance(data_dict["OLifE"]["FormInstance"][i]["FormResponse"], list):
                                for j in range(len(data_dict["OLifE"]["FormInstance"][i]["FormResponse"])):
                                    #print("Found FormResponse") 
                                    mib_temp = {}  
                                    if "ResponseData" in data_dict["OLifE"]["FormInstance"][i]["FormResponse"][j]:
                                        mib_temp["MIBCode"] = data_dict["OLifE"]["FormInstance"][i]["FormResponse"][j]["ResponseData"]
                                    
                                    if "MiBCodeMeaning" in data_dict["OLifE"]["FormInstance"][i]["FormResponse"][j]:
                                        mib_temp["MiBCodeMeaning"] = data_dict["OLifE"]["FormInstance"][i]["FormResponse"][j]["MiBCodeMeaning"]

                                    #print(mib_temp)
                                    codes.append(mib_temp)

                            else:
                                mib_temp = {} 
                                if "ResponseData" in data_dict["OLifE"]["FormInstance"][i]["FormResponse"]:
                                    mib_temp["MIBCode"] = data_dict["OLifE"]["FormInstance"][i]["FormResponse"]["ResponseData"]
                                    
                                if "MiBCodeMeaning" in data_dict["OLifE"]["FormInstance"][i]["FormResponse"]:
                                    mib_temp["MiBCodeMeaning"] = data_dict["OLifE"]["FormInstance"][i]["FormResponse"]["MiBCodeMeaning"]

                                if mib_temp:
                                    codes.append(mib_temp)
                mib_fields["MIBCodes"] = codes
            #print("MIB:", mib_fields)
        return mib_fields
    except Exception as e:
        print(f"Error reading MIB JSON file: {e}")
        # print(f"Error reading MIB JSON file: {e}")
        # print(f"Error type: {type(e)}")
        # print(f"Error details: {traceback.format_exc()}")
        return {}
    

# Merge all
def prepare_context_subset1(partAfile,partBfile,mvr_file, mibfile):
    app_date = date_App(partAfile)
    partA_content = get_partA_content(partAfile)
    partB_content = get_partB_content(partBfile)
    mvr_content = get_mvr_json(mvr_file)
    mib_content = get_mib_content(mibfile)
    output = (
        f"Application Date: {app_date}\n"
        "\nPart A\n"
        f"{partA_content}\n\n"
        "Part B\n"
        f"{partB_content}\n\n"
        "Motor Vehicle Report (MVR)\n"
        f"{mvr_content}\n\n"
        "MIB\n"
        f"{mib_content}\n"
    )
    
    return output

def main():
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    prod_samples_dir = os.path.join(base_dir, 'data_sources_batch3')
    case_folder = "9217470"  # Example case folder, change as neede
    base_folder = os.path.join(prod_samples_dir, case_folder)
    partAfile = os.path.join(base_folder, f"{case_folder}_MWA_BASEPAYLOAD_part_A.json")
    partBfile = os.path.join(base_folder, f"{case_folder}_MWA_BASEPAYLOAD_part_B.json")
    mvrfile = os.path.join(base_folder, f"{case_folder}_modified_MWA_RISKCLASSIFIER.json")
    mibfile = os.path.join(base_folder, f"{case_folder}_modified_MWA_MIB.json")
    print(prepare_context_subset1(partAfile, partBfile, mvrfile, mibfile))

if __name__ == "__main__":
    main()
