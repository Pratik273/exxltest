import pandas as pd
import json
import os

# === USER VARIABLE: Set your Excel file path here ===
EXCEL_FILE = 'data_sources/FAQs_Results_By_Application_with_subset.xlsx'  # Change as needed
OUTPUT_FILE = 'data_sources/dataset_temp.jsonl'  # Change as needed

# Columns to extract
COLUMNS = ['Question', 'Subset', 'Thought', 'Answer']

def excel_to_jsonl(excel_file, output_file, columns):
    # Load the Excel file and get all sheet names
    xls = pd.ExcelFile(excel_file)
    all_sheets = xls.sheet_names
    
    with open(output_file, 'w', encoding='utf-8') as f_out:
        for sheet in all_sheets:
            df = pd.read_excel(xls, sheet_name=sheet)
            # Only keep rows where all required columns are present and not null
            if not all(col in df.columns for col in columns):
                print(f"Skipping sheet '{sheet}' (missing columns)")
                continue
            for _, row in df.iterrows():
                # Skip rows with missing values in any of the required columns
                if any(pd.isna(row[col]) for col in columns):
                    continue
                entry = {col: str(row[col]).strip() for col in columns}
                f_out.write(json.dumps(entry, ensure_ascii=False) + '\n')
    print(f"Done! Output written to {output_file}")

if __name__ == '__main__':
    excel_to_jsonl(EXCEL_FILE, OUTPUT_FILE, COLUMNS) 