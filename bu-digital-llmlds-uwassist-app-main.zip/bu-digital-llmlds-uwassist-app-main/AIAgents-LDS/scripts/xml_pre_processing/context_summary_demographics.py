import json
import os
import re
from context_subset1 import prepare_context_subset1, get_mvr_json

def extract_mvr_essentials_from_large_file(raw_content):
    """
    Fast extraction of essential MVR information from large files using regex patterns.
    Returns formatted MVR data that LLM can process without expensive JSON parsing.
    """
    try:
        # Initialize extracted information
        extracted_info = []
        
        # === EXTRACT RISK CLASSIFIER SCORE ===
        score_patterns = [
            r'"Score":\s*(\d+)',
            r'"Score":\s*"(\d+)"',
            r'Score.*?(\d{3,4})',  # 3-4 digit scores
        ]
        
        score = None
        for pattern in score_patterns:
            score_matches = re.findall(pattern, raw_content, re.IGNORECASE)
            if score_matches:
                score = score_matches[0]
                break
        
        if score:
            extracted_info.append(f"=== RISK CLASSIFIER SCORE ===\nScore: {score}\n")
        
        # === EXTRACT MVR STATUS ===
        mvr_status_patterns = [
            r'"MVRStatus":\s*(\d+)',
            r'"MVRStatus":\s*"([^"]+)"',
            r'MVRStatus.*?(\d+)',
        ]
        
        mvr_status_mapping = {
            "1": "Valid", "2": "Suspended", "3": "Revoked", "4": "Expired", "5": "Cancelled",
            "6": "Denied", "7": "Limited", "8": "Military", "9": "ID Only",
            "A": "Disqualified", "B": "Eligible", "D": "Deceased", 
            "U": "Unavailable", "X": "No valid LIC"
        }
        
        mvr_status = None
        for pattern in mvr_status_patterns:
            status_matches = re.findall(pattern, raw_content, re.IGNORECASE)
            if status_matches:
                status_code = str(status_matches[0])
                status_text = mvr_status_mapping.get(status_code, f"Status {status_code}")
                mvr_status = f"MVR Status: {status_code} ({status_text})"
                break
        
        # === EXTRACT STATE INFORMATION ===
        state_patterns = [
            r'"StatePostalCode":\s*"([^"]+)"',
            r'"State":\s*"([^"]+)"',
            r'StatePostalCode.*?"([A-Z]{2})"',
        ]
        
        state_info = None
        for pattern in state_patterns:
            state_matches = re.findall(pattern, raw_content, re.IGNORECASE)
            if state_matches:
                state_info = f"State: {state_matches[0]}"
                break
        
        # === EXTRACT VIOLATIONS FROM MVRViolations SECTION ONLY ===
        mvr_violations_pattern = r'"MVRViolations":\s*\[(.*?)\]'
        mvr_violations_match = re.search(mvr_violations_pattern, raw_content, re.DOTALL | re.IGNORECASE)
        
        violations = []
        if mvr_violations_match:
            mvr_violations_section = mvr_violations_match.group(1)
            
            # Extract violation descriptions ONLY from StandardViolations within MVRViolations section
            standard_violation_pattern = r'"StandardViolationCodeDesc":\s*"([^"]+)"'
            violation_matches = re.findall(standard_violation_pattern, mvr_violations_section, re.IGNORECASE)
            
            # Filter out placeholder/generic descriptions
            filtered_violations = []
            for violation in violation_matches[:20]:  # Limit to prevent huge datasets
                # Skip generic placeholder descriptions
                if not any(keyword in violation.upper() for keyword in [
                    'LEXISNEXIS CLEAR', 'VIOLATION_RECORD_INFO', 'PLACEHOLDER'
                ]):
                    filtered_violations.append(violation)
            
            violations = filtered_violations[:10]  # Limit to top 10
            
            # If no meaningful violations found in StandardViolationCodeDesc, try ViolationDescriptions
            if not violations:
                violation_desc_pattern = r'"ViolationDescriptions":\s*"([^"]+)"'
                desc_matches = re.findall(violation_desc_pattern, mvr_violations_section, re.IGNORECASE)
                # Filter out placeholder descriptions
                for desc in desc_matches[:10]:
                    if not any(keyword in desc.upper() for keyword in [
                        'VIOLATION_RECORD_INFO', 'PLACEHOLDER', '_'
                    ]):
                        violations.append(desc)
        
        # Remove duplicates while preserving order
        unique_violations = []
        seen = set()
        for violation in violations:
            if violation.lower() not in seen:
                unique_violations.append(violation)
                seen.add(violation.lower())
                if len(unique_violations) >= 5:  # Limit to top 5
                    break
        
        # === GENERATE OUTPUT ===
        if mvr_status or state_info:
            extracted_info.append("=== MVR PROCESSING INFORMATION ===")
            if mvr_status:
                extracted_info.append(mvr_status)
            if state_info:
                extracted_info.append(state_info)
            extracted_info.append("")
        
        # Violations summary
        if unique_violations:
            extracted_info.append("=== MVR VIOLATIONS ===")
            for idx, violation in enumerate(unique_violations, 1):
                extracted_info.append(f"Violation {idx}: {violation}")
            extracted_info.append(f"\nSummary: {len(unique_violations)} unique violations found")
            extracted_info.append("")
        else:
            extracted_info.append("=== MVR VIOLATIONS ===")
            extracted_info.append("No violations found\n")
        
        # Data summary
        # extracted_info.append("=== MVR DATA SUMMARY ===")
        # extracted_info.append(f"Total MVR data size: {len(raw_content):,} characters")
        # extracted_info.append(f"Unique violations processed: {len(unique_violations)}")
        if mvr_status:
            extracted_info.append(f"License status: {mvr_status.split(': ')[1] if ': ' in mvr_status else 'Unknown'}")
        
        if extracted_info:
            return "\n".join(extracted_info)
        else:
            return f"MVR Data Available: {len(raw_content)} characters of MVR information"
            
    except Exception as e:
        print(f"Error extracting MVR essentials: {e}")
        return f"MVR Data Available (error processing): {len(raw_content)} characters"

def prepare_context_demographics(partAfile, partBfile, mvrfile, mibfile):
    """
    Prepare demographics context using context_subset1 functions and enhanced MVR processing.
    Focuses on demographic and lifestyle information for risk assessment.
    """
    try:
        # Use the existing context_subset1 function as base
        base_context = prepare_context_subset1(partAfile, partBfile, mvrfile, mibfile)
        
        # Enhanced MVR processing for large files
        if os.path.exists(mvrfile):
            try:
                with open(mvrfile, 'r', encoding='utf-8') as f:
                    raw_content = f.read()
                
                # If file is too large, use fast pattern extraction
                if len(raw_content) > 1_000_000:  # 1MB limit
                    enhanced_mvr = extract_mvr_essentials_from_large_file(raw_content)
                    # Replace the MVR section in base_context with enhanced version
                    if "Motor Vehicle Report (MVR)" in base_context:
                        parts = base_context.split("Motor Vehicle Report (MVR)")
                        if len(parts) >= 2:
                            mvr_end = parts[1].find("\n\nMIB")
                            if mvr_end != -1:
                                enhanced_context = (
                                    parts[0] + 
                                    "Motor Vehicle Report (MVR)\n" + 
                                    enhanced_mvr + 
                                    parts[1][mvr_end:]
                                )
                                return enhanced_context
                
            except Exception as e:
                print(f"Error enhancing MVR processing: {e}")
        
        return base_context
        
    except Exception as e:
        print(f"Error preparing demographics context: {e}")
        return f"Error processing demographics context: {str(e)}" 