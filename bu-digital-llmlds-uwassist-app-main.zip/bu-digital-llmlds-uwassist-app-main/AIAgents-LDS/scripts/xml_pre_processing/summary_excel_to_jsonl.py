import pandas as pd
import json
import os
from summary_application_processor import process_single_application_from_excel_row, write_jsonl_entries_to_file

# === USER VARIABLE: Set your Excel file path here ===
EXCEL_FILE = 'summary_results_100_2.xlsx'  # Change as needed
OUTPUT_FILE = 'data_sources/summary_dataset.jsonl'  # Change as needed
ERROR_LOG_FILE = 'data_sources/summary_error_log.txt'

# Normalized columns to extract (all lowercase, no spaces)
APP_NUMBER_COL = 'applicationnumber'
DEMOGRAPHICS_SUMMARY_COL = 'demographicssummary'
MEDICAL_SUMMARY_COL = 'medicalsummary'
OVERALL_SUMMARY_COL = 'overallsummary'
STATUS_COL = 'status'

# Clear the error log at the start of each run
open(ERROR_LOG_FILE, 'w').close()

def log_error(message):
    print(message)
    with open(ERROR_LOG_FILE, 'a', encoding='utf-8') as err_f:
        err_f.write(message + '\n')

def normalize_columns(df):
    df.columns = [str(col).strip().replace(' ', '').lower() for col in df.columns]
    return df

def process_summary_excel(excel_file, output_file, sheet_names_to_process=None, batch_dir="data_sources_batch4"):
    """
    Process summary results Excel file and generate JSONL entries for each application.
    
    Args:
        excel_file (str): Path to the Excel file
        output_file (str): Output JSONL file path
        sheet_names_to_process (list): List of sheet names to process (None for all)
        batch_dir (str): Directory containing application data
    """
    xls = pd.ExcelFile(excel_file)
    sheet_names = xls.sheet_names
    
    if sheet_names_to_process is not None:
        sheet_names = [s for s in sheet_names if s in sheet_names_to_process]
    
    # Build a mapping from stripped folder name to actual folder name
    folder_map = {}
    for folder_name in os.listdir(batch_dir):
        if os.path.isdir(os.path.join(batch_dir, folder_name)):
            folder_map[folder_name.strip()] = folder_name
    
    total_entries = 0
    
    with open(output_file, 'w', encoding='utf-8') as f_out:
        for sheet in sheet_names:
            try:
                print(f"Processing sheet: {sheet}")
                df = pd.read_excel(xls, sheet_name=sheet)
                df = normalize_columns(df)
                
                # Use the mapping to get the actual folder name (with spaces if present)
                real_folder = folder_map.get(sheet.strip())
                if not real_folder:
                    log_error(f"Warning: No folder found for application '{sheet}' (after stripping spaces)")
                    continue
                
                # Process each row in the sheet
                for idx, row in df.iterrows():
                    try:
                        # Skip rows with missing required fields
                        if pd.isna(row.get(APP_NUMBER_COL)):
                            continue
                        
                        # Process the application using the common processor
                        jsonl_entries = process_single_application_from_excel_row(row, batch_dir)
                        
                        # Write entries to file
                        for entry in jsonl_entries:
                            f_out.write(json.dumps(entry, ensure_ascii=False) + '\n')
                            total_entries += 1
                        
                        if jsonl_entries:
                            print(f"  Processed application {row.get(APP_NUMBER_COL)}: {len(jsonl_entries)} entries")
                        
                    except Exception as e:
                        app_number = row.get(APP_NUMBER_COL, 'Unknown')
                        error_msg = f"Error processing application {app_number} in sheet {sheet}: {e}"
                        log_error(error_msg)
                        print(error_msg)
                        continue
                
            except Exception as e:
                error_msg = f"Error processing sheet '{sheet}': {e}"
                log_error(error_msg)
                print(error_msg)
                continue
    
    print(f"Done! Total entries written to {output_file}: {total_entries}")

def process_specific_applications(excel_file, output_file, application_numbers, batch_dir="data_sources_batch4"):
    """
    Process specific applications from the Excel file.
    
    Args:
        excel_file (str): Path to the Excel file
        output_file (str): Output JSONL file path
        application_numbers (list): List of application numbers to process
        batch_dir (str): Directory containing application data
    """
    xls = pd.ExcelFile(excel_file)
    sheet_names = xls.sheet_names
    
    total_entries = 0
    
    with open(output_file, 'w', encoding='utf-8') as f_out:
        for sheet in sheet_names:
            try:
                # Check if this sheet contains any of the target applications
                df = pd.read_excel(xls, sheet_name=sheet)
                df = normalize_columns(df)
                
                # Filter for target applications
                target_rows = df[df[APP_NUMBER_COL].isin(application_numbers)]
                
                if not target_rows.empty:
                    print(f"Processing {len(target_rows)} applications from sheet: {sheet}")
                    
                    for idx, row in target_rows.iterrows():
                        try:
                            # Process the application using the common processor
                            jsonl_entries = process_single_application_from_excel_row(row, batch_dir)
                            
                            # Write entries to file
                            for entry in jsonl_entries:
                                f_out.write(json.dumps(entry, ensure_ascii=False) + '\n')
                                total_entries += 1
                            
                            if jsonl_entries:
                                print(f"  Processed application {row.get(APP_NUMBER_COL)}: {len(jsonl_entries)} entries")
                            
                        except Exception as e:
                            app_number = row.get(APP_NUMBER_COL, 'Unknown')
                            error_msg = f"Error processing application {app_number} in sheet {sheet}: {e}"
                            log_error(error_msg)
                            print(error_msg)
                            continue
                
            except Exception as e:
                error_msg = f"Error processing sheet '{sheet}': {e}"
                log_error(error_msg)
                print(error_msg)
                continue
    
    print(f"Done! Total entries written to {output_file}: {total_entries}")

if __name__ == '__main__':
    # Process all sheets
    process_summary_excel(EXCEL_FILE, OUTPUT_FILE)
    
    # Or process specific applications
    # specific_apps = ["9223266", "9223171", "9222551"]
    # process_specific_applications(EXCEL_FILE, OUTPUT_FILE, specific_apps)
    
    # Or process specific sheets
    # specific_sheets = ["Summary 2", "Summary 3"]
    # process_summary_excel(EXCEL_FILE, OUTPUT_FILE, specific_sheets) 