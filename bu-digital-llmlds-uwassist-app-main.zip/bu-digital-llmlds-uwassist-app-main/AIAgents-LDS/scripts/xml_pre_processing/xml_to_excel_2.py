import xmltodict
import json
import pandas as pd
import openpyxl
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter
from main import mib_parsing
import os
import sys
import chardet
from requirements_handler import format_requirements_for_excel
from collections import defaultdict

def extract_keys(data, keys):
    """
    Extracts specific keys from a dictionary and returns them as a new dictionary.
    """
    extracted_data = {}
    for key in keys:
        if key in data:
            extracted_data[key] = data[key]
    return extracted_data


# xml_file = "data_source/Q34414-89/Q34414-89_MWA_MIB.xml"
# xml_data = get_mib_xml(xml_file)
# print(xml_data)

def get_basepayload_json(input_file_name):
    """
    Extracts data from a JSON file and returns it as a list of dictionaries.
    """
    try:
        requirements = []
        payload_json = {}
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            # print(f"Content: {content}")
            if not content:
                return {}, []  # Return empty dict for empty file
            data_dict = json.loads(content)
            payload_json = extract_keys(data_dict, ["CertificateNumber", "Gender", "USCitizen", "AgeAtWrittenDate", "Age", "Occupation", "HeightInchesTotal", "Weight", "WeightLoss", "WeightLossReason", "InsuranceIssuedPastYear", "LiabilityAmount", "ExistingMwaInsuranceAmount" , "BeneficiaryTypes"])
            payload_json["Impairment"] = data_dict["EAppJson"]["Impairment1"]
            payload_json["Height"] = f"{data_dict['HeightFeetInteger']} feet {data_dict['HeightInchesRemainder']} inches"
            payload_json["BMI"] = str(round(float((int(data_dict["Weight"]) * 703) / (int(data_dict["HeightInchesTotal"]) ** 2) ), 1))
            payload_json["TobaccoUse"] = f"{data_dict['TobaccoStatus']}, 12 months: {data_dict['Nicotine12Months']}, 36 months: {data_dict['Nicotine36Months']}"
            
            # Store requirements list separately instead of adding to payload
            requirements = data_dict["Requirements"]
            
            return payload_json, requirements
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}")
        return {}, []

def put_dict_in_excel(json_data, output_file_path, sheet_name):
    """
    From the JSON payload, extracts relevant data, transforms it and puts it in Excel.
    If the Excel file already exists, it will append columns to the existing data.
    If the sheet name is new, it will create a new sheet.
    """
    try:     
        # If json_data is None, empty dict, or empty list, skip processing
        if json_data is None or (isinstance(json_data, dict) and not json_data) or (isinstance(json_data, list) and not json_data):
            print(f"No data to export for '{sheet_name}' sheet (data was empty)")
            return False
            
        # If json_data is a single dictionary, convert to a list
        if isinstance(json_data, dict):
            base_df = pd.DataFrame([json_data])
        elif isinstance(json_data, pd.DataFrame):
            # If it's already a DataFrame, use it directly
            base_df = json_data
        else:
            # For lists and other iterable types
            base_df = pd.DataFrame(json_data)
            
        # If DataFrame is empty after conversion, skip processing
        if base_df.empty:
            print(f"No data to export for '{sheet_name}' sheet (DataFrame was empty)")
            return False
            
        # Convert string boolean values to proper Excel boolean values
        boolean_columns = ["USCitizen"]  # Add any other columns that should be boolean
        for col in boolean_columns:
            if col in base_df.columns:
                # Convert string 'true'/'false' to Excel-compatible boolean values
                base_df[col] = base_df[col].map(lambda x: 
                    "TRUE" if str(x).lower() == 'true' else 
                    "FALSE" if str(x).lower() == 'false' else x)
        
        # Clean column names
        base_df.columns = [str(col).replace('[', '_').replace(']', '_').replace('@', '').replace(':', '_') for col in base_df.columns]
        
        # Check if the file and specific sheet already exist
        file_exists = os.path.exists(output_file_path)
        sheet_exists = False
        combined_df = base_df  # Default to using base_df
        
        if file_exists:
            try:
                # Check if this specific sheet already exists
                with pd.ExcelFile(output_file_path) as xls:
                    if sheet_name in xls.sheet_names:
                        sheet_exists = True
                        
                        # Read existing sheet
                        existing_df = pd.read_excel(output_file_path, sheet_name=sheet_name)
                        
                        # For each column in base_df, add it to the existing dataframe
                        # If the existing df has fewer rows, we'll need to pad it
                        if len(existing_df) < len(base_df):
                            # Pad existing_df with NaN values to match base_df's row count
                            existing_df = existing_df.reindex(range(len(base_df)))
                        
                        # If base_df has fewer rows, pad it
                        if len(base_df) < len(existing_df):
                            base_df = base_df.reindex(range(len(existing_df)))
                        
                        # Combine the dataframes
                        # First, identify columns that are already in existing_df to avoid duplicates
                        new_columns = [col for col in base_df.columns if col not in existing_df.columns]
                        
                        # Add each new column from base_df to the existing dataframe
                        for col in new_columns:
                            existing_df[col] = base_df[col]
                        
                        # Use the combined dataframe
                        combined_df = existing_df
            except Exception as e:
                print(f"Warning: Issue reading existing sheet: {e}")
                # We'll use the base_df by default if there's an issue
        
        # Clean all column names again to ensure they're Excel-compatible
        combined_df.columns = [str(col).replace('[', '_').replace(']', '_').replace('@', '').replace(':', '_') for col in combined_df.columns]
        
        # Determine the Excel writer mode based on whether the file exists
        mode = 'a' if file_exists else 'w'
        if_sheet_exists = 'replace' if sheet_exists else None
        
        # Create Excel writer
        with pd.ExcelWriter(output_file_path, engine='openpyxl', mode=mode, if_sheet_exists=if_sheet_exists) as writer:
            # Write DataFrame to Excel
            combined_df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            # Auto-adjust columns' width
            worksheet = writer.sheets[sheet_name]
            for idx, col in enumerate(combined_df.columns):
                # Calculate the maximum width needed
                max_length = 0
                for value in combined_df[col].dropna():
                    # For each value, find the longest line if it contains newlines
                    lines = str(value).split('\n')
                    for line in lines:
                        max_length = max(max_length, len(line))
                
                # Also consider column header length
                max_length = max(max_length, len(str(col))) + 2  # Add extra space
                
                try:
                    # Use a safer approach to get column letter
                    col_idx = idx + 1
                    if col_idx > 0:  # Ensure positive column index
                        col_letter = get_column_letter(col_idx)
                        # Set column width (limit to reasonable maximum)
                        worksheet.column_dimensions[col_letter].width = min(max_length, 50)
                except Exception as e:
                    print(f"Warning: Could not set width for column {idx+1}: {e}")
                    continue
                
                # Special formatting for boolean values to ensure they show as TRUE/FALSE
                if col in boolean_columns:
                    for row_idx in range(2, len(combined_df) + 2):  # +2 for header and 1-indexing
                        cell = worksheet.cell(row=row_idx, column=idx+1)
                        if cell.value is True:
                            cell.value = "TRUE"
                        elif cell.value is False:
                            cell.value = "FALSE"

        #print(f"Single column data exported successfully to {output_file_path}, sheet {sheet_name}")
        return True
        
    except Exception as e:
        print(f"Error exporting base payload data to Excel: {e}")
        import traceback
        traceback.print_exc()
        return False

    
def get_healthresults_xml(input_file_name):
    """
    Extracts data from an XML file and returns it as a list of dictionaries.
    """
    try:
        with open(input_file_name) as xml_file:
            data_dict = xmltodict.parse(xml_file.read())
            json_data = json.loads(json.dumps(data_dict))
 
        # Store the XML data in a JSON file
        # with open("data_source/prod_samples/9218062/9218062_MWA_HEALTHRESULTS.json", "w") as json_file:
        #     json.dump(json_data, json_file, indent=4)
            return json_data
 
    except UnicodeDecodeError:
        # Fallback: detect encoding
        with open(input_file_name, 'rb') as f:
            raw_data = f.read()
            result = chardet.detect(raw_data)
            detected_encoding = result['encoding']
            print(f"[Fallback] {input_file_name}: Detected {detected_encoding}")
 
        # Read with detected encoding (replace bad bytes)
        xml_new_file = raw_data.decode(detected_encoding or 'utf-8', errors='replace')
        data_dict = xmltodict.parse(xml_new_file)
        json_data = json.loads(json.dumps(data_dict))
        return json_data
 
    except Exception as e:
        print(f"Error reading XML file: {e}")
        return {}

def get_health_json(input_file_name):
    """
    Extracts data from a JSON file and returns it as a list of dictionaries.
    """
    try:
        payload_json = []
        health_cause = []
        data_dict = get_healthresults_xml(input_file_name)
        
        # Keep track of processed prescription labels and their fill dates
        prescription_fills = defaultdict(list)
        drug_details = {}

        physicians = []
        for item in data_dict["TXLife"]["TXLifeRequest"]["OLifE"]["Party"]:
            if "Physician" in item:
                physicians.append(item)
        physician_dict = {phy.get('@id'): phy for phy in physicians}

        # First, find all health causes across all parties
        for item in data_dict["TXLife"]["TXLifeRequest"]["OLifE"]["Party"]:
            if "Risk" in item and "OLifEExtension" in item["Risk"]:
                extension = item["Risk"]["OLifEExtension"]
                if isinstance(extension, list):
                    for ext_item in extension:
                        if isinstance(ext_item, dict) and "DrugDetail" in ext_item:
                            if isinstance(ext_item["DrugDetail"]["Drug"], list):
                                health_cause = ext_item["DrugDetail"]["Drug"]
                                break
                elif isinstance(extension, dict) and "DrugDetail" in extension:
                    if isinstance(extension["DrugDetail"]["Drug"], list):
                        health_cause = extension["DrugDetail"]["Drug"]
                    else:
                        health_cause = [extension["DrugDetail"]["Drug"]]

        # Collect all fill dates and details for each prescription
        for item in data_dict["TXLife"]["TXLifeRequest"]["OLifE"]["Party"]:
            if "Risk" in item and "PrescriptionDrug" in item["Risk"]:
                health = item["Risk"]["PrescriptionDrug"]
                if not isinstance(health, list):
                    health = [health]
                for drug in health:
                    if "PrescriptionLabel" not in drug:
                        continue
                    prescription_label = str(drug["PrescriptionLabel"])
                    fill_date = None
                    if "PrescriptionFill" in drug and "PrescriptionFillDate" in drug["PrescriptionFill"]:
                        fill_date = drug["PrescriptionFill"]["PrescriptionFillDate"]
                    if fill_date:
                        prescription_fills[prescription_label].append(fill_date)
                    # Save the latest drug details for this label (will use for output)
                    drug_details[prescription_label] = drug

        # Now build the output
        for prescription_label, fill_dates in prescription_fills.items():
            results = {}
            drug = drug_details[prescription_label]
            results["PrescriptionLabel"] = prescription_label
            results["RefillsAllowed"] = len(fill_dates)
            if "PrescriptionDaysSupply" in drug:
                results["PrescriptionDaysSupply"] = drug["PrescriptionDaysSupply"]

            # Set first/last filled dates as required
            fill_dates_sorted = sorted(fill_dates)
            results["DateFirstFilled"] = fill_dates_sorted[0]
            if len(fill_dates_sorted) > 1:
                results["DateLastFilled"] = fill_dates_sorted[-1]

            # Dose information
            if ("PrescriptionFill" in drug and 
                "OLifEExtension" in drug["PrescriptionFill"] and 
                "PrescriptionStrength" in drug["PrescriptionFill"]["OLifEExtension"]):
                results["Dose"] = drug["PrescriptionFill"]["OLifEExtension"]["PrescriptionStrength"]

            # Drug class
            if "TherapeuticClass" in drug and "#text" in drug["TherapeuticClass"]:
                results["DrugClass"] = drug["TherapeuticClass"]["#text"]

            # Add physician information
            if "PrescriptionFill" in drug and "@PhysicianID" in drug["PrescriptionFill"]:
                physician_id = drug["PrescriptionFill"]["@PhysicianID"]
                physician = physician_dict.get(physician_id)
                if physician:
                    results["PhysicianID"] = physician_id
                    if "Person" in physician:
                        results["PhysicianTitle"] = physician['Person'].get('Title', '')
                    if "Physician" in physician:
                        if "PhysicianInfo" in physician["Physician"]:
                            if "OLifEExtension" in physician["Physician"]["PhysicianInfo"]:
                                specialities = []
                                if isinstance(physician["Physician"]["PhysicianInfo"]["OLifEExtension"], list):
                                    for phy in range(len(physician["Physician"]["PhysicianInfo"]["OLifEExtension"])):
                                        specialities.append(physician["Physician"]["PhysicianInfo"]["OLifEExtension"][phy]["PhysicianSpecialty"])
                                    results["PhysicianSpecialties"] = specialities
                                elif isinstance(physician["Physician"]["PhysicianInfo"]["OLifEExtension"], dict):
                                    if isinstance(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"], dict):
                                        specialities.append(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"])
                                        results["PhysicianSpecialties"] = specialities
                                    elif isinstance(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"], list):
                                        for phy in range(len(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"])):
                                            specialities.append(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"][phy])
                                        results["PhysicianSpecialties"] = specialities

            # Find matching disease information
            for cause in health_cause:
                if cause.get("DrugLabel") == prescription_label:
                    if "DiseaseDescription" in cause:
                        results["DiseaseDescription"] = str(cause["DiseaseDescription"])
                    break

            payload_json.append(results)

        return payload_json

    except Exception as e:
        print(f"Error processing health data: {e}")
        import traceback
        traceback.print_exc()
        return []

def get_potential_conditions(input_file_name):
    """
    Extracts potential conditions from a JSON file and returns them as a list of dictionaries.
    """
    try:
        data_dict = get_healthresults_xml(input_file_name)
        # print(data_dict)
        conditions = []
        # First, find all health causes across all parties
        for item in data_dict["TXLife"]["TXLifeRequest"]["OLifE"]["Party"]:
            if "Risk" in item and "OLifEExtension" in item["Risk"]:
                extension = item["Risk"]["OLifEExtension"]
                for i, key in enumerate(extension):
                    #print("Found HealthPiQturePotentialConditions")
                    if "HealthPiQturePotentialConditions" in key:
                        conditions = item["Risk"]["OLifEExtension"][i]["HealthPiQturePotentialConditions"]["PotentialCondition"]
                        break
                        
                    
        return conditions
    except Exception as e:
        print(f"Error processing potential conditions: {e}")
        import traceback
        traceback.print_exc()
        return []
            
def get_health_scores(input_file_name):
    """
    Extracts health scores from a JSON file and returns them as a list of dictionaries.
    """
    try:
        data_dict = get_healthresults_xml(input_file_name)
        # print(data_dict)
        scores = []
        final_scores = {}
        contributing_factors = []
        # First, find all health causes across all parties
        for item in data_dict["TXLife"]["TXLifeRequest"]["OLifE"]["Party"]:
            if "Risk" in item and "OLifEExtension" in item["Risk"]:
                extension = item["Risk"]["OLifEExtension"]
                for i, key in enumerate(extension):
                    if "TotalTherapeuticClassScore" in key:
                        #print("Found TotalTherapeuticClassScore")
                        final_scores["TherapeuticClassScore"] = item["Risk"]["OLifEExtension"][i]["TotalTherapeuticClassScore"]
                        
                    if "RiskScoring" in key:
                        #print("Found RiskScoring")
                        if "RiskScore" in item["Risk"]["OLifEExtension"][i]["RiskScoring"]:
                        
                            scores = item["Risk"]["OLifEExtension"][i]["RiskScoring"]["RiskScore"]
                        if "ContributingFactors" in item["Risk"]["OLifEExtension"][i]["RiskScoring"]:
                            if "ContributingFactor" in item["Risk"]["OLifEExtension"][i]["RiskScoring"]["ContributingFactors"]:
                                contributing_factors = item["Risk"]["OLifEExtension"][i]["RiskScoring"]["ContributingFactors"]["ContributingFactor"]
                        
                    
        
        for score in scores:
            if score["RiskScoreName"]["#text"] == "MortalityScore":
                final_scores["MortalityScore"] = score["QuantitativeScore"]
                        
                    
        return final_scores, contributing_factors
    except Exception as e:
        print(f"Error processing health scores: {e}")
        import traceback
        traceback.print_exc()
        return {}, []     
    
def get_health_labtests(input_file_name):
    """
    Extracts health lab tests from a JSON file and returns them as a list of dictionaries.
    """
    try:
        data_dict = get_healthresults_xml(input_file_name)
        labtests = []
        for item in data_dict["TXLife"]["TXLifeRequest"]["OLifE"]["Party"]:
            if "Risk" in item and "LabTesting" in item["Risk"]:
                extension = item["Risk"]["LabTesting"]
                if not isinstance(extension, list):
                    extension = [extension]
                for lab in extension:
                    test_date = lab.get("TestDate")
                    labtest_results = lab.get("LabTestResult", [])
                    if isinstance(labtest_results, dict):
                        labtest_results = [labtest_results]
                    for result in labtest_results:
                        temp_lab = {}
                        if test_date:
                            temp_lab["TestDate"] = test_date
                        # Test name
                        if "TestCode" in result:
                            # Sometimes TestCode is a dict with #text
                            if isinstance(result["TestCode"], dict) and "#text" in result["TestCode"]:
                                temp_lab["TestName"] = result["TestCode"]["#text"]
                            else:
                                temp_lab["TestName"] = result["TestCode"]
                        if "ProviderTestCode" in result:
                            temp_lab["ProviderTestCode"] = result["ProviderTestCode"]
                        if "QualitativeResult" in result:
                            temp_lab["QualitativeResult"] = result["QualitativeResult"]
                        if "QuantitativeResult" in result:
                            temp_lab["QuantitativeResult"] = result["QuantitativeResult"]
                        if "LabTestRemark" in result:
                            temp_lab["LabTestRemark"] = result["LabTestRemark"]
                        labtests.append(temp_lab)
        return labtests
    except Exception as e:
        print(f"Error processing health lab tests: {e}")
        import traceback
        traceback.print_exc()
        return []


def put_list_in_excel(json_data, output_file_path, sheet_name):
    """
    From the JSON payload, extracts relevant data, transforms it and adds it as new columns
    to an existing Excel sheet. If the sheet doesn't exist, creates a new one.
    """
    try: 
        # Handle case where json_data is None or empty
        if json_data is None or (isinstance(json_data, dict) and not json_data) or (isinstance(json_data, list) and not json_data):
            print(f"No health data found for sheet '{sheet_name}' - skipping")
            return False
        
        # Create DataFrame from health data
        if isinstance(json_data, list) and json_data:
            # Get all unique keys across all dictionaries
            all_keys = set()
            for item in json_data:
                if isinstance(item, dict):  # Only process dictionary items
                    all_keys.update(item.keys())
            
            # If no valid keys found, skip processing
            if not all_keys:
                print(f"No valid data fields found in list for sheet '{sheet_name}' - skipping")
                return False
                
            # Create a dictionary where each key maps to a list of values from all dictionaries
            data_by_column = {key: [] for key in all_keys}
            
            # For each dictionary in the list, add its values to the appropriate column list
            for item in json_data:
                if not isinstance(item, dict):  # Skip non-dictionary items
                    continue
                    
                for key in all_keys:
                    # If this dictionary has this key, add its value to the list
                    if key in item:
                        data_by_column[key].append(item[key])
                    else:
                        # Add None for missing values to maintain alignment
                        data_by_column[key].append(None)
            
            # Create DataFrame with each column being all values for that key
            health_df = pd.DataFrame(data_by_column)
            
        elif isinstance(json_data, dict) and json_data:
            # If it's a single dictionary, convert to DataFrame with a single row
            health_df = pd.DataFrame([json_data])
        else:
            # Unexpected data type
            print(f"Unexpected data type for sheet '{sheet_name}': {type(json_data)}")
            return False
            
        # If DataFrame is empty after conversion, skip processing
        if health_df.empty:
            print(f"No data to export for '{sheet_name}' sheet (DataFrame was empty)")
            return False

        # Clean column names thoroughly before any Excel operations
        health_df.columns = [str(col).replace('[', '_').replace(']', '_').replace('@', '').replace(':', '_') for col in health_df.columns]
        
        # Check if the file and specific sheet already exist
        file_exists = os.path.exists(output_file_path)
        sheet_exists = False
        combined_df = health_df  # Default to using health_df
        
        if file_exists:
            try:
                # Check if this specific sheet already exists
                with pd.ExcelFile(output_file_path) as xls:
                    if sheet_name in xls.sheet_names:
                        sheet_exists = True
                        
                        # Read existing sheet
                        existing_df = pd.read_excel(output_file_path, sheet_name=sheet_name)
                        
                        # For each column in health_df, add it to the existing dataframe
                        # If the existing df has fewer rows, we'll need to pad it
                        if len(existing_df) < len(health_df):
                            # Pad existing_df with NaN values to match health_df's row count
                            existing_df = existing_df.reindex(range(len(health_df)))
                        
                        # If health_df has fewer rows, pad it
                        if len(health_df) < len(existing_df):
                            health_df = health_df.reindex(range(len(existing_df)))
                        
                        # Add each health column to the existing dataframe
                        for col in health_df.columns:
                            # Add prefix to avoid column name collisions
                            existing_df[f"Health_{col}"] = health_df[col]
                        
                        # Use the combined dataframe
                        combined_df = existing_df
            except Exception as e:
                print(f"Warning: Issue reading existing sheet: {e}")
                # We'll use the health_df by default if there's an issue
        
        # Clean all column names in combined_df to ensure they're Excel-compatible
        combined_df.columns = [str(col).replace('[', '_').replace(']', '_').replace('@', '').replace(':', '_') for col in combined_df.columns]
        
        # Determine the Excel writer mode based on whether the file exists
        mode = 'a' if file_exists else 'w'
        if_sheet_exists = 'replace' if sheet_exists else None
        
        # Write the combined dataframe back to Excel
        with pd.ExcelWriter(output_file_path, engine='openpyxl', mode=mode, if_sheet_exists=if_sheet_exists) as writer:
            # Write DataFrame to Excel
            combined_df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            # Auto-adjust columns' width - use try/except to handle any column issues
            try:
                worksheet = writer.sheets[sheet_name]
                for idx, col in enumerate(combined_df.columns):
                    # Get max length across all values in the column
                    max_length = 0
                    for value in combined_df[col].dropna():
                        # For each value, find the longest line if it contains newlines
                        lines = str(value).split('\n')
                        for line in lines:
                            max_length = max(max_length, len(line))
                    
                    # Also consider column header length
                    max_length = max(max_length, len(str(col))) + 2  # Add extra space
                    
                    try:
                        # Use a safer approach to get column letter
                        col_idx = idx + 1
                        if col_idx > 0:  # Ensure positive column index
                            col_letter = get_column_letter(col_idx)
                            # Set column width (limit to reasonable maximum)
                            worksheet.column_dimensions[col_letter].width = min(max_length, 50)
                    except Exception as e:
                        print(f"Warning: Could not set width for column {idx+1}: {e}")
                        continue
                        
                    # Format cells for all rows
                    for row_idx in range(1, len(combined_df) + 2):  # +2 for header and 1-indexing
                        try:
                            cell = worksheet.cell(row=row_idx, column=idx+1)
                            if cell.value and '\n' in str(cell.value):
                                # Enable text wrapping for cells with newlines
                                cell.alignment = Alignment(wrap_text=True, vertical='top')
                                
                                # Set row height based on number of lines
                                num_lines = str(cell.value).count('\n') + 1
                                worksheet.row_dimensions[row_idx].height = max(15 * num_lines, 15)
                        except Exception as e:
                            print(f"Warning: Could not format cell at row {row_idx}, column {idx+1}: {e}")
                            continue
            except Exception as e:
                print(f"Warning: Could not format worksheet: {e}")
                
        #print(f"Combined column data exported successfully to {output_file_path}, sheet {sheet_name}")
        return True
        
    except Exception as e:
        print(f"Error exporting health data to Excel: {e}")
        import traceback
        traceback.print_exc()
        return False
    
def get_mvr_json(input_file_name):
    """
    Extracts data from a JSON file and returns it as a list of dictionaries.
    """
    try:
        payload_json = {}
        violations = []
        mvr_violations = []
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            print("Successfully read MVR file")
            # print(f"Content: {content}")
            if not content:
                return {}  # Return empty dict for empty file
            data_dict = json.loads(content)
            # print(f"Data Dict: {data_dict}")

            if "ScoreResult" in data_dict["ProductResults"]:
                for i in range(len(data_dict["ProductResults"]["ScoreResult"]["Result"])):
                    if "Models" in data_dict["ProductResults"]["ScoreResult"]["Result"][0][i]:
                        for j in range(len(data_dict["ProductResults"]["ScoreResult"]["Result"][0][i]["Models"])):
                            if "Score" in data_dict["ProductResults"]["ScoreResult"]["Result"][0][i]["Models"][j]:
                                payload_json["RiskClassScore"] = data_dict["ProductResults"]["ScoreResult"]["Result"][0][i]["Models"][j]["Score"]
                                break
                        break
            
            
            if "MVRResults" in data_dict["ProductResults"]:
                for i in range(len(data_dict["ProductResults"]["MVRResults"]["Result"])):
                    if "MVRReport" in data_dict["ProductResults"]["MVRResults"]["Result"][0][i]:
                        payload_json["MVRStatus"] = data_dict["ProductResults"]["MVRResults"]["Result"][0][i]["MVRReport"]["ProcessingInfo"]["MVRStatus"]

                        payload_json["DLExpirationDate"] = data_dict["ProductResults"]["MVRResults"]["Result"][0][i]["MVRReport"]["ProcessingInfo"]["DriversLicense"]["ExpirationDate"]
                        
                        violations = data_dict["ProductResults"]["MVRResults"]["Result"][0][i]["MVRReport"]["Response"]["MVRViolations"]

                        break
            
            if "NationalCreditFileResults" in data_dict["ProductResults"]:
                for index in range(len(data_dict["ProductResults"]["NationalCreditFileResults"]["Result"])):
                    if "NcfReport" in data_dict["ProductResults"]["NationalCreditFileResults"]["Result"][0][index]:
                        payload_json["CreditScore"] = data_dict["ProductResults"]["NationalCreditFileResults"]["Result"][0][index]["NcfReport"]["NcfProductReport"]["AlertsScoring"]["Scores"]
                        break
            
            for i in range(len(violations)):
                temp_dict = {}
                if "ViolationSuspensionDate" in violations[i] and violations[i]["ViolationSuspensionDate"] is not None:
                    temp_dict["MVRViolationDate"] = f"{violations[i]['ViolationSuspensionDate']['Month']}/{violations[i]['ViolationSuspensionDate']['Day']}/{violations[i]['ViolationSuspensionDate']['Year']}"
                if "Description" in violations[i] and violations[i]["Description"] is not None:
                    temp_dict["ViolationDescription"] = violations[i]["Description"]
                if "StandardViolations" in violations[i] and violations[i]["StandardViolations"] is not None:
                    temp_dict["StandardViolationType"] = violations[i]["StandardViolations"][0]['CustomerSpecificCode']
                
                mvr_violations.append(temp_dict)

            def remove_duplicate_dictionaries(dict_list):
                """
                Removes duplicate dictionaries from a list based on 'ViolationDescription', date, and other fields.
                """
                seen = set()
                unique_dicts = []
                for d in dict_list:
                    # Create a tuple of the values to check for uniqueness
                    identifier = (d.get("ViolationDescription"), d.get("MVRViolationDate"), d.get("StandardViolationType"))
                    if identifier not in seen:
                        seen.add(identifier)
                        unique_dicts.append(d)
                return unique_dicts

                # Remove duplicates based on 'ViolationDescription', 'MVRViolationDate' and 'StandardViolationType'
            
            
        mvr_violations = remove_duplicate_dictionaries(mvr_violations)        

        #print(f"MVR Violations: {mvr_violations}")
        return payload_json, mvr_violations
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}")
        return {}, []
    

def get_mib_xml(input_file_name):
    """
    Extracts data from an XML file and returns it as a list of dictionaries.
    """
    try:
        with open(input_file_name, encoding="utf-8") as xml_file:
            data_dict = xmltodict.parse(xml_file.read())

        json_data=json.loads(json.dumps(data_dict))
        # with open("data_source/prod_samples/9222517/9222517_MWA_MIB.json", "w") as json_file:
        #     json.dump(json_data, json_file, indent=4)
        return json_data

    except Exception as e:
        print(f"Error reading XML file: {e}")
        return {}
    

def get_mib_json(input_file_name):
    """
    Extracts data from JSON and returns a dictionary
    """
    import traceback
    try:
        mib_fields = {}
        codes = []
        data_dict = get_mib_xml(input_file_name)
        #print(data_dict)
        # Extract Hit/Try
        try:
            relations = data_dict["string"]["TXLife"]["TXLifeResponse"]["OLifE"].get("Relation", [])
            if isinstance(relations, dict):
                relations = [relations]
            for rel in relations:
                if "RelationRoleCode" in rel and "#text" in rel["RelationRoleCode"]:
                    mib_fields["Hit/Try"] = rel["RelationRoleCode"]["#text"]
                break  # Assuming we only need the first relation's role code
        
        except Exception:
            pass

        # Extract Face_Amount
        try:
            holdings = data_dict["string"]["TXLife"]["TXLifeResponse"]["OLifE"].get("Holding", [])
            if isinstance(holdings, dict):
                holdings = [holdings]
            for holding in holdings:
                policy = holding.get("Policy", {})
                life = policy.get("Life", {})
                mib_fields["Face_Amount"] = life.get("FaceAmt", 0)
        except Exception as e:
            print(f"Warning: Could not extract Face_Amount: {e}")

        # Extract FormInstance(s)
        olife = data_dict["string"]["TXLife"]["TXLifeResponse"]["OLifE"]
        form_instances = olife.get("FormInstance", [])
        if isinstance(form_instances, dict):
            form_instances = [form_instances]

        for form_inst in form_instances:
            # SubmitDate
            if "SubmitDate" in form_inst:
                mib_fields["SubmitDate"] = form_inst["SubmitDate"]

            # FormResponse(s)
            form_responses = form_inst.get("FormResponse", [])
            if isinstance(form_responses, dict):
                form_responses = [form_responses]

            for fr in form_responses:
                mib_temp = {}
                if "ResponseData" in fr:
                    mib_temp["MIBCode"] = fr["ResponseData"]
                    mib_temp["MIBCodeMeaning"] = mib_parsing(mib_temp["MIBCode"])
                    codes.append(mib_temp)

        #print("MIB Codes:", codes)
        #print("MIB Fields:", mib_fields)
        return mib_fields, codes

    except Exception as e:
        print(f"Error reading JSON file: {e}")
        traceback.print_exc()
        return {}, []
    
def main_excel(basepayload_file_name, health_file_name, mvr_file_name, mib_file_name, output_file_path, sheet_name):
    """
    Main function to process the XML and JSON files and export to Excel.
    """

    # Process MWA Base Payload
    json_basepayload, requirements = get_basepayload_json(basepayload_file_name) 
    
    # Export base payload data if not empty
    if json_basepayload:
        put_dict_in_excel(json_basepayload, output_file_path, sheet_name)
        print(f"Base payload data exported successfully to {output_file_path}, sheet {sheet_name}")
    else:
        print(f"No base payload data to export for {sheet_name}")
    
    # Process requirements separately - format them and add to Excel
    if requirements and len(requirements) > 0:
        requirements_df = format_requirements_for_excel(requirements)
        # Only export if we have valid requirements data
        if requirements_df is not None and not requirements_df.empty:
            put_dict_in_excel(requirements_df, output_file_path, sheet_name)
            print(f"Requirements data exported successfully to {output_file_path}, sheet {sheet_name}")
        else:
            print(f"No valid requirements data to export for {sheet_name}")
    else:
        print(f"No requirements data to export for {sheet_name}")
    
    # Process Health Results
    json_data = get_health_json(health_file_name)
    if json_data:
        put_list_in_excel(json_data, output_file_path, sheet_name)
        print(f"Health data exported successfully to {output_file_path}, sheet {sheet_name}")
    else:
        print(f"No health data to export for {sheet_name}")
    
    # Process potential conditions
    xml_list = get_potential_conditions(health_file_name)
    if xml_list:
        put_list_in_excel(xml_list, output_file_path, sheet_name)
        print(f"Potential conditions data exported successfully to {output_file_path}, sheet {sheet_name}")
    else:
        print(f"No potential conditions data to export for {sheet_name}")

    # Process health scores
    final_scores, contributing_factors = get_health_scores(health_file_name)
    if final_scores:
        put_dict_in_excel(final_scores, output_file_path, sheet_name)
        print(f"Health scores data exported successfully to {output_file_path}, sheet {sheet_name}")
    else:
        print(f"No health scores data to export for {sheet_name}")
        
    if contributing_factors:
        put_list_in_excel(contributing_factors, output_file_path, sheet_name)
        print(f"Contributing factors data exported successfully to {output_file_path}, sheet {sheet_name}")
    else:
        print(f"No contributing factors data to export for {sheet_name}")

    # Process health lab tests
    labtests = get_health_labtests(health_file_name)
    if labtests:
        # print(labtests)
        put_list_in_excel(labtests, output_file_path, sheet_name)
        print(f"Health lab tests data exported successfully to {output_file_path}, sheet {sheet_name}")
    else:
        print(f"No health lab tests data to export for {sheet_name}")

    # Process MVR data
    payload_json, mvr_violations = get_mvr_json(mvr_file_name)
    if payload_json:
        put_dict_in_excel(payload_json, output_file_path, sheet_name)
        print(f"MVR payload data exported successfully to {output_file_path}, sheet {sheet_name}")
    else:
        print(f"No MVR payload data to export for {sheet_name}")
        
    if mvr_violations:
        put_list_in_excel(mvr_violations, output_file_path, sheet_name)
        print(f"MVR violations data exported successfully to {output_file_path}, sheet {sheet_name}")
    else:
        print(f"No MVR violations data to export for {sheet_name}")

    # Process MIB data
    mib_fields, codes = get_mib_json(mib_file_name)
    if mib_fields:
        put_dict_in_excel(mib_fields, output_file_path, sheet_name)
        # print("MIB fields:", mib_fields)
        print(f"MIB fields data exported successfully to {output_file_path}, sheet {sheet_name}")
    else:
        print(f"No MIB fields data to export for {sheet_name}")
        
    if codes:
        put_list_in_excel(codes, output_file_path, sheet_name)
        # print("MIB codes:", codes)
        print(f"MIB codes data exported successfully to {output_file_path}, sheet {sheet_name}")
    else:
        print(f"No MIB codes data to export for {sheet_name}")
    
    print(f"All data for {sheet_name} processed successfully")

    
def main():
    """
    Main function to run the script.
    """
    # Get the list of all directories inside data_source/prod_samples
    prod_samples_dir = "data_source/prod_samples/90_samples"
    if not os.path.exists(prod_samples_dir):
        print(f"Directory {prod_samples_dir} does not exist")
        sys.exit(1)

    # List all directories in the prod_samples directory
    case_folders = [f for f in os.listdir(prod_samples_dir) if os.path.isdir(os.path.join(prod_samples_dir, f))]
    print(f"Found {len(case_folders)} case folders: {case_folders}")

    # Process each case folder
    for case_folder in case_folders:
        print(f"\nProcessing case: {case_folder}")
        
        # Set up file paths for this case
        base_folder = os.path.join(prod_samples_dir, case_folder)
        basepayload_file = os.path.join(base_folder, f"{case_folder}_MWA_BASEPAYLOAD.json")
        health_file = os.path.join(base_folder, f"{case_folder}_MWA_HEALTHRESULTS.xml")
        mvr_file = os.path.join(base_folder, f"{case_folder}_MWA_RISKCLASSIFIER.json")
        mib_file = os.path.join(base_folder, f"{case_folder}_MWA_MIB.xml")
        
        # Check if files exist
        missing_files = []
        for file_path in [basepayload_file, health_file, mvr_file, mib_file]:
            if not os.path.exists(file_path):
                missing_files.append(file_path)
        
        if missing_files:
            print(f"Skipping {case_folder} due to missing files: {missing_files}")
            continue
        
        # Process the case
        output_file_path = "Underwriting_MWA_90_Samples.xlsx"
        sheet_name = case_folder
        
        try:
            print(f"Processing files for case {case_folder}")
            main_excel(basepayload_file, health_file, mvr_file, mib_file, output_file_path, sheet_name)
            print(f"Successfully processed case {case_folder}")
        except Exception as e:
            print(f"Error processing case {case_folder}: {e}")

if __name__ == "__main__":
    main()
   
    # basepayload_file = "data_source/Q34414-89/Q34414-89_MWA_BASEPAYLOAD.json"
    # health_file = "data_source/prod_samples/trial/9218592/9218592_MWA_HEALTHRESULTS.xml"
    # print(get_health_labtests(health_file))
    # mvr_file = "data_source/Q34414-89/Q34414-89_MWA_RISKCLASSIFIER.json"
    # # mib_file = "data_source/Q34414-89/Q34414-89_MWA_MIB.xml"
    # output_file_path = "Underwriting_MWA_Data.xlsx"
    # sheet_name = "Q34414-89"
    # # xml_data = main_excel(basepayload_file, health_file, mvr_file, mib_file, output_file_path, sheet_name)

    # mib_file = "data_source/prod_samples/9222517/9222517_MWA_MIB.xml"
    # xml_data = main_excel(basepayload_file, health_file, mvr_file, mib_file, output_file_path, sheet_name)
   # get_healthresults_xml(health_file)

