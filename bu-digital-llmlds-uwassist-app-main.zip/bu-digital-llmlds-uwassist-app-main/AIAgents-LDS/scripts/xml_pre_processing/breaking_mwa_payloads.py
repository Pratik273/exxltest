import json
import chardet
import xmltodict
import os
import sys
from dotenv import load_dotenv
import boto3
from botocore.exceptions import ClientError
from loguru import logger
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
from utils.aws_services import upload_file_to_s3
from scripts.convert_MIB_excel_to_json.main import mib_parsing

load_dotenv(override=True)

def upload_processed_files(case_number, local_dir, bucket_name, output_prefix):
    """
    Upload all processed JSON files for a case to S3
    
    :param case_number: Case identifier
    :param local_dir: Directory with processed files
    :param bucket_name: S3 bucket name
    :param output_prefix: Prefix for S3 output files
    :return: List of successfully uploaded files
    """
    uploaded_files = []
    
    # List all JSON files in the case directory
    case_dir = local_dir
    if not os.path.exists(case_dir):
        logger.warning(f"Case directory not found: {case_dir}")
        return uploaded_files
    
    # Find all JSON files that were generated
    json_files = [f for f in os.listdir(case_dir) if f.endswith('.json') and (
                   '_part_A' in f or 
                   '_part_B' in f or 
                   '_Rx' in f or 
                   '_Lab' in f or 
                   '_Dx' in f or 
                   'modified_' in f)]
    
    # Upload each file
    for json_file in json_files:
        local_path = os.path.join(case_dir, json_file)
        s3_key = f"{output_prefix}/{case_number}/{json_file}"
        
        if upload_file_to_s3(local_path, bucket_name, s3_key):
            uploaded_files.append(s3_key)
    
    return uploaded_files


def extract_keys(data, keys):
    """
    Extracts specific keys from a dictionary and returns them as a new dictionary.
    """
    extracted_data = {}
    for key in keys:
        if key in data:
            extracted_data[key] = data[key]
    return extracted_data


def delete_keys(data, keys):
    """
    Deletes specific keys from a dictionary.
    """
    for key in keys:
        if key in data:
            del data[key]
    return data

def get_healthresults_xml(input_file_name):
    """
    Extracts data from an XML file and returns it as a list of dictionaries.
    """
    try:
        with open(input_file_name) as xml_file:
            data_dict = xmltodict.parse(xml_file.read())
            json_data = json.loads(json.dumps(data_dict))

        # Store the XML data in a JSON file
        # with open("data_source/prod_samples/9218062/9218062_MWA_HEALTHRESULTS.json", "w") as json_file:
        #     json.dump(json_data, json_file, indent=4)
            return json_data

    except UnicodeDecodeError:
        # Fallback: detect encoding
        with open(input_file_name, 'rb') as f:
            raw_data = f.read()
            result = chardet.detect(raw_data)
            detected_encoding = result['encoding']
            print(f"[Fallback] {input_file_name}: Detected {detected_encoding}")

        # Read with detected encoding (replace bad bytes)
        xml_new_file = raw_data.decode(detected_encoding or 'utf-8', errors='replace')
        data_dict = xmltodict.parse(xml_new_file)
        json_data = json.loads(json.dumps(data_dict))
        return json_data

    except Exception as e:
        print(f"Error reading XML file: {e}")
        return {}

def get_mib_xml(input_file_name):
    """
    Extracts data from an XML file and returns it as a list of dictionaries.
    """
    try:
        with open(input_file_name) as xml_file:
            data_dict = xmltodict.parse(xml_file.read())

        json_data=json.loads(json.dumps(data_dict))
        # with open("data_source/prod_samples/9222517/9222517_MWA_MIB.json", "w") as json_file:
        #     json.dump(json_data, json_file, indent=4)
        return json_data

    except Exception as e:
        print(f"Error reading XML file: {e}")
        return {}

def decouple_part_a_b(basepayload_file_name, output_file_path_part_A, output_file_path_part_B):
    """
    Decouples the payload into part A and part B.
    """
    part_a = {}
    part_b = {}     
    
    with open(basepayload_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            # print(f"Content: {content}")
            if not content:
                return {}, {}  # Return empty dict for empty file
            data_dict = json.loads(content)

            part_b = extract_keys(data_dict, ["CertificateNumber"])

            part_b["Content"] = extract_keys(data_dict, ["HeightInchesTotal", "HeightFeetInteger", "HeightInchesRemainder", "Weight", "WeightLoss", "WeightLossReason", "TobaccoStatus", "Nicotine12Months", "Nicotine36Months", "PartialConversion" , "Requirements"])
            part_b["Content"]["BMI"] = str(round(float((int(data_dict["Weight"]) * 703) / (int(data_dict["HeightInchesTotal"]) ** 2) ), 1))
            

            part_a = extract_keys(data_dict, ["CertificateNumber"])
            part_a["Content"] = delete_keys(data_dict, ["HeightInchesTotal", "HeightFeetInteger", "HeightInchesRemainder", "Weight", "WeightLoss", "WeightLossReason", "TobaccoStatus", "Nicotine12Months", "Nicotine36Months", "PartialConversion" , "Requirements"])

    # Write the decoupled data to JSON files
    with open(output_file_path_part_A, 'w', encoding='utf-8') as json_file:
        json.dump(part_a, json_file, indent=4)
    with open(output_file_path_part_B, 'w', encoding='utf-8') as json_file:
        json.dump(part_b, json_file, indent=4)
    
    # print("Part A:", part_a["Content"].keys())
    # print("Part B:", part_b["Content"]["BMI"])

    return part_a, part_b

def decouple_rx_lab_dx(health_file_name, part_a, output_file_path_rx, output_file_path_lab, output_file_path_dx):
    """
    Decouples the Payload into Rx, Lab, and Dx.
    """
    rx = {}
    lab = {}
    dx = {}

    data_dict = get_healthresults_xml(health_file_name)
    if not data_dict:
        return {}, {}, {}

    if "Policy" in data_dict["TXLife"]["TXLifeRequest"]["OLifE"]["Holding"]:
        policy = data_dict["TXLife"]["TXLifeRequest"]["OLifE"]["Holding"]["Policy"]
        rx["CertificateNumber"] = part_a["CertificateNumber"]
        lab["CertificateNumber"] = part_a["CertificateNumber"]
        dx["CertificateNumber"] = part_a["CertificateNumber"]
        
        rx["Content"] = delete_keys(policy.copy(), ["RequirementInfo", "ApplicationInfo"])
        lab["Content"] = delete_keys(policy.copy(), ["RequirementInfo", "ApplicationInfo"])

    if "Party" in data_dict["TXLife"]["TXLifeRequest"]["OLifE"]:
        party = data_dict["TXLife"]["TXLifeRequest"]["OLifE"]["Party"]
        if isinstance(party, list):
            for p in party:
                if "Risk" in p:
                    if "PrescriptionDataStatus" in p["Risk"]:
                        rx["Content"]["Risk"] = extract_keys(p["Risk"].copy(), ["PrescriptionDataStatus"])
                    if "PrescriptionDrug" in p["Risk"]:
                        rx["Content"]["Risk"].update(extract_keys(p["Risk"].copy(), ["PrescriptionDrug"]))
                    if "LabTesting" in p["Risk"]:
                        lab["Content"]["Risk"] = extract_keys(p["Risk"].copy(), ["LabTesting"])
                    if "OLifEExtension" in p["Risk"]:
                        if isinstance(p["Risk"]["OLifEExtension"], list):
                            for ext in p["Risk"]["OLifEExtension"]:
                                if "DrugDetail" in ext:
                                    rx["Content"]["Risk"].update(ext.copy())
                                if "LabDataStatus" in ext:
                                    labStatus = {} 
                                    labStatus["LabDataStatus"] = ext["LabDataStatus"]
                                    labStatus["@VendorCode"] = ext["@VendorCode"]
                                    labStatus["@ExtensionCode"] = ext["@ExtensionCode"]
                                    if "Risk" not in lab["Content"]:
                                        lab["Content"]["Risk"] = labStatus

                                    else:
                                        lab["Content"]["Risk"].update(labStatus)
                                if "MedicalClaimDataStatus" in ext:
                                    dx["Content"] = {}
                                    dx["Content"]["Risk"] = {}
                                    dx["Content"]["Risk"] = ext.copy()
                                if "medical-health-profile" in ext:
                                    dx["Content"]["Risk"].update(ext.copy())
                                if "CoverageDetail" in ext:
                                    dx["Content"]["Risk"].update(ext.copy())
                                if "RiskScoring" in ext:
                                    dx["Content"]["Risk"].update(ext.copy())
                                    rx["Content"]["Risk"].update(ext.copy())
                                    lab["Content"]["Risk"].update(ext.copy())
                                if "HealthPiQturePotentialConditions" in ext:
                                    dx["Content"]["Risk"].update(ext.copy())
                                    rx["Content"]["Risk"].update(ext.copy())
                                    lab["Content"]["Risk"].update(ext.copy())
                                if "@ExtensionCode" in ext and ext["@ExtensionCode"] == "Notice":
                                    dx["Content"]["Risk"].update(ext.copy())
                                    rx["Content"]["Risk"].update(ext.copy())
                                    lab["Content"]["Risk"].update(ext.copy())
                if "@id" in p and "Carrier" in p["@id"]:
                    rx["Content"]["Carrier"] = p
                    lab["Content"]["Carrier"] = p
                    dx["Content"]["Carrier"] = p
                if "Physician" in p:
                    if "Physicians" not in rx["Content"]:
                        rx["Content"]["Physicians"] = []
                        rx["Content"]["Physicians"].append(p)
                    else:
                        rx["Content"]["Physicians"].append(p)
                    if "Physicians" not in lab["Content"]:
                        lab["Content"]["Physicians"] = []
                        lab["Content"]["Physicians"].append(p)
                    else:
                        lab["Content"]["Physicians"].append(p)
                    if "Physicians" not in dx["Content"]:
                        dx["Content"]["Physicians"] = []
                        dx["Content"]["Physicians"].append(p)
                    else:
                        dx["Content"]["Physicians"].append(p)

                if "@id" in p and "PHR" in p["@id"]:
                    if "Pharmacies" not in rx["Content"]:
                        rx["Content"]["Pharmacies"] = []
                        rx["Content"]["Pharmacies"].append(p)
                    else:
                        rx["Content"]["Pharmacies"].append(p)
                    if "Pharmacies" not in lab["Content"]:
                        lab["Content"]["Pharmacies"] = []
                        lab["Content"]["Pharmacies"].append(p)
                    else:
                        lab["Content"]["Pharmacies"].append(p)
                    if "Pharmacies" not in dx["Content"]:
                        dx["Content"]["Pharmacies"] = []
                        dx["Content"]["Pharmacies"].append(p)
                    else:
                        dx["Content"]["Pharmacies"].append(p)
    

    # print("Rx:", rx.keys())
    # print("Lab:", lab.keys())
    # print("Dx:", dx.keys())
    
    # Write the decoupled data to JSON files
    with open(output_file_path_rx, 'w', encoding='utf-8') as json_file:
        json.dump(rx, json_file, indent=4)
    with open(output_file_path_lab, 'w', encoding='utf-8') as json_file:
        json.dump(lab, json_file, indent=4)
    with open(output_file_path_dx, 'w', encoding='utf-8') as json_file:
        json.dump(dx, json_file, indent=4)
    
    return rx, lab, dx

def get_new_mib(mib_file_name, part_a, output_file_path_mib):
    """
    Extracts data from an XML file and returns it as a list of dictionaries.
    """
    mib = {}
    mib_parsing_used = False
    
    # Check if file exists
    if not os.path.exists(mib_file_name):
        print(f"MIB file not found: {mib_file_name}")
        return {}, False
        
    try:
        data_dict = get_mib_xml(mib_file_name)
        if not data_dict:
            print(f"Empty or invalid MIB data from: {mib_file_name}")
            return {}, False
        
        # Debug the structure to understand what we're working with
        print(f"Top level MIB keys: {list(data_dict.keys())}")
        
        # Handle potential different structures
        if "string" in data_dict:
            if "TXLife" in data_dict["string"]:
                if "TXLifeResponse" in data_dict["string"]["TXLife"]:
                    txlife_response = data_dict["string"]["TXLife"]["TXLifeResponse"]
                    
                    # Check if OLifE is present
                    if "OLifE" in txlife_response:
                        if "Holding" in txlife_response["OLifE"]:
                            holding = txlife_response["OLifE"]["Holding"]
                            
                            # Handle both list and dictionary cases for Holding
                            if isinstance(holding, dict) and "Policy" in holding:
                                policy = holding["Policy"]
                                if "ApplicationInfo" in policy and "TrackingID" in policy["ApplicationInfo"]:
                                    mib["CertificateNumber"] = part_a["CertificateNumber"]
                                    # Create a deep copy to avoid reference issues
                                    temp_mib = json.loads(json.dumps(data_dict))
                                    
                                    # Safely remove keys
                                    policy_path = temp_mib["string"]["TXLife"]["TXLifeResponse"]["OLifE"]["Holding"]["Policy"]
                                    if "ApplicationInfo" in policy_path:
                                        del policy_path["ApplicationInfo"]
                                    if "PolNumber" in policy_path:
                                        del policy_path["PolNumber"]
                                    

                                    if "OLifE" in temp_mib["string"]["TXLife"]["TXLifeResponse"] and "FormInstance" in temp_mib["string"]["TXLife"]["TXLifeResponse"]["OLifE"]:
                                        form_instance = temp_mib["string"]["TXLife"]["TXLifeResponse"]["OLifE"]["FormInstance"]
                                        
                                        if isinstance(form_instance, list):
                                            for form in form_instance:
                                                
                                                if "FormResponse" in form:
                                                    response = form["FormResponse"]
                                                    if isinstance(response, list):
                                                        for data in response:
                                                            if "ResponseData" in data and not "AssociatedResponseData" in data:
                                                                logger.success(f"Here is the mib code {data}")
                                                                meaning = mib_parsing(data["ResponseData"])
                                                                data["MiBCodeMeaning"] = meaning
                                                                mib_parsing_used = True
                                                    elif isinstance(response, dict):
                                                        if "ResponseData" in response and not "AssociatedResponseData" in response:
                                                            logger.success(f"Here is the mib code {response}")
                                                            meaning = mib_parsing(response["ResponseData"])
                                                            response["MiBCodeMeaning"] = meaning
                                                            mib_parsing_used = True

                                        elif isinstance(form_instance, dict):
                                            if "FormResponse" in form_instance:
                                                response = form_instance["FormResponse"]
                                                if isinstance(response, list):
                                                    for data in response:
                                                        if "ResponseData" in data and not "AssociatedResponseData" in data:
                                                            logger.success(f"Here is the mib code f{data}")
                                                            meaning = mib_parsing(data["ResponseData"])
                                                            data["MiBCodeMeaning"] = meaning
                                                            mib_parsing_used = True
                                                elif isinstance(response, dict):
                                                    if "ResponseData" in response and not "AssociatedResponseData" in response:
                                                        logger.success(f"Here is the mib code {response}")
                                                        meaning = mib_parsing(response["ResponseData"])
                                                        response["MiBCodeMeaning"] = meaning
                                                        mib_parsing_used = True

                                    mib["Content"] = temp_mib["string"]["TXLife"]["TXLifeResponse"]
                            
                            # Handle list case
                            elif isinstance(holding, list):
                                for item in holding:
                                    if "Policy" in item and "ApplicationInfo" in item["Policy"]:
                                        policy = item["Policy"]
                                        if "TrackingID" in policy["ApplicationInfo"]:
                                            mib["CertificateNumber"] = part_a["CertificateNumber"]
                                            # Create a deep copy to avoid reference issues
                                            temp_mib = json.loads(json.dumps(data_dict))
                                            
                                            # Find the corresponding policy in the copy
                                            for temp_item in temp_mib["string"]["TXLife"]["TXLifeResponse"]["OLifE"]["Holding"]:
                                                if "Policy" in temp_item and "ApplicationInfo" in temp_item["Policy"]:
                                                    if temp_item["Policy"]["ApplicationInfo"]["TrackingID"] == mib["CertificateNumber"]:
                                                        # Remove sensitive keys
                                                        if "ApplicationInfo" in temp_item["Policy"]:
                                                            del temp_item["Policy"]["ApplicationInfo"]
                                                        if "PolNumber" in temp_item["Policy"]:
                                                            del temp_item["Policy"]["PolNumber"]
                                            
                                            if "OLifE" in temp_mib["string"]["TXLife"]["TXLifeResponse"] and "FormInstance" in temp_mib["string"]["TXLife"]["TXLifeResponse"]["OLifE"]:
                                                form_instance = temp_mib["string"]["TXLife"]["TXLifeResponse"]["OLifE"]["FormInstance"]
                                                
                                                if isinstance(form_instance, list):
                                                    for form in form_instance:
                                                        
                                                        if "FormResponse" in form:
                                                            response = form["FormResponse"]
                                                            if isinstance(response, list):
                                                                for data in response:
                                                                    if "ResponseData" in data and not "AssociatedResponseData" in data:
                                                                        logger.success(f"Here is the mib code {data}")
                                                                        meaning = mib_parsing(data["ResponseData"])
                                                                        data["MiBCodeMeaning"] = meaning
                                                                        mib_parsing_used = True
                                                            elif isinstance(response, dict):
                                                                if "ResponseData" in response and not "AssociatedResponseData" in response:
                                                                    logger.success(f"Here is the mib code {response}")
                                                                    meaning = mib_parsing(response["ResponseData"])
                                                                    response["MiBCodeMeaning"] = meaning
                                                                    mib_parsing_used = True

                                                elif isinstance(form_instance, dict):
                                                    if "FormResponse" in form_instance:
                                                        response = form_instance["FormResponse"]
                                                        if isinstance(response, list):
                                                            for data in response:
                                                                if "ResponseData" in data and not "AssociatedResponseData" in data:
                                                                    logger.success(f"Here is the mib code f{data}")
                                                                    meaning = mib_parsing(data["ResponseData"])
                                                                    data["MiBCodeMeaning"] = meaning
                                                                    mib_parsing_used = True
                                                        elif isinstance(response, dict):
                                                            if "ResponseData" in response and not "AssociatedResponseData" in response:
                                                                logger.success(f"Here is the mib code {response}")
                                                                meaning = mib_parsing(response["ResponseData"])
                                                                response["MiBCodeMeaning"] = meaning
                                                                mib_parsing_used = True

                                            mib["Content"] = temp_mib["string"]["TXLife"]["TXLifeResponse"]
                                            break  # Found what we need, exit loop
        
        # If we've populated the mib dictionary, print some debug info
        if mib:
            logger.debug(f"Successfully processed MIB for certificate: {mib.get('CertificateNumber')}")
            if "Content" in mib:
                # print("MIB Content structure:", mib["Content"]["OLifE"]["FormInstance"])
                # Save the modified MIB data to a new JSON file
                with open(output_file_path_mib, 'w', encoding='utf-8') as json_file:
                    json.dump(mib, json_file, indent=4)
        else:
            print(f"No matching policy information found in MIB file: {mib_file_name}")
            
        return mib, mib_parsing_used
        
    except Exception as e:
        print(f"Error processing MIB file {mib_file_name}: {str(e)}")
        import traceback
        traceback.print_exc()
        return {}, False



def get_new_mvr(mvr_file_name, part_a, output_file_path_mvr):
    """
    Extracts data from an XML file and returns it as a list of dictionaries.
    """
    mvr = {}
    
    # Check if file exists
    if not os.path.exists(mvr_file_name):
        print(f"MVR file not found: {mvr_file_name}")
        return {}
        
    try:
        with open(mvr_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            # print(f"Content: {content}")
            if not content:
                return {}, {}  # Return empty dict for empty file
            data_dict = json.loads(content)

            mvr["CertificateNumber"] = part_a["CertificateNumber"]
            mvr["Content"] = data_dict.copy()
        # Debug the structure to understand what we're working with
            # print(f"Top level MVR keys: {list(data_dict.keys())}")
        # print("MVR:", mvr["Content"].keys())
        # Write the modified MVR data to a new JSON file
        with open(output_file_path_mvr, 'w', encoding='utf-8') as json_file:
            json.dump(mvr, json_file, indent=4)

        return mvr
        
    except Exception as e:
        print(f"Error reading MVR file: {e}")
        return {}

def main(bucket_name=os.getenv('BUCKET_NAME'), folder_prefix="lds-mwa-dev"):
    """
    Main function to run the script.
    """
    
    # s3 = boto3.client('s3', region_name=os.getenv('AWS_REGION'))
    
    # # Sample application list - can be expanded or loaded externally
    # application_names = ["9217523", "9217639", "9217744", "9217937", "9217938", "9218062", "9218159", "9222406", "9230523"]
    # #["9222517"]
    
    # logger.info(f"Pre-processing applications: {application_names}")
    
    # for name in application_names:
    #     # Create a local temporary directory for this application
    #     local_temp_dir = os.path.join(os.getcwd(), "temp", name)
    #     os.makedirs(local_temp_dir, exist_ok=True)
        
    #     logger.info(f"Processing application: {name}")
        
    #     # List objects in the application folder
    #     app_prefix = f"{folder_prefix}/{name}/"
    #     logger.debug(f"Application: {bucket_name}/{app_prefix}")
    #     try:
    #         response = s3.list_objects_v2(Bucket=bucket_name, Prefix=app_prefix)
            
    #     except ClientError as e:
    #         logger.error(f"S3 error listing objects: {str(e)}")
    #         continue
    #     except Exception as e:
    #         logger.error(f"S3 list object error: {e}")
            
        
    #     # Check if objects exist
    #     if "Contents" not in response:
    #         logger.info(f"No files found for application {name}")
    #         continue
            
    #     case_files = [obj["Key"] for obj in response["Contents"] 
    #                 if obj["Key"].endswith(".json") or obj["Key"].endswith(".xml")]
        
    #     if not case_files:
    #         logger.info(f"No XML/JSON files found for application {name}")
    #         continue
            
    #     logger.info(f"Found {len(case_files)} data sources for application {name}")
    
        # basepayload_file = None
        # health_file = None
        # mvr_file = None
        # mib_file = None
        
        # # Download and identify files
        # for i, file_key in enumerate(case_files):
        #     file_name = os.path.basename(file_key)
        #     local_file_path = os.path.join(local_temp_dir, file_name)
            
        #     try:
        #         # Download the file
        #         logger.info(f"Downloading {file_key} to {local_file_path}")
        #         s3.download_file(bucket_name, file_key, local_file_path)
                
        #         # Identify file type
        #         if "BASEPAYLOAD" in file_name and file_name.endswith(".json"):
        #             basepayload_file = local_file_path
        #             logger.info(f"Found basepayload file: {file_name}")
        #         elif "HEALTHRESULTS" in file_name and file_name.endswith(".xml"):
        #             health_file = local_file_path
        #             logger.info(f"Found health results file: {file_name}")
        #         elif "RISKCLASSIFIER" in file_name and file_name.endswith(".json"):
        #             mvr_file = local_file_path
        #             logger.info(f"Found MVR file: {file_name}")
        #         elif "MIB" in file_name and file_name.endswith(".xml"):
        #             mib_file = local_file_path
        #             logger.info(f"Found MIB file: {file_name}")
                
        #     except ClientError as e:
        #         logger.error(f"AWS API error downloading {file_key}: {str(e)}")
        #         continue
                
        #     except Exception as e:
        #         logger.error(f"Unexpected error processing {file_key}: {str(e)}")
        #         continue
    
        # # Check if we have the minimum required files
        # missing_files = []
        # if not basepayload_file:
        #     missing_files.append("basepayload")
        # if not health_file:
        #     missing_files.append("health results")
        
        # if missing_files:
        #     logger.warning(f"Skipping case {name} due to missing files: {', '.join(missing_files)}")
        #     continue
    
    data_directory = "AIAgents-LDS/data_sources_batch4"
    prod_samples_dir = os.path.abspath(data_directory)
    if not os.path.exists(prod_samples_dir):
        print(f"Directory {prod_samples_dir} does not exist")
        sys.exit(1)

    # List all directories in the prod_samples directory
    case_folders = [f for f in os.listdir(prod_samples_dir) if os.path.isdir(os.path.join(prod_samples_dir, f))]
    folders_to_skip = ["9217523", "9217639", "9217744", "9217937", "9217938", "9218062", "9218159", "9222406", "9230523", "9222517"]
    print(f"Found {len(case_folders)} case folders: {case_folders}")
    folders_to_process = [folder for folder in case_folders if folder not in folders_to_skip]
    print(f"Found {len(folders_to_process)} case folders to process: {folders_to_process}")
        
    
    mib_usage_folders = []
    
    for case_folder in folders_to_process:
        # if case_folder == "9218695":
            # break
        # else:
            print(f"\nProcessing case: {case_folder}")
            
            # Set up file paths for this case
            base_folder = os.path.join(prod_samples_dir, case_folder)
            basepayload_file = os.path.join(base_folder, f"{case_folder}_MWA_BASEPAYLOAD.json")
            health_file = os.path.join(base_folder, f"{case_folder}_MWA_HEALTHRESULTS.xml")
            mvr_file = os.path.join(base_folder, f"{case_folder}_MWA_RISKCLASSIFIER.json")
            mib_file = os.path.join(base_folder, f"{case_folder}_MWA_MIB.xml")
            
            # Check if files exist
            missing_files = []
            for file_path in [basepayload_file, health_file]:
                if not os.path.exists(file_path):
                    missing_files.append(file_path)
            
            if missing_files:
                print(f"Skipping {case_folder} due to missing files: {missing_files}")
                continue
            # Process the case
            # output_file_path_part_A = os.path.join(local_temp_dir, f"{name}_MWA_BASEPAYLOAD_part_A.json")
            # output_file_path_part_B = os.path.join(local_temp_dir, f"{name}_MWA_BASEPAYLOAD_part_B.json")
            # output_file_path_rx = os.path.join(local_temp_dir, f"{name}_MWA_HEALTHRESULTS_Rx.json")
            # output_file_path_lab = os.path.join(local_temp_dir, f"{name}_MWA_HEALTHRESULTS_Lab.json")
            # output_file_path_dx = os.path.join(local_temp_dir, f"{name}_MWA_HEALTHRESULTS_Dx.json")
            # output_file_path_mib = os.path.join(local_temp_dir, f"{name}_modified_MWA_MIB.json")
            # output_file_path_mvr = os.path.join(local_temp_dir, f"{name}_modified_MWA_RISKCLASSIFIER.json")

            output_file_path_part_A = os.path.join(base_folder, f"{case_folder}_MWA_BASEPAYLOAD_part_A.json")
            output_file_path_part_B = os.path.join(base_folder, f"{case_folder}_MWA_BASEPAYLOAD_part_B.json")
            output_file_path_rx = os.path.join(base_folder, f"{case_folder}_MWA_HEALTHRESULTS_Rx.json")
            output_file_path_lab = os.path.join(base_folder, f"{case_folder}_MWA_HEALTHRESULTS_Lab.json")
            output_file_path_dx = os.path.join(base_folder, f"{case_folder}_MWA_HEALTHRESULTS_Dx.json")
            output_file_path_mib = os.path.join(base_folder, f"{case_folder}_modified_MWA_MIB.json")
            output_file_path_mvr = os.path.join(base_folder, f"{case_folder}_modified_MWA_RISKCLASSIFIER.json")

            
            try:
                # logger.info(f"Processing files for case {name}")
                logger.info(f"Processing files for case {case_folder}")
                part_a, part_b = decouple_part_a_b(basepayload_file, output_file_path_part_A, output_file_path_part_B)
                rx, lab, dx = decouple_rx_lab_dx(health_file, part_a, output_file_path_rx, output_file_path_lab, output_file_path_dx)
                
                # Optional processing
                if mib_file:
                    mib, mib_parsing_used = get_new_mib(mib_file, part_a, output_file_path_mib)
                    if mib_parsing_used:
                        mib_usage_folders.append(case_folder)
                if mvr_file and part_a:
                    mvr = get_new_mvr(mvr_file, part_a, output_file_path_mvr)
                    
                # logger.info(f"Successfully processed case {name}")
                logger.info(f"Successfully processed case {case_folder}")
                # break
                
                # Upload all processed files to S3
                # uploaded_files = upload_processed_files(name, local_temp_dir, bucket_name, folder_prefix)
                # logger.info(f"Uploaded {len(uploaded_files)} processed files for case {name}")
                
                # Cleanup temporary files
                # logger.info(f"Cleaning up temporary files for case {name}")
                # for file_path in os.listdir(local_temp_dir):
                #     os.remove(os.path.join(local_temp_dir, file_path))
                
            except Exception as e:
                # logger.error(f"Error processing case {name}: {str(e)}")
                logger.error(f"Error processing case {case_folder}: {str(e)}")
                import traceback
                logger.error(traceback.format_exc())
                
            # break
        
    
    output_file = "mib_folders_batch4.txt"
    with open(output_file, 'w') as f:
        for folder in mib_usage_folders:
            f.write(f"{folder}\n")

    logger.success(f"Found {len(mib_usage_folders)} folders using mib_parsing. List saved to {output_file}")


if __name__ == "__main__":
    main()


    # Example usage
    # basepayload_file_name = "data_source/Q34414-89/Q34414-89_MWA_BASEPAYLOAD.json"
    # part_a, part_b = decouple_part_a_b(basepayload_file_name)
    # print("Part A:", part_a)
    # print("Part B:", part_b)

    # health_file_name = "data_source/Q34414-89/Q34414-89_MWA_HEALTHRESULTS.xml"
    # decouple_rx_lab_dx(health_file_name)