#!/usr/bin/env python3
"""
Data splitter for test_summary_data_enhanced.jsonl based on existing train/val/test splits.

This script splits the enhanced dataset according to:
- Use exact application numbers from existing train/val/test files
- For test: only keep specific 18 applications, move rest to train
- Ensure both subsets (demographics + medical) are present for each application
"""

import json
import os
from collections import defaultdict

def load_existing_splits():
    """Load application numbers from existing train/val/test files."""
    files = {
        'train': 'train_summary_775_mwa_28july.jsonl',
        'val': 'val_summary_200_mwa_28july.jsonl', 
        'test': 'test_summary_25_mwa_28july.jsonl'
    }
    
    splits = {}
    
    for split_name, filename in files.items():
        app_numbers = set()
        
        print(f"Loading {split_name} applications from {filename}...")
        
        with open(filename, 'r') as f:
            for line in f:
                entry = json.loads(line)
                # Use CertificateNumber as that's what the existing files use
                app_num = str(entry.get('ApplicationNumber', ''))
                if app_num:
                    app_numbers.add(app_num)
        
        splits[split_name] = sorted(list(app_numbers))
        print(f"  Found {len(app_numbers)} unique applications")
    
    return splits

def load_enhanced_data(filename):
    """Load the enhanced dataset and organize by application number."""
    data_by_app = defaultdict(list)
    
    print(f"Loading enhanced dataset from {filename}...")
    
    with open(filename, 'r') as f:
        for line_num, line in enumerate(f, 1):
            try:
                entry = json.loads(line)
                app_num = str(entry.get('ApplicationNumber', ''))
                
                if app_num:
                    data_by_app[app_num].append(entry)
                else:
                    print(f"Warning: No ApplicationNumber found in line {line_num}")
                    
            except json.JSONDecodeError as e:
                print(f"Error parsing line {line_num}: {e}")
    
    print(f"  Found data for {len(data_by_app)} applications")
    
    # Check completeness (both subsets should be present)
    complete_apps = 0
    incomplete_apps = []
    
    for app_num, entries in data_by_app.items():
        subsets = set(entry.get('Subset') for entry in entries)
        if len(subsets) == 2 and 1 in subsets and 2 in subsets:
            complete_apps += 1
        else:
            incomplete_apps.append((app_num, subsets))
    
    print(f"  Complete applications (both subsets): {complete_apps}")
    if incomplete_apps:
        print(f"  Incomplete applications: {len(incomplete_apps)}")
        for app, subsets in incomplete_apps[:5]:  # Show first 5
            print(f"    {app}: subsets {subsets}")
    
    return data_by_app

def split_data(enhanced_data, existing_splits):
    """Split the enhanced data according to the requirements."""
    
    # New test applications to keep (25 applications)
    test_keep_apps = [
        9217386, 9217743, 9217828, 9217937, 9227727, 9228791, 9232546, 
        9219040, 9219092, 9219125, 9219237, 9219247, 9219282, 9219564, 
        9220504, 9220866, 9220960, 9221524, 9226628, 9226643, 9229522, 
        9233002, 9220520, 9218315, 9218485
    ]
    test_keep_apps_str = [str(app) for app in test_keep_apps]
    
    # Original splits
    original_train = existing_splits['train']  # 700 apps
    original_val = existing_splits['val']      # 200 apps  
    original_test = existing_splits['test']    # 100 apps
    
    # New training logic: 700 from train + 75 remaining test apps (no val apps in train)
    # Find test apps that should move to train (original test - new test)
    test_apps_to_move = [app for app in original_test if app not in test_keep_apps_str]
    
    print(f"\nSplitting logic:")
    print(f"  Original train: {len(original_train)} apps")
    print(f"  Original val: {len(original_val)} apps") 
    print(f"  Original test: {len(original_test)} apps")
    print(f"  New test apps to keep: {len(test_keep_apps_str)} apps")
    print(f"  Test apps to move to train: {len(test_apps_to_move)} apps")
    print(f"  Expected new train size: {len(original_train)} + {len(test_apps_to_move)} = {len(original_train) + len(test_apps_to_move)} apps")
    print(f"  Expected new val size: {len(original_val)} apps")
    
    # Process each split
    splits_results = {
        'train': {'apps': original_train + test_apps_to_move, 'entries': []},
        'val': {'apps': original_val, 'entries': []},
        'test': {'apps': test_keep_apps_str, 'entries': []}
    }
    
    # Collect entries for each split
    total_found = 0
    total_missing = 0
    
    for split_name, split_data in splits_results.items():
        found_apps = 0
        missing_apps = []
        
        for app_num in split_data['apps']:
            if app_num in enhanced_data:
                # Add both subsets for this application
                for entry in enhanced_data[app_num]:
                    split_data['entries'].append(entry)
                found_apps += 1
            else:
                missing_apps.append(app_num)
                total_missing += 1
        
        total_found += found_apps
        
        print(f"\n{split_name.upper()} split:")
        print(f"  Expected apps: {len(split_data['apps'])}")
        print(f"  Found apps: {found_apps}")
        print(f"  Missing apps: {len(missing_apps)}")
        print(f"  Total entries: {len(split_data['entries'])}")
        
        if missing_apps:
            print(f"  Missing apps sample: {missing_apps[:5]}")
    
    print(f"\nOverall summary:")
    print(f"  Total apps found: {total_found}")
    print(f"  Total apps missing: {total_missing}")
    
    return splits_results

def write_split_files(splits_results, output_dir="./"):
    """Write the split files."""
    
    for split_name, split_data in splits_results.items():
        output_file = os.path.join(output_dir, f"{split_name}_enhanced.jsonl")
        
        print(f"\nWriting {split_name} split to {output_file}...")
        
        with open(output_file, 'w') as f:
            for entry in split_data['entries']:
                f.write(json.dumps(entry, ensure_ascii=False) + '\n')
        
        print(f"  Wrote {len(split_data['entries'])} entries")
        
        # Verify the split
        subset_counts = defaultdict(int)
        app_counts = defaultdict(int)
        
        for entry in split_data['entries']:
            subset = entry.get('Subset')
            app_num = entry.get('ApplicationNumber')
            subset_counts[subset] += 1
            app_counts[app_num] += 1
        
        unique_apps = len(app_counts)
        print(f"  Unique applications: {unique_apps}")
        print(f"  Subset 1 (demographics): {subset_counts.get(1, 0)}")
        print(f"  Subset 2 (medical): {subset_counts.get(2, 0)}")
        
        # Check completeness
        complete_apps = sum(1 for count in app_counts.values() if count == 2)
        incomplete_apps = unique_apps - complete_apps
        
        print(f"  Complete apps (both subsets): {complete_apps}")
        if incomplete_apps > 0:
            print(f"  Incomplete apps: {incomplete_apps}")

def main():
    """Main function to split the data."""
    
    # Change to the correct directory
    os.chdir("/home/CORP/shreya235361/projects/bu-digital-llmlds-uwassist-app/AIAgents-LDS")
    
    print("Enhanced Data Splitter")
    print("=" * 50)
    
    # Load existing splits
    existing_splits = load_existing_splits()
    
    # Load enhanced data
    enhanced_data = load_enhanced_data("summary_data_1aug.jsonl")
    
    # Split the data
    splits_results = split_data(enhanced_data, existing_splits)
    
    # Write split files
    write_split_files(splits_results)
    
    print("\n" + "=" * 50)
    print("Data splitting completed!")
    
    # Final verification
    print("\nFinal verification:")
    train_size = len([e for e in splits_results['train']['entries'] if e.get('Subset') == 1])
    val_size = len([e for e in splits_results['val']['entries'] if e.get('Subset') == 1])
    test_size = len([e for e in splits_results['test']['entries'] if e.get('Subset') == 1])
    
    print(f"Train: {train_size} applications")
    print(f"Val: {val_size} applications") 
    print(f"Test: {test_size} applications")
    print(f"Total: {train_size + val_size + test_size} applications")

if __name__ == "__main__":
    main()