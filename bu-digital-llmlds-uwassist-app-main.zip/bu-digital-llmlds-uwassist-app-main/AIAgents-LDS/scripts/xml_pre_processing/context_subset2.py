import json, os
# from main import mib_parsing
from datetime import datetime

# Application Date from Part A
def date_App(input_file_name):
    try:
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            if not content:
                return None
            data = json.loads(content)
            data_dict = data["Content"]
            date = data_dict['AppWrittenDate']
            date = datetime.strptime(date, '%m-%d-%Y')
            return date.strftime('%m-%d-%Y')
    except json.JSONDecodeError as e:
        print(f"Part A JSON decode error: {e}")
        return None
    
def extract_keys(data, keys):
    """
    Extracts specific keys from a dictionary and returns them as a new dictionary.
    """
    extracted_data = {}
    for key in keys:
        if key in data:
            extracted_data[key] = data[key]
    return extracted_data


# Part B: Content
def get_partB_content(input_file_name):
    """
    Extracts data from a JSON file and returns it as a list of dictionaries.
    """
    try:
        # requirements = []
        payload_json = {}
        if not os.path.exists(input_file_name):
            return {}
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            # print(f"Content: {content}")
            if not content:
                return {} # Return empty dict for empty file
            data = json.loads(content)
            data_dict = data["Content"]
            payload_json = extract_keys(data_dict, ["Weight", "WeightLoss", "WeightLossReason", "HeightInchesTotal", "BMI"])
            payload_json["Height"] = f"{data_dict['HeightFeetInteger']} feet {data_dict['HeightInchesRemainder']} inches"
            payload_json["TobaccoUse"] = f"{data_dict['TobaccoStatus']}, 12 months: {data_dict['Nicotine12Months']}, 36 months: {data_dict['Nicotine36Months']}"
            payload_json["Requirements"] = data_dict["Requirements"]
            
            return payload_json
    except json.JSONDecodeError as e:
        print(f"Part B JSON decode error: {e}")
        return {}


# Lab Content
def get_Lab_content(input_file_name):
    try:
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            if not content:
                return []
            data = json.loads(content)
            data_dict = data["Content"]
            labtests = []  # Initialize an empty list to store lab test results

        if "Risk" in data_dict and "LabTesting" in data_dict["Risk"]:
            extension = data_dict["Risk"]["LabTesting"]
            if not isinstance(extension, list):
                extension = [extension]  # Make it a list if it's not already

            for lab in extension:
                    test_date = lab.get("TestDate")
                    labtest_results = lab.get("LabTestResult", [])
                    if isinstance(labtest_results, dict):
                        labtest_results = [labtest_results]
                    for result in labtest_results:
                        temp_lab = {}
                        if test_date:
                            temp_lab["TestDate"] = test_date
                        # Test name
                        if "TestCode" in result:
                            # Sometimes TestCode is a dict with #text
                            if isinstance(result["TestCode"], dict) and "#text" in result["TestCode"]:
                                temp_lab["TestName"] = result["TestCode"]["#text"]
                            else:
                                temp_lab["TestName"] = result["TestCode"]
                        if "ProviderTestCode" in result:
                            temp_lab["ProviderTestCode"] = result["ProviderTestCode"]
                        if "QualitativeResult" in result:
                            temp_lab["QualitativeResult"] = result["QualitativeResult"]
                        if "QuantitativeResult" in result:
                            temp_lab["QuantitativeResult"] = result["QuantitativeResult"]
                        if "LabTestRemark" in result:
                            temp_lab["LabTestRemark"] = result["LabTestRemark"]
                        labtests.append(temp_lab)
        
        # check if labtests is empty
        if not labtests:
            print("No lab tests found in the provided file.")
            return data_dict
        else:
            # print(f"Lab tests found: {len(labtests)}")
            return labtests
    
    except Exception as e:
        print(f"Error processing health lab tests: {e}")
        import traceback
        traceback.print_exc()
        return []
                            

# Dx Content
def get_Dx_content(input_file_name):
    try:
        if not os.path.exists(input_file_name):
            return {}
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            if not content:
                return []
            data = json.loads(content)
            data_dict = data["Content"]

        if "Risk" in data_dict or "RiskScoring" not in data_dict["Risk"]:
            #return data_dict  # Return the original data_dict if no risk scoring is found
            risk_scoring = data_dict["Risk"]["RiskScoring"]
            result = []

        # Extract MortalityScore
        for risk_score in risk_scoring.get("RiskScore", []):
            if risk_score["RiskScoreName"]["#text"] == "MortalityScore":
                result.append({"MortalityScore": int(risk_score["QuantitativeScore"])})
                break

        # Extract Contributing Factors
        contributing_factors = risk_scoring.get("ContributingFactors", {}).get("ContributingFactor", [])
        if isinstance(contributing_factors, dict):
            contributing_factors = [contributing_factors]

        for factor in contributing_factors:
            result.append({
                "Sequence": int(factor["Sequence"]),
                "MortalityEffectPercent": int(factor["MortalityEffectPercent"]),
                "Health_Factor": factor["Factor"]
            })

        # check if result is empty
        if not result:
            print("No Dx data found in the provided file.")
            return data_dict
        else:
            # print(f"Risk scoring data found: {len(result)} entries")
            return result

    except json.JSONDecodeError as e:
        print(f" Dx JSON decode error: {e}")
        return []   


# Rx Content
def get_Rx_content(input_file_name):
    try:
        if not os.path.exists(input_file_name):
            print(f"Rx file not found: {input_file_name}")
            return []
            
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            if not content:
                print(f"Rx file is empty: {input_file_name}")
                return []
            data = json.loads(content)
            data_dict = data["Content"]
            print("Successfully read Rx file")
            # print(f"Data Dict: {data_dict}")

        # Check if 'Risk' and 'Physicians' keys exist in the data_dict
        if "Risk" in data_dict:
              risk = data_dict["Risk"]
              print("Risk data found in the file")
        else:
            print("No Risk data found in the file")
            # return []
        
        if "Physicians" in data_dict:
            # Ensure Physicians is a list
            if not isinstance(data_dict["Physicians"], list):
                data_dict["Physicians"] = [data_dict["Physicians"]]
            physicians = data_dict["Physicians"]
            specialities = []

        if "PrescriptionDrug" in risk:
            health = risk['PrescriptionDrug']
            print("PrescriptionDrug data found in the file")
            print(f"Health data: {health}")
        else:
            print("No PrescriptionDrug data found in the file")
            health = []
        
        if "DrugDetail" in risk:
            meds = risk['DrugDetail']['Drug']
            if not isinstance(meds, list):
                meds = [meds]
            print("DrugDetail data found in the file")
            print(f"Meds data: {meds}") 
        else:
            print("No DrugDetail data found in the file")
            meds = []
            

        # Create a dictionary to quickly look up physician information
        if "Physicians" in data_dict:
           physician = data_dict["Physicians"]
        
        else:
            physicians = []

        physician_dict = {phy.get('@id'): phy for phy in physicians}
        # check if physician_dict is empty
        if not physician_dict:
            print("No physician data found in the file")
            physician_dict = {}

        payload_json = []
        processed_labels = set()
        total_therapeutic_class_score = 0
        
        if not isinstance(health, list):
            health = [health]
        
        if not isinstance(meds, list):
            meds = [meds]
        
        if not isinstance(physicians, list):
            physicians = [physicians]

        for drug in health:
            if "PrescriptionLabel" not in drug:
                continue  # Skip entries without a label

            prescription_label = str(drug["PrescriptionLabel"])
            fill_date = None

            if "PrescriptionFill" in drug and "PrescriptionFillDate" in drug["PrescriptionFill"]:
                fill_date = drug["PrescriptionFill"]["PrescriptionFillDate"]

            if prescription_label in processed_labels:
                if fill_date:
                    for entry in payload_json:
                        if entry.get("PrescriptionLabel") == prescription_label:
                            if "DateLastFilled" not in entry or fill_date > entry["DateLastFilled"]:
                                entry["DateLastFilled"] = fill_date
                            if "RefillsAllowed" in entry:
                                entry["RefillsAllowed"] = int(entry["RefillsAllowed"]) + 1
                            break
                continue  # Skip to next drug — we've already processed this label

            # First-time processing of this label
            processed_labels.add(prescription_label)

            results = {
                "PrescriptionLabel": prescription_label,
                "RefillsAllowed": 1
            }

            if "PrescriptionDaysSupply" in drug:
                results["PrescriptionDaysSupply"] = drug["PrescriptionDaysSupply"]

            if fill_date:
                results["DateFirstFilled"] = fill_date

            if ("PrescriptionFill" in drug and 
                "OLifEExtension" in drug["PrescriptionFill"] and 
                "PrescriptionStrength" in drug["PrescriptionFill"]["OLifEExtension"]):
                results["Dose"] = drug["PrescriptionFill"]["OLifEExtension"]["PrescriptionStrength"]

            if "TherapeuticClass" in drug and "#text" in drug["TherapeuticClass"]:
                results["DrugClass"] = drug["TherapeuticClass"]["#text"]

            # Add physician information
            if "PrescriptionFill" in drug and "@PhysicianID" in drug["PrescriptionFill"]:
                physician_id = drug["PrescriptionFill"]["@PhysicianID"]
                physician = physician_dict.get(physician_id)
                if physician:
                    results["PhysicianID"] = physician_id
                    if "Person" in physician:
                        #results["PhysicianName"] = f"{physician['Person'].get('FirstName', '')} {physician['Person'].get('LastName', '')}".strip()
                        results["PhysicianTitle"] = physician['Person'].get('Title', '')
                    if "Physician" in physician:
                        if "PhysicianInfo" in physician["Physician"]:
                            if "OLifEExtension" in physician["Physician"]["PhysicianInfo"]:
                                specialities = []
                                if isinstance(physician["Physician"]["PhysicianInfo"]["OLifEExtension"], list):
                                    for phy in range(len(physician["Physician"]["PhysicianInfo"]["OLifEExtension"])):
                                        # print("Physician Info:", physician["Physician"]["PhysicianInfo"]["OLifEExtension"][phy])
                                        specialities.append(physician["Physician"]["PhysicianInfo"]["OLifEExtension"][phy]["PhysicianSpecialty"])
                                    results["PhysicianSpecialties"] = specialities
                                elif isinstance(physician["Physician"]["PhysicianInfo"]["OLifEExtension"], dict):
                                    # print("Physician Info:", physician["Physician"]["PhysicianInfo"]["OLifEExtension"])
                                    #specialities.append(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"])
                                    #results["PhysicianSpecialties"] = specialities
                                    if isinstance(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"], dict):
                                                specialities.append(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"])
                                                results["PhysicianSpecialties"] = specialities
                                    elif isinstance(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"], list):
                                                for phy in range(len(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"])):
                                                    specialities.append(physician["Physician"]["PhysicianInfo"]["OLifEExtension"]["PhysicianSpecialty"][phy])
                                                results["PhysicianSpecialties"] = specialities


            for cause in meds:
                if cause.get("DrugLabel") == prescription_label and "DiseaseDescription" in cause:
                    results["DiseaseDescription"] = str(cause["DiseaseDescription"])
                    break

            payload_json.append(results)

        # Calculate total TherapeuticClassScore
        has_therapeutic_class_score = False
        for med in meds:
            if "TherapeuticClassScore" in med:
                total_therapeutic_class_score += float(med["TherapeuticClassScore"])
                has_therapeutic_class_score = True
            else:
                # do not add to the total if TherapeuticClassScore is not present
                print("TherapeuticClassScore not found for drug")

        if has_therapeutic_class_score:
            # Add the total TherapeuticClassScore to the payload_json
            #print(f"Total TherapeuticClassScore: {total_therapeutic_class_score}")
            payload_json.append({"TherapeuticClassScore": total_therapeutic_class_score})
        else:
            print("No TherapeuticClassScore found for any drug")

        # Check if payload_json is empty
        if not payload_json:
            print("No Rx data found in the provided file.")
            return data_dict
        else:
           # print(f"Rx data found: {len(payload_json)} entries")
            #print(f"Rx content: {payload_json}")
            return payload_json

    except json.JSONDecodeError as e:
        print(f"Rx JSON decode error: {e}")
        import traceback
        traceback.print_exc()
        return {} 
    
# MIB Content
def get_mib_content(input_file_name):
    """
    Extracts data from JSON and returns a dictionary
    """
    try:
        mib_fields = {}
        codes = []
        if not os.path.exists(input_file_name):
            return {}
        with open(input_file_name, 'r', encoding='utf-8-sig') as json_file:
            content = json_file.read().strip()
            if not content:
                return {}
            data = json.loads(content)
            data_dict = data["Content"]

            if "Relation" in data_dict["OLifE"]:
                for i in range(len(data_dict["OLifE"]["Relation"])):
                    if "RelationRoleCode" in data_dict["OLifE"]["Relation"][i]:
                        if "#text" in data_dict["OLifE"]["Relation"][i]["RelationRoleCode"]:
                            mib_fields["Hit/Try"] = data_dict["OLifE"]["Relation"][i]["RelationRoleCode"]["#text"]
                            break
            
            mib_fields["Face_Amount"] = 0  # Default to zero
            if "Holding" in data_dict["OLifE"]:
                if isinstance(data_dict["OLifE"]["Holding"], list):
                    for i in range(len(data_dict["OLifE"]["Holding"])):
                        if "Policy" in data_dict["OLifE"]["Holding"][i]:
                            if "Life" in data_dict["OLifE"]["Holding"][i]["Policy"]:
                                if "FaceAmt" in data_dict["OLifE"]["Holding"][i]["Policy"]["Life"]:
                                    mib_fields["Face_Amount"] = data_dict["OLifE"]["Holding"][i]["Policy"]["Life"]["FaceAmt"]
                                    break
                elif isinstance(data_dict["OLifE"]["Holding"], dict):
                    if "Policy" in data_dict["OLifE"]["Holding"]:
                        if "Life" in data_dict["OLifE"]["Holding"]["Policy"]:
                            if "FaceAmt" in data_dict["OLifE"]["Holding"]["Policy"]["Life"]:
                                mib_fields["Face_Amount"] = data_dict["OLifE"]["Holding"]["Policy"]["Life"]["FaceAmt"]  

            if "FormInstance" in data_dict["OLifE"]:
                #print("Found FormInstance")
                if not isinstance(data_dict["OLifE"]["FormInstance"], list):
                    if "FormResponse" in data_dict["OLifE"]["FormInstance"]:
                        #print("Found FormResponse")
                        mib_fields["SubmitDate"] = data_dict["OLifE"]["FormInstance"]["SubmitDate"]
                        if isinstance(data_dict["OLifE"]["FormInstance"]["FormResponse"], list):
                            for i in range(len(data_dict["OLifE"]["FormInstance"]["FormResponse"])):
                                #print("Found FormResponse") 
                                mib_temp = {}  
                                if "ResponseData" in data_dict["OLifE"]["FormInstance"]["FormResponse"][i]:
                                    mib_temp["MIBCode"] = data_dict["OLifE"]["FormInstance"]["FormResponse"][i]["ResponseData"]
                                if "MiBCodeMeaning" in data_dict["OLifE"]["FormInstance"]["FormResponse"][i]:
                                    mib_temp["MiBCodeMeaning"] = data_dict["OLifE"]["FormInstance"]["FormResponse"][i]["MiBCodeMeaning"]

                                codes.append(mib_temp)
                        else:
                            mib_temp = {} 
                            if "ResponseData" in data_dict["OLifE"]["FormInstance"]["FormResponse"]:
                                mib_temp["MIBCode"] = data_dict["OLifE"]["FormInstance"]["FormResponse"]["ResponseData"]
                                
                            if "MiBCodeMeaning" in data_dict["OLifE"]["FormInstance"]["FormResponse"]:
                                mib_temp["MiBCodeMeaning"] = data_dict["OLifE"]["FormInstance"]["FormResponse"]["MiBCodeMeaning"]

                            if mib_temp:
                                codes.append(mib_temp)
                                
                else:
                    for i in range(len(data_dict["OLifE"]["FormInstance"])):
                        if "FormResponse" in data_dict["OLifE"]["FormInstance"][i]:
                            #print("Found FormResponse")
                            if "SubmitDate" in data_dict["OLifE"]["FormInstance"][i]:
                                mib_fields["SubmitDate"] = data_dict["OLifE"]["FormInstance"][i]["SubmitDate"]
                            if isinstance(data_dict["OLifE"]["FormInstance"][i]["FormResponse"], list):
                                for j in range(len(data_dict["OLifE"]["FormInstance"][i]["FormResponse"])):
                                    #print("Found FormResponse") 
                                    mib_temp = {}  
                                    if "ResponseData" in data_dict["OLifE"]["FormInstance"][i]["FormResponse"][j]:
                                        mib_temp["MIBCode"] = data_dict["OLifE"]["FormInstance"][i]["FormResponse"][j]["ResponseData"]
                                    
                                    if "MiBCodeMeaning" in data_dict["OLifE"]["FormInstance"][i]["FormResponse"][j]:
                                        mib_temp["MiBCodeMeaning"] = data_dict["OLifE"]["FormInstance"][i]["FormResponse"][j]["MiBCodeMeaning"]

                                    #print(mib_temp)
                                    codes.append(mib_temp)

                            else:
                                mib_temp = {} 
                                if "ResponseData" in data_dict["OLifE"]["FormInstance"][i]["FormResponse"]:
                                    mib_temp["MIBCode"] = data_dict["OLifE"]["FormInstance"][i]["FormResponse"]["ResponseData"]
                                    
                                if "MiBCodeMeaning" in data_dict["OLifE"]["FormInstance"][i]["FormResponse"]:
                                    mib_temp["MiBCodeMeaning"] = data_dict["OLifE"]["FormInstance"][i]["FormResponse"]["MiBCodeMeaning"]

                                if mib_temp:
                                    codes.append(mib_temp)
                mib_fields["MIBCodes"] = codes
            #print("MIB:", mib_fields)
        return mib_fields
    except Exception as e:
        print(f"Error reading MIB JSON file: {e}")
        # print(f"Error reading MIB JSON file: {e}")
        # print(f"Error type: {type(e)}")
        # print(f"Error details: {traceback.format_exc()}")
        return {}


# Merge all
def prepare_context_subset2(partAfile, partBfile, Rxfile,Dxfile,labfile,mibfile):
    app_date = date_App(partAfile)
    partB_content = get_partB_content(partBfile)
    Rx_content = get_Rx_content(Rxfile)
    Dx_content = get_Dx_content(Dxfile)
    Lab_content = get_Lab_content(labfile)
    mib_content = get_mib_content(mibfile)
    output = (
        f"Application Date: {app_date}\n"
        "Part B\n"
        f"{partB_content}\n\n"
        "\nPrescription (Rx)\n"
        f"{Rx_content}\n\n"
        "Diagnosis (Dx)\n"
        f"{Dx_content}\n\n"
        "Lab Results\n"
        f"{Lab_content}\n\n"
        "MIB\n"
        f"{mib_content}"
    )
    
    return output

def main():
    # /home/CORP/shreya235361/projects/bu-digital-llmlds-uwassist-app/AIAgents-LDS/data_sources_batch4/ 9226578/ 9226578_MWA_BASEPAYLOAD_part_A.json
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    prod_samples_dir = os.path.join(base_dir, 'data_sources_batch4')
    case_folder = " 9233022"  # Example case folder, change as needed
    base_folder = os.path.join(prod_samples_dir, case_folder)
    partAfile = os.path.join(base_folder, f"{case_folder}_MWA_BASEPAYLOAD_part_A.json")
    partBfile = os.path.join(base_folder, f"{case_folder}_MWA_BASEPAYLOAD_part_B.json")
    Rx = os.path.join(base_folder, f"{case_folder}_MWA_HEALTHRESULTS_Rx.json")
    Dx = os.path.join(base_folder, f"{case_folder}_MWA_HEALTHRESULTS_Dx.json")
    Lab = os.path.join(base_folder, f"{case_folder}_MWA_HEALTHRESULTS_Lab.json")
    mib = os.path.join(base_folder, f"{case_folder}_modified_MWA_MIB.json")
    # print(prepare_context_subset2(partAfile, partBfile, Rx, Dx, Lab, mib))


if __name__ == "__main__":
    main()