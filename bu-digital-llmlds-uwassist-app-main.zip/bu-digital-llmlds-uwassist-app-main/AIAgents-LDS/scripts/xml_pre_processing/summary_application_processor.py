import json
import os
import pandas as pd
from context_summary_demographics import prepare_context_demographics
from context_summary_medical import prepare_context_medical

# System prompts for different contexts
# SYSTEM_PROMPT_DEMOGRAPHICS = (
#     "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
#     "You are an underwriting expert specializing in demographic and lifestyle risk assessment. "
#     "Analyze the provided demographic information and provide insights on risk factors related to "
#     "age, occupation, driving record, and lifestyle choices. Focus on identifying potential red flags "
#     "that may require additional underwriting consideration. Only respond in the below JSON format:\n"
#     "[{\"Risk Factor\": <risk_factor>, \"Assessment\": <assessment>, \"Recommendation\": <recommendation>}, { }, ..]<|eot_id|>\n"
# )

SYSTEM_PROMPT = (
    """<|begin_of_text|><|start_heade_id|>system<|end_header_id|> You are an expert at summarizing and reasoning over underwriting data given in the <Context> to provide a good overall summary. Follow the formatting instructions given in the user prompts, keep the bullet points small and concise, focusing on the seriousness of findings. In the user input, <Context></Context> contains the underwriting case details, and <Sections></Sections> contains the sections that you have to summarize from the context. Only respond in the below JSON format: {\"Answer\": <final answer>} <|eot_id|> \n"""
)

# User prompt templates
USER_PROMPT_TEMPLATE_DEMOGRAPHICS = (
    """\n <|start_header_id|>user<|end_header_id|> Within the <Sections> tag, all the sections that need to be summarized are given. Only refer to the details mentioned within the <Context> tag. <Sections> Demographics \n MVR \n Miscellaneous \n Additional Notes</Sections> \n
                Instructions:
                1. In the Answer field, group your summary by these topics with HIDDEN MARKDOWN HEADERS for validation: Demographics, MVR, Miscellaneous and Additional Notes. Give bullet points in the form of string.
                2. For Demographics topic: include age at written date, gender, occupation and citizenship
                3. For MVR topic: include the driving status (MVRStatus) which will tell if the applicant has a valid driving license or not and tell the name of the ACTUAL MOTOR VEHICLE RECORD violations present ONLY from the MVRViolations section if they are present, otherwise state that there are no violations reported, also give the risk classifier score. Do NOT include risk classifier messages (like "Presence of Account Currently Not Paid", "Collection Agency Filings", "Absence of Property Ownership") as these are NOT driving violations - they are credit/financial information. Do NOT give order number or any other irrelevant details for underwriting. Lexisnexis clear is for violations. MVR Status is given separately in the context.
                4. For Miscellaneous topic: include aviation, avocation, foreign travel, criminal background, coverage information. If something is not present state that its not present.
                5. In the Additional Notes topic, include any recommendations for underwriter if there are any serious findings in a concise way. 
                
                IMPORTANT FORMATTING REQUIREMENTS:
                - Start each section with a hidden markdown header: <!-- Section: <section_name> -->
                - Use the exact section names: Physical Metrics, Medical History, Substance Use, Miscellaneous, Additional Notes
                - Format example:
                  <!-- Section: Demographics -->
                    • Age: 46
                    • Gender: Male
                  
                You will provide your response in the following JSON format ONLY:
                {
                  "Answer": "Summary by topics mentioned above in bullet points WITH HIDDEN MARKDOWN HEADERS"
                }
                
                Do not give any additional text or context, only the JSON response. Generate a valid JSON object using only double quotes (") for keys and string values, as per the JSON standard. Ensure there are no single quotes (') in the output. Provide a well-formatted and syntactically correct JSON.
                You will get the user query, application date, and the available answers as input below.\n"""

)

USER_PROMPT_TEMPLATE_MEDICAL = (
    """\n <|start_header_id|>user<|end_header_id|> Within the <Sections> tag, all the sections that need to be summarized are given. Only refer to the details mentioned within the <Context> tag. <Sections> Physical Metrics \n Medical History \n Substance Use \n Miscellaneous \n Additional Notes</Sections> \n
                Instructions:
                1. In the Answer field, group your summary by these topics with HIDDEN MARKDOWN HEADERS for validation: Physical Metrics, Medical History, Substance Use, Miscellaneous and Additional Notes. Give bullet points in the form of string.
                2. For Physical Metrics topic: include height, weight, BMI, weight loss reason if there is any weight loss, Pulse, Blood Pressure readings. State whether its from Part B, MIB, Lab test data source or any other data source. If there is no weight loss then mention that there is no weight loss. If these information are also found in other data sources except Part B, then mention that its from other data sources and mention the values from other data sources.
                3. For Medical History topic:
                   - mention the data sources that you used to infer each finding in the medical history section.
                   - for prescriptions, also give information like number of refills taken, number of refills allowed, date first filled, date last filled, drug class for each major prescriptionetc.
                   - include prescription, Lab tests, Diagnosis, Risk Scores and whether there are any serious findings.
                   - If there are serious findings for potential indications of risk, summarize them clearly and directly under the relevant topic, state the evidence.
                   - always give the source from which you got the information.
                   - Risk Scores should always include prescription score, mortality score, theraputic class score all should be categorized as Risk Scores
                4. For Substance Use topic: include smoking status, tobacco use, alcohol use, drug use, and any other substance use. If something is not present state that its not present.
                5. For Miscellaneous topic: include beneficiary types information. If something is not present state that its not present.
                6. In the Additional Notes topic, include any recommendations for underwriter if there are any serious findings in a concise way. 
                7. Always give the build information, MIB codes if present, any comorbid conditions
                
                IMPORTANT FORMATTING REQUIREMENTS:
                - Start each section with a hidden markdown header: <!-- Section: <section_name> -->
                - Use the exact section names: Physical Metrics, Medical History, Substance Use, Miscellaneous, Additional Notes
                - Format example:
                  <!-- Section: Physical Metrics -->
                  • Height: 5'7"
                  • Weight: 185 lbs
                  
                You will provide your response in the following JSON format ONLY:
                {
                  "Answer": "Summary by topics mentioned above in bullet points WITH HIDDEN MARKDOWN HEADERS"
                }
                
                Do not give any additional text or context, only the JSON response. Generate a valid JSON object using only double quotes (") for keys and string values, as per the JSON standard. Ensure there are no single quotes (') in the output. Provide a well-formatted and syntactically correct JSON.
                You will get the user query, application date, and the available data as input below. \n"""
)

# Context templates
CONTEXT_TEMPLATE_DEMOGRAPHICS = (
    "<Context>\n"
    "{context}\n"
    "</Context>\n"
)

CONTEXT_TEMPLATE_MEDICAL = (
    "<Context>\n"
    "{context}\n"
    "</Context>\n"
)

def find_application_folder(batch_dirs, application_number):
    """
    Find the application folder across multiple batch directories, handling naming variations.
    
    Args:
        batch_dirs (list): List of batch directory paths to search
        application_number (str): The application number to find
    
    Returns:
        tuple: (batch_dir, folder_name) if found, (None, None) if not found
    """
    app_num_str = str(application_number).strip()
    
    for batch_dir in batch_dirs:
        if not os.path.exists(batch_dir):
            continue
            
        # Try exact match first
        exact_folder = os.path.join(batch_dir, app_num_str)
        if os.path.exists(exact_folder):
            return batch_dir, app_num_str
        
        # Try variations with spaces (common issue)
        for folder in os.listdir(batch_dir):
            folder_path = os.path.join(batch_dir, folder)
            if os.path.isdir(folder_path):
                # Check if folder matches after stripping spaces
                if folder.strip() == app_num_str:
                    return batch_dir, folder
    
    return None, None

def get_application_file_paths(batch_dirs, application_number):
    """
    Get all required file paths for an application, searching across multiple batch directories.
    
    Args:
        batch_dirs (list): List of batch directory paths to search
        application_number (str): The application number
    
    Returns:
        dict: File paths dictionary, or None if application folder not found
    """
    batch_dir, folder_name = find_application_folder(batch_dirs, application_number)
    
    if batch_dir is None:
        return None
    
    folder = os.path.join(batch_dir, folder_name)
    app_num_clean = str(application_number).strip()
    
    # For files with spaces in folder names, the file names might also have spaces
    # Let's check what files actually exist and use the correct naming pattern
    file_paths = {}
    
    # Define the base file name patterns to check
    base_patterns = [
        ('partA', '_MWA_BASEPAYLOAD_part_A.json'),
        ('partB', '_MWA_BASEPAYLOAD_part_B.json'),
        ('mvr', '_modified_MWA_RISKCLASSIFIER.json'),
        ('mib', '_modified_MWA_MIB.json'),
        ('rx', '_MWA_HEALTHRESULTS_Rx.json'),
        ('dx', '_MWA_HEALTHRESULTS_Dx.json'),
        ('lab', '_MWA_HEALTHRESULTS_Lab.json')
    ]
    
    # Try different naming patterns
    for file_type, suffix in base_patterns:
        # Try with clean app number first
        clean_path = os.path.join(folder, f"{app_num_clean}{suffix}")
        if os.path.exists(clean_path):
            file_paths[file_type] = clean_path
        else:
            # Try with folder name (which might have spaces)
            folder_name_path = os.path.join(folder, f"{folder_name}{suffix}")
            if os.path.exists(folder_name_path):
                file_paths[file_type] = folder_name_path
            else:
                # File doesn't exist with either pattern
                file_paths[file_type] = clean_path  # Use clean path as default for error reporting
    
    return file_paths

def validate_application_files(file_paths, context_type="both"):
    """
    Validate that required files exist for an application based on context type.
    
    Args:
        file_paths (dict): Dictionary of file paths
        context_type (str): "demographics", "medical", or "both"
    
    Returns:
        tuple: (can_process_demographics, can_process_medical, missing_files)
    """
    if file_paths is None:
        return False, False, ["Application folder not found"]
    
    # Core files needed for both contexts
    core_files = ['partA', 'partB']
    
    # Additional files for demographics context (MVR is often missing, so make it optional)
    demographics_files = ['mib']  # mvr removed from required
    
    # Additional files for medical context (at least one medical file needed)
    medical_files = ['rx', 'dx', 'lab', 'mib']
    
    missing_files = []
    can_process_demographics = True
    can_process_medical = True
    
    # Check core files
    for file_type in core_files:
        if not os.path.exists(file_paths[file_type]):
            missing_files.append(f"{file_type}: {file_paths[file_type]}")
            can_process_demographics = False
            can_process_medical = False
    
    # Check demographics files (only if core files exist)
    if can_process_demographics:
        for file_type in demographics_files:
            if not os.path.exists(file_paths[file_type]):
                missing_files.append(f"{file_type}: {file_paths[file_type]}")
                # Don't fail demographics for missing mib - it's often empty anyway
                # can_process_demographics = False
    
    # Check medical files (only if core files exist and at least one medical file exists)
    if can_process_medical:
        medical_files_exist = 0
        for file_type in medical_files:
            if os.path.exists(file_paths[file_type]):
                medical_files_exist += 1
            else:
                missing_files.append(f"{file_type}: {file_paths[file_type]}")
        
        # Need at least core files + one medical file for medical processing
        if medical_files_exist == 0:
            can_process_medical = False
    
    return can_process_demographics, can_process_medical, missing_files

def prepare_application_jsonl_entries(application_number, demographics_summary, medical_summary, 
                                    overall_summary, batch_dirs):
    """
    Prepare JSONL entries for a single application with both demographics and medical contexts.
    
    Args:
        application_number (str): The application number
        demographics_summary (str): Demographics summary from Excel
        medical_summary (str): Medical summary from Excel
        overall_summary (str): Overall summary from Excel
        batch_dirs (list): List of directories containing application data
    
    Returns:
        list: List of JSONL entries (demographics and medical contexts), or empty list if files missing
    """
    jsonl_entries = []
    
    # Get file paths for the application across all batch directories
    file_paths = get_application_file_paths(batch_dirs, application_number)
    
    # Validate files exist and determine what contexts can be processed
    can_process_demographics, can_process_medical, missing_files = validate_application_files(file_paths)
    
    if not can_process_demographics and not can_process_medical:
        # Skip this application entirely if no processing is possible
        return jsonl_entries
    
    # Prepare demographics context and entry (Subset 1) - only if we can process demographics
    if can_process_demographics:
        try:
            demographics_context = prepare_context_demographics(
                file_paths['partA'], 
                file_paths['partB'], 
                file_paths['mvr'] if os.path.exists(file_paths['mvr']) else "", 
                file_paths['mib'] if os.path.exists(file_paths['mib']) else ""
            )
            
            demographics_entry = {
                "ApplicationNumber": application_number,
                "Subset": 1,
                "Type": "demographics",
                "System": SYSTEM_PROMPT,
                "User": USER_PROMPT_TEMPLATE_DEMOGRAPHICS,
                "Context": CONTEXT_TEMPLATE_DEMOGRAPHICS.format(context=demographics_context),
                "Summary": demographics_summary,
                "OverallSummary": overall_summary
            }
            
            jsonl_entries.append(demographics_entry)
            
        except Exception as e:
            print(f"Error preparing demographics context for application {application_number}: {e}")
    
    # Prepare medical context and entry (Subset 2) - only if we can process medical
    if can_process_medical:
        try:
            medical_context = prepare_context_medical(
                file_paths['partA'], 
                file_paths['partB'], 
                file_paths['rx'] if os.path.exists(file_paths['rx']) else "", 
                file_paths['dx'] if os.path.exists(file_paths['dx']) else "", 
                file_paths['lab'] if os.path.exists(file_paths['lab']) else "", 
                file_paths['mib'] if os.path.exists(file_paths['mib']) else ""
            )
            
            medical_entry = {
                "ApplicationNumber": application_number,
                "Subset": 2,
                "Type": "medical",
                "System": SYSTEM_PROMPT,
                "User": USER_PROMPT_TEMPLATE_MEDICAL,
                "Context": CONTEXT_TEMPLATE_MEDICAL.format(context=medical_context),
                "Summary": medical_summary,
                "OverallSummary": overall_summary
            }
            
            jsonl_entries.append(medical_entry)
            
        except Exception as e:
            print(f"Error preparing medical context for application {application_number}: {e}")
    
    return jsonl_entries

def process_excel_file_to_jsonl(excel_file_path, output_jsonl_path, batch_dirs):
    """
    Process the Excel file and create a JSONL file with application data.
    
    Args:
        excel_file_path (str): Path to the Excel file
        output_jsonl_path (str): Path to the output JSONL file
        batch_dirs (list): List of directories containing application data files
    """
    try:
        # Read the Excel file
        print(f"Reading Excel file: {excel_file_path}")
        df = pd.read_excel(excel_file_path)
        
        print(f"Found {len(df)} rows in Excel file")
        print(f"Columns: {df.columns.tolist()}")
        
        # Initialize output file (append mode - will add to existing file if it exists)
        # Note: File will be created if it doesn't exist, or appended to if it does exist
        
        total_entries = 0
        processed_applications = 0
        
        # Process each row
        for index, row in df.iterrows():
            # Extract data from row
            app_number = str(row.get('ApplicationNumber', '')).strip()
            demographics_summary = str(row.get('Demographics Summary', '')).strip()
            
            # Check if demographics summary is already a valid JSON object with "Answer" key
            if demographics_summary:
                try:
                    # Try to parse as JSON and check if it has "Answer" key at root level
                    parsed_json = json.loads(demographics_summary.strip())
                    if isinstance(parsed_json, dict) and "Answer" in parsed_json:
                        # Check if the Answer value is itself a JSON object with another Answer key (nested case)
                        answer_value = parsed_json["Answer"]
                        if isinstance(answer_value, dict) and "Answer" in answer_value:
                            # This is the double Answer case - extract the inner Answer value
                            demographics_summary = json.dumps(answer_value["Answer"])
                        elif isinstance(answer_value, dict):
                            demographics_summary = json.dumps(answer_value)
                        else:
                            # Already has Answer key, keep as is (it's already properly formatted)
                            demographics_summary = demographics_summary.strip()
                    else:
                        # Need to wrap with Answer key
                        demographics_summary = f'{{"Answer": {demographics_summary.strip()}}}'
                except (json.JSONDecodeError, ValueError):
                    # If it's not valid JSON, wrap it properly
                    demographics_summary = f'{{"Answer": {demographics_summary.strip()}}}'
            
            medical_summary = str(row.get('Medical Summary', '')).strip()
            if medical_summary:
                # try:
                    # Try to parse as JSON and check if it has "Answer" key at root level
                    # parsed_json = json.loads(medical_summary.strip())
                    # if isinstance(parsed_json, dict) and "Answer" in parsed_json:
                    #     # Check if the Answer value is itself a JSON object with another Answer key (nested case)
                    #     answer_value = parsed_json["Answer"]
                    #     if isinstance(answer_value, dict) and "Answer" in answer_value:
                    #         # This is the double Answer case - extract the inner Answer value
                    #         medical_summary = json.dumps({"Answer": answer_value["Answer"]})
                    #     else:
                    #         # Already has Answer key, keep as is (it's already properly formatted)
                    medical_summary = medical_summary.strip()
                    # else:
                    #     # Need to wrap with Answer key
                    #     medical_summary = f'{{"Answer": {medical_summary.strip()}}}'
                # except (json.JSONDecodeError, ValueError):
                #     # If it's not valid JSON, wrap it properly
                #     medical_summary = f'{{"Answer": {medical_summary.strip()}}}'

            overall_summary = str(row.get('Overall Summary', '')).strip()
            
            # Skip if no application number
            if not app_number or app_number == 'nan':
                print(f"Skipping row {index + 1}: No application number")
                continue
            
            print(f"Processing application {app_number} (row {index + 1})")
            
            # Prepare JSONL entries
            jsonl_entries = prepare_application_jsonl_entries(
                app_number, 
                demographics_summary, 
                medical_summary, 
                overall_summary, 
                batch_dirs
            )
            
            # Write entries to file (append mode)
            if jsonl_entries:
                with open(output_jsonl_path, 'a', encoding='utf-8') as f:
                    for entry in jsonl_entries:
                        f.write(json.dumps(entry, ensure_ascii=False) + '\n')
                
                total_entries += len(jsonl_entries)
                processed_applications += 1
                print(f"  - Created {len(jsonl_entries)} entries for application {app_number}")
            else:
                print(f"  - No entries created for application {app_number}")
        print(f"\nProcessing complete!")
        print(f"Total applications processed: {processed_applications}")
        print(f"Total JSONL entries created: {total_entries}")
        print(f"Output file: {output_jsonl_path}")
        
    except Exception as e:
        print(f"Error processing Excel file: {e}")
        raise

def main():
    """
    Main function to process the Excel file and create JSONL output.
    """
    # File paths
    excel_file_path = "summary_results_100_3_cleaned.xlsx"
    output_jsonl_path = "summary_data_1aug_.jsonl"
    batch_dirs = ["data_sources_batch3", "data_sources_batch4"]  # Search both directories
    
    # Check if Excel file exists
    if not os.path.exists(excel_file_path):
        print(f"Error: Excel file '{excel_file_path}' not found")
        return
    
    # Check if batch directories exist
    existing_dirs = [d for d in batch_dirs if os.path.exists(d)]
    if not existing_dirs:
        print(f"Error: None of the batch directories exist: {batch_dirs}")
        return
    
    print(f"Using batch directories: {existing_dirs}")
    
    # Process the Excel file
    process_excel_file_to_jsonl(excel_file_path, output_jsonl_path, existing_dirs)

if __name__ == "__main__":
    main() 