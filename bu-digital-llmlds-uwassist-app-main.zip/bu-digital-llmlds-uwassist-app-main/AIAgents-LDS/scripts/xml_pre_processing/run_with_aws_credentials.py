#!/usr/bin/env python3
"""
AWS Credentials Setup and LLM Processing Runner

This script helps set up AWS credentials and run the test LLM processor.
"""

import os
import subprocess

def setup_aws_credentials():
    """
    Guide user through AWS credentials setup.
    """
    print("AWS Credentials Setup")
    print("=" * 50)
    print()
    print("The LLM processor requires AWS credentials to access Bedrock.")
    print("You have several options:")
    print()
    print("1. Set environment variables:")
    print("   export AWS_ACCESS_KEY_ID='your-access-key'")
    print("   export AWS_SECRET_ACCESS_KEY='your-secret-key'")
    print("   export AWS_DEFAULT_REGION='us-east-1'")
    print()
    print("2. Use AWS CLI to configure credentials:")
    print("   aws configure")
    print()
    print("3. Use IAM roles if running on EC2")
    print()
    print("4. Set up AWS credentials file at ~/.aws/credentials")
    print()
    
    # Check if .env file exists
    env_file = os.path.join(os.path.dirname(__file__), '..', '..', '.env')
    if os.path.exists(env_file):
        print(f"Found .env file at: {env_file}")
        print("Make sure it contains the required AWS and Bedrock environment variables.")
    else:
        print("No .env file found. You may need to create one with your AWS/Bedrock configuration.")
    
    print()
    input("Press Enter when you have configured AWS credentials...")

def check_aws_credentials():
    """
    Check if AWS credentials are available.
    """
    try:
        import boto3
        client = boto3.client('bedrock-runtime', region_name='us-east-1')
        # Try to list models to test credentials
        client.list_foundation_models()
        print("✅ AWS credentials are properly configured!")
        return True
    except Exception as e:
        print(f"❌ AWS credentials issue: {e}")
        return False

def run_llm_processor():
    """
    Run the test LLM processor.
    """
    try:
        print("\nRunning Test LLM Processor...")
        print("=" * 50)
        result = subprocess.run(['python', 'test_llm_processor.py'], 
                              capture_output=True, text=True)
        
        if result.returncode == 0:
            print("✅ LLM processor completed successfully!")
            print("\nOutput:")
            print(result.stdout)
        else:
            print("❌ LLM processor failed!")
            print("\nError output:")
            print(result.stderr)
            
    except Exception as e:
        print(f"Error running LLM processor: {e}")

def main():
    """
    Main function to set up and run the LLM processor.
    """
    print("Test LLM Processor with AWS Setup")
    print("=" * 50)
    
    # Check current credentials
    print("Checking AWS credentials...")
    if check_aws_credentials():
        print("Credentials are ready. Proceeding with LLM processing...")
        run_llm_processor()
    else:
        print("Setting up AWS credentials...")
        setup_aws_credentials()
        
        # Check again after setup
        if check_aws_credentials():
            run_llm_processor()
        else:
            print("❌ AWS credentials still not working. Please check your setup.")
            print("\nThe Excel file structure has been created with error messages.")
            print("You can find it at: test_llm_results.xlsx")

if __name__ == "__main__":
    main()