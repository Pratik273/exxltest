#!/usr/bin/env python3
"""
Test script for the enhanced summary application processor.
Process a smaller subset to verify functionality.
"""

import os
import sys
import pandas as pd

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from summary_application_processor import process_excel_file_to_jsonl

def test_enhanced_processor():
    """Test the enhanced processor with a small subset."""
    
    # Change to the correct directory
    original_dir = os.getcwd()
    target_dir = "/home/CORP/shreya235361/projects/bu-digital-llmlds-uwassist-app/AIAgents-LDS"
    os.chdir(target_dir)
    
    try:
        # Read only first 50 rows for testing
        excel_path = "summary_results_100_3_cleaned.xlsx"
        df = pd.read_excel(excel_path)
        
        # Create a subset for testing
        test_df = df.head(50)  # Test with first 50 applications
        test_excel_path = "test_summary_results_50.xlsx"
        test_df.to_excel(test_excel_path, index=False)
        
        print(f"Created test file with {len(test_df)} applications")
        
        # Process the test file
        output_jsonl_path = "test_summary_data_enhanced.jsonl"
        batch_dirs = ["data_sources_batch3", "data_sources_batch4"]
        
        existing_dirs = [d for d in batch_dirs if os.path.exists(d)]
        print(f"Using batch directories: {existing_dirs}")
        
        # Process the test Excel file
        process_excel_file_to_jsonl(test_excel_path, output_jsonl_path, existing_dirs)
        
        # Check results
        if os.path.exists(output_jsonl_path):
            with open(output_jsonl_path, 'r') as f:
                lines = f.readlines()
            
            print(f"\nTest Results:")
            print(f"Generated {len(lines)} JSONL entries")
            print(f"Expected up to {len(test_df) * 2} entries (50 apps × 2 contexts)")
            print(f"Success rate: {len(lines) / (len(test_df) * 2) * 100:.1f}%")
            
            # Show sample entry
            if lines:
                import json
                sample_entry = json.loads(lines[0])
                print(f"\nSample entry keys: {list(sample_entry.keys())}")
        
        # Clean up test files
        if os.path.exists(test_excel_path):
            os.remove(test_excel_path)
            
    except Exception as e:
        print(f"Error in test: {e}")
        import traceback
        traceback.print_exc()
    finally:
        os.chdir(original_dir)

if __name__ == "__main__":
    test_enhanced_processor()