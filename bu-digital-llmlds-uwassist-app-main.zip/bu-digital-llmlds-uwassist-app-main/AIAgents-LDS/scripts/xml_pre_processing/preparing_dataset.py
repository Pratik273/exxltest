import os
import sys
# sys.path.append(os.path.join(os.path.dirname(__file__), "../.."))
from context_subset1 import prepare_context_subset1
from context_subset2 import prepare_context_subset2
import json

def load_json_file(file_path):
    """Helper function to load JSON data from file"""
    if not file_path:
        return None
        
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading file {file_path}: {e}")
        return None
    
def get_questions_by_subset(excel_file, subset_num=1):
    """
    Extracts questions from Excel file where Subset equals the specified number
    
    Args:
        excel_file (str): Path to Excel file
        subset_num (int): Subset number to filter (default: 1)
    
    Returns:
        list: List of questions from the specified subset
    """
    import pandas as pd
    try:
        # Read the Excel file
        df = pd.read_excel(excel_file, sheet_name='FAQs', header=1)
        
        # Print column names to debug
        # print(f"Excel columns: {df.columns.tolist()}")

        # Filter rows where Subset column equals subset_num
        subset_df = df[df['Subset (1 or 2)'] == subset_num]
        
        # Extract just the questions column
        questions_list = []
        
        # Assuming 'Qn' column contains the questions
        if 'Qn' in subset_df.columns:
            questions_list = subset_df['Qn'].tolist()

            questions_list = [
                str(q)
                .strip()                    # Remove leading/trailing whitespace
                .replace('\xa0', ' ')       # Replace non-breaking space with regular space
                .replace('\n', ' ')         # Replace newlines with spaces
                .replace('\t', ' ')         # Replace tabs with spaces
                .replace('\r', '')          # Remove carriage returns
                for q in questions_list 
                if pd.notna(q)              # Skip NaN values
            ]
        
        print(f"Found {len(questions_list)} questions for Subset {subset_num}")
        # print(f"Questions: {questions_list}")  # Print first 5 questions for debugging
        return questions_list
    except Exception as e:
        print(f"Error reading Excel file {excel_file}: {e}")
        return []

def get_questions_1(excel_file):
    """
    Extracts Subset 1 questions from Excel file
    """
    return get_questions_by_subset(excel_file, 1)

def get_questions_2(excel_file):
    """
    Extracts Subset 2 questions from Excel file
    """
    return get_questions_by_subset(excel_file, 2)

def get_output_by_subset(excel_file, certificate_number, subset_num=1):
    """
    Extracts questions, reasons, and answers for Subset 1 from Excel file
    for a specific certificate number from row 1.
    
    Args:
        excel_file (str): Path to Excel file
        certificate_number (str): Certificate number to match from row 1
    
    Returns:
        list: List of dictionaries with Question, Reason, and Answer
    """
    import pandas as pd
    try:
        # Read the first row (certificate numbers) without header
        cert_df = pd.read_excel(excel_file, sheet_name='FAQs', nrows=1, header=None)
        
        # Find columns containing the certificate number
        cert_cols = []
        for col_idx, col in enumerate(cert_df.columns):
            if str(cert_df.iloc[0, col_idx]) == str(certificate_number):
                cert_cols.append(col_idx)
        
        if not cert_cols:
            print(f"Certificate number {certificate_number} not found in row 1")
            return []
            
        # Read the rest of the Excel file with headers on row 2
        df = pd.read_excel(excel_file, sheet_name='FAQs', header=1)
        
        # Filter rows where Subset is 1
        subset_df = df[df['Subset (1 or 2)'] == subset_num]
        
        # Find the correct Reason and Answer columns for the certificate number
        reason_col = None
        answer_col = None
        
        # Map column indices to header names
        col_mapping = dict(enumerate(df.columns))
        
        for col_idx in cert_cols:
            col_name = col_mapping.get(col_idx)
            if col_name and 'Reason' in str(col_name):
                reason_col = col_name
            elif col_name and 'Answer' in str(col_name):
                answer_col = col_name
        
        if not reason_col or not answer_col:
            print(f"Could not find Reason/Answer columns for certificate {certificate_number}")
            # print("Available columns:", df.columns.tolist())
            return []
        
        # Create output list
        output_list = []
        
        # Process each row
        for _, row in subset_df.iterrows():
            if pd.notna(row['Qn']):
                # Clean the strings
                question = str(row['Qn']).strip().replace('\xa0', ' ')
                reason = str(row[reason_col]).strip().replace('\xa0', ' ') if pd.notna(row[reason_col]) else ''
                answer = str(row[answer_col]).strip().replace('\xa0', ' ') if pd.notna(row[answer_col]) else ''
                
                # Additional string cleaning
                for text in [question, reason, answer]:
                    text = (text
                           .replace('\n', ' ')
                           .replace('\t', ' ')
                           .replace('\r', '')
                           .replace('  ', ' ')  # Remove double spaces
                           .strip())
                
                # Create dictionary for this QRA set
                qra_dict = {
                    "Question": question,
                    "Reason": reason,
                    "Answer": answer
                }
                output_list.append(qra_dict)
        
        print(f"Created output list with {len(output_list)} QRA sets for certificate {certificate_number}")
        # print(f"Sample output: {output_list}")
        return output_list
        
    except Exception as e:
        print(f"Error processing Excel file {excel_file}: {e}")
        import traceback
        traceback.print_exc()
        return []

def get_output_1(excel_file, certificate_number):
    """
    Gets output for Subset 1 from Excel file for a specific certificate number.
    
    Args:
        excel_file (str): Path to Excel file
        certificate_number (str): Certificate number to match from row 1
    
    Returns:
        list: List of dictionaries with Question, Reason, and Answer
    """
    return get_output_by_subset(excel_file, certificate_number, subset_num=1)

def get_output_2(excel_file, certificate_number):
    """
    Gets output for Subset 2 from Excel file for a specific certificate number.
    
    Args:
        excel_file (str): Path to Excel file
        certificate_number (str): Certificate number to match from row 1
    
    Returns:
        list: List of dictionaries with Question, Reason, and Answer
    """
    return get_output_by_subset(excel_file, certificate_number, subset_num=2)


def prepare_entries(part_A, part_B, rx, dx, lab, mvr, mib, excel_file):
    """
    Creates dataset by combining data from different functions and outputs a .jsonl file.
    """
    system_prompt = """<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n
    You are an underwriting expert. Answer all questions using only the context provided by the user. Keep 
    responses concise and include clear reasoning. In the user input, <Context></Context> contains the 
    underwriting case details, and <Questions></Questions> contains the questions to be answered. Only respond in the
    below JSON format:\n
    [{"Question": <question>, "Reason": <reason of final answer>, "Answer": <final answer>}, {},..]<|eot_id|>\n
    """

    part_a_json = load_json_file(part_A)
    certificate_number = part_a_json.get('CertificateNumber', 'N/A') if part_a_json else 'N/A'
    prepared_context_2 = prepare_context_subset1(part_A, part_B, rx, dx, lab, mib)
    prepared_context_1 = prepare_context_subset2(part_A, part_B, mvr, mib)


    user_prompt_1 = """
    <|start_header_id|>user<|end_header_id|>\n
    Within the <Questions> tag, all the questions that need to be answered are given. Only refer to the details
    mentioned within the <Context> tag.\n
    <Questions>\n
    {questions_1}\n
    </Questions>\n
    """

    context_1 = """
    <Context>\n
    {context_1}\n
    </Context>\n
    <|eot_id|>\n
    
    """

    output_1 = """ 
    <start_header_id|>assistant<|end_header_id|>\n
    {output_1_results}
    <|eot_id|>\n
    """
    

    user_prompt_2 = """
    <|start_header_id|>user<|end_header_id|>
    Within the <Questions> tag, all the questions that need to be answered are given. Only refer to the details
    mentioned within the <Context> tag.
    <Questions>
    {questions_2}
    </Questions>
    """

    context_2 = """
    <Context>\n
    {context_2}\n
    </Context>\n
    <|eot_id|>\n
    <start_header_id|>assistant<|end_header_id|>\n
    """

    output_2 = """ 
    <start_header_id|>assistant<|end_header_id|>\n
    {output_2_results}
    <|eot_id|>\n
    """

    entry_1 = {
        "CertificateNumber": certificate_number,
        "Subset": "1",
        "System": system_prompt,    
        "User": user_prompt_1.format(questions_1=get_questions_1(excel_file)),
        "Context": context_1.format(context_1=prepared_context_1),
        "Output": output_1.format(output_1_results=get_output_1(excel_file, certificate_number))
    }

    entry_2 = {
        "CertificateNumber": certificate_number,
        "Subset": "2",
        "System": system_prompt,
        "User": user_prompt_2.format(questions_2=get_questions_2(excel_file)),
        "Context": context_2.format(context_2=prepared_context_2),
        "Output": output_2.format(output_2_results=get_output_2(excel_file, certificate_number))
    }

    return entry_1, entry_2


def create_dataset(part_A, part_B, rx, dx, lab, mvr, mib, excel_file, output_file):
    """
    Creates a dataset by preparing entries and saving them to a .jsonl file.
    """
    entries = []
    entry_1, entry_2 = prepare_entries(part_A, part_B, rx, dx, lab, mvr, mib, excel_file)
    entries.append(entry_1)
    entries.append(entry_2)
    
    # Assuming you want to save the entries to a file
    # Check if the file exists, if it does we'll append to it
    
    if not os.path.exists(output_file):
        # File doesn't exist, create it
        mode = 'w'
    else:
        # File exists, append to it
        mode = 'a'
        
    with open(output_file, mode, encoding='utf-8') as f:
        for entry in entries:
            f.write(json.dumps(entry) + '\n')
    
    print(f"Dataset {'created' if mode == 'w' else 'appended'} to {output_file}")


def main_dataset_creation():
    """
    Iterates through all the folders in data_source/prod_samples and creates a dataset
    """

    import os
    import glob

    excel_file = 'data_source/FAQs_Division.xlsx'
    output_file = 'data_source/10_mwa_prod_training_dataset.jsonl'
    # Define the path to the data source directory
    data_source_dir = 'data_source/prod_samples'
    
    # Get all subdirectories in the data source directory
    subdirs = [d for d in os.listdir(data_source_dir) if os.path.isdir(os.path.join(data_source_dir, d))]
    
    # Iterate through each subdirectory
    for subdir in subdirs:
        print(f"Processing folder: {subdir}")
        
        # Construct the full path to the current subdirectory
        subdir_path = os.path.join(data_source_dir, subdir)
        
        # Find all part_A files in the current subdirectory
        part_A_file = os.path.join(subdir_path, f'{subdir}_MWA_BASEPAYLOAD_part_A.json')
        
        # Find all part_B files in the current subdirectory
        part_B_file = os.path.join(subdir_path, f'{subdir}_MWA_BASEPAYLOAD_part_B.json')
        
        # Find all rx files in the current subdirectory
        rx_file = os.path.join(subdir_path, f'{subdir}_MWA_HEALTHRESULTS_Rx.json')
        
        # Find all dx files in the current subdirectory
        dx_file = os.path.join(subdir_path, f'{subdir}_MWA_HEALTHRESULTS_Dx.json')
        
        # Find all lab files in the current subdirectory
        lab_file = os.path.join(subdir_path, f'{subdir}_MWA_HEALTHRESULTS_Lab.json')
        
        # Find all mvr files in the current subdirectory
        mvr_file = os.path.join(subdir_path, f'{subdir}_modified_MWA_RISKCLASSIFIER.json')
        
        # Find all mib files in the current subdirectory
        mib_file = os.path.join(subdir_path, f'{subdir}_modified_MWA_MIB.json')
        
        # Check if all files exist
        all_files = [part_A_file, part_B_file, rx_file, dx_file, lab_file, mvr_file, mib_file]
        if all(os.path.exists(file) for file in all_files):
            print(f"All required files found in {subdir}. Processing...")
            
        else:
            # print(f"Skipping folder {subdir} due to missing files.")
            missing = [file for file in all_files if not os.path.exists(file)]
            print(f"Missing files: {missing}")

        # Excel file path
        # excel_file = 'data_source/FAQs_Division.xlsx'
        
        # Create dataset
        create_dataset(part_A_file, part_B_file, rx_file, dx_file, lab_file, 
                mvr_file, mib_file, excel_file, output_file)
    
        
main_dataset_creation()



# excel_file = 'data_source/FAQs_Division.xlsx'
# get_output_2(excel_file, "9222517")



    # user_prompt_subset_1 = """
    # <|start_header_id|>user<|end_header_id|>
    # Within the <Questions> tag, all the questions that need to be answered are given. Only refer to the details
    # mentioned within the <Context> tag.
    # <Questions>
    # {questions_1}
    # </Questions>
    # <Context>
    # {context_1}
    # </Context>
    # <|eot_id|>
    # <|start_header_id|>assistant<|end_header_id|>
    # """

    # # user_prompt_subset_2 = """
    # <|start_header_id|>user<|end_header_id|>
    # Within the <Questions> tag, all the questions that need to be answered are given. Only refer to the details
    # mentioned within the <Context> tag.
    # <Questions>
    # {questions_2}
    # </Questions>
    # <Context>
    # {context_2}
    # </Context>
    # <|eot_id|>
    # <|start_header_id|>assistant<|end_header_id|>
    # """
