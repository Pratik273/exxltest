#!/usr/bin/env python3
"""
Test script to verify the enhanced Rx processing functionality.
This script tests the get_enhanced_Rx_content function to ensure DiseaseDescription appears correctly.
"""

import os
import sys
import json

# Add the current directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from context_summary_medical import get_enhanced_Rx_content, prepare_context_medical_enhanced

def test_enhanced_rx_processing():
    """
    Test the enhanced Rx processing with a sample data file.
    """
    # Get the base directory
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    
    # Look for sample data files in data_sources_batch3 or data_sources_batch4
    batch_dirs = ['data_sources_batch3', 'data_sources_batch4']
    
    for batch_dir in batch_dirs:
        data_dir = os.path.join(base_dir, batch_dir)
        if os.path.exists(data_dir):
            print(f"Found batch directory: {data_dir}")
            
            # List available case folders
            case_folders = [f for f in os.listdir(data_dir) if os.path.isdir(os.path.join(data_dir, f))]
            
            if case_folders:
                # Use the first available case folder
                case_folder = case_folders[0].strip() 
                case_path = os.path.join(data_dir, case_folder)
                
                # Construct file paths
                rx_file = None
                for file in os.listdir(case_path):
                    if 'HEALTHRESULTS_Rx' in file:
                        rx_file = os.path.join(case_path, file)
                        break
                
                if rx_file and os.path.exists(rx_file):
                    print(f"Testing with Rx file: {rx_file}")
                    
                    try:
                        # Test the enhanced Rx processing
                        enhanced_rx_data = get_enhanced_Rx_content(rx_file)
                        
                        print(f"\nEnhanced Rx data type: {type(enhanced_rx_data)}")
                        if isinstance(enhanced_rx_data, list):
                            print(f"Number of prescriptions: {len(enhanced_rx_data)}")
                            
                            # Check for DiseaseDescription in the results
                            has_disease_description = False
                            for i, prescription in enumerate(enhanced_rx_data):
                                if isinstance(prescription, dict):
                                    print(f"\nPrescription {i+1}:")
                                    print(f"  Label: {prescription.get('PrescriptionLabel', 'N/A')}")
                                    if 'DiseaseDescription' in prescription:
                                        print(f"  ✓ DiseaseDescription: {prescription['DiseaseDescription']}")
                                        has_disease_description = True
                                    else:
                                        print(f"  ✗ DiseaseDescription: Not found")
                                    
                                    # Show other fields
                                    for key in ['DrugClass', 'RefillsAllowed', 'DateFirstFilled', 'DateLastFilled']:
                                        if key in prescription:
                                            print(f"  {key}: {prescription[key]}")
                            
                            if has_disease_description:
                                print(f"\n✓ SUCCESS: DiseaseDescription field found in enhanced processing!")
                            else:
                                print(f"\n✗ WARNING: DiseaseDescription field not found in any prescription")
                        else:
                            print(f"Enhanced Rx data: {enhanced_rx_data}")
                        
                        return enhanced_rx_data
                        
                    except Exception as e:
                        print(f"Error testing enhanced Rx processing: {e}")
                        import traceback
                        traceback.print_exc()
                        return None
                else:
                    print(f"No Rx file found in {case_path}")
            else:
                print(f"No case folders found in {data_dir}")
    
    print("No suitable test data found")
    return None

def test_full_context():
    """
    Test the full enhanced medical context preparation.
    """
    print("\n" + "="*60)
    print("TESTING FULL ENHANCED CONTEXT PREPARATION")
    print("="*60)
    
    # Get the base directory
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    
    # Look for sample data files
    batch_dirs = ['data_sources_batch3', 'data_sources_batch4']
    
    for batch_dir in batch_dirs:
        data_dir = os.path.join(base_dir, batch_dir)
        if os.path.exists(data_dir):
            case_folders = [f for f in os.listdir(data_dir) if os.path.isdir(os.path.join(data_dir, f))]
            
            if case_folders:
                case_folder = case_folders[0].strip()
                case_path = os.path.join(data_dir, case_folder)
                
                # Construct all file paths
                files = {
                    'partA': None,
                    'partB': None, 
                    'Rx': None,
                    'Dx': None,
                    'Lab': None,
                    'mib': None
                }
                
                for file in os.listdir(case_path):
                    if 'BASEPAYLOAD_part_A' in file:
                        files['partA'] = os.path.join(case_path, file)
                    elif 'BASEPAYLOAD_part_B' in file:
                        files['partB'] = os.path.join(case_path, file)
                    elif 'HEALTHRESULTS_Rx' in file:
                        files['Rx'] = os.path.join(case_path, file)
                    elif 'HEALTHRESULTS_Dx' in file:
                        files['Dx'] = os.path.join(case_path, file)
                    elif 'HEALTHRESULTS_Lab' in file:
                        files['Lab'] = os.path.join(case_path, file)
                    elif 'MIB' in file:
                        files['mib'] = os.path.join(case_path, file)
                
                print(f"Using case folder: {case_folder}")
                print(f"Available files:")
                for key, path in files.items():
                    print(f"  {key}: {'✓' if path and os.path.exists(path) else '✗'}")
                
                if files['Rx'] and os.path.exists(files['Rx']):
                    try:
                        # Test the full enhanced context
                        enhanced_context = prepare_context_medical_enhanced(
                            files['partA'] or '', 
                            files['partB'] or '', 
                            files['Rx'], 
                            files['Dx'] or '', 
                            files['Lab'] or '', 
                            files['mib'] or ''
                        )
                        
                        print(f"\nEnhanced context length: {len(enhanced_context)}")
                        
                        # Check if DiseaseDescription appears in the formatted context
                        if 'DiseaseDescription' in enhanced_context or 'Indication:' in enhanced_context:
                            print(f"✓ SUCCESS: DiseaseDescription/Indication found in enhanced context!")
                        else:
                            print(f"✗ WARNING: DiseaseDescription/Indication not found in context")
                        
                        # Show a snippet of the Rx section
                        if "Prescription (Rx)" in enhanced_context:
                            rx_start = enhanced_context.find("Prescription (Rx)")
                            rx_end = enhanced_context.find("Diagnosis (Dx)", rx_start)
                            if rx_end == -1:
                                rx_end = rx_start + 1000  # Show first 1000 chars
                            
                            rx_section = enhanced_context[rx_start:rx_end]
                            print(f"\nRx section preview:")
                            print("-" * 40)
                            print(rx_section[:800] + "..." if len(rx_section) > 800 else rx_section)
                            print("-" * 40)
                        
                        return enhanced_context
                        
                    except Exception as e:
                        print(f"Error testing full enhanced context: {e}")
                        import traceback
                        traceback.print_exc()
                        return None
    
    return None

if __name__ == "__main__":
    print("="*60)
    print("TESTING ENHANCED RX PROCESSING")
    print("="*60)
    
    # Test enhanced Rx processing
    enhanced_data = test_enhanced_rx_processing()
    
    # Test full context preparation
    enhanced_context = test_full_context()
    
    print(f"\n" + "="*60)
    print("TEST COMPLETE")
    print("="*60)