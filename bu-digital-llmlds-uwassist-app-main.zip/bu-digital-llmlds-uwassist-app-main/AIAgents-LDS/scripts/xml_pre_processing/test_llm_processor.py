#!/usr/bin/env python3
"""
Test LLM Processor for specific applications from test_100_mwa_4jun.jsonl

This script processes specific applications through Claude LLM and saves results to Excel.
"""

import json
import pandas as pd
import os
import sys
from datetime import datetime
from loguru import logger

# Add utils to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.calling_claude_model import invoking_claude
from utils.llm_retries_and_validation import call_llm_with_retries

# Global error log list
error_log = []

def log_error(error_type, error_message, context=None, cert_number=None, subset=None):
    """
    Log an error to the global error log list.
    
    Args:
        error_type (str): Type of error (e.g., 'LLM_ERROR', 'JSON_PARSE_ERROR', 'FILE_ERROR')
        error_message (str): Detailed error message
        context (str, optional): Additional context about the error
        cert_number (str, optional): Certificate number if applicable
        subset (str, optional): Subset number if applicable
    """
    error_entry = {
        'timestamp': datetime.now().isoformat(),
        'error_type': error_type,
        'error_message': str(error_message),
        'context': context,
        'certificate_number': cert_number,
        'subset': subset
    }
    error_log.append(error_entry)
    logger.error(f"Error logged: {error_type} - {error_message}")

def save_error_log(error_log_file):
    """
    Save the error log to a JSON file.
    
    Args:
        error_log_file (str): Path to the error log JSON file
    """
    try:
        with open(error_log_file, 'w', encoding='utf-8') as f:
            json.dump({
                'total_errors': len(error_log),
                'generated_at': datetime.now().isoformat(),
                'errors': error_log
            }, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Error log saved to {error_log_file} with {len(error_log)} errors")
    except Exception as e:
        logger.error(f"Failed to save error log: {e}")

def call_llm_without_pydantic(system_prompt: str, user_prompt: str, max_retries=4, cert_number=None, subset=None):
    """
    Call LLM without Pydantic response model validation.
    Similar to call_llm_with_retries but returns raw text response.
    
    Args:
        system_prompt (str): System prompt for Claude
        user_prompt (str): User prompt including context
        max_retries (int): Maximum number of retry attempts
        cert_number (str, optional): Certificate number for error logging
        subset (str, optional): Subset number for error logging
    
    Returns:
        str: Raw response from Claude, or None if all retries failed
    """
    retries = 0
    while retries <= max_retries:
        try:
            response_text = invoking_claude(system_prompt, user_prompt)
            
            if response_text and response_text.strip():
                logger.info(f"Successfully got response on attempt {retries + 1}")
                return response_text.strip()
            else:
                logger.warning(f"Empty response on attempt {retries + 1}")
                retries += 1
                
        except ClientError as e:
            if e.response['Error']['Code'] in ['ThrottlingException', 'TooManyRequestsException']:
                wait = (2 ** retries) + random.uniform(0, 1)  # exponential backoff + jitter
                print(f"Throttled. Retrying in {wait:.2f} seconds...")
                time.sleep(wait)
                retries += 1

        except Exception as e:
            logger.error(f"Error on attempt {retries + 1}: {e}")
            log_error(
                error_type='LLM_ERROR',
                error_message=f"Error on attempt {retries + 1}: {e}",
                context=f"System prompt length: {len(system_prompt)}, User prompt length: {len(user_prompt)}",
                cert_number=cert_number,
                subset=subset
            )
            retries += 1
            
    logger.error("All retry attempts failed")
    log_error(
        error_type='LLM_MAX_RETRIES_EXCEEDED',
        error_message="All retry attempts failed",
        context=f"Max retries: {max_retries}",
        cert_number=cert_number,
        subset=subset
    )
    return None

def load_test_applications(file_path, target_applications):
    """
    Load specific applications from the test JSONL file.
    
    Args:
        file_path (str): Path to the test JSONL file
        target_applications (list): List of application numbers to process
    
    Returns:
        list: List of application data dictionaries
    """
    applications = []
    target_apps_str = [str(app) for app in target_applications]
    
    logger.info(f"Loading applications from {file_path}")
    logger.info(f"Target applications: {target_apps_str}")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        for line_num, line in enumerate(f, 1):
            try:
                entry = json.loads(line)
                cert_number = str(entry.get('ApplicationNumber', ''))
                
                if cert_number in target_apps_str:
                    applications.append(entry)
                    logger.info(f"Found target application: {cert_number}")
                    
            except json.JSONDecodeError as e:
                logger.error(f"Error parsing line {line_num}: {e}")
                log_error(
                    error_type='JSON_PARSE_ERROR',
                    error_message=f"Error parsing line {line_num}: {e}",
                    context=f"Line number: {line_num}, Line content: {line[:200]}...",
                    cert_number=None,
                    subset=None
                )
    
    logger.info(f"Loaded {len(applications)} target applications")
    return applications

def process_applications_through_llm(applications):
    """
    Process applications through Claude LLM and collect results.
    
    Args:
        applications (list): List of application data
    
    Returns:
        list: List of result dictionaries
    """
    results = []
    
    for i, app in enumerate(applications, 1):
        cert_number = app.get('ApplicationNumber', '')
        subset = app.get('Subset', '')
        system_prompt = app.get('System', '')
        user_prompt = app.get('User', '')
        context = app.get('Context', '')
        
        logger.info(f"Processing application {i}/{len(applications)}: {cert_number} (Subset {subset})")
        
        # Combine user prompt and context
        combined_user_prompt = user_prompt + "\n" + context if context else user_prompt
        
        # Call Claude LLM
        claude_response = call_llm_without_pydantic(system_prompt, combined_user_prompt, cert_number=cert_number, subset=subset)
        
        if claude_response is None:
            claude_response = ""
            logger.error(f"Failed to process application {cert_number} Subset: {subset}")
            log_error(
                error_type='PROCESSING_FAILED',
                error_message=f"Failed to process application {cert_number} Subset: {subset}",
                context=f"Application {i}/{len(applications)}",
                cert_number=cert_number,
                subset=subset
            )
        
        # Create result record
        result = {
            'ApplicationNumber': cert_number,
            'Subset': subset,
            'SystemPrompt': system_prompt,
            'UserPrompt': user_prompt,
            'Context': context,
            'ClaudeAnswer': claude_response
        }
        
        results.append(result)
        logger.info(f"Completed processing application {cert_number}")
    
    return results

def save_results_to_excel(results, output_file, append=False):
    """
    Save results to an Excel file.
    
    Args:
        results (list): List of result dictionaries
        output_file (str): Path to output Excel file
        append (bool): If True, append to existing file; if False, overwrite
    """
    logger.info(f"Saving results to {output_file} (append={append})")
    
    try:
        # Create DataFrame
        df = pd.DataFrame(results)
        
        # Reorder columns for better readability
        column_order = ['ApplicationNumber', 'Subset', 'SystemPrompt', 'UserPrompt', 'Context', 'ClaudeAnswer']
        df = df[column_order]
        
        if append and os.path.exists(output_file):
            # Load existing data and append
            try:
                existing_df = pd.read_excel(output_file, sheet_name='LLM_Results')
                logger.info(f"Loaded existing data with {len(existing_df)} rows")
                
                # Combine existing and new data
                combined_df = pd.concat([existing_df, df], ignore_index=True)
                logger.info(f"Combined data has {len(combined_df)} total rows")
                
                # Remove duplicates based on CertificateNumber and Subset
                combined_df = combined_df.drop_duplicates(subset=['CertificateNumber', 'Subset'], keep='last')
                logger.info(f"After removing duplicates: {len(combined_df)} rows")
                
                df = combined_df
                
            except Exception as e:
                logger.warning(f"Could not load existing file for appending: {e}. Creating new file.")
                append = False
        
        # Save to Excel with formatting
        mode = 'a' if append and os.path.exists(output_file) else 'w'
        with pd.ExcelWriter(output_file, engine='openpyxl', mode=mode) as writer:
            df.to_excel(writer, sheet_name='LLM_Results', index=False)
            
            # Get the workbook and worksheet
            workbook = writer.book
            worksheet = writer.sheets['LLM_Results']
            
            # Auto-adjust column widths (basic adjustment)
            for column in worksheet.columns:
                max_length = 0
                column_letter = column[0].column_letter
                
                for cell in column:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except:
                        pass
                
                # Set maximum width to avoid extremely wide columns
                adjusted_width = min(max_length + 2, 100)
                worksheet.column_dimensions[column_letter].width = adjusted_width
        
        logger.info(f"Successfully saved {len(results)} results to {output_file}")
        
    except Exception as e:
        logger.error(f"Error saving results to Excel: {e}")
        log_error(
            error_type='EXCEL_SAVE_ERROR',
            error_message=f"Error saving results to Excel: {e}",
            context=f"Output file: {output_file}, Results count: {len(results)}, Append mode: {append}",
            cert_number=None,
            subset=None
        )
        raise

def main():
    """
    Main function to process test applications through LLM.
    """
    # Configuration
    test_file_path = "/home/CORP/shreya235361/projects/bu-digital-llmlds-uwassist-app/AIAgents-LDS/data_sources/test_summary_25_mwa_28july.jsonl"
    output_file = "/home/CORP/shreya235361/projects/bu-digital-llmlds-uwassist-app/AIAgents-LDS/data_sources/claude_15_summary_results_30july.xlsx"
    error_log_file = "/home/CORP/shreya235361/projects/bu-digital-llmlds-uwassist-app/AIAgents-LDS/scripts/xml_pre_processing/test_llm_summaey_errors.json"
    
    # Target applications as specified
    target_applications = [
        9217743, 9217828, 9217937, 9227727, 9228791, 9232546, 9219040, 9219092, 9219125, 9219237, 9219247, 9219282, 9219564, 9220504, 9220866
    ]
    
    
    logger.info("Starting Test LLM Processor")
    logger.info("=" * 50)
    
    # Check if test file exists
    if not os.path.exists(test_file_path):
        logger.error(f"Test file not found: {test_file_path}")
        log_error(
            error_type='FILE_NOT_FOUND',
            error_message=f"Test file not found: {test_file_path}",
            context="Main function initialization",
            cert_number=None,
            subset=None
        )
        return
    
    try:
        # Load target applications
        applications = load_test_applications(test_file_path, target_applications)
        
        if not applications:
            logger.error("No target applications found in test file")
            log_error(
                error_type='NO_APPLICATIONS_FOUND',
                error_message="No target applications found in test file",
                context=f"Target applications: {target_applications}",
                cert_number=None,
                subset=None
            )
            return
        
        logger.info(f"Found {len(applications)} applications to process")
        
        # Process applications through LLM
        results = process_applications_through_llm(applications)
        
        # Save results to Excel (set append=True to append to existing file)
        save_results_to_excel(results, output_file, append=True)
        
        logger.info("=" * 50)
        logger.info("Test LLM processing completed successfully!")
        logger.info(f"Results saved to: {output_file}")
        
        # Summary
        successful_results = sum(1 for r in results if r['ClaudeAnswer'] and not r['ClaudeAnswer'].startswith('ERROR:'))
        failed_results = len(results) - successful_results
        
        logger.info(f"Summary:")
        logger.info(f"  Total applications processed: {len(results)}")
        logger.info(f"  Successful responses: {successful_results}")
        logger.info(f"  Failed responses: {failed_results}")
        
        # Save error log if any errors occurred
        if error_log:
            save_error_log(error_log_file)
            logger.info(f"Error log saved to: {error_log_file}")
        else:
            logger.info("No errors occurred during processing")
        
    except Exception as e:
        logger.error(f"Error during processing: {e}")
        log_error(
            error_type='MAIN_PROCESSING_ERROR',
            error_message=f"Error during processing: {e}",
            context="Main function execution",
            cert_number=None,
            subset=None
        )
        # Save error log even if main processing fails
        if error_log:
            save_error_log(error_log_file)
        raise

if __name__ == "__main__":
    main()