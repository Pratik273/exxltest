import pandas as pd
import json
import os
from context_subset1 import prepare_context_subset1
from context_subset2 import prepare_context_subset2

# === USER VARIABLE: Set your Excel file path here ===
EXCEL_FILE = 'data_sources/FAQs_Results_By_Application_Multiprocessing_100_11_with_subset.xlsx'  # Change as needed
OUTPUT_FILE = 'data_sources/dataset_by_subset.jsonl'  # Change as needed
ERROR_LOG_FILE = 'data_sources/error_log.txt'

# Normalized columns to extract (all lowercase, no spaces)
QUESTION_COL = 'question'
SUBSET_COL = 'subset'
THOUGHT_COL = 'thought'
ANSWER_COL = 'answer'

SUBSETS = [1, 2]

SYSTEM_PROMPT = (
    "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
    "You are an underwriting expert. Answer all questions using only the context provided by the user. "
    "Keep responses concise and include clear reasoning. In the user input, <Context></Context> contains the "
    "underwriting case details, and <Questions></Questions> contains the questions to be answered. Only respond in the "
    "below JSON format:\n"
    "[{\"Question\": <question>, \"Reason\": <reason of final answer>, \"Answer\": <final answer>}, { }, ..]<|eot_id|>\n"
)

USER_PROMPT_TEMPLATE = (
    "<|start_header_id|>user<|end_header_id|>\n"
    "Within the <Questions> tag, all the questions that need to be answered are given. Only refer to the details "
    "mentioned within the <Context> tag.\n"
    "<Questions>\n{questions}\n</Questions>\n"
)

CONTEXT_TEMPLATE = (
    "<Context>\n"
    "{context}\n"
    "</Context>\n"
    "<|eot_id|>\n"
)

# Clear the error log at the start of each run
open(ERROR_LOG_FILE, 'w').close()

def log_error(message):
    print(message)
    with open(ERROR_LOG_FILE, 'a', encoding='utf-8') as err_f:
        err_f.write(message + '\n')

def normalize_columns(df):
    df.columns = [str(col).strip().replace(' ', '').lower() for col in df.columns]
    return df

def process_excel_by_subset(excel_file, output_file, sheet_names_to_process=None):
    xls = pd.ExcelFile(excel_file)
    sheet_names = xls.sheet_names
    
    if sheet_names_to_process is not None:
        sheet_names = [s for s in sheet_names if s in sheet_names_to_process]
    
    # Build a mapping from stripped folder name to actual folder name
    batch3_dir = 'data_sources_batch4'
    folder_map = {}
    for folder_name in os.listdir(batch3_dir):
        if os.path.isdir(os.path.join(batch3_dir, folder_name)):
            folder_map[folder_name.strip()] = folder_name
    
    with open(output_file, 'a', encoding='utf-8') as f_out:
        for sheet in sheet_names:
            df = pd.read_excel(xls, sheet_name=sheet)
            df = normalize_columns(df)
            # Use the mapping to get the actual folder name (with spaces if present)
            real_folder = folder_map.get(sheet.strip())
            if not real_folder:
                log_error(f"Warning: No folder found for certificate '{sheet}' (after stripping spaces)")
                continue
            folder = os.path.join(batch3_dir, real_folder)
            partAfile = os.path.join(folder, f"{real_folder}_MWA_BASEPAYLOAD_part_A.json")
            partBfile = os.path.join(folder, f"{real_folder}_MWA_BASEPAYLOAD_part_B.json")
            mvrfile = os.path.join(folder, f"{real_folder}_modified_MWA_RISKCLASSIFIER.json")
            mibfile = os.path.join(folder, f"{real_folder}_modified_MWA_MIB.json")
            Rxfile = os.path.join(folder, f"{real_folder}_MWA_HEALTHRESULTS_Rx.json")
            Dxfile = os.path.join(folder, f"{real_folder}_MWA_HEALTHRESULTS_Dx.json")
            Labfile = os.path.join(folder, f"{real_folder}_MWA_HEALTHRESULTS_Lab.json")
            required_files = [partAfile, partBfile, mvrfile, mibfile, Rxfile, Dxfile, Labfile]
            for file in required_files:
                if not os.path.exists(file):
                    log_error(f"Missing file for application '{sheet}': {file}")
            for subset in SUBSETS:
                subset_df = df[df[SUBSET_COL] == subset]
                output_list = []
                questions_list = []
                for _, row in subset_df.iterrows():
                    # Skip rows with missing required fields
                    if any(pd.isna(row.get(col)) for col in [QUESTION_COL, THOUGHT_COL, ANSWER_COL]):
                        continue
                    question = str(row[QUESTION_COL]).strip()
                    reason = str(row[THOUGHT_COL]).strip()
                    answer = str(row[ANSWER_COL]).strip()
                    output_list.append({
                        "Question": question,
                        "Reason": reason,
                        "Answer": answer
                    })
                    questions_list.append(question)
                if output_list:
                    try:
                        if subset == 1:
                            context = prepare_context_subset1(partAfile, partBfile, mvrfile, mibfile)
                        elif subset == 2:
                            context = prepare_context_subset2(partAfile, partBfile, Rxfile, Dxfile, Labfile, mibfile)
                    except Exception as e:
                        log_error(f"Error preparing context for application '{sheet}' (subset {subset}): {e}")
                        continue
                    entry = {
                        "CertificateNumber": sheet,
                        "Subset": str(subset),
                        "System": SYSTEM_PROMPT,
                        "User": USER_PROMPT_TEMPLATE.format(questions="\n".join(questions_list)),
                        "Context": CONTEXT_TEMPLATE.format(context=context),
                        "Output": json.dumps(output_list, ensure_ascii=False)
                    }
                    f_out.write(json.dumps(entry, ensure_ascii=False) + '\n')
    print(f"Done! Output written to {output_file}")

if __name__ == '__main__':
    # sheet_names_to_process = ["9222406", "9230523"]
    process_excel_by_subset(EXCEL_FILE, OUTPUT_FILE) 