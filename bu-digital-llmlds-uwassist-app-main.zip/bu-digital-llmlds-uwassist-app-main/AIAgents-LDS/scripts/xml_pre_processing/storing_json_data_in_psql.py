from loguru import logger
from pathlib import Path
from typing import List, Dict, Any
from datetime import datetime
from dotenv import load_dotenv
import boto3
import time
from botocore.exceptions import ClientError
import psycopg2
from psycopg2 import sql, Error
import os
import sys
import json
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
from scripts.convert_MIB_excel_to_json.main import mib_parsing
from scripts.database.check_db_conn import connect_to_db
from utils.embeddings import get_embedding
from utils.store_data_in_psql_db import store_data_in_applications_table, fetch_application_id, fetch_data_source_id

load_dotenv(override=True)

# Global error log list to collect all errors
ERROR_LOG = []

def log_error_to_json(application_number: str, file_path: str, error_type: str, error_message: str, data_source: str = None):
    """
    Log errors to a global list that will be saved to JSON file.
    
    Args:
        application_number: The application/certificate number
        file_path: Path of the file that failed to process
        error_type: Type of error (e.g., 'database_error', 'file_processing_error', etc.)
        error_message: Detailed error message
        data_source: The data source being processed (optional)
    """
    error_entry = {
        "timestamp": datetime.now().isoformat(),
        "application_number": application_number,
        "file_path": file_path,
        "data_source": data_source,
        "error_type": error_type,
        "error_message": str(error_message)
    }
    ERROR_LOG.append(error_entry)
    logger.error(f"Error logged for app {application_number}: {error_type} - {error_message}")

def save_error_log_to_file(output_file: str = "error_log.json", application_name: str = None):
    """
    Save the accumulated error log to a JSON file.
    
    Args:
        output_file: Name of the output JSON file
        application_name: Optional application name for incremental logging
    """
    if ERROR_LOG:
        try:
            # Group errors by application for summary
            errors_by_app = {}
            for error in ERROR_LOG:
                app_num = error.get('application_number', 'unknown')
                if app_num not in errors_by_app:
                    errors_by_app[app_num] = []
                errors_by_app[app_num].append(error)
            
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump({
                    "total_errors": len(ERROR_LOG),
                    "generated_at": datetime.now().isoformat(),
                    "last_processed_application": application_name,
                    "applications_with_errors": len(errors_by_app),
                    "summary_by_application": {
                        app: {
                            "error_count": len(errors),
                            "error_types": list(set(e.get('error_type', 'unknown') for e in errors))
                        } for app, errors in errors_by_app.items()
                    },
                    "errors": ERROR_LOG
                }, f, indent=2, ensure_ascii=False)
            
            if application_name:
                logger.info(f"Error log updated after processing application {application_name}: {len(ERROR_LOG)} total errors")
            else:
                logger.debug(f"Error log saved to {output_file} with {len(ERROR_LOG)} errors")
        except Exception as e:
            logger.error(f"Failed to save error log: {str(e)}")
    else:
        if application_name:
            logger.info(f"No errors logged for application {application_name}")
        else:
            logger.debug("No errors to log")

def application_exists(cur, conn, certificate_number):
    """
    Check if an application/certificate number already exists in the database.
    
    Args:
        certificate_number: The certificate number to check
        
    Returns:
        bool: True if the certificate number exists, False otherwise
    """
    try:
        
        # Execute query to check if certificate number exists
        cur.execute(
            "SELECT EXISTS(SELECT 1 FROM applications WHERE application_number = %s)",
            (certificate_number,)
        )
        
        # Fetch result (will be a tuple with one boolean value)
        exists = cur.fetchone()[0]
        
        # # Close cursor and connection
        # cur.close()
        # conn.close()
        
        return exists
        
    except (Exception, psycopg2.DatabaseError) as error:
        print(f"Database error: {error}")
        return False

def application_documents_exist(cur, conn, application_number):
    """
    Check if an application already has documents stored in the documents table.
    
    Args:
        cur: Database cursor
        conn: Database connection
        application_number: The application number to check
        
    Returns:
        bool: True if documents exist for this application, False otherwise
    """
    try:
        # First get the application ID
        application_id = fetch_application_id(cur, conn, application_number.strip())
        if not application_id:
            return False
            
        # Check if documents exist for this application
        cur.execute(
            "SELECT EXISTS(SELECT 1 FROM documents WHERE application_id = %s)",
            (application_id,)
        )
        
        # Fetch result (will be a tuple with one boolean value)
        exists = cur.fetchone()[0]
        
        return exists
        
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(f"Database error checking documents for application {application_number}: {error}")
        return False

def store_in_documents_table(cur, conn, application_number: str, data_source: str, data: Dict[str, Any], file_path: str = None):
    
    try:
        # Get application ID
        application_id = fetch_application_id(cur, conn, application_number)
        if not application_id:
            error_msg = f"Application ID not found for application number: {application_number}"
            logger.error(error_msg)
            log_error_to_json(application_number, file_path or "unknown", "application_id_not_found", error_msg, data_source)
            return False
            
        data_source_id = fetch_data_source_id(cur, conn, data_source)
        if not data_source_id:
            error_msg = f"Data Source ID not found for data source: {data_source}"
            logger.error(error_msg)
            log_error_to_json(application_number, file_path or "unknown", "data_source_id_not_found", error_msg, data_source)
            return False
        
        if data_source == "Part A":
            extracted_date = data["Content"]["AppWrittenDate"]
        else:
            extracted_date = None
            
        if extracted_date:
            try:
                # Convert string to Python date object
                extracted_date = datetime.strptime(extracted_date, "%m-%d-%Y").date()
            except AttributeError:
                logger.warning(f"Invalid date format for extracted_date: {extracted_date}")
                extracted_date = None
            
                
        # Get raw content and validate
        raw_content = data["Content"]
        if not raw_content:
            logger.warning(f"Empty content for source {data_source}")
            
        
            
        # Generate embeddings for content
        try:
            text_input = json.dumps(raw_content)
            # embedding = get_embedding(text_input)
        except Exception as e:
            error_msg = f"Failed to generate embeddings: {e}"
            logger.error(error_msg)
            log_error_to_json(application_number, file_path or "unknown", "embedding_generation_error", error_msg, data_source)
            
            
        # Insert data into pages table
        try:
            cur.execute(
                "INSERT INTO documents (application_id, data_source_id, extracted_date, raw_content) "
                "VALUES (%s, %s, %s, %s);",
                (application_id, data_source_id, 
                 extracted_date, text_input)
            )
            conn.commit()
            logger.info(f"Successfully inserted source {data_source}")
            success = True
        except Exception as e:
            error_msg = f"Error inserting JSON data: {e}"
            logger.error(error_msg)
            log_error_to_json(application_number, file_path or "unknown", "database_insert_error", error_msg, data_source)
            conn.rollback()
            success = False
                
        return success
                
    except Exception as e:
        error_msg = f"Unexpected error in store_data_in_documents_table: {e}"
        logger.error(error_msg)
        log_error_to_json(application_number, file_path or "unknown", "unexpected_error", error_msg, data_source)
        conn.rollback()
        return False
    
    
def store_mib_codes_from_json(cur, conn, application_number:str, data_dict: Dict[str, Any], file_path: str = None):
    application_id = fetch_application_id(cur, conn, application_number)
    if not application_id:
        error_msg = f"Application ID not found for application number: {application_number}"
        logger.error(error_msg)
        log_error_to_json(application_number, file_path or "unknown", "application_id_not_found", error_msg, "MIB")
        return False
    
    # Get the MIB code and meaning if present
    submit_date = None
    mib_code = None
    mib_meaning = None
    # print(f"data dict: {data_dict}")
    if "FormInstance" in data_dict["Content"]["OLifE"]:
            # print("Found FormInstance")
            if not isinstance(data_dict["Content"]["OLifE"]["FormInstance"], list):
                if "FormResponse" in data_dict["Content"]["OLifE"]["FormInstance"]:
                    # print("Found FormResponse")
                    submit_date = str(data_dict["Content"]["OLifE"]["FormInstance"]["SubmitDate"])
                    if isinstance(data_dict["Content"]["OLifE"]["FormInstance"]["FormResponse"], list):
                        for i in range(len(data_dict["Content"]["OLifE"]["FormInstance"]["FormResponse"])):
                            # print("Found FormResponse") 
                            mib_temp = {}  
                            if "ResponseData" in data_dict["Content"]["OLifE"]["FormInstance"]["FormResponse"][i] and not "AssociatedResponseData" in data_dict["Content"]["OLifE"]["FormInstance"]["FormResponse"][i]:
                                mib_code = str(data_dict["Content"]["OLifE"]["FormInstance"]["FormResponse"][i]["ResponseData"])
                                if "MiBCodeMeaning" in data_dict["Content"]["OLifE"]["FormInstance"]["FormResponse"][i]:
                                    mib_meaning = str(data_dict["Content"]["OLifE"]["FormInstance"]["FormResponse"][i]["MiBCodeMeaning"])
                                
                                try:
                                    if mib_code is not None and mib_meaning is not None:
                                        cur.execute(
                                            "INSERT INTO mib_codes (application_id, submit_date, mib_code, meaning) VALUES (%s, %s, %s, %s);",
                                            (application_id, submit_date, mib_code, mib_meaning)
                                        )
                                        conn.commit()
                                        logger.info(f"Successfully stored MIB code {mib_code} meaning for application {application_number} in mib_codes table")
                                    
                                    else:
                                        logger.info("MIB code is not present")
                                        
                                except Exception as e:
                                    error_msg = f"Error occurred while inserting data: {str(e)}"
                                    logger.error(error_msg)
                                    log_error_to_json(application_number, file_path or "unknown", "mib_database_insert_error", error_msg, "MIB")
                                    conn.rollback()
                                    # return False
                    elif isinstance(data_dict["Content"]["OLifE"]["FormInstance"]["FormResponse"], dict):
                        if "ResponseData" in data_dict["Content"]["OLifE"]["FormInstance"]["FormResponse"] and not "AssociatedResponseData" in data_dict["Content"]["OLifE"]["FormInstance"]["FormResponse"]:
                            mib_code = str(data_dict["Content"]["OLifE"]["FormInstance"]["FormResponse"]["ResponseData"])
                            if "MiBCodeMeaning" in data_dict["Content"]["OLifE"]["FormInstance"]["FormResponse"]:
                                mib_meaning = str(data_dict["Content"]["OLifE"]["FormInstance"]["FormResponse"]["MiBCodeMeaning"])
                            
                            try:
                                if mib_code is not None and mib_meaning is not None:
                                    cur.execute(
                                        "INSERT INTO mib_codes (application_id, submit_date, mib_code, meaning) VALUES (%s, %s, %s, %s);",
                                        (application_id, submit_date, mib_code, mib_meaning)
                                    )
                                    conn.commit()
                                    logger.info(f"Successfully stored MIB code {mib_code} meaning for application {application_number} in mib_codes table")

                                else:
                                        logger.info("MIB code is not present")
                                    
                            except Exception as e:
                                error_msg = f"Error occurred while inserting data: {str(e)}"
                                logger.error(error_msg)
                                log_error_to_json(application_number, file_path or "unknown", "mib_database_insert_error", error_msg, "MIB")
                                conn.rollback()
                                # return False
                    
                    return True

            else:
                for i in range(len(data_dict["Content"]["OLifE"]["FormInstance"])):
                    if "FormResponse" in data_dict["Content"]["OLifE"]["FormInstance"][i]:
                        # print("Found FormResponse")
                        if "SubmitDate" in data_dict["Content"]["OLifE"]["FormInstance"][i]:
                            submit_date = str(data_dict["Content"]["OLifE"]["FormInstance"][i]["SubmitDate"])
                        if isinstance(data_dict["Content"]["OLifE"]["FormInstance"][i]["FormResponse"], list):
                            for j in range(len(data_dict["Content"]["OLifE"]["FormInstance"][i]["FormResponse"])):
                                # print("Found FormResponse") 
                                if "ResponseData" in data_dict["Content"]["OLifE"]["FormInstance"][i]["FormResponse"][j] and not "AssociatedResponseData" in data_dict["Content"]["OLifE"]["FormInstance"][i]["FormResponse"][j]:
                                    mib_code = str(data_dict["Content"]["OLifE"]["FormInstance"][i]["FormResponse"][j]["ResponseData"])
                                    if "MiBCodeMeaning" in data_dict["Content"]["OLifE"]["FormInstance"][i]["FormResponse"][j]:
                                        mib_meaning = str(data_dict["Content"]["OLifE"]["FormInstance"][i]["FormResponse"][j]["MiBCodeMeaning"])
                                        
                                    try:
                                        if mib_code is not None and mib_meaning is not None:
                                            cur.execute(
                                                "INSERT INTO mib_codes (application_id, submit_date, mib_code, meaning) VALUES (%s, %s, %s, %s);",
                                                (application_id, submit_date, mib_code, mib_meaning)
                                            )
                                            conn.commit()
                                            logger.info(f"Successfully stored MIB code {mib_code} meaning for application {application_number} in mib_codes table")

                                        else:
                                            logger.info("MIB code is not present")
                                            
                                    except Exception as e:
                                        error_msg = f"Error occurred while inserting data: {str(e)}"
                                        logger.error(error_msg)
                                        log_error_to_json(application_number, file_path or "unknown", "mib_database_insert_error", error_msg, "MIB")
                                        conn.rollback()
                                        # return False
                        
                        elif isinstance(data_dict["Content"]["OLifE"]["FormInstance"][i]["FormResponse"], dict):
                            logger.info(f"Data dict: {data_dict["Content"]["OLifE"]["FormInstance"][i]}")
                            if "ResponseData" in data_dict["Content"]["OLifE"]["FormInstance"][i]["FormResponse"] and not "AssociatedResponseData" in data_dict["Content"]["OLifE"]["FormInstance"][i]["FormResponse"]:
                                mib_code = str(data_dict["Content"]["OLifE"]["FormInstance"][i]["FormResponse"]["ResponseData"])
                                if "MiBCodeMeaning" in data_dict["Content"]["OLifE"]["FormInstance"][i]["FormResponse"]:
                                    mib_meaning = str(data_dict["Content"]["OLifE"]["FormInstance"][i]["FormResponse"]["MiBCodeMeaning"]) 

                                try:
                                    if mib_code is not None and mib_meaning is not None:
                                        cur.execute(
                                            "INSERT INTO mib_codes (application_id, submit_date, mib_code, meaning) VALUES (%s, %s, %s, %s);",
                                            (application_id, submit_date, mib_code, mib_meaning)
                                        )
                                        conn.commit()
                                        logger.info(f"Successfully stored MIB code {mib_code} meaning for application {application_number} in mib_codes table")

                                    else:
                                        logger.info("MIB code is not present")

                                except Exception as e:
                                    error_msg = f"Error occurred while inserting data: {str(e)}"
                                    logger.error(error_msg)
                                    log_error_to_json(application_number, file_path or "unknown", "mib_database_insert_error", error_msg, "MIB")
                                    conn.rollback()
                                    # return False
                        
                                    

                        else:
                            if "ResponseData" in data_dict["string"]["TXLife"]["TXLifeResponse"]["OLifE"]["FormInstance"][i]["FormResponse"] and not "AssociatedResponseData" in data_dict["string"]["TXLife"]["TXLifeResponse"]["OLifE"]["FormInstance"][i]["FormResponse"]:
                            
                                mib_code = str(data_dict["string"]["TXLife"]["TXLifeResponse"]["OLifE"]["FormInstance"][i]["FormResponse"]["ResponseData"])
                                
                                if "MiBCodeMeaning" in data_dict["string"]["TXLife"]["TXLifeResponse"]["OLifE"]["FormInstance"][i]["FormResponse"]:  
                                    mib_meaning =str(data_dict["string"]["TXLife"]["TXLifeResponse"]["OLifE"]["FormInstance"][i]["FormResponse"]["ResponseData"])

                                    logger.debug(f"MIB code: {mib_code} meaning: {mib_meaning}")
                                
                                try:
                                    if mib_code is not None and mib_meaning is not None:
                                        cur.execute(
                                            "INSERT INTO mib_codes (application_id, submit_date, mib_code, meaning) VALUES (%s, %s, %s, %s);",
                                            (application_id, submit_date, mib_code, mib_meaning)
                                        )
                                        conn.commit()
                                        logger.info(f"Successfully stored MIB code {mib_code} meaning for application {application_number} in mib_codes table")

                                    else:
                                        logger.info("MIB code is not present")
                                        
                                except Exception as e:
                                    error_msg = f"Error occurred while inserting data: {str(e)}"
                                    logger.error(error_msg)
                                    log_error_to_json(application_number, file_path or "unknown", "mib_database_insert_error", error_msg, "MIB")
                                    conn.rollback()
                                    # return False
                return True
                        
                               
    if mib_code is None and mib_meaning is None:
        logger.info("No MIB code present")
        return True
                               

    


def store_json_in_postgres_db(data_path: str):
    """
    Store application data in PostgreSQL database with proper transaction handling.
    
    Args:
        data_path: Path to the JSON file containing application data
    
    Returns:
        bool: True if successful, False if any operation failed
    """
    logger.info("Storing data in PostgreSQL database...")
    cur, conn = None, None
    success = False
    application_number = "unknown"
    
    try:
        cur, conn = connect_to_db()
        if not cur or not conn:
            error_msg = "Failed to establish database connection"
            logger.error(error_msg)
            log_error_to_json(application_number, data_path, "database_connection_error", error_msg)
            return False
            
        # Start transaction
        conn.autocommit = False
        
        try:
            with open(data_path, 'r', encoding='utf-8-sig') as json_file:
                content = json_file.read().strip()
                # print(f"Content: {content}")
                if not content:
                    error_msg = "Empty JSON file"
                    log_error_to_json(application_number, data_path, "empty_file_error", error_msg)
                    return success  # Return empty dict for empty file
                data_dict = json.loads(content)
        except FileNotFoundError:
            error_msg = f"JSON file not found: {data_path}"
            logger.error(error_msg)
            log_error_to_json(application_number, data_path, "file_not_found_error", error_msg)
            return False
        except json.JSONDecodeError as e:
            error_msg = f"Invalid JSON format: {str(e)}"
            logger.error(error_msg)
            log_error_to_json(application_number, data_path, "json_decode_error", error_msg)
            return False
        except Exception as e:
            error_msg = f"Error reading file: {str(e)}"
            logger.error(error_msg)
            log_error_to_json(application_number, data_path, "file_read_error", error_msg)
            return False
        
        logger.debug("JSON loaded successfuly")
        
        try:
            application_number = data_dict["CertificateNumber"]
            print(f"Application Number: {application_number}")
        except KeyError:
            error_msg = "CertificateNumber not found in JSON data"
            logger.error(error_msg)
            log_error_to_json("unknown", data_path, "missing_certificate_number", error_msg)
            return False
        
        if application_exists(cur, conn, application_number):
            logger.info(f"Application Number: {application_number} already exists")
        else:
            # Store application data
            try:
                store_data_in_applications_table(cur=cur, conn=conn, file_format="JSON", app_number=application_number)
                logger.info(f"Storing Application Number: {application_number} in db")
            except Exception as e:
                error_msg = f"Error storing application data: {str(e)}"
                logger.error(error_msg)
                log_error_to_json(application_number, data_path, "application_storage_error", error_msg)
                return False
            
        data_source = None
        
        if "_modified_MWA_MIB" in data_path:
            data_source = "MIB"
        elif "_modified_MWA_RISKCLASSIFIER" in data_path:
            data_source = "MVR"
        elif "part_A" in data_path:
            data_source = "Part A"
        elif "part_B" in data_path:
            data_source = "Part B"
        elif "Rx" in data_path:
            data_source = "Rx"
        elif "Lab" in data_path:
            data_source = "Lab Tests"
        elif "Dx" in data_path:
            data_source = "Dx"
        
        if not data_source:
            error_msg = f"Could not determine data source from file path: {data_path}"
            logger.warning(error_msg)
            log_error_to_json(application_number, data_path, "unknown_data_source", error_msg)
        
        source_stored = store_in_documents_table(cur, conn, application_number, data_source, data_dict, data_path)
        
        if source_stored:
            logger.info(f"successfully stored data source {data_source} into DB for application {application_number}")
            success = True
        else:
            error_msg = f"Failed to store data source {data_source} into DB for application {application_number}"
            logger.error(error_msg)
            log_error_to_json(application_number, data_path, "document_storage_error", error_msg, data_source)
        
        
        if data_source == "MIB":
            try:
                mib_codes = store_mib_codes_from_json(cur, conn, application_number, data_dict, data_path)
                if mib_codes:
                    logger.info(f"successfully stored MIB into DB for application {application_number}")
                else:
                    error_msg = f"Failed to store MIB into DB for application {application_number}"
                    logger.error(error_msg)
                    log_error_to_json(application_number, data_path, "mib_storage_error", error_msg, data_source)
            except Exception as e:
                error_msg = f"Error processing MIB codes: {str(e)}"
                logger.error(error_msg)
                log_error_to_json(application_number, data_path, "mib_processing_error", error_msg, data_source)
        
        
    except Error as e:
        error_msg = f"Database error storing data: {str(e)}"
        logger.error(error_msg)
        log_error_to_json(application_number, data_path, "database_error", error_msg)
        if conn:
            conn.rollback()
    except Exception as e:
        error_msg = f"Unexpected error in store_json_in_postgres_db: {str(e)}"
        logger.error(error_msg)
        log_error_to_json(application_number, data_path, "unexpected_error", error_msg)
        if conn:
            conn.rollback()
    finally:
        # Ensure resources are properly released
        if cur:
            cur.close()
        if conn:
            conn.close()
        logger.debug("Database connection closed")
        
    return success
    
    
def s3_download_db_store(bucket_name=os.getenv('BUCKET_NAME'), folder_prefix="lds-mwa-dev"):
    """
    Download appropriate files to upload in POstgreSQL
    """
    
    s3 = boto3.client('s3', region_name=os.getenv('AWS_REGION'))
    
    # Sample application list - can be expanded or loaded externally
    application_names = ["9217523", "9217639", "9217744", "9217937", "9217938", "9218062", "9218159", "9222406", "9222517","9230523"] 
    # "9217523", "9217639", "9217744", "9217937", "9217938", "9218062", "9218159", "9222406", "9222517","9230523"
    
    logger.info(f"Pre-processing applications: {application_names}")
    
    for name in application_names:
        # Create a local temporary directory for this application
        local_temp_dir = os.path.join(os.getcwd(), "temp", name)
        os.makedirs(local_temp_dir, exist_ok=True)
        
        logger.info(f"Processing application: {name}")
        
        # List objects in the application folder
        app_prefix = f"{folder_prefix}/{name}/"
        logger.debug(f"Application: {bucket_name}/{app_prefix}")
        try:
            response = s3.list_objects_v2(Bucket=bucket_name, Prefix=app_prefix)
            
        except ClientError as e:
            error_msg = f"S3 error listing objects: {str(e)}"
            logger.error(error_msg)
            log_error_to_json(name, f"s3://{bucket_name}/{app_prefix}", "s3_list_error", error_msg)
            continue
        except Exception as e:
            error_msg = f"S3 list object error: {e}"
            logger.error(error_msg)
            log_error_to_json(name, f"s3://{bucket_name}/{app_prefix}", "s3_connection_error", error_msg)
            
        
        # Check if objects exist
        if "Contents" not in response:
            logger.info(f"No files found for application {name}")
            continue
            
        case_files = [obj["Key"] for obj in response["Contents"] 
                    if obj["Key"].endswith(".json") or obj["Key"].endswith(".xml")]
        
        if not case_files:
            logger.info(f"No XML/JSON files found for application {name}")
            continue
            
        logger.info(f"Found {len(case_files)} data sources for application {name}")
        
        files_to_store = []
        
        # Download and identify files
        for i, file_key in enumerate(case_files):
            file_name = os.path.basename(file_key)
            local_file_path = os.path.join(local_temp_dir, file_name)
            
            try:
    
                # Identify file type
                if "part_A" in file_name and file_name.endswith(".json"):
                    # Download the file
                    logger.info(f"Downloading {file_key} to {local_file_path}")
                    s3.download_file(bucket_name, file_key, local_file_path)
                    files_to_store.append(local_file_path)
                    logger.info(f"Found basepayload file: {file_name}")
                    
                elif "part_B" in file_name and file_name.endswith(".json"):
                    # Download the file
                    logger.info(f"Downloading {file_key} to {local_file_path}")
                    s3.download_file(bucket_name, file_key, local_file_path)
                    files_to_store.append(local_file_path)
                    logger.info(f"Found basepayload file: {file_name}")
                    
                elif "Rx" in file_name and file_name.endswith(".json"):
                    # Download the file
                    logger.info(f"Downloading {file_key} to {local_file_path}")
                    s3.download_file(bucket_name, file_key, local_file_path)
                    files_to_store.append(local_file_path)
                    logger.info(f"Found Rx file: {file_name}")
                
                elif "Dx" in file_name and file_name.endswith(".json"):
                    # Download the file
                    logger.info(f"Downloading {file_key} to {local_file_path}")
                    s3.download_file(bucket_name, file_key, local_file_path)
                    files_to_store.append(local_file_path)
                    logger.info(f"Found Dx file: {file_name}")
                
                elif "Lab" in file_name and file_name.endswith(".json"):
                    # Download the file
                    logger.info(f"Downloading {file_key} to {local_file_path}")
                    s3.download_file(bucket_name, file_key, local_file_path)
                    files_to_store.append(local_file_path)
                    logger.info(f"Found Lab file: {file_name}")
                    
                if "modified_MWA_RISKCLASSIFIER" in file_name and file_name.endswith(".json"):
                    # Download the file
                    logger.info(f"Downloading {file_key} to {local_file_path}")
                    s3.download_file(bucket_name, file_key, local_file_path)
                    files_to_store.append(local_file_path)
                    logger.info(f"Found MVR file: {file_name}")
                    
                elif "modified_MWA_MIB" in file_name and file_name.endswith(".json"):
                    # Download the file
                    logger.info(f"Downloading {file_key} to {local_file_path}")
                    s3.download_file(bucket_name, file_key, local_file_path)
                    files_to_store.append(local_file_path)
                    logger.info(f"Found MIB file: {file_name}")
                
            except ClientError as e:
                error_msg = f"AWS API error downloading {file_key}: {str(e)}"
                logger.error(error_msg)
                log_error_to_json(name, file_key, "s3_download_error", error_msg)
                continue
                
            except Exception as e:
                error_msg = f"Unexpected error processing {file_key}: {str(e)}"
                logger.error(error_msg)
                log_error_to_json(name, file_key, "file_processing_error", error_msg)
                continue
    
        for file_path in files_to_store:
            try:
                store_json_in_postgres_db(file_path)
            except Exception as e:
                error_msg = f"Error storing file in database: {str(e)}"
                logger.error(error_msg)
                log_error_to_json(name, file_path, "storage_error", error_msg)
            
        
        # Cleanup temporary files
        logger.info(f"Cleaning up temporary files for case {name}")
        for file_path in os.listdir(local_temp_dir):
            os.remove(os.path.join(local_temp_dir, file_path))

def find_application_start_index(application_folders, target_application):
    """
    Find the starting index for a specific application in the sorted list.
    
    Args:
        application_folders: List of application folder names (sorted)
        target_application: The application number to start from
        
    Returns:
        int: Index of the target application, or -1 if not found
    """
    try:
        start_index = application_folders.index(target_application)
        logger.info(f"Found application {target_application} at index {start_index}")
        return start_index
    except ValueError:
        logger.error(f"Application {target_application} not found in the list")
        logger.info(f"Available applications: {application_folders}")
        return -1

def process_local_files(data_dir_path, start_from_application=None):
    """
    Process JSON files from local directory and store them in PostgreSQL database.
    
    Args:
        data_dir_path: Path to the directory containing application folders
        start_from_application: Application number to start processing from (optional)
    """
    logger.debug(f"Processing files from directory: {data_dir_path}")
    
    # Check if directory exists
    if not os.path.exists(data_dir_path):
        error_msg = f"Directory not found: {data_dir_path}"
        logger.error(error_msg)
        log_error_to_json("unknown", data_dir_path, "directory_not_found", error_msg)
        return
    
    # Get all application folders
    try:
        initial_app_folders = [f for f in sorted(os.listdir(data_dir_path)) 
                             if os.path.isdir(os.path.join(data_dir_path, f))]
        folders_to_skip = ["9217523", "9217639", "9217744", "9217937", "9217938", "9218062", "9218159", "9222406", "9230523", "9222517"]
        application_folders = [folder for folder in initial_app_folders if folder not in folders_to_skip]

    except Exception as e:
        error_msg = f"Error listing directory contents: {str(e)}"
        logger.error(error_msg)
        log_error_to_json("unknown", data_dir_path, "directory_listing_error", error_msg)
        return
    
    logger.info(f"Found {len(application_folders)} application folders")
    
    # Determine starting index
    start_index = 0
    if start_from_application:
        start_index = find_application_start_index(application_folders, start_from_application)
        if start_index == -1:
            logger.error(f"Cannot start processing: Application {start_from_application} not found")
            return
        logger.info(f"Starting processing from application {start_from_application} (index {start_index})")
    else:
        logger.info("Starting processing from the beginning")
    
    # Show which applications will be processed
    applications_to_process = application_folders[start_index:]
    logger.info(f"Will process {len(applications_to_process)} applications: {applications_to_process[:5]}{'...' if len(applications_to_process) > 5 else ''}")
    
    for app_folder in applications_to_process:
        # if app_folder == "9227990":
            folder_path = os.path.join(data_dir_path, app_folder)
            logger.info(f"Processing application folder: {app_folder}")
            
            # Check if application already has documents stored
            try:
                cur, conn = connect_to_db()
                if cur and conn:
                    if application_documents_exist(cur, conn, app_folder):
                        logger.info(f"Application {app_folder} already has documents stored. Skipping...")    
                        
                        cur.close()
                        conn.close()
                        continue
                    cur.close()
                    conn.close()
            except Exception as e:
                logger.error(f"Error checking if documents exist for application {app_folder}: {str(e)}")
                # Continue processing if we can't check (better to process than skip)
            
            # Start time
            start_time = time.time()
            
            # Track errors at start of application processing
            initial_error_count = len(ERROR_LOG)
            
            # Get all JSON files in the application folder
            files_to_store = []
            try:
                for file_name in os.listdir(folder_path):
                    file_path = os.path.join(folder_path, file_name)
                    
                    if not os.path.isfile(file_path) or not file_name.endswith('.json'):
                        continue
                        
                    # Identify file type based on name
                    if any(key in file_name for key in ["part_A", "part_B", "Rx", "Dx", "Lab", "modified_MWA_RISKCLASSIFIER", "modified_MWA_MIB"]):
                        # "part_A", "part_B", "Rx", "Dx", "Lab", "modified_MWA_RISKCLASSIFIER", "modified_MWA_MIB"        
                        files_to_store.append(file_path)    
                        logger.debug(f"Found file to process: {file_name}")
                    
            except Exception as e:
                error_msg = f"Error listing files in application folder {app_folder}: {str(e)}"
                logger.error(error_msg)
                log_error_to_json(app_folder, folder_path, "folder_listing_error", error_msg)
                # Save error log after this application fails
                save_error_log_to_file("processing_error_log.json", app_folder)
                continue
        
            # Process each identified file
            for file_path in files_to_store:
                try:
                    store_json_in_postgres_db(file_path)
                except Exception as e:
                    error_msg = f"Error processing file {file_path}: {str(e)}"
                    logger.error(error_msg)
                    log_error_to_json(app_folder, file_path, "file_processing_error", error_msg)
                    continue
            
            # End time
            end_time = time.time()
            processing_time = end_time - start_time
            
            # Count errors for this application
            app_error_count = len(ERROR_LOG) - initial_error_count
            
            if app_error_count > 0:
                logger.warning(f"Application {app_folder} completed with {app_error_count} errors in {processing_time:.2f} seconds")
            else:
                logger.info(f"Application {app_folder} completed successfully in {processing_time:.2f} seconds")
            
            # Save error log after each application (whether it has errors or not)
            save_error_log_to_file("processing_error_log.json", app_folder)

if __name__ == "__main__":
    try:
        # s3_download_db_store()
        
        # Specify the application to start from (or None to start from beginning)
        START_FROM_APPLICATION = None
        #"9221728"  # Change this to the desired starting application
        
        process_local_files("AIAgents-LDS/data_sources_batch4", start_from_application=START_FROM_APPLICATION) 
        # "AIAgents-LDS/data_sources_new"
    finally:
        # Always save error log at the end
        save_error_log_to_file("processing_error_log_batch4.json")      