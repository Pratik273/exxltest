import os
import shutil



def restructure_files_in_folders(folder_name):
    """
    Move files into the specified foldr which will be created if it does not exist.
    This folder name would be the same as the application number provided at the start of the xml json files.
    :param folder_name: Name of the folder inside which the files will be moved into specified folders
    """
    print(f"Starting restructuring files in '{folder_name}'")

    # Get the directory where the script is located
    script_dir = "/home/CORP/shreya235361/projects/bu-digital-llmlds-uwassist-app/AIAgents-LDS/"
    parent_dir = os.path.join(script_dir, folder_name)
    # print(f"Script directory: {script_dir}")
    print(f"Parent directory: {parent_dir}")

    # Create the parent folder if it doesn't exist
    if not os.path.exists(parent_dir):
        print(f"Creating parent directory: {parent_dir}")
        os.makedirs(parent_dir)
    else:
        print(f"Parent directory already exists: {parent_dir}")

    # Get all files in the script directory
    files = [f for f in os.listdir(parent_dir) if os.path.isfile(os.path.join(parent_dir, f))]
    print(f"Found {len(files)} files in the script directory")

    # Process each file
    files_moved = 0
    for file in files:
        # Skip the script file itself
        if file == os.path.basename(__file__):
            print(f"Skipping script file: {file}")
            continue
        
        # Extract the application number from the file name (before first underscore)
        if '_' in file:
            app_number = file.split('_')[0]
            print(f"Processing file: {file}, application number: {app_number}")
            
            # Create a folder for this application if it doesn't exist
            app_folder = os.path.join(parent_dir, app_number)
            if not os.path.exists(app_folder):
                print(f"Creating application folder: {app_folder}")
                os.makedirs(app_folder)
            
            # Move the file to the appropriate folder
            source = os.path.join(parent_dir, file)
            destination = os.path.join(app_folder, file)
            print(f"Moving file from {source} to {destination}")
            try:
                shutil.copy2(source, destination)  # Copy file to destination
                os.remove(source)  # Remove original file after copying
                print(f"Successfully moved {file} to {app_folder}")
            except Exception as e:
                print(f"Error moving file {file}: {str(e)}")
            files_moved += 1
        else:
            print(f"Skipping file {file} - no underscore found in filename")
    
    print(f"Restructuring complete. {files_moved} files moved to appropriate folders.")

if __name__ == "__main__":
    # Example usage
    folder_name = "data_sources_batch4"
    restructure_files_in_folders(folder_name)
    print(f"Files have been moved into folders under '{folder_name}'")