import boto3
import io
import tempfile
from loguru import logger
import fitz # PyMuPDF
import os
from botocore.exceptions import ClientError

def convert_pdf_pages_to_images_s3(s3_source_bucket: str, s3_source_key: str, 
                           s3_dest_prefix: str) -> None:
    """
    Download PDF from S3, convert pages to images, and upload images back to S3.
    
    Args:
        s3_source_bucket: Source S3 bucket containing the PDF
        s3_source_key: Key (path) to the PDF in source bucket
        s3_dest_prefix: Prefix (folder path) in destination bucket
    """
    logger.debug(f"Starting convert_pdf_to_images_s3 with source: {s3_source_bucket}/{s3_source_key}")
    
    # Initialize S3 client
    s3_client = boto3.client('s3')
    
    try:
        # Download the PDF from S3
        with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as temp_pdf:
            logger.debug(f"Downloading PDF from S3 to temporary file: {temp_pdf.name}")
            s3_client.download_fileobj(s3_source_bucket, s3_source_key, temp_pdf)
            temp_pdf_path = temp_pdf.name
        
        # Open the PDF with PyMuPDF
        doc = fitz.open(temp_pdf_path)
        logger.debug(f"Successfully opened PDF with {len(doc)} pages")
        
        # Create temp directory for images
        with tempfile.TemporaryDirectory() as temp_dir:
            # Convert each page to image
            for i in range(len(doc)):
                page = doc.load_page(i)
                width, height = page.rect.width, page.rect.height
                page_size_mb = (width * height * 4) / (1024 * 1024)  # Assuming 4 bytes per pixel (RGBA)
                logger.debug(f'Page {i + 1} size: width={width}, height={height}, size={page_size_mb:.2f} MB')
                
                # Adjust resolution based on page size
                if page_size_mb > 5:
                    matrix = fitz.Matrix(1, 1)  # Keep the original resolution
                    logger.debug(f'Page {i + 1} exceeds 5 MB, using matrix (1, 1)')
                else:
                    matrix = fitz.Matrix(2, 2)  # Double the resolution
                    logger.debug(f'Page {i + 1} within size limit, using matrix (2, 2)')
                
                # Render page to pixmap
                pix = page.get_pixmap(matrix=matrix)
                
                # Save image to temp file
                temp_image_path = f"{temp_dir}/page_{i + 1}.png"
                pix.save(temp_image_path)
                logger.debug(f'Saved page {i + 1} to temporary image: {temp_image_path}')
                
                # Upload image to S3
                s3_image_key = f"{s3_dest_prefix}/pages/page_{i + 1}.png"
                logger.debug(f'Uploading to S3: {s3_source_bucket}/{s3_image_key}')
                s3_client.upload_file(temp_image_path, s3_source_bucket, s3_image_key)
                logger.debug(f'Successfully uploaded page {i + 1} to S3')
        
        logger.debug(f"Completed processing PDF from {s3_source_bucket}/{s3_source_key}")
        
        # Clean up the temporary PDF file
        os.unlink(temp_pdf_path)
        
    except ClientError as e:
        logger.error(f"Error working with S3: {e}")
        raise
    except Exception as e:
        logger.error(f"Error processing PDF: {e}")
        raise
    

if __name__ == "__main__":
    convert_pdf_pages_to_images_s3('sb-dev18-tenant-70e3729f-tenantbucket-wdeapjbo39p1', 'lds-friendly-applications/F41307451/F41307451_original.pdf',
    'lds-friendly-applications/F41307451')