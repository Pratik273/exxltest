import os
import sys
import json
from dotenv import load_dotenv
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
from utils.aws_services import calling_s3
from utils.store_data_in_psql_db import store_data_in_postgres_db

def call_s3_and_store():
    load_dotenv(override=True)
    # application_names = "F14612930", "F33529572", "F41307451", "F39414621", "F11248249"
    application_names = ["F14612930", "F33529572", "F41307451", "F39414621", "F11248249"]
    for name in application_names:
        # Downloading extracted content JSON file
        json_file_path = f"lds-friendly-applications/{name}/extracted_content.json"
        temp_file_path = calling_s3(os.getenv('BUCKET_NAME'), json_file_path)
        
        # Opening the JSOn file
        try:
            with open(temp_file_path, 'r') as f:
                data_file = json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"Ground truth JSON file not found: {temp_file_path}")
        except json.JSONDecodeError:
            raise ValueError(f"Invalid JSON format in file: {temp_file_path}")
        except Exception as e:
            raise Exception(f"Error loading ground truth file: {e}")
    
        # Storing in PostgresDB
        store_data_in_postgres_db(data_file[0])
        

if __name__ == "__main__":
    call_s3_and_store()
        