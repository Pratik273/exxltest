# from calling_claude_3_5_sonnet import using_claude_for_image_analysis
import boto3
import json
from loguru import logger
import os
import fitz  # PyMuPDF
from dotenv import load_dotenv
from botocore.exceptions import ClientError
# import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
from prompts.pdf_pre_procesing_prompts import EXTRACT_CONTENT_PROMPT, EXTRACT_METADATA_PROMPT
from utils.calling_claude_model import invoking_claude_for_image_analysis
from utils.llm_retries_and_validation import call_llm_with_retries
from utils.response_structures import MetadataResponse
from utils.aws_services import calling_s3, upload_json_to_s3


load_dotenv()

def get_pdf_length(pdf_path):
    """Get the number of pages in a PDF file.
    
    Args:
        pdf_path (str): Path to the PDF file
        
    Returns:
        int: Number of pages in the PDF
    """
    try:
        with fitz.open(pdf_path) as doc:
            return len(doc)
    except Exception as e:
        logger.error(f"Error getting PDF length for {pdf_path}: {e}")
        return 0


def extract_metadata_from_pdf(image_file):
    """Extract metadata from a PDF page image using Claude API.
    
    Args:
        image_file (str): Path to the image file
        
    Returns:
        dict: Extracted metadata or None if extraction fails
    """
    user_prompt = EXTRACT_METADATA_PROMPT
    
    logger.info(f"Extracting metadata from {image_file}")
    
    try:
        json_data = call_llm_with_retries(invoking_claude_for_image_analysis, image_file, user_prompt, MetadataResponse)
        # json_data = using_claude_for_image_analysis(image_file, user_prompt)
        json_output = json.loads(json_data)
        logger.debug(f"Metadata extracted successfully: {json_output}")
        return json_output
        
    except ClientError as e:
        error_code = e.response.get('Error', {}).get('Code', 'Unknown')
        error_msg = e.response.get('Error', {}).get('Message', str(e))
        
        if error_code == 'ValidationException' and "image exceeds 5 MB maximum" in error_msg:
            logger.warning(f"Error: {image_file} exceeds the 5 MB size limit. Skipping.")
        else:
            logger.error(f"AWS API error processing {image_file}: {error_code} - {error_msg}")
        return None
    
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error for {image_file}: {e}")
        return None
        
    except Exception as e:
        logger.error(f"Unexpected error processing {image_file}: {e}")
        return None


def extract_content_from_pdf(image_file, metadata_json):
    """Extract text content from a PDF page image and add it to metadata.
    
    Args:
        image_file (str): Path to the image file
        metadata_json (dict): Metadata dictionary to update with content
        
    Returns:
        dict: Updated metadata with extracted content or None if extraction fails
    """
    if not metadata_json:
        logger.warning(f"Cannot extract content: metadata is None for {image_file}")
        return None
        
    user_prompt = EXTRACT_CONTENT_PROMPT
    
    logger.info(f"Extracting content from {image_file}")
    
    try:
        json_data = call_llm_with_retries(invoking_claude_for_image_analysis, image_file, user_prompt)
        # json_data = using_claude_for_image_analysis(image_file, user_prompt)
        # json_output = json.loads(json_data)
        
        metadata_json["extracted_content"] = json_data
        logger.debug(f"Content extracted successfully for {image_file}")
        return metadata_json
        
    except ClientError as e:
        error_code = e.response.get('Error', {}).get('Code', 'Unknown')
        error_msg = e.response.get('Error', {}).get('Message', str(e))
        
        if error_code == 'ValidationException' and "image exceeds 5 MB maximum" in error_msg:
            logger.warning(f"Error: {image_file} exceeds the 5 MB size limit. Skipping.")
        else:
            logger.error(f"AWS API error extracting content from {image_file}: {error_code} - {error_msg}")
        return None
    
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error for content extraction from {image_file}: {e}")
        return None
        
    except Exception as e:
        logger.error(f"Unexpected error extracting content from {image_file}: {e}")
        return None


def pdf_extraction(bucket_name=os.getenv('BUCKET_NAME'), folder_prefix="lds-friendly-applications"):
    """Extract metadata and content from PDF files for specified applications.
    
    Args:
        bucket_name (str): S3 bucket name
        folder_prefix (str): Prefix for folders in S3
        application_names (list, optional): List of application names to process
            
    Returns:
        list: List of dictionaries with extracted data for each application
    """
    s3 = boto3.client('s3')
    # , "F33529572", "F41307451"
    
    application_names = ["F41307451"]
    
    logger.info(f"Starting PDF extraction for applications: {application_names}")
    # all_results = []
    
    for name in application_names:
        # List objects in the application folder
        app_prefix = f"{folder_prefix}/{name}/pages/"
        response = s3.list_objects_v2(Bucket=bucket_name, Prefix=app_prefix)
        
        # Check if objects exist
        if "Contents" not in response:
            logger.info(f"No files found for application {name}")
            continue
            
        page_files = [obj["Key"] for obj in response["Contents"] 
                     if obj["Key"].endswith(".png")]
        
        if not page_files:
            logger.info(f"No image files found for application {name}")
            continue
            
        logger.info(f"Found {len(page_files)} pages for application {name}")
        
        json_data = []
        final_json = {"application_number": name, "type": "PDF", "pages": []}
        
        for i, file_path in enumerate(sorted(page_files), 1):
            local_file_path = calling_s3(bucket_name, file_path)
            
            if not local_file_path:
                logger.warning(f"Failed to download {file_path} from S3")
                continue
                
            logger.info(f"Processing page {i} at {file_path}")
            
            try:
                # Extract metadata
                metadata_json = extract_metadata_from_pdf(local_file_path)
                if not metadata_json:
                    logger.warning(f"Failed to extract metadata from {file_path}")
                    continue
                    
                # Extract content
                content_json = extract_content_from_pdf(local_file_path, metadata_json)
                if not content_json:
                    logger.warning(f"Failed to extract content from {file_path}")
                    continue
                    
                # Add file info
                content_json["file_path"] = file_path
                content_json["page_number"] = i
                
                # Add to final result
                final_json["pages"].append(content_json)
                logger.info(f"Successfully processed page {i} for application {name}")
                
                # Clean up temporary file
                os.remove(local_file_path)

            except ClientError as e:
                logger.error(f"AWS API error processing {file_path}: {str(e)}")
                continue
                
            except Exception as e:
                logger.error(f"Unexpected error processing {file_path}: {str(e)}")
                continue
                
        json_data.append(final_json)
        # all_results.extend(json_data)
        
        logger.info(f"Completed processing for application {name}")
        
        # Save individual application results
        output_json_file = f"{folder_prefix}/{name}/extracted_content.json"
        upload_json_to_s3(json_data, bucket_name, output_json_file)
        logger.info(f"Results saved to S3: s3://{bucket_name}/{output_json_file}")
    
    # logger.info(f"PDF extraction complete. Processed {len(all_results)} applications.")


if __name__ == "__main__":
    # Run extraction
    pdf_extraction()
