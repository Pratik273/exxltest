import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from check_db_conn import connect_to_db
from loguru import logger

ddl_statements = {
    "applications.sql": """
    CREATE TABLE applications (
        application_id SERIAL PRIMARY KEY,
        application_number VARCHAR(50) NOT NULL UNIQUE,
        status VARCHAR(20) CHECK (status IN ('NOT STARTED', 'PROCESSING', 'AVAILABLE')) NOT NULL DEFAULT 'NOT STARTED',
        type VARCHAR(20) CHECK (type IN ('PDF', 'XML', 'JSON')) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """,
    "data_sources.sql": """
    CREATE TABLE data_sources (
        data_source_id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """,
    "pdf_pages.sql": """
    CREATE TABLE pages (
        page_id SERIAL PRIMARY KEY,
        application_id INT NOT NULL REFERENCES applications(application_id) ON DELETE CASCADE,
        data_source_id INT NOT NULL REFERENCES data_sources(data_source_id) ON DELETE CASCADE,
        page_number INT NOT NULL,
        extracted_date DATE,
        raw_content TEXT NOT NULL,
        embedding VECTOR(1024),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """,
    "documents.sql": """
    CREATE TABLE documents (
        document_id SERIAL PRIMARY KEY,
        application_id INT NOT NULL REFERENCES applications(application_id) ON DELETE CASCADE,
        data_source_id INT NOT NULL REFERENCES data_sources(data_source_id) ON DELETE CASCADE,
        extracted_date DATE,
        raw_content TEXT,
        embedding VECTOR(1024),
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
       
        UNIQUE (application_id, data_source_id)
    );
    """,
    "mib_codes.sql": """
    CREATE TABLE mib_codes (
        mib_code_id SERIAL PRIMARY KEY,
        application_id INT NOT NULL REFERENCES applications(application_id) ON DELETE CASCADE,
        mib_code VARCHAR(50) NOT NULL,
        meaning VARCHAR(5000) NOT NULL,
        submit_date VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE (application_id, mib_code, submit_date)
    );
    """,
    "conversations.sql": """
    CREATE TABLE conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    application_id INT NULL REFERENCES applications(application_id) ON DELETE CASCADE,
    session_id UUID NULL,
    start_time TIMESTAMP DEFAULT NOW(),
    end_time TIMESTAMP);
    """,
    "messages.sql": """
    CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID REFERENCES conversations(id) ON DELETE CASCADE,
    sender TEXT NOT NULL,
    message_text TEXT NOT NULL,
    thought_process TEXT NULL,
    message_type TEXT CHECK (message_type IN ('question', 'intermediate_answer', 'final_answer')),
    timestamp TIMESTAMP DEFAULT NOW()
    );
    """,
    "feedback.sql": """
    CREATE TABLE feedback (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id UUID REFERENCES messages(id) ON DELETE CASCADE,
    conversation_id UUID REFERENCES conversations(id) ON DELETE CASCADE,
    user_query TEXT NOT NULL,
    user_id TEXT NOT NULL,
    rating INT CHECK (rating IN (0, 1)), -- 0 for thumbs down, 1 for thumbs up
    comments TEXT,
    created_at TIMESTAMP DEFAULT NOW()
    );
    """
}


cur, conn = connect_to_db()

cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
conn.commit()
logger.debug("Vector extension created successfully")

for filename, ddl in ddl_statements.items():
    try:
        cur.execute(ddl)
        conn.commit()
        logger.debug(f"Table {filename} created successfully")
    except Exception as e:
        logger.error(f"Error creating table {filename}: {str(e)}")
        conn.rollback()

cur.close()
conn.close()
logger.info("Database connection closed")


# # UNIQUE (document_id, data_source_id)