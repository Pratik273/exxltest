import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from database.check_db_conn import connect_to_db
from loguru import logger

cur, conn = connect_to_db()
# date_query = """
#             SELECT DISTINCT p.extracted_date
#             FROM pages p
#             JOIN applications a ON a.application_id = p.application_id
#             JOIN data_sources ds ON ds.data_source_id = p.data_source_id
#             WHERE a.application_id = '2' AND ds.name = 'Part B'
#             AND p.extracted_date IS NOT NULL
#             ORDER BY p.extracted_date DESC
#             LIMIT 1;
# #             """
# date_query = """
# INSERT INTO data_sources VALUES (name) VALUES (%s);
# """
# date_query = """
# DELETE FROM applications WHERE application_id = 19;
# """
# date_query = """
# DELETE FROM documents WHERE application_id = 19;
# """
# date_query = """
# SELECT * FROM applications;
# """
# date_query = """
# SELECT * FROM mib_codes WHERE application_id = '25';
# """
# date_query = """
# SELECT d.raw_content
#                 FROM documents d
#                 JOIN applications a ON a.application_id = d.application_id
#                 JOIN data_sources ds ON ds.data_source_id = d.data_source_id
#                 WHERE a.application_id = '' AND ds.name = '{source}'
#                 ORDER BY embedding <-> '{vector_query}'
#                 LIMIT 2;
# """
# date_query = """
# SELECT * FROM applications WHERE application_number = '9217744';
# """
# date_query = """
# SELECT data_source_id FROM documents WHERE application_id = 14;
# """
# date_query = """
# SELECT sender, message_text, thought_process FROM messages WHERE conversation_id = '8cb6f09e-bacd-49a1-a194-103824b7fe7a';
# """
# date_query = """
# SELECT data_source_id FROM documents WHERE application_id = '15';
# """
# date_query = """
# SELECT application_id FROM applications WHERE application_number = '9227990';
# """
# date_query = """
# ALTER TABLE mib_codes DROP CONSTRAINT mib_codes_application_id_mib_code_key;
# """
# date_query = """
# ALTER TABLE mib_codes ADD CONSTRAINT unique_app_date_code UNIQUE (application_id, mib_code, submit_date);
# """
date_query = """
SELECT application_id, COUNT(*) FROM mib_codes group by application_id;
"""
# date_query = """
# ALTER TABLE messages DROP CONSTRAINT conversation_id;
# """
cur.execute(date_query)
# data_source = "Dx"
# cur.execute(
#             "INSERT INTO data_sources (name) VALUES (%s);",
#             (data_source,)
#         )
conn.commit()
logger.success("Successfully fetched the date extracted")
extracted_date = cur.fetchall()
logger.info(f"Extracted  date: {extracted_date}")
logger.info(f"Instance length: {len(extracted_date)}")
cur.close()
conn.close()
logger.info("Database connection closed")
