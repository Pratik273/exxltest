import mysql.connector
from mysql.connector import Error
from dotenv import load_dotenv
from loguru import logger
import os
import boto3


def restore_mysql_backup():
    try:
        logger.info("Loading environment variables")
        load_dotenv(override=True)
        
        # Create a Secrets Manager client
        
        client = boto3.client('secretsmanager', region_name=os.getenv('AWS_REGION'))
        
        
        # Get the secret value
        
        response = client.get_secret_value(SecretId=os.getenv('SQL_SECRET_ID')) 
        
        secret_string = eval(response['SecretString'])
        # print(secret_string)
          
        # Get database connection parameters from environment variables
        host = os.getenv('SQL_HOST')
        port = os.getenv('SQL_PORT')
        # database = os.getenv('POSTGRES_DB')
        user = secret_string["username"]
        password = secret_string["password"]
        logger.info("Connecting to SQL Server...")
        # Connect to the MySQL database
        conn = mysql.connector.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            # database=db_name
        )
        
        # Check if the connection was successful
        if conn.is_connected():
            print("Connected to MySQL Server:")
            
            cur = conn.cursor()
            # # Open the backup file and execute its contents
            # with open(backup_file_path, 'r') as file:
            #     sql_script = file.read()
            #     cursor = connection.cursor()
            #     cursor.execute(sql_script, multi=True)
            #     connection.commit()
            #     print("Backup restore complete.")
            
        # Close the connection
        cur.close()
        conn.close()
        print("Connection closed.")

    except Error as e:
        print(f"Error: {e}")
    

# Call the function
restore_mysql_backup()