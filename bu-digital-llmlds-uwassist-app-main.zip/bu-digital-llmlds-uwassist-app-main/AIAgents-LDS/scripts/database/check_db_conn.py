import os
import sys
from dotenv import load_dotenv
import psycopg2
from loguru import logger
import boto3
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
# from utils.store_data_in_psql_db import store_data_in_data_sources_table
# from chromadb import HttpClient

# Configure logger
# logger.add("db_connection.log", rotation="10 MB", level="DEBUG")

def connect_to_db():
    try:
         # Load environment variables
        logger.debug("Loading environment variables...")
        load_dotenv()
        # Create a Secrets Manager client
        
        # client = boto3.client('secretsmanager', region_name=os.getenv('AWS_REGION'))
        
        
        # Get the secret value
        
        # response = client.get_secret_value(SecretId=os.getenv('SECRET_ID')) 
        
        
        # Access the secret value
        
        # secret_string = eval(response['SecretString'])
        # print(secret_string)
        # print(type(secret_string))
        
        
        # Get database connection parameters from environment variables
        host = os.getenv('POSTGRES_HOST')
        port = os.getenv('POSTGRES_PORT')
        database = os.getenv('POSTGRES_DB')
        user = os.getenv('DB_USERNAME')
        password = os.getenv('DB_PASSWORD')
        # user = secret_string["username"]
        # password = secret_string["password"]
        
        logger.debug(f"Attempting to connect to database at {host}:{port}")
        
        # Establish connection
        conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password,
            # keepalives=1,
            # keepalives_idle=30,   # Send keepalive packets every 30 seconds
            # keepalives_interval=10,  # Retry unacked keepalive after 10 seconds
            # keepalives_count=5    # Mark connection dead after 5 failed retries
        )
        
        logger.debug("Successfully connected to the database")
        # conn.autocommit = True  # Required for running procedural commands
        
        # Create a cursor
        cur = conn.cursor()
        
        # Store all available data sources in DB (One time)
        # store_data_in_data_sources_table(cur, conn)
        # name = "MIB"
        # cur.execute("SELECT * FROM applications;")
        # cur.execute("TRUNCATE TABLE applications, pages, mib_codes, documents RESTART IDENTITY;")
        # cur.execute('ALTER TABLE documents ALTER COLUMN extracted_date DROP NOT NULL;')
        # conn.commit()
        # logger.info("Column altered successfully")
        # Fetch the result
        # answer = cur.fetchall()
        # logger.info(f"PostgreSQL response: {answer}")
        
        # # Query to drop all tables from DB
        # drop_tables_query = """
        #                 DO $$ 
        #                 DECLARE 
        #                     r RECORD;
        #                 BEGIN 
        #                     FOR r IN (SELECT tablename FROM pg_tables WHERE schemaname = 'public') 
        #                     LOOP 
        #                         EXECUTE 'DROP TABLE IF EXISTS ' || quote_ident(r.tablename) || ' CASCADE';
        #                     END LOOP;
        #                 END $$;
        #                 """
        # drop_tables_query = """
        # INSERT INTO 
        # """
        # cur.execute(drop_tables_query)
        # logger.info("All tables dropped successfully.")
        
        # cur.close()
        # conn.close()
        # logger.info("Database connection closed")

        return cur, conn
        
       
        
    except Exception as e:
        logger.error(f"Error connecting to the database: {str(e)}")
        raise

if __name__ == "__main__":
    connect_to_db()