import csv
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from database.check_db_conn import connect_to_db

def extract_data():
    try:
        cur, conn = connect_to_db()
        
        # Get all table names
        cur.execute("SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = 'public';")
        tables = cur.fetchall()
        
        # print("Tables: ", tables)
        
        for table in tables:
            table_name = table[0]
            print(f"Extracting data from table: {table_name}")
            
            # Fetch all data from the table
            cur.execute(f"SELECT * FROM {table_name}")
            rows = cur.fetchall()
            columns = [desc[0] for desc in cur.description]  # Get column names
            
            # Save data to CSV
            with open(f"{table_name}.csv", mode="w", newline="") as file:
                writer = csv.writer(file)
                writer.writerow(columns)  # Write header
                writer.writerows(rows)   # Write rows
            
            print(f"Data from {table_name} saved to {table_name}.csv")

        cur.close()
        conn.close()
        print("Data extraction complete.")

    except Exception as e:
        print(f"Error: {e}")

# Run the extraction
extract_data()
