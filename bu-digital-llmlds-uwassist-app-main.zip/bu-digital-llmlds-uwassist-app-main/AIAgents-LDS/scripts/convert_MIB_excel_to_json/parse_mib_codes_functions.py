import json
import re
from abc import ABC, abstractmethod

class MIBCodeParser(ABC):
    """Base class for all MIB code parsers"""
    
    def __init__(self, json_file_path):
        """Initialize with the path to the JSON ground truth file"""
        self.mib_json = self._load_ground_truth(json_file_path)
        
    def _load_ground_truth(self, file_path):
        """Load the JSON from the file"""
        with open(file_path, 'r') as f:
            return json.load(f)
    
    @abstractmethod
    def validate_format(self, input_code):
        """Validate if the code has the correct format"""
        pass
    
    @abstractmethod
    def parse(self, input_code):
        """Parse the input code and return structured information"""
        pass
    
    def _check_character(self, primary_code, char_position, char_value, 
                        position_name=None, fourth_character=None):
        """Helper method to check character validity"""
        missing_characters = []
        primary_data = self.mib_json["primary_codes"][primary_code]
        
        # Direct match in 4th character data
        if char_position == "4th" and char_value in primary_data["4th_character"]:
            return primary_data["4th_character"][char_value]["description"], missing_characters
            
        # Check in 4th character's nested data
        elif char_position != "4th" and fourth_character in primary_data["4th_character"]:
            fourth_data = primary_data["4th_character"][fourth_character]
            if f"{char_position}_character" in fourth_data and char_value in fourth_data[f"{char_position}_character"]:
                return fourth_data[f"{char_position}_character"][char_value]["description"], missing_characters
        
        # Check in primary code's own data
        if f"{char_position}_character" in primary_data and char_value in primary_data[f"{char_position}_character"]:
            return primary_data[f"{char_position}_character"][char_value]["description"], missing_characters
            
        # Check common character if enabled (only for 5th and 6th characters)
        if char_position in ["5th", "6th"] and position_name and f"use_common_{position_name}_character" in primary_data:
            if primary_data[f"use_common_{position_name}_character"] and char_value in self.mib_json[f"{char_position}_character"]:
                return self.mib_json[f"{char_position}_character"][char_value]["description"], missing_characters
            
        # Character not found
        missing_characters.append(f"{char_position}_character")
        return None, missing_characters


class MedicalCodeParser(MIBCodeParser):
    """Parser for standard medical MIB codes"""
    
    def validate_format(self, input_code):
        """Validate if the code has the correct format for medical codes"""
        if len(input_code) != 6:
            return False, "General MIB code should be 6 characters long."

        # Check if the first 3 characters are digits
        if not input_code[:3].isdigit():
            return False, "First 3 characters should be digits."

        # Check if 4th, 5th and 6th characters are letters
        if not (input_code[3:6].isalpha() or "#" in input_code[3:6]):
            return False, "Last 3 characters should be letters or '#'."

        return True, "Valid MIB code format."
    
    def parse(self, input_code):
        """Parse medical code and return structured information"""
        output = {}
        missing_characters = []

        # Extract the first three characters (primary code)
        primary_code = input_code[:3]
        if primary_code in self.mib_json["primary_codes"]:
            output["primary_code"] = self.mib_json["primary_codes"][primary_code]["description"]
            output["recommendation"] = self.mib_json["primary_codes"][primary_code]["recommendation"]
        else:
            missing_characters.append("primary_code")
            return {"wrong_position_characters": missing_characters}, False

        # Extract characters
        fourth_character = input_code[3:4] if len(input_code) > 3 else None
        fifth_character = input_code[4:5] if len(input_code) > 4 else None
        sixth_character = input_code[5:6] if len(input_code) > 5 else None

        # Process characters using the helper method
        if fourth_character:
            char_desc, new_missing = self._check_character(primary_code, "4th", fourth_character)
            missing_characters.extend(new_missing)
            if char_desc:
                output["4th_character"] = char_desc
        
        if fifth_character:
            char_desc, new_missing = self._check_character(primary_code, "5th", fifth_character, 
                                                        "fifth", fourth_character)
            missing_characters.extend(new_missing)
            if char_desc:
                output["5th_character"] = char_desc
        
        if sixth_character:
            char_desc, new_missing = self._check_character(primary_code, "6th", sixth_character, 
                                                        "sixth", fourth_character)
            missing_characters.extend(new_missing)
            if char_desc:
                output["6th_character"] = char_desc

        is_complete = len(missing_characters) == 0
        if is_complete:
            return output, True
        else:
            return {"wrong_position_characters": missing_characters}, False


class SiteCodeParser(MIBCodeParser):
    """Parser for MIB codes with site information"""
    
    def validate_format(self, input_code):
        """Validate if the code has the correct format for site codes"""
        if len(input_code) != 11:
            return False, "MIB code with site code should be 11 characters long."

        if input_code[:3] not in ["150", "152", "153", "154", "183", "184", "955"]:
            return False, "Site code is not valid for the first 3 digits"
        
        if not input_code[:3].isdigit():
            return False, "First 3 characters should be digits."
        
        if not input_code[3] == "(" or not input_code[7] == ")":
            return False, "4th character should be '(' and 8th character should be ')'."
        
        if not (input_code[4:7].isdigit() or input_code[4:7] == "???"):
            return False, "Site code should be digits or '???'."

        if not (input_code[8:11].isalpha() or "#" in input_code[8:11]):
            return False, "Last 3 characters should be letters or '#'."

        return True, "Valid MIB code format."
    
    def parse(self, input_code):
        """Parse site code and return structured information"""
        output = {}
        missing_characters = []

        # Extract primary code and site code
        primary_code = input_code[:3]
        site_code = input_code[4:7]
        
        # Validate primary code
        if primary_code not in self.mib_json["primary_codes"]:
            return {"wrong_position_characters": ["primary_code"]}, False
        
        output["primary_code"] = self.mib_json["primary_codes"][primary_code]["description"]
        output["recommendation"] = self.mib_json["primary_codes"][primary_code]["recommendation"]
        
        # Process site code
        if site_code in self.mib_json["site_codes"]:
            output["site_code"] = self.mib_json["site_codes"][site_code]["description"]
        else:
            missing_characters.append("site_code")

        # Extract characters for MIB portion
        fourth_character = input_code[8:9] if len(input_code) > 8 else None
        fifth_character = input_code[9:10] if len(input_code) > 9 else None
        sixth_character = input_code[10:11] if len(input_code) > 10 else None
        
        # Process characters
        if fourth_character:
            char_desc, new_missing = self._check_character(primary_code, "4th", fourth_character)
            missing_characters.extend(new_missing)
            if char_desc:
                output["4th_character"] = char_desc
        
        if fifth_character:
            char_desc, new_missing = self._check_character(primary_code, "5th", fifth_character, "fifth", fourth_character)
            missing_characters.extend(new_missing)
            if char_desc:
                output["5th_character"] = char_desc
        
        if sixth_character:
            char_desc, new_missing = self._check_character(primary_code, "6th", sixth_character, "sixth", fourth_character)
            missing_characters.extend(new_missing)
            if char_desc:
                output["6th_character"] = char_desc
        
        is_complete = len(missing_characters) == 0
        if is_complete:
            return output, True
        else:
            return {"wrong_position_characters": missing_characters}, False


# You can similarly implement EKGCodeParser and VitalsCodeParser classes
# Following the same pattern, extending the MIBCodeParser base class


# Example usage
# def main():
#     json_path = "path/to/your/mib_json_file.json"
    
#     # Initialize parsers
#     medical_parser = MedicalCodeParser(json_path)
#     site_parser = SiteCodeParser(json_path)
    
#     # Example medical code
#     code = "123ABC"
#     valid, message = medical_parser.validate_format(code)
#     if valid:
#         result, is_complete = medical_parser.parse(code)
#         print(f"Medical code result: {result}")
#     else:
#         print(f"Invalid medical code: {message}")
    
#     # Example site code
#     site_code = "150(123)ABC"
#     valid, message = site_parser.validate_format(site_code)
#     if valid:
#         result, is_complete = site_parser.parse(site_code)
#         print(f"Site code result: {result}")
#     else:
#         print(f"Invalid site code: {message}")

# if __name__ == "__main__":
#     main()


class EKGCodeParser(MIBCodeParser):
    """Parser for EKG codes"""
    
    def validate_format(self, input_code):
        """Validate if the code has the correct format for EKG codes"""
        pattern = r'^\d{3}(\(\d{1,2}[a-z]?\)[A-Z]{3}|[A-Z]{3}\(\d{1,2}[a-z]?\))$'

        if not re.match(pattern, input_code):
            return False, "EKG code should be in the format 900(45)ABC or 900ABC(45)."

        elif input_code[:3] != "900":
            return False, "EKG code should start with 900."

        return True, "Valid EKG code format."
    
    def parse(self, input_code):
        """Parse EKG code and return structured information"""
        output = {}
        missing_characters = []

        # Extract the first three characters (primary code)
        primary_code = input_code[:3]
        if primary_code not in self.mib_json["primary_codes"]:
            return {"wrong_position_characters": ["primary_code"]}, False
        
        output["primary_code"] = self.mib_json["primary_codes"][primary_code]["description"]
        output["recommendation"] = self.mib_json["primary_codes"][primary_code]["recommendation"]
        
        # Extract EKG code, alpha character, and 4th, 5th, 6th characters based on format
        ekg_code, ekg_alpha, fourth_character, fifth_character, sixth_character = self._extract_ekg_components(input_code)
        
        # Process EKG code
        if ekg_code in self.mib_json["ekg_codes"]:
            output["ekg_code"] = self.mib_json["ekg_codes"][ekg_code]["description"]
            # Process alpha character if present
            if ekg_alpha and ekg_alpha in self.mib_json["ekg_codes"][ekg_code]["alpha_character"]:
                output["ekg_alpha"] = self.mib_json["ekg_codes"][ekg_code]["alpha_character"][ekg_alpha]["description"]
            elif ekg_alpha:
                missing_characters.append("ekg_alpha")
        else:
            missing_characters.append("ekg_code")

        # Process 4th character
        if fourth_character:
            char_desc, new_missing = self._check_character(primary_code, "4th", fourth_character)
            missing_characters.extend(new_missing)
            if char_desc:
                output["4th_character"] = char_desc
        
        # Process 5th character
        if fifth_character:
            char_desc, new_missing = self._check_character(primary_code, "5th", fifth_character, "fifth", fourth_character)
            missing_characters.extend(new_missing)
            if char_desc:
                output["5th_character"] = char_desc
        
        # Process 6th character
        if sixth_character:
            char_desc, new_missing = self._check_character(primary_code, "6th", sixth_character, "sixth", fourth_character)
            missing_characters.extend(new_missing)
            if char_desc:
                output["6th_character"] = char_desc

        is_complete = len(missing_characters) == 0
        
        if is_complete:
            return output, is_complete
        else:
            return {"wrong_position_characters": missing_characters}, is_complete
            
    def _extract_ekg_components(self, input_code):
        """Extract EKG code components based on format"""
        ekg_code = None
        ekg_alpha = None
        fourth_character = None
        fifth_character = None
        sixth_character = None
        
        # Format: 900(45)ABC or 900(4a)ABC or 900(45a)ABC
        if input_code[3] == '(':
            # Handle case with 2 digits and alpha: 900(45a)ABC
            if len(input_code) > 6 and input_code[5].isdigit() and input_code[6].isalpha():
                ekg_code = input_code[4:6]
                ekg_alpha = input_code[6]
                fourth_character = input_code[8]
                fifth_character = input_code[9] if len(input_code) > 9 else None
                sixth_character = input_code[10] if len(input_code) > 10 else None
            # Handle case with 1 digit and alpha: 900(4a)ABC
            elif input_code[4].isdigit() and input_code[5].isalpha():
                ekg_code = input_code[4]
                ekg_alpha = input_code[5]
                fourth_character = input_code[7]
                fifth_character = input_code[8] if len(input_code) > 8 else None
                sixth_character = input_code[9] if len(input_code) > 9 else None
            # Handle case with 2 digits, no alpha: 900(45)ABC
            elif input_code[5].isdigit():
                ekg_code = input_code[4:6]
                ekg_alpha = None
                fourth_character = input_code[7]
                fifth_character = input_code[8] if len(input_code) > 8 else None
                sixth_character = input_code[9] if len(input_code) > 9 else None
            # Handle case with 1 digit, no alpha: 900(4)ABC
            else:
                ekg_code = input_code[4]
                ekg_alpha = None
                fourth_character = input_code[6]
                fifth_character = input_code[7] if len(input_code) > 7 else None
                sixth_character = input_code[8] if len(input_code) > 8 else None
        # Format: 900ABC(45) or 900ABC(4a) or 900ABC(45a)
        else:
            fourth_character = input_code[3]
            fifth_character = input_code[4] if len(input_code) > 4 else None
            sixth_character = input_code[5] if len(input_code) > 5 else None
            
            # Handle case with 2 digits and alpha: 900ABC(45a)
            if len(input_code) > 9 and input_code[8].isdigit() and input_code[9].isalpha():
                ekg_code = input_code[7:9]
                ekg_alpha = input_code[9]
            # Handle case with 1 digit and alpha: 900ABC(4a)
            elif input_code[7].isdigit() and len(input_code) > 8 and input_code[8].isalpha():
                ekg_code = input_code[7]
                ekg_alpha = input_code[8]
            # Handle cases with digits only: 900ABC(4) or 900ABC(45)
            else:
                ekg_code = input_code[7:9] if len(input_code) > 8 else input_code[7]
                ekg_alpha = None
        
        return ekg_code, ekg_alpha, fourth_character, fifth_character, sixth_character

class VitalsCodeParser(MIBCodeParser):
    """Parser for Vitals codes"""
    
    def validate_format(self, input_code):
        """Validate if the code has the correct format for vitals codes"""
        pattern = r'^\d+\.\d+\.\d+(\(\d+\))?([A-Z#]{3})$'

        if not re.match(pattern, input_code):
            return False, "Vitals code should be in the format 5.10.180ABC or 5.10.180(20)ABC."

        return True, "Valid vitals code format."
    
    def parse(self, input_code):
        """Parse vitals code and return structured information"""
        output = {}
        missing_characters = []
        vitals_alpha = None

        # Extract the first part before the first dot (height in feet)
        first_part = input_code.split('.')[0]
        output["Height in feet"] = first_part
        
        # Extract the second part between the dots (height in inches)
        second_part = input_code.split('.')[1]
        output["Height in inches"] = second_part
        
        # Extract the third part after the second dot (weight and code)
        third_half = input_code.split('.')[2]
        third_part = re.split(r'(?=[#S])', third_half)[0]
        output["Weight in pounds"] = third_part
        
        # Extract weight loss information if present
        if '(' in third_half:
            third_half_cleaned, paren_part = third_half.split('(')
            paren_part = paren_part.rstrip(')')
            output["Amount of weight loss"] = paren_part
            # Update third_half to the part without parentheses for code extraction
            third_half = third_half_cleaned + third_half.split(')')[1]
        
        # Extract the MIB code characters (last three characters)
        code_chars = third_half[-3:]
        
        # Extract the fourth character
        fourth_character = code_chars[0]
        if fourth_character in self.mib_json["vital_codes"]:
            output["4th_character"] = self.mib_json["vital_codes"][fourth_character]["description"]
        else:
            missing_characters.append("4th_character")

        # Extract the fifth character
        fifth_character = code_chars[1]
        if fifth_character in self.mib_json["5th_character"]:
            output["5th_character"] = self.mib_json["5th_character"][fifth_character]["description"]
        else:
            missing_characters.append("5th_character")

        # Extract the sixth character
        sixth_character = code_chars[2]
        if sixth_character in self.mib_json["6th_character"]:
            output["6th_character"] = self.mib_json["6th_character"][sixth_character]["description"]
        else:
            missing_characters.append("6th_character")

        is_complete = len(missing_characters) == 0

        if is_complete:
            return output, is_complete
        else:
            return {"wrong_position_characters": missing_characters}, is_complete
        