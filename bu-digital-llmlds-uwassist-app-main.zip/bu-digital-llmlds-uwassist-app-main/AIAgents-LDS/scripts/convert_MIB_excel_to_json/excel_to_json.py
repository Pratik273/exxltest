import pandas as pd
import json
from openpyxl import load_workbook


def load_merged_cells_with_openpyxl(file_path: str, sheet_name: str, num_rows: int = None, num_cols: int = None, use_header: bool = True) -> pd.DataFrame:
    """
    Load an Excel sheet into a Pandas DataFrame, handling merged cells using openpyxl.
    Args:
        file_path (str): The path to the Excel file.
        sheet_name (str): The name of the sheet to load.
        num_rows (int, optional): The number of rows to load. If None, all rows are loaded.
        num_cols (int, optional): The number of columns to load. If None, all columns are loaded.
        use_header (bool, optional): Whether to use the first row as column headers. Defaults to True.
    Returns:
        pd.DataFrame: A DataFrame containing the data from the specified Excel sheet, with merged cells handled.
    """
    def _convert_cell_ref_to_df_ref(cell_ref: tuple) -> tuple:
        """Convert openpyxl cell reference (1-based) to Pandas DataFrame index (0-based)."""
        return cell_ref[0] - 1, cell_ref[1] - 1

    # Load the Excel file
    df = pd.read_excel(file_path, sheet_name=sheet_name, header=None)

    # Limit rows and columns if specified
    if num_rows is not None:
        df = df.iloc[:num_rows, :num_cols if num_cols is not None else df.shape[1]]

    # Open the workbook with openpyxl to handle merged cells
    openpyxl_wb = load_workbook(file_path, data_only=True)
    sheet = openpyxl_wb[sheet_name]

    # Process merged cells
    for merged_cell in sheet.merged_cells.ranges:
        try:
            # Get the value from the top-left cell of the merged range
            top_left_row, top_left_col = _convert_cell_ref_to_df_ref((merged_cell.min_row, merged_cell.min_col))
            
            # Ensure indices are within bounds
            if top_left_row >= df.shape[0] or top_left_col >= df.shape[1]:
                continue  # Skip out-of-bound cells

            merge_val = df.iloc[top_left_row, top_left_col]

            # Fill all cells in the merged range with the top-left value
            for row in range(merged_cell.min_row, merged_cell.max_row + 1):
                for col in range(merged_cell.min_col, merged_cell.max_col + 1):
                    df_row, df_col = _convert_cell_ref_to_df_ref((row, col))

                    if df_row < df.shape[0] and df_col < df.shape[1]:  # Ensure it's within bounds
                        df.iloc[df_row, df_col] = merge_val

        except Exception as e:
            print(f"Error processing merged cells at {merged_cell}: {e}")

    # If using headers, set the first row as column names
    if use_header and not df.empty:
        df.columns = df.iloc[0]  # Set the first row as headers
        df = df[1:]  # Drop the first row (now used as headers)

    return df.reset_index(drop=True)


def handle_fifth_character(primary_code: str, fourth_character: str, fifth_character: str, fifth_meaning: str, output_json: dict) -> bool:
    """
    Handle the fifth character logic for different primary codes and update output_json.
    
    Args:
        primary_code (str): The primary code (e.g., "039", "180")
        fourth_character (str): The fourth character value
        fifth_character (str): The fifth character value
        fifth_meaning (str): The meaning of the fifth character
        output_json (dict): The JSON structure to update
        
    Returns:
        bool: Whether to use common fifth character (True) or not (False)
    """
    use_common_fifth_character = True
    
    # Handle special cases for specific primary codes
    if primary_code == "039":
        output_json["primary_codes"][primary_code]["5th_character"] = {}
        output_json["primary_codes"][primary_code]["5th_character"]["R"] = {
            "description": "from CPA or Financial Advisor"
        }
        
    elif primary_code == "103":
        output_json["primary_codes"][primary_code]["5th_character"] = {}
        output_json["primary_codes"][primary_code]["5th_character"]["R"] = {
            "description": "from Prescription Profile"
        }
    
    elif primary_code == "180":
        if fourth_character == "Q":
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["5th_character"] = {}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["5th_character"]["X"] = {
                "description": "Current observation on physical examination by medical or paramendical examiner, or in a laboratory report, test or special study, in conection with insurance application"
            }
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["5th_character"]["Z"] = {
                "description": "Physician or Hospital records (APS)"
            }
        else:
            output_json["primary_codes"][primary_code]["5th_character"] = {}
            output_json["primary_codes"][primary_code]["5th_character"]["X"] = {
                "description": "Current observation on physical examination by medical or paramendical examiner, or in a laboratory report, test or special study, in conection with insurance application"
            }
            output_json["primary_codes"][primary_code]["5th_character"]["Z"] = {
                "description": "Physician or Hospital records (APS)"
            }
            output_json["primary_codes"][primary_code]["5th_character"]["R"] = {
                "description": "Personal and medical information supplied "
            }
            output_json["primary_codes"][primary_code]["5th_character"]["E"] = {
                "description": "Proposed Insured admitted"
            }
        use_common_fifth_character = False
        
    elif primary_code == "281":  # Fix: Changed from 'is' to '=='
        output_json["primary_codes"][primary_code]["5th_character"] = {}
        output_json["primary_codes"][primary_code]["5th_character"]["X"] = {
            "description": "Current observation on physical examination by medical or paramendical examiner, or in a laboratory report, test or special study, in conection with insurance application"
        }
        output_json["primary_codes"][primary_code]["5th_character"]["Z"] = {
            "description": "Physician or Hospital records (APS)"
        }
        output_json["primary_codes"][primary_code]["5th_character"]["R"] = {
            "description": "Personal and medical information supplied "
        }
        output_json["primary_codes"][primary_code]["5th_character"]["E"] = {
            "description": "Proposed Insured admitted"
        }
        output_json["primary_codes"][primary_code]["5th_character"]["Y"] = {
            "description": "Information obtained from publice records maintained by government"
        }
        output_json["primary_codes"][primary_code]["5th_character"]["A"] = {
            "description": "Information obtained from non government public records"
        }
        use_common_fifth_character = False
    
    elif primary_code == "803":
        if fourth_character == "Q":
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["5th_character"] = {}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["5th_character"]["X"] = {
                "description": "Current observation on physical examination by medical or paramendical examiner, or in a laboratory report, test or special study, in conection with insurance application"}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["5th_character"]["Z"] = {
                "description": "Physician or Hospital records (APS)"}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["5th_character"]["R"] = {
                "description": "Personal and medical information supplied "}
        
    elif primary_code in ["979", "990"]:
        output_json["primary_codes"][primary_code]["5th_character"] = {}
        output_json["primary_codes"][primary_code]["5th_character"]["R"] = {
            "description": "Screening test conducted through an Interview"
        }  
        
    elif pd.notna(fifth_character) and pd.notna(fifth_meaning):
        if "5th_character" not in output_json["primary_codes"][primary_code]:
            output_json["primary_codes"][primary_code]["5th_character"] = {}
        output_json["primary_codes"][primary_code]["5th_character"][fifth_character] = {
            "description": fifth_meaning
        }
        use_common_fifth_character = False
        
    return use_common_fifth_character


def handle_sixth_character(primary_code: str, fourth_character: str, sixth_character: str, sixth_meaning: str, output_json: dict) -> bool:
    """
    Handle the sixth character logic and update output_json.
    
    Args:
        primary_code (str): The primary code
        fourth_character (str): The fourth character value
        sixth_character (str): The sixth character value
        sixth_meaning (str): The meaning of the sixth character
        output_json (dict): The JSON structure to update
        
    Returns:
        bool: Whether to use common sixth character (True) or not (False)
    """
    use_common_sixth_character = True

    if primary_code == "803":
        if fourth_character == "J":
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"] = {}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["N"] = {
                "description": "Current or within las 12 mo. prior to application"}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["B"] = {
                "description": "Within 13-24 mo. prior to application "}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["C"] = {
                "description": "Within 25-60 mo. prior to application"}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["D"] = {
                "description": "Within 6 - 10 yrs. prior to application"}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["F"] = {
                "description": "IMore than 10 years prior to application"}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["L"] = {
                "description": "At some indefinite time in the past"}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["#"] = {
                "description": "No other code applies"}
            # output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"] = {}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["P"] = {
                "description": "At some time in the future"}
        elif fourth_character in ["G", "H", "K", "Q"]:
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"] = {}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["N"] = {
                "description": "Current or within las 12 mo. prior to application"}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["B"] = {
                "description": "Within 13-24 mo. prior to application"}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["C"] = {
                "description": "Within 25-60 mo. prior to application"}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["D"] = {
                "description": "Within 6 - 10 yrs. prior to application"}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["F"] = {
                "description": "More than 10 years prior to application"}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["L"] = {
                "description": "At some indefinite time in the past"}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character]["6th_character"]["#"] = {
                "description": "No other code applies"}
        use_common_sixth_character = False
    
    elif pd.notna(sixth_character) and pd.notna(sixth_meaning):
        if "6th_character" not in output_json["primary_codes"][primary_code]:
            output_json["primary_codes"][primary_code]["6th_character"] = {}
        output_json["primary_codes"][primary_code]["6th_character"][sixth_character] = {
            "description": sixth_meaning
        }
        use_common_sixth_character = False
        
    return use_common_sixth_character


def get_codes_characters(excel_data_df: pd.DataFrame, output_json: dict) -> dict:
    # Iterate over rows to construct the JSON structure
    for _, row in excel_data_df.iterrows():
        # print(row)
        # Extract values from the row
        primary_code = str(row["First three characters MIB Codes- digits"])  # First column (e.g., "011")
        # print(primary_code)
        description = row["Impairment"]  # Second column (e.g., description text)
        
        fourth_character = row["4th Character First alpha character* (indication of severity)"]  # Third column (e.g., "G", "H", "K")
        fourth_meaning = row["Interpretation"]  # Fourth column (e.g., "Office of Foreign Assets Control")

        fifth_character = row["5th character Second Alpha Character* (source notation)"]
        fifth_meaning = row["Interpretation*(slight variation by impairment)"]

        sixth_character = row["6th Character Third Alpha Character*"]
        sixth_meaning = row["Interpretation Time Code*"]

        type_code = row["Type of MIB code"]

        recommend = row["Recommendation"]

        use_common_fifth_character = True
        use_common_sixth_character = True

        # Ensure the primary_code exists
        if primary_code not in output_json["primary_codes"]:
            output_json["primary_codes"][primary_code] = {"description": description}

        if pd.notna(fourth_character) and pd.notna(fourth_meaning):
            if "4th_character" not in output_json["primary_codes"][primary_code]:
                output_json["primary_codes"][primary_code]["4th_character"] = {}
            output_json["primary_codes"][primary_code]["4th_character"][fourth_character] = {"description": fourth_meaning}
       
        # Handle the fifth character
        use_common_fifth_character = handle_fifth_character(primary_code, fourth_character, fifth_character, fifth_meaning, output_json)

        # Handle the sixth character
        use_common_sixth_character = handle_sixth_character(primary_code, fourth_character, sixth_character, sixth_meaning, output_json)

        if "type" not in output_json["primary_codes"][primary_code]:
            output_json["primary_codes"][primary_code]["type"] = type_code 

        if "recommendation" not in output_json["primary_codes"][primary_code]:
            if pd.isna(recommend):
                output_json["primary_codes"][primary_code]["recommendation"] = "No recommendation"
            else:
                output_json["primary_codes"][primary_code]["recommendation"] = recommend
        
        output_json["primary_codes"][primary_code]["use_common_fifth_character"] = use_common_fifth_character
        output_json["primary_codes"][primary_code]["use_common_sixth_character"] = use_common_sixth_character
        
    return output_json


def get_general_characters(file_path: str, sheet_name: str, output_json: dict) -> dict:
    """
    Extracts specific characters and their meanings from an Excel sheet and updates the provided JSON object.
    Args:
        file_path (str): The path to the Excel file.
        sheet_name (str): The name of the sheet in the Excel file to read from.
        output_json (dict): The JSON object to update with the extracted characters and their meanings.
    Returns:
        dict: The updated JSON object containing the extracted characters and their meanings.
    """
    # Read specific row range
    start_row = 1544  # Adjust as needed
    end_row = 1552  # Adjust as needed

    general_char_df = pd.read_excel(file_path, sheet_name=sheet_name, header=None, skiprows=start_row, nrows=end_row - start_row)
    # print(general_char_df)
    for _, row in general_char_df.iterrows():
        # print(row)
        fifth_character = row[4]
        fifth_meaning = row[5]

        sixth_character = row[6]
        sixth_meaning = row[7]

        if pd.notna(fifth_character) and pd.notna(fifth_meaning):
            if "5th_character" not in output_json:
                output_json["5th_character"] = {}
            output_json["5th_character"][fifth_character] = {"description": fifth_meaning}

        if pd.notna(sixth_character) and pd.notna(sixth_meaning):
            if "6th_character" not in output_json:
                output_json["6th_character"] = {}
            output_json["6th_character"][sixth_character] = {"description": sixth_meaning}
        
    # print(output_json)
    return output_json

def get_site_codes(file_path: str, sheet_name: str, output_json: dict) -> dict:
    # Read specific row range
    start_row = 2  # Adjust as needed
    end_row = 40  # Adjust as needed

    site_codes_df = pd.read_excel(file_path, sheet_name=sheet_name, header=None, skiprows=start_row, nrows=end_row - start_row)
    # print(site_codes_df)
    for _, row in site_codes_df.iterrows():
        # print(row)
        site_character = str(row[0])
        site_meaning = row[1]

        if pd.notna(site_character) and pd.notna(site_meaning):
            if "site_codes" not in output_json:
                output_json["site_codes"] = {}
            output_json["site_codes"][site_character] = {"description": site_meaning}

    # print(output_json)
    return output_json

def get_ekg_codes(ekg_codes_df: pd.DataFrame, output_json: dict) -> dict:
    output_json["ekg_codes"] = {}
    # Iterate over rows to construct the JSON structure
    for _, row in ekg_codes_df.iterrows():
        # print(row)
        ekg_character = str(row["Number"])
        ekg_meaning = row["Description"]

        alpha_character = row["Letters"]
        alpha_meaning = row["Additional info - TYPE (some #'s do not include ltrs)"]

        if ekg_character not in output_json["ekg_codes"]:
            output_json["ekg_codes"][ekg_character] = {"description": ekg_meaning}

        if pd.notna(alpha_character) and pd.notna(alpha_meaning):
            if "alpha_character" not in output_json["ekg_codes"][ekg_character]:
                output_json["ekg_codes"][ekg_character]["alpha_character"] = {}
            output_json["ekg_codes"][ekg_character]["alpha_character"][alpha_character] = {"description": alpha_meaning}

    # print(output_json)
    return output_json

def get_vital_codes(output_json: dict) -> dict:
    output_json["vital_codes"] = {
        "#": {
            "description": "No other modifying letters apply"
        },
        "S": {
            "description": "Suspected"
        }
    }
    return output_json


if __name__ == "__main__":

    file_path = 'data_source/MIB codes with character definitions  Jan 6, 2025.xlsx'
    code_sheet_name = "MIB Data"  # Replace with your sheet name
    num_rows_code = 1542  # Number of rows to load
    num_cols_code = 11
    site_sheet_name = "Site codes"
    num_rows_ekg = 51
    num_cols_ekg = 4
    ekg_sheet_name = "EKG (900 codes)"

    # Apply the function to the DataFrame
    excel_data_df = load_merged_cells_with_openpyxl(file_path, code_sheet_name, num_rows_code, num_cols_code)

    # print(excel_data_df)
    # Initialize the output dictionary
    output_json = {"primary_codes": {}}

    # Extract codes and characters
    code_json = get_codes_characters(excel_data_df, output_json)

    # Extract general characters
    char_json = get_general_characters(file_path, code_sheet_name, output_json)

    # Extract site codes
    site_json = get_site_codes(file_path, site_sheet_name, output_json)

    # Extract ekg codes
    ekg_data_df = load_merged_cells_with_openpyxl(file_path, ekg_sheet_name, num_rows_ekg, num_cols_ekg)

    # Get vitals codes
    vital_json = get_vital_codes(output_json)

    final_json = get_ekg_codes(ekg_data_df, output_json)

    # Write the JSON data to a file
    with open('mib_codes.json', 'w') as json_file:
        json.dump(final_json, json_file)
        