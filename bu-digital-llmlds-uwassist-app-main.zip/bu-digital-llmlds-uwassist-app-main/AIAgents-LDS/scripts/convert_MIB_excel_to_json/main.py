import os
import re
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
from convert_MIB_excel_to_json.parse_mib_codes_functions import MedicalCodeParser, SiteCodeParser, EKGCodeParser, VitalsCodeParser
from typing import Dict
from loguru import logger
sys.path.append(os.path.join(os.path.dirname(__file__), "../.."))
from prompts.xml_pre_process_prompts import MIB_SUMMARIZE_PROMPT
from utils.calling_claude_model import invoking_claude



class MIBCodeAnalyzer:
    """Main class to analyze and process MIB codes"""
    
    def __init__(self, json_path):
        """Initialize the analyzer with parsers"""
        self.json_path = json_path
        self.medical_parser = MedicalCodeParser(json_path)
        self.site_parser = SiteCodeParser(json_path)
        self.ekg_parser = EKGCodeParser(json_path)
        self.vitals_parser = VitalsCodeParser(json_path)
    
    def detect_code_type(self, input_code):
        """Determine the type of MIB code based on format patterns"""
        if "." in input_code:
            return "vitals"
        elif "(" in input_code and ")" in input_code:
            inside_parenthesis = input_code.split("(")[1].split(")")[0]
            if len(inside_parenthesis) == 3 and (inside_parenthesis.isdigit() or inside_parenthesis == "???"):
                return "site"
            elif inside_parenthesis.isdigit() or (inside_parenthesis[:-1].isdigit() and inside_parenthesis[-1].isalpha()):
                return "ekg"
        return "medical"
    
    def parse_code(self, input_code):
        """Parse an MIB code and return the results"""
        code_type = self.detect_code_type(input_code)
        logger.info(f"Code type detected: {code_type}")
        
        parser = self._get_parser_for_type(code_type)
        valid, message = parser.validate_format(input_code)
        
        if not valid:
            return False, message, None, False
        
        result, is_complete = parser.parse(input_code)
        return True, None, result, is_complete
    
    def _get_parser_for_type(self, code_type):
        """Get the appropriate parser for the code type"""
        parsers = {
            "medical": self.medical_parser,
            "site": self.site_parser,
            "ekg": self.ekg_parser,
            "vitals": self.vitals_parser
        }
        return parsers.get(code_type, self.medical_parser)
    
    def display_results(self, is_valid, message, parse_result, got_all_info):
        """Display the parsing results in a user-friendly format"""
        result = {}

        if not is_valid:
            logger.error("Error: ", message)
            result = {"status": "error", "message": message}
        else:
            if got_all_info:
                logger.debug("Results found:")
                result = {"status": "success", "data": parse_result, "complete": True}
                
            else:
                logger.debug("No matching data found for the following alphanumeric code:")
                result = {"status": "partial", "data": parse_result, "complete": False}
            
            for k, v in parse_result.items():
                logger.debug(f"{k}: {v}")

        return result

    def summarize_with_claude(self, system_prompt, content):
        """Send the parsing results to Claude for summarization"""
        return invoking_claude(system_prompt, content)


def mib_parsing(input_code: str) -> Dict[str, str]:
    # Get the directory of the current script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Construct the path to the JSON file relative to the script location
    ground_truth_file = os.path.join(script_dir, "mib_codes.json")
    
    # Create the analyzer
    analyzer = MIBCodeAnalyzer(ground_truth_file)
    
    # Example codes for testing
    # test_codes = [
    #     "011GRN",     # Medical code
    #     "152(120)WXN", # Site code
    #     "900TAB(24f)", # EKG code
    #     "5.1.209#ZN"   # Vitals code
    # ]
    
    
    logger.info("\nInput code:", input_code)
    
    # Parse and display results
    is_valid, message, parse_result, got_all_info = analyzer.parse_code(input_code)
    final_result = analyzer.display_results(is_valid, message, parse_result, got_all_info)
    result_statement = analyzer.summarize_with_claude(MIB_SUMMARIZE_PROMPT, str(final_result))
    return result_statement


if __name__ == "__main__":
    meaning = mib_parsing("5.1.209#ZN")
    logger.info(f"Final result: {meaning}")
