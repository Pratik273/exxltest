import os
import pandas as pd
from openpyxl import load_workbook
import re

# === User-editable variables ===
SOURCE_EXCEL_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                           'data_sources', 'FAQs_Division_2.xlsx') # Path to source Excel with 'subset' column
TARGET_EXCEL_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                           'data_sources', 'FAQs_Results_By_Application.xlsx')  # Path to target Excel to modify
SUBSET_COL_SOURCE = 'Subset (1 or 2)'  # Name of the subset column in the source file
QUESTIONS_COL_SOURCE = 'Qn'      # Name of the questions column in the source file
SUBSET_COL_TARGET = 'subset'           # Name of the subset column to add in the target file
QUESTIONS_COL_TARGET = 'question'     # Name of the questions column in the target file

def clean_question(q):
    if isinstance(q, str):
        return re.sub(r'\s+', ' ', q.replace('\xa0', ' ')).strip()
    return q

def normalize_colname(col):
    return col.strip().lower().replace('\xa0', ' ')

# === Read source Excel (first sheet assumed) ===
df_source = pd.read_excel(SOURCE_EXCEL_PATH, header = 1)
if SUBSET_COL_SOURCE not in df_source.columns or QUESTIONS_COL_SOURCE not in df_source.columns:
    raise ValueError(f"Source file must contain columns '{SUBSET_COL_SOURCE}' and '{QUESTIONS_COL_SOURCE}'")

# Map question to subset value for order checking
question_to_subset = {clean_question(q): v for q, v in zip(df_source[QUESTIONS_COL_SOURCE], df_source[SUBSET_COL_SOURCE])}

# === Load target Excel and process all sheets ===
wb = load_workbook(TARGET_EXCEL_PATH)
for sheet_name in wb.sheetnames:
    df_target = pd.read_excel(TARGET_EXCEL_PATH, sheet_name=sheet_name)
    # Robustly find the question column
    normalized_cols = {normalize_colname(col): col for col in df_target.columns}
    norm_target_col = normalize_colname(QUESTIONS_COL_TARGET)
    if norm_target_col not in normalized_cols:
        print(f"Available columns: {list(df_target.columns)}")
        print(f"Normalized columns: {list(normalized_cols.keys())}")
        print(f"Looking for column: '{QUESTIONS_COL_TARGET}' (normalized: '{norm_target_col}')")
        print(f"Skipping sheet '{sheet_name}': no '{QUESTIONS_COL_TARGET}' column (robust check).")
        continue
    real_question_col = normalized_cols[norm_target_col]
    # Check order and match
    target_questions = df_target[real_question_col].tolist()
    source_questions = df_source[QUESTIONS_COL_SOURCE].tolist()[:len(target_questions)]
    target_questions_clean = [clean_question(q) for q in target_questions]
    source_questions_clean = [clean_question(q) for q in source_questions]
    if target_questions_clean != source_questions_clean:
        for i, (t, s) in enumerate(zip(target_questions_clean, source_questions_clean)):
            if t != s:
                print(f"Row {i}: target='{t}' | source='{s}'")
        raise ValueError(f"Questions mismatch in sheet '{sheet_name}'. Please check order and content.")
    # Add subset column at the end
    subset_values = [question_to_subset[q] for q in target_questions_clean]
    df_target[SUBSET_COL_TARGET] = subset_values
    # Write back to Excel sheet (add column at the end)
    for r_idx, value in enumerate(subset_values, start=2):  # Excel rows start at 2 (after header)
        wb[sheet_name].cell(row=r_idx, column=len(df_target.columns), value=value)
    # Write the header for the new column
    wb[sheet_name].cell(row=1, column=len(df_target.columns), value=SUBSET_COL_TARGET)
# Save as a new file with '_with_subset' appended
base, ext = os.path.splitext(TARGET_EXCEL_PATH)
new_excel_path = base + '_with_subset' + ext
wb.save(new_excel_path)
print(f"Added '{SUBSET_COL_TARGET}' column to all sheets in {new_excel_path}.") 