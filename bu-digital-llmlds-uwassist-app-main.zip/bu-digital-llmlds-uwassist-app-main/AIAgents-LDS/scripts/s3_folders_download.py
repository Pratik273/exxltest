import boto3
import os
from dotenv import load_dotenv
load_dotenv(override=True)

bucket = os.getenv('BUCKET_NAME_SFTP')
prefix = 'mwa-llm-data-13jun-folders/'  # Must end with /
local_path = 'AIAgents-LDS/data_sources_batch2/'

s3 = boto3.client('s3')

# Load downloaded folders
with open('folders.txt') as f:
    downloaded = set(line.strip() for line in f if line.strip())

# Get all top-level folders in the S3 path
paginator = s3.get_paginator('list_objects_v2')
pages = paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter='/')

missing_folders = []
for page in pages:
    for cp in page.get('CommonPrefixes', []):
        folder = cp['Prefix'].replace(prefix, '').strip('/')
        if folder not in downloaded:
            missing_folders.append(folder)

# Output sync commands
for folder in missing_folders:
    cmd = f'aws s3 sync s3://{bucket}/{prefix}{folder}/ {local_path}{folder}/'
    print(cmd)