#!/usr/bin/env python3
"""
Example script showing how to use the multiprocessing batch summary processing.
This demonstrates different ways to configure and run multiprocessing batch processing.
"""

import sys
import os
import uuid
import multiprocessing as mp

# Add the project root to the path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from run_summaries_batch_multiprocessing import (
    run_multiprocessing_batch_pipeline,
    run_sequential_batch_pipeline,
    process_application_worker
)

def example_1_basic_multiprocessing():
    """Example 1: Basic multiprocessing with default settings."""
    print("="*60)
    print("EXAMPLE 1: Basic Multiprocessing")
    print("="*60)
    
    # Define your application numbers
    application_numbers = [
        "9218062",
        "9218063", 
        "9218064",
        "9218065",
        # Add more as needed
    ]
    
    # Run the multiprocessing pipeline
    results = run_multiprocessing_batch_pipeline(
        application_numbers=application_numbers,
        session_id=str(uuid.uuid4()),
        user_id="multiprocessing_user_1",
        save_to_excel=True,
        save_json=False,
        excel_filename="example_1_multiprocessing_results.xlsx",
        max_workers=3  # Use 3 parallel processes
    )
    
    print(f"Processed {len(results)} applications using multiprocessing")
    return results


def example_2_adaptive_workers():
    """Example 2: Adaptive number of workers based on system capabilities."""
    print("="*60)
    print("EXAMPLE 2: Adaptive Workers")
    print("="*60)
    
    application_numbers = [
        "9218066",
        "9218067", 
        "9218068",
        "9218069",
        "9218070",
        "9218071",
    ]
    
    # Calculate optimal number of workers
    cpu_count = mp.cpu_count()
    optimal_workers = min(cpu_count - 1, len(application_numbers), 4)  # Leave 1 core free
    
    print(f"CPU cores: {cpu_count}")
    print(f"Applications: {len(application_numbers)}")
    print(f"Optimal workers: {optimal_workers}")
    
    results = run_multiprocessing_batch_pipeline(
        application_numbers=application_numbers,
        session_id=str(uuid.uuid4()),
        user_id="multiprocessing_user_2",
        save_to_excel=True,
        excel_filename="example_2_adaptive_results.xlsx",
        max_workers=optimal_workers
    )
    
    return results


def example_3_sequential_vs_multiprocessing():
    """Example 3: Compare sequential vs multiprocessing performance."""
    print("="*60)
    print("EXAMPLE 3: Sequential vs Multiprocessing Comparison")
    print("="*60)
    
    application_numbers = [
        "9218072",
        "9218073", 
        "9218074",
    ]
    
    print("Running sequential processing...")
    sequential_results = run_sequential_batch_pipeline(
        application_numbers=application_numbers,
        session_id=str(uuid.uuid4()),
        user_id="comparison_user",
        save_to_excel=True,
        excel_filename="example_3_sequential_results.xlsx"
    )
    
    print("\nRunning multiprocessing...")
    multiprocessing_results = run_multiprocessing_batch_pipeline(
        application_numbers=application_numbers,
        session_id=str(uuid.uuid4()),
        user_id="comparison_user",
        save_to_excel=True,
        excel_filename="example_3_multiprocessing_results.xlsx",
        max_workers=2
    )
    
    print("\n📊 Comparison Summary:")
    print("Both approaches should produce the same results but with different timing.")
    print("Multiprocessing should be faster for multiple applications.")
    
    return sequential_results, multiprocessing_results


def example_4_large_batch():
    """Example 4: Large batch processing with optimal settings."""
    print("="*60)
    print("EXAMPLE 4: Large Batch Processing")
    print("="*60)
    
    # Simulate a large batch of applications
    application_numbers = [
        f"9218{str(i).zfill(3)}" for i in range(100, 110)  # 9218100 to 9218109
    ]
    
    print(f"Processing large batch of {len(application_numbers)} applications")
    print(f"Application numbers: {application_numbers}")
    
    # Use more workers for larger batches
    max_workers = min(mp.cpu_count(), len(application_numbers), 6)
    
    results = run_multiprocessing_batch_pipeline(
        application_numbers=application_numbers,
        session_id=str(uuid.uuid4()),
        user_id="large_batch_user",
        save_to_excel=True,
        save_json=True,  # Save individual JSON files for large batches
        excel_filename="example_4_large_batch_results.xlsx",
        max_workers=max_workers
    )
    
    return results


def example_5_custom_worker_configuration():
    """Example 5: Custom worker configuration and error handling."""
    print("="*60)
    print("EXAMPLE 5: Custom Worker Configuration")
    print("="*60)
    
    application_numbers = [
        "9218110",
        "9218111", 
        "9218112",
    ]
    
    # Test with different worker configurations
    worker_configs = [1, 2, 3]
    
    for workers in worker_configs:
        print(f"\n--- Testing with {workers} worker(s) ---")
        
        try:
            results = run_multiprocessing_batch_pipeline(
                application_numbers=application_numbers,
                session_id=str(uuid.uuid4()),
                user_id=f"worker_test_{workers}",
                save_to_excel=True,
                excel_filename=f"example_5_{workers}_workers.xlsx",
                max_workers=workers
            )
            
            successful = sum(1 for r in results if r["Status"] == "Success")
            print(f"✅ {workers} worker(s): {successful}/{len(results)} successful")
            
        except Exception as e:
            print(f"❌ {workers} worker(s): Failed with error - {e}")


def example_6_load_from_file_multiprocessing():
    """Example 6: Load application numbers from file and process with multiprocessing."""
    print("="*60)
    print("EXAMPLE 6: Load from File + Multiprocessing")
    print("="*60)
    
    # Create a sample file with application numbers
    sample_file = "multiprocessing_app_numbers.txt"
    with open(sample_file, "w") as f:
        f.write("9218120\n")
        f.write("9218121\n")
        f.write("9218122\n")
        f.write("# This is a comment\n")
        f.write("9218123\n")
        f.write("9218124\n")
    
    # Read application numbers from file
    application_numbers = []
    with open(sample_file, "r") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                application_numbers.append(line)
    
    print(f"Loaded {len(application_numbers)} application numbers from file")
    print(f"Applications: {application_numbers}")
    
    # Run multiprocessing batch processing
    results = run_multiprocessing_batch_pipeline(
        application_numbers=application_numbers,
        session_id=str(uuid.uuid4()),
        user_id="file_loader_user",
        save_to_excel=True,
        excel_filename="example_6_file_loaded_results.xlsx",
        max_workers=min(3, len(application_numbers))
    )
    
    # Clean up sample file
    os.remove(sample_file)
    
    return results


def main():
    """Run all examples."""
    print("MULTIPROCESSING BATCH PROCESSING EXAMPLES")
    print("="*80)
    print(f"CPU Cores Available: {mp.cpu_count()}")
    print("="*80)
    
    # Uncomment the example you want to run:
    
    # Example 1: Basic multiprocessing
    # example_1_basic_multiprocessing()
    
    # Example 2: Adaptive workers
    # example_2_adaptive_workers()
    
    # Example 3: Sequential vs multiprocessing comparison
    # example_3_sequential_vs_multiprocessing()
    
    # Example 4: Large batch processing
    # example_4_large_batch()
    
    # Example 5: Custom worker configuration
    # example_5_custom_worker_configuration()
    
    # Example 6: Load from file + multiprocessing
    # example_6_load_from_file_multiprocessing()
    
    print("\nTo run an example, uncomment the desired function call above.")
    print("Make sure to update the application numbers with valid ones from your system.")
    print("\n💡 Tips:")
    print("   - Start with Example 1 for basic usage")
    print("   - Use Example 3 to compare performance")
    print("   - Adjust MAX_WORKERS based on your system capabilities")
    print("   - Monitor system resources during multiprocessing")


if __name__ == "__main__":
    main() 