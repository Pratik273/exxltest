import os
import sys
import pandas as pd
import traceback
import uuid
import time
import json
from loguru import logger
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from agents.dataset_workflow import dataset_graph
from agents.state import AgentState

# Configure Loguru to only show INFO and higher
logger.remove()
logger.add(sys.stdout, level="INFO")

# Path to the Excel file
def get_excel_path():
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        'data_sources', 'FAQs_Results_By_Application_Multiprocessing_100_10.xlsx')

def process_low_confidence_for_app(args):
    app_number = args[0]
    excel_path = args[1]
    target_questions = args[2] if len(args) > 2 else None
    errors = []
    try:
        all_sheets = pd.read_excel(excel_path, sheet_name=None, engine='openpyxl')
    except FileNotFoundError:
        logger.error(f"Excel file not found at {excel_path}")
        errors.append({"application_number": app_number, "question": "N/A", "error": "Excel file not found."})
        return (app_number, None, errors)
    except Exception as e:
        logger.error(f"Error reading Excel file: {e}")
        errors.append({"application_number": app_number, "question": "N/A", "error": f"Failed to read Excel file: {e}"})
        return (app_number, None, errors)

    if app_number not in all_sheets:
        logger.warning(f"Application number {app_number} not found in Excel file.")
        return (app_number, None, [])

    df = all_sheets[app_number]
    df.columns = [str(col).strip().lower() for col in df.columns]
    question_col = next((col for col in df.columns if 'question' in col), None)
    thought_col = next((col for col in df.columns if 'thought' in col), None)
    answer_col = next((col for col in df.columns if 'answer' in col), None)
    confidence_col = next((col for col in df.columns if 'confidence' in col), None)
    if not question_col or not confidence_col or not thought_col or not answer_col:
        logger.error(f"Sheet for '{app_number}' is missing required columns.")
        errors.append({"application_number": app_number, "question": "N/A", "error": "Could not find required columns."})
        return (app_number, None, errors)

    # Build condition for low confidence or specific questions
    low_confidence_condition = df[confidence_col] == 0
    if target_questions:
        specific_question_condition = df[question_col].astype(str).str.strip().isin([q.strip() for q in target_questions])
        indices_to_process = list(df[specific_question_condition].index)
        # --- Add missing target questions as new rows ---
        existing_questions = set(df[question_col].astype(str).str.strip())
        for q in target_questions:
            if q.strip() not in existing_questions:
                # Prepare a new row with the question and empty/zero values for other columns
                new_row = {col: '' for col in df.columns}
                new_row[question_col] = q.strip()
                new_row[thought_col] = ''
                new_row[answer_col] = ''
                new_row[confidence_col] = 0
                df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
                indices_to_process.append(df.index[-1])
    else:
        indices_to_process = list(df[low_confidence_condition].index)

    if len(indices_to_process) == 0:
        logger.info(f"No questions to update for application {app_number}.")
        return (app_number, df, [])

    logger.info(f"Found {len(indices_to_process)} questions to re-process for application {app_number}.")
    session_id = str(uuid.uuid4())
    user_id = "user_123_90_update"
    for i, idx in enumerate(indices_to_process):
        question = df.at[idx, question_col]
        logger.info(f"  -> Processing Q{i+1}/{len(indices_to_process)}: '{question}'")
        answer_generated = False
        try:
            app_state = AgentState(
                application_number=app_number,
                input_message=question,
                session_id=session_id,
                user_id=user_id
            )
            for output in dataset_graph.stream(app_state):
                for value in output.values():
                    if value.get("current_step") == "Reasoning & Refining the answer":
                        thought = value.get('ai_thought')
                        answer = value.get('ai_response')
                        confidence = value.get('confidence_score')
                        if thought is not None and answer is not None:
                            processed_confidence = 0
                            if isinstance(confidence, str):
                                try:
                                    processed_confidence = int(float(confidence.strip().replace('%', '')))
                                except (ValueError, TypeError):
                                    processed_confidence = 0
                            elif isinstance(confidence, (int, float)):
                                processed_confidence = int(confidence)
                            df.at[idx, thought_col] = thought
                            df.at[idx, answer_col] = answer
                            df.at[idx, confidence_col] = processed_confidence
                            answer_generated = True
                           
            time.sleep(1)
            if not answer_generated:
                errors.append({
                    "app_number": app_number,
                    "question": question,
                    "error": "Agent did not produce a valid thought and answer."
                })
        except Exception as e:
            logger.error(f"Error updating question for app {app_number}: '{question}' - {e}")
            traceback.print_exc()
            errors.append({"app_number": app_number, "question": question, "error": str(e)})

    return (app_number, df, errors)

def main():
    excel_path = get_excel_path()
    # Specify your list of target questions here (case-sensitive, exact match)
    target_questions = [
        # "What is the proposed insured's current build?",
        # "Is there any evidence of drug or alcohol use?",
        # "What is the drug/alcohol product being used?",
        # "What is the date of last use of drug/alcohol?",
        # "What prescriptions are proposed in the application?",
        # "Has there been any change in prescriptions in the past 12 months?",
        # "Are there any high-risk/ concerning prescriptions found?",
        "Any high-risk avocations found in the application?",
        "Any history of aviation in the application?",
        "What medical condition is the prescription related to?",
        "Is there any evidence of noncompliance with regards to prescriptions?",
        "Are there any comorbid conditions present that would impact mortality?"
        # Add more questions as needed
    ]

    # Read all sheets (application numbers)
    try:
        all_sheets = pd.read_excel(excel_path, sheet_name=None, engine='openpyxl')
    except Exception as e:
        logger.error(f"Error reading Excel file: {e}")
        return

    application_numbers = list(all_sheets.keys())
    logger.info(f"Found {len(application_numbers)} application sheets in the Excel file.")

    all_errors = []
    updated_dfs = {}
    args_list = [(app_number, excel_path, target_questions) for app_number in application_numbers]

    # Use ProcessPoolExecutor for parallel processing
    with ProcessPoolExecutor(max_workers=6) as executor:
        futures = {executor.submit(process_low_confidence_for_app, args): args[0] for args in args_list}
        for future in futures:
            app_number = futures[future]
            try:
                app_number, updated_df, app_errors = future.result()
                if app_errors:
                    all_errors.extend(app_errors)
                    logger.warning(f"Logged {len(app_errors)} error(s) for application {app_number}.")
                if updated_df is not None:
                    updated_dfs[app_number] = updated_df
                    logger.info(f"Successfully updated sheet for application {app_number}.")
                logger.info(f"Finished processing application: {app_number}")
            except Exception as e:
                logger.error(f"Error processing application {app_number}: {e}")
                all_errors.append({"app_number": app_number, "error": str(e)})

    # Write all updated sheets back to the Excel file
    if updated_dfs:
        try:
            with pd.ExcelWriter(excel_path, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
                for app_number, updated_df in updated_dfs.items():
                    updated_df.to_excel(writer, sheet_name=app_number, index=False)
            logger.info(f"Successfully updated all sheets in the Excel file.")
        except Exception as e:
            logger.error(f"Error saving updated sheets: {e}")
    else:
        logger.info("No sheets were updated.")

    # Write all errors to a single static error file at the end
    error_file_path = os.path.join(os.path.dirname(excel_path), 'update_low_confidence_errors_90.json')
    if all_errors:
        with open(error_file_path, 'w') as f:
            json.dump(all_errors, f, indent=4)
        logger.info(f"All errors logged to: {error_file_path}")
    else:
        logger.info("No errors encountered!")

if __name__ == "__main__":
    main() 