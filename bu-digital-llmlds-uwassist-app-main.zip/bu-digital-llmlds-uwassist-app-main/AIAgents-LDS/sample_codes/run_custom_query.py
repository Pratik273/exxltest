import os
import sys
import asyncio
import uuid
import time
from loguru import logger
from dotenv import load_dotenv
import traceback

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

# from agents.dataset_workflow import dataset_graph
from agents.summary_workflow import summary_graph
from agents.state import AgentState

load_dotenv()

async def run_custom_query(question: str, application_number: str):
    """
    Runs the dataset_graph with a custom question and application number.
    """
    # input_state = InputState(input_message=question, application_number=application_number)
    session_id = str(uuid.uuid4())
    user_id = "user_test"
    app_state = AgentState()
    app_state.application_number = application_number
    app_state.input_message = question
    app_state.session_id = session_id
    app_state.user_id = user_id
    
    # Run the workflow
    try:
        thought, answer, confidence = None, None, 0
        for output in summary_graph.stream(app_state):
            for value in output.values():
                app_state.current_step = value.get("current_step", None)
                if app_state.current_step == "Reasoning & Refining the answer":
                    thought = value.get('ai_thought', None)
                    logger.info(f"Thought: {thought}")
                    answer = value.get('ai_response', None)
                    logger.info(f"Answer: {answer}")
                    confidence = value.get('confidence_score', None)
                    logger.info(f"Confidence score: {confidence}")
        
               
                    
        # Pause to avoid rate limiting
        time.sleep(1)
        
    except Exception as e:
        print(f"Error processing question for app {application_number}: '{question}'")
        # print(f"Current enumerate index 'i': {i}, DataFrame index 'idx': {idx}")
        print(f"Error details: {e}")
        traceback.print_exc()

if __name__ == "__main__":
    # Example usage: Replace with your custom question and application number
    # "Are there any comorbid conditions present that would impact mortality?"
    #"What is the proposed insured's current build?"
    # "Are there any pending tests, MD visits, labs, consultations?"
    # "Any inforce coverage present in the application?"
    # "Is there any evidence of drug or alcohol use?"
    custom_question = "Write an overall summary of the application."

    #"Write a summary on Physical Metrics, Medical History, Substance Use and Additional Notes section. The additional notes should only include recommendations for underwriters if there are any. The additional notes should be concise and to the point."
    #"Write a summary on demographics, MVR, Miscellaneous and Additional Notes section. The additional notes should only include recommendations for underwriters if there are any."
    #"Write a summary on the medical and lifestyle history of the applicant."
    #"Write a summary on the medical and lifestyle history of the applicant, especially if any concerning prescription, diagnosis, lab results etc"
    # Example usage: Replace with your custom question and application number
    # "Write a summary on the medical history of the applicant especially if anything is concerning"
    # "Are there any comorbid conditions present that would impact mortality?"
    #"What is the proposed insured's current build?"
    # "Are there any pending tests, MD visits, labs, consultations?"
    # "Any inforce coverage present in the application?"
    # "Is there any evidence of drug or alcohol use?"
    custom_application_number = "9218062"
    #"9217470"
    # "9218596"
    # "9218462"
    # To run the asynchronous function
    asyncio.run(run_custom_query(custom_question, custom_application_number)) 