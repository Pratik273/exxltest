import pandas as pd
import numpy as np

def format_requirements_for_excel(requirements_list):
    """
    Formats a list of requirement dictionaries for Excel export.
    
    Args:
        requirements_list: A list of dictionaries containing requirement information
        
    Returns:
        A pandas DataFrame with a single column 'Requirements' where each row contains
        a formatted requirement dictionary, or None if the requirements list is empty
    """
    # If requirements_list is empty or not a list, return None to signal skipping Excel export
    if not requirements_list or not isinstance(requirements_list, list):
        return None
    
    # If the list is empty, return None to signal skipping Excel export
    if len(requirements_list) == 0:
        return None
    
    # Create a DataFrame with a single column for requirements
    requirements_df = pd.DataFrame({"Requirements": np.nan}, index=range(len(requirements_list)))
    
    # Format each requirement as a string and add to the DataFrame
    for i, req in enumerate(requirements_list):
        if isinstance(req, dict):
            # Format dictionary as a readable string with line breaks
            if len(req) > 0:  # Only process non-empty dictionaries
                formatted_req = "\n".join([f"{key}: {value}" for key, value in req.items()])
                requirements_df.loc[i, "Requirements"] = formatted_req
            else:
                requirements_df.loc[i, "Requirements"] = "Empty requirement"
        else:
            # If not a dictionary, convert to string
            requirements_df.loc[i, "Requirements"] = str(req)
    
    return requirements_df
