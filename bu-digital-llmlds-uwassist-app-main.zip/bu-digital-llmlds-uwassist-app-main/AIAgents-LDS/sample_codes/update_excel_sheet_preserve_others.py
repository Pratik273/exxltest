import os
import pandas as pd
from loguru import logger
import sys
import uuid
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
import json

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from agents.state import AgentState
from agents.dataset_workflow import dataset_graph

# ====== USER VARIABLES (EDIT THESE) ======
questions_excel_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                           'data_sources', 'FAQs_Division_4.xlsx')
# questions_excel_file = "data_sources/FAQS_Division_4.xlsx"  # Path to Excel file with questions
results_excel_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),'data_sources', 'FAQs_Results_By_Application_Multiprocessing_100_7.xlsx')      # Path to main Excel file to update
app_numbers = ["9226628", "9227550"]                             # List of application numbers (sheet names)
questions_sheet = "FAQs"                                   # Sheet name in questions file
questions_header = 1                                        # Header row index (0-based)
max_workers = 2                                             # Number of parallel processes
# ==========================================

def generate_answers_for_questions(questions_df, app_number):
    session_id = str(uuid.uuid4())
    user_id = "user_123"
    results_df = pd.DataFrame({
        'Question': questions_df['Qn'],
        'Thought': [""] * len(questions_df),
        'Answer': [""] * len(questions_df),
        'Confidence': [0] * len(questions_df)
    })
    for idx, row in questions_df.iterrows():
        question = row.get('Qn', '')
        if not question:
            continue
        logger.info(f"App {app_number}: Processing question {idx+1}/{len(questions_df)}: {question}")
        app_state = AgentState()
        app_state.application_number = app_number
        app_state.input_message = question
        app_state.session_id = session_id
        app_state.user_id = user_id
        try:
            thought, answer, confidence = None, None, 0
            answer_generated = False
            for output in dataset_graph.stream(app_state):
                for value in output.values():
                    app_state.current_step = value.get("current_step", None)
                    if app_state.current_step == "Reasoning & Refining the answer":
                        thought = value.get('ai_thought', None)
                        answer = value.get('ai_response', None)
                        confidence = value.get('confidence_score', None)
                        if thought is not None and answer is not None:
                            processed_confidence = 0
                            if isinstance(confidence, str):
                                try:
                                    processed_confidence = int(float(confidence.strip().replace('%', '')))
                                except (ValueError, TypeError):
                                    processed_confidence = 0
                            elif isinstance(confidence, (int, float)):
                                processed_confidence = int(confidence)
                            results_df.at[idx, 'Thought'] = thought
                            results_df.at[idx, 'Answer'] = answer
                            results_df.at[idx, 'Confidence'] = processed_confidence
                            answer_generated = True
            if not answer_generated:
                logger.warning(f"App {app_number}: No answer generated for question: {question}")
            time.sleep(1)  # Rate limiting
        except Exception as e:
            logger.error(f"App {app_number}: Error processing question: '{question}' - {e}")
    return results_df

def update_or_add_sheet(excel_path, app_number, df_new):
    sheet_name = str(app_number)[:31]
    logger.info(f"Updating sheet '{sheet_name}' in '{excel_path}'")
    if os.path.exists(excel_path):
        with pd.ExcelWriter(excel_path, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
            df_new.to_excel(writer, sheet_name=sheet_name, index=False)
            logger.info(f"Sheet '{sheet_name}' updated or added.")
    else:
        with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
            df_new.to_excel(writer, sheet_name=sheet_name, index=False)
            logger.info(f"File created and sheet '{sheet_name}' written.")

def process_app(app_number):
    try:
        logger.info(f"App {app_number}: Reading questions from input Excel file...")
        questions_df = pd.read_excel(questions_excel_file, sheet_name=questions_sheet, header=questions_header)
        logger.info(f"App {app_number}: Loaded {len(questions_df)} questions.")
        results_df = generate_answers_for_questions(questions_df, app_number)
        update_or_add_sheet(results_excel_file, app_number, results_df)
        logger.info(f"App {app_number}: Done!")
        return (app_number, True, None)
    except Exception as e:
        logger.error(f"App {app_number}: Failed with error: {e}")
        return (app_number, False, str(e))

if __name__ == "__main__":
    logger.info(f"Starting multiprocessing update for {len(app_numbers)} applications with {max_workers} workers...")
    results = []
    errors = []
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        future_to_app = {executor.submit(process_app, app_number): app_number for app_number in app_numbers}
        for future in as_completed(future_to_app):
            app_number = future_to_app[future]
            try:
                app, success, error = future.result()
                if success:
                    logger.info(f"App {app}: ✅ Successfully updated.")
                else:
                    logger.error(f"App {app}: ❌ Failed. Error: {error}")
                    errors.append({"app_number": app, "error": error})
                results.append((app, success, error))
            except Exception as exc:
                logger.error(f"App {app_number}: ❌ Exception in future: {exc}")
                errors.append({"app_number": app_number, "error": str(exc)})
                results.append((app_number, False, str(exc)))
    # Write errors to JSON file
    error_file = "update_errors.json"
    if errors:
        with open(error_file, "w") as f:
            json.dump(errors, f, indent=4)
        logger.info(f"Errors logged to: {error_file}")
    else:
        logger.info("No errors encountered!")
    logger.info("All multiprocessing updates completed.") 