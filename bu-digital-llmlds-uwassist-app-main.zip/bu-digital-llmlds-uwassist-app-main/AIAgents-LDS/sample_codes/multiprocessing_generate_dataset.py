import os
import uuid
from loguru import logger
import pandas as pd
import sys
import math
import traceback
import json
import time
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import pickle
from multiprocessing import Manager, Lock

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from agents.workflow import graph
from agents.dataset_workflow import dataset_graph
from agents.state import AgentState

# Configure Loguru to only show INFO and higher
logger.remove()
logger.add(sys.stdout, level="INFO")


def setup_logger():
    """Setup logger for each process"""
    logger.remove()
    logger.add(sys.stdout, level="INFO")


def process_faqs_for_application(args):
    """Process FAQs for a single application - multiprocessing worker function.
    
    Args:
        args: Tuple containing (app_number, questions_data, base_paths)
        
    Returns:
        Tuple of (app_number, results_data, errors_data, success_flag)
    """
    app_number, questions_data, excel_path, prod_samples_dir = args
    
    # Setup logger for this process
    setup_logger()
    
    process_name = mp.current_process().name
    logger.info(f"Process {process_name}: Starting application {app_number}")
    
    try:
        # Recreate questions DataFrame from serialized data
        questions_df = pd.DataFrame(questions_data)
        
        session_id = str(uuid.uuid4())
        user_id = "user_123"
        
        # Initialize the results dataframe
        results_df = pd.DataFrame({
            'Question': questions_df['Qn'],
            'Thought': [""] * len(questions_df),
            'Answer': [""] * len(questions_df),
            'Confidence': [0] * len(questions_df)
        })

        errors = []
        
        # Process each question sequentially within this application
        for i, (idx, row) in enumerate(questions_df.iterrows()):
            question = row.get('Qn', '')
            if not question:
                continue
                
            logger.info(f"Process {process_name} - App {app_number}: Question {i+1}/{len(questions_df)}")
            
            # Create conversation app_state
            app_state = AgentState()
            app_state.application_number = app_number
            app_state.input_message = question
            app_state.session_id = session_id
            app_state.user_id = user_id
            
            # Run the workflow
            try:
                thought, answer, confidence = None, None, 0
                answer_generated = False
                
                for output in dataset_graph.stream(app_state):
                    for value in output.values():
                        app_state.current_step = value.get("current_step", None)
                        if app_state.current_step == "Reasoning & Refining the answer":
                            thought = value.get('ai_thought', None)
                            logger.debug(f"Process {process_name} - App {app_number} - Thought: {thought}")
                            answer = value.get('ai_response', None)
                            confidence = value.get('confidence_score', None)
                            logger.debug(f"Process {process_name} - App {app_number} - Raw confidence score: {confidence}")
                
                            if thought is not None and answer is not None:
                                # Process confidence score
                                processed_confidence = 0
                                if isinstance(confidence, str):
                                    try:
                                        processed_confidence = int(float(confidence.strip().replace('%', '')))
                                    except (ValueError, TypeError):
                                        processed_confidence = 0
                                elif isinstance(confidence, (int, float)):
                                    processed_confidence = int(confidence)
                                
                                # Update results
                                results_df.at[idx, 'Thought'] = thought
                                results_df.at[idx, 'Answer'] = answer
                                results_df.at[idx, 'Confidence'] = processed_confidence
                                answer_generated = True
                            
                # Check if answer was generated
                if not answer_generated:
                    errors.append({
                        "app_number": app_number,
                        "question": question,
                        "error": "Agent did not produce a valid thought and answer."
                    })

                # Rate limiting
                time.sleep(1)
                
            except Exception as e:
                logger.error(f"Process {process_name} - Error processing question for app {app_number}: '{question}' - {e}")
                traceback.print_exc()
                errors.append({"app_number": app_number, "question": question, "error": str(e)})
        
        logger.info(f"Process {process_name}: Completed application {app_number} with {len(results_df)} questions")
        
        # Return serializable data
        return (app_number, results_df.to_dict('records'), errors, True)
        
    except Exception as e:
        logger.error(f"Process {process_name}: Error processing application {app_number}: {e}")
        traceback.print_exc()
        return (app_number, None, [{"app_number": app_number, "error": str(e)}], False)


def write_results_to_excel(results_data, output_path):
    """Write all results to Excel file with separate sheets for each application."""
    try:
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            for app_number, data_records in results_data.items():
                if data_records:
                    df = pd.DataFrame(data_records)
                    sheet_name = f"{app_number}"[:31]  # Excel sheet name limit
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
                    logger.info(f"Written sheet '{sheet_name}' with {len(df)} rows")
        
        logger.info(f"📊 All results successfully written to {output_path}")
        return True
    except Exception as e:
        logger.error(f"❌ Error writing results to Excel: {e}")
        traceback.print_exc()
        return False


def write_backup_results(results_data, base_path):
    """Write backup results as individual Excel files if main file fails."""
    backup_dir = os.path.join(os.path.dirname(base_path), 'backup_results')
    os.makedirs(backup_dir, exist_ok=True)
    
    successful_backups = 0
    for app_number, data_records in results_data.items():
        if data_records:
            try:
                backup_file = os.path.join(backup_dir, f'FAQs_Results_{app_number}_backup.xlsx')
                df = pd.DataFrame(data_records)
                df.to_excel(backup_file, index=False)
                successful_backups += 1
                logger.info(f"Backup saved: {backup_file}")
            except Exception as e:
                logger.error(f"Failed to save backup for {app_number}: {e}")
    
    logger.info(f"💾 Saved {successful_backups} backup files in {backup_dir}")
    return successful_backups


def process_all_applications_multiprocess(max_workers=6):
    """Process FAQs for all applications using multiprocessing for true parallelism."""
    
    prod_samples_dir = "data_sources_batch4"
    if not os.path.exists(prod_samples_dir):
        logger.error(f"Directory {prod_samples_dir} does not exist")
        sys.exit(1)

    # Get application folders
    # application_folders = ["9217744", "9218062", "9222406", "9222517", "9230523"]
    application_folders = []
    for item_name in sorted(os.listdir(prod_samples_dir)):
        item_path = os.path.join(prod_samples_dir, item_name)
        if os.path.isdir(item_path):
            application_folders.append(item_name)
    
    logger.info(f"Found {len(application_folders)} application folders")
    
    # Load questions
    excel_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                           'data_sources', 'FAQs_Division_4.xlsx')
    try:
        questions_df = pd.read_excel(excel_path, sheet_name='FAQs', header=0)
        logger.info(f"Successfully loaded {len(questions_df)} questions from Excel file.")
    except Exception as e:
        logger.error(f"Error reading Excel file: {e}")
        return
    
    # Create output paths
    output_path = os.path.join(os.path.dirname(excel_path), 'FAQs_Results_By_Application_Multiprocessing_100_11.xlsx')
    error_file_path = os.path.join(os.path.dirname(excel_path), 'FAQs_Errors_Multiprocessing_11.json')

    # Initialize error log
    with open(error_file_path, 'w') as f:
        json.dump([], f, indent=4)
    
    # Remove output file if it exists to start fresh
    if os.path.exists(output_path):
        os.remove(output_path)
        logger.info(f"Removed existing output file: {output_path}")
    
    folders_to_skip = [
    "9218851", "9218833", "9218838", "9218813", "9218880", "9218881",
    "9217304", "9217310", "9217328", "9217370", "9217386", "9217440",
    "9217470", "9217499", "9217523", "9217578", "9217639", "9217640",
    "9217647", "9217743", "9217750", "9217751", "9217756", "9217775",
    "9217779", "9217781", "9217787", "9217816", "9217828", "9217831",
    "9217834", "9217835", "9217870", "9217895", "9217897", "9217899",
    "9217937", "9217938", "9217964", "9217986", "9217997", "9218002",
    "9218015", "9218059", "9218084", "9218085", "9218131", "9218134",
    "9218151", "9218159", "9218177", "9218185", "9218193", "9218199",
    "9218204", "9218208", "9218220", "9218233", "9218299", "9218300",
    "9218315", "9218355", "9218363", "9218364", "9218416", "9218443",
    "9218452", "9218456", "9218462", "9218477", "9218485", "9218529",
    "9218536", "9218539", "9218553", "9218559", "9218563", "9218592",
    "9218593", "9218596", "9218615", "9218624", "9218625", "9218648",
    "9218653", "9218669", "9218670", "9218672", "9218681", "9218695",
    "9218696", "9218709", "9218710", "9218718", "9218739", "9218794",
    "9217744", "9218062", "9222406", "9222517", "9230523"
]
    #Skipping 9218851, 9218833, 9218838, 9218813, 9218880, 9218881
    application_folders = [app for app in application_folders if app.strip() not in folders_to_skip]

    # Process applications starting from index 2 (skip certain apps as in original)
    applications_to_process = [app.strip() for app in application_folders[402:413]]
    
    logger.info(f"🚀 Starting multiprocessing of {len(applications_to_process)} applications with {max_workers} processes")
    logger.info(f"🔥 This bypasses Python's GIL for TRUE parallelism!")
    
    # Prepare arguments for multiprocessing
    questions_data = questions_df.to_dict('records')  # Serialize for multiprocessing
    args_list = [
        (app_folder, questions_data, excel_path, prod_samples_dir)
        for app_folder in applications_to_process
    ]
    
    # Collect results
    all_results = {}
    all_errors = []
    
    # Use ProcessPoolExecutor for true parallelism
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        # Submit all applications
        future_to_app = {
            executor.submit(process_faqs_for_application, args): args[0] 
            for args in args_list
        }
        
        # Process completed futures
        completed_count = 0
        for future in as_completed(future_to_app):
            app_folder = future_to_app[future]
            try:
                app_number, results_data, errors_data, success = future.result()
                completed_count += 1
                
                if success and results_data:
                    all_results[app_number] = results_data
                    logger.info(f"[{completed_count}/{len(applications_to_process)}] ✅ Successfully processed application {app_number}")
                else:
                    logger.warning(f"[{completed_count}/{len(applications_to_process)}] ⚠️  Failed to process application {app_number}")
                
                if errors_data:
                    all_errors.extend(errors_data)
                    
            except Exception as exc:
                completed_count += 1
                logger.error(f"[{completed_count}/{len(applications_to_process)}] ❌ Application {app_folder} generated an exception: {exc}")
                all_errors.append({"app_number": app_folder, "error": str(exc)})
    
    # Write all results to Excel
    if all_results:
        logger.info(f"📝 Writing results for {len(all_results)} applications to Excel...")
        success = write_results_to_excel(all_results, output_path)
        if success:
            logger.info(f"📊 Results successfully written to: {output_path}")
        else:
            logger.warning("⚠️  Main Excel write failed, creating backup files...")
            write_backup_results(all_results, output_path)
    else:
        logger.warning("⚠️  No results to write!")
    
    # Write errors to JSON
    if all_errors:
        with open(error_file_path, 'w') as f:
            json.dump(all_errors, f, indent=4)
        logger.info(f"📝 {len(all_errors)} errors logged to: {error_file_path}")
    else:
        logger.info("✅ No errors encountered!")
    
    logger.info("🎉 Multiprocessing completed!")


if __name__ == "__main__":
    # Required for multiprocessing on some systems
    if mp.get_start_method(allow_none=True) is None:
        mp.set_start_method('spawn')
    
    start_time = time.time()
    
    # Use 6 processes for true parallelism (adjust based on your CPU cores)
    # With 8 vCPUs, you can use up to 7-8, but 6 leaves some headroom
    max_workers = 6
    
    logger.info("=" * 70)
    logger.info("🚀 MULTIPROCESSING DATASET GENERATION")
    logger.info("=" * 70)
    logger.info(f"🔥 Using {max_workers} separate processes for TRUE parallelism")
    logger.info(f"💪 Bypassing Python's GIL completely!")
    logger.info(f"🖥️  Utilizing your {mp.cpu_count()} CPU cores effectively")
    logger.info("=" * 70)
    
    process_all_applications_multiprocess(max_workers=max_workers)
    
    end_time = time.time()
    elapsed_seconds = end_time - start_time
    hours, rem = divmod(elapsed_seconds, 3600)
    minutes, seconds = divmod(rem, 60)

    time_parts = []
    if hours > 0:
        time_parts.append(f"{int(hours)} hour{'s' if int(hours) != 1 else ''}")
    if minutes > 0:
        time_parts.append(f"{int(minutes)} minute{'s' if int(minutes) != 1 else ''}")
    if elapsed_seconds < 60 or seconds > 0:
        time_parts.append(f"{int(seconds)} second{'s' if int(seconds) != 1 else ''}")
    
    beautiful_time_str = " and ".join(filter(None, [", ".join(time_parts[:-1]), time_parts[-1]])) if time_parts else "less than a second"

    logger.info("=" * 70)
    logger.info("🎉 ALL MULTIPROCESSING TASKS COMPLETED!")
    logger.info(f"⏱️  Total Time Taken: {beautiful_time_str}")
    logger.info(f"🔥 Processed with {max_workers} separate processes (TRUE parallelism!)")
    logger.info(f"💾 Results saved to: FAQs_Results_By_Application_Multiprocessing.xlsx")
    logger.info("=" * 70) 