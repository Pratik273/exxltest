# Batch Summary Processing

This directory contains scripts for processing multiple application numbers and generating summaries in Excel format.

## Files

- `run_summaries_batch.py` - Main batch processing script
- `example_batch_usage.py` - Examples showing different usage patterns
- `run_summaries.py` - Original single application processing script

## Quick Start

### 1. Basic Usage

Edit the configuration in `run_summaries_batch.py`:

```python
# Add your application numbers here
APPLICATION_NUMBERS = [
    "9218062",
    "9218063", 
    "9218064",
    # Add more as needed
]

# Configuration options
SAVE_TO_EXCEL = True              # Save results to Excel
EXCEL_FILENAME = "batch_summary_results.xlsx"
DELAY_BETWEEN_APPS = 2            # Delay between applications (seconds)
RETRY_ATTEMPTS = 3                # Retry attempts if an application fails
```

### 2. Run the Script

```bash
cd AIAgents-LDS/sample_codes
python run_summaries_batch.py
```

## Excel Output Structure

The script generates an Excel file with the following structure:

| ApplicationNumber | Demographics Summary | Medical Summary | Overall Summary |
|-------------------|---------------------|-----------------|-----------------|
| 9218062           | Summary text...     | Summary text... | Summary text... |
| 9218063           | Summary text...     | Summary text... | Summary text... |

## Configuration Options

### Application Numbers
```python
APPLICATION_NUMBERS = [
    "9218062",
    "9218063",
    # Add more application numbers
]
```

### Processing Options
```python
DELAY_BETWEEN_APPS = 2            # Delay between processing applications
RETRY_ATTEMPTS = 3                # Number of retry attempts per application
```

### Output Options
```python
SAVE_TO_EXCEL = True              # Save results to Excel file
EXCEL_FILENAME = "batch_summary_results.xlsx"
SAVE_JSON_FILES = False           # Save individual JSON files
```

## Advanced Usage Examples

### Example 1: Basic Batch Processing
```python
from run_summaries_batch import run_batch_summary_pipeline

application_numbers = ["9218062", "9218063", "9218064"]

results = run_batch_summary_pipeline(
    application_numbers=application_numbers,
    session_id="my_session",
    user_id="my_user",
    save_to_excel=True,
    excel_filename="my_results.xlsx"
)
```

### Example 2: Load from File
```python
# Create a file with application numbers
with open("app_numbers.txt", "w") as f:
    f.write("9218062\n")
    f.write("9218063\n")
    f.write("9218064\n")

# Read and process
with open("app_numbers.txt", "r") as f:
    app_numbers = [line.strip() for line in f if line.strip()]

results = run_batch_summary_pipeline(app_numbers)
```

### Example 3: Custom Retry Logic
```python
from run_summaries_batch import run_single_application_with_retry

# Process with custom retry settings
result = run_single_application_with_retry(
    application_number="9218062",
    session_id="my_session",
    user_id="my_user",
    max_retries=5  # More retry attempts
)
```

## Error Handling

The script includes robust error handling:

- **Retry Logic**: Failed applications are retried up to the specified number of attempts
- **Graceful Failures**: If an application fails after all retries, processing continues with the next application
- **Progress Tracking**: Real-time progress updates and success/failure counts
- **Detailed Logging**: Comprehensive logging for debugging

## Output Files

### Excel File
- **Filename**: `batch_summary_results.xlsx` (configurable)
- **Structure**: ApplicationNumber | Demographics Summary | Medical Summary | Overall Summary
- **Status Tracking**: Includes success/failure status for each application

### JSON Files (Optional)
- **Individual files**: `summary_results_<app_number>.json`
- **Complete results**: All results in a single JSON structure

## Performance Considerations

- **Rate Limiting**: Built-in delays between applications to avoid API rate limits
- **Memory Management**: Processes applications sequentially to manage memory usage
- **Progress Monitoring**: Real-time progress updates for long-running batches

## Troubleshooting

### Common Issues

1. **Application Not Found**: Ensure application numbers exist in your system
2. **API Rate Limits**: Increase `DELAY_BETWEEN_APPS` if you encounter rate limiting
3. **Memory Issues**: Process smaller batches if you encounter memory problems
4. **Network Issues**: Increase `RETRY_ATTEMPTS` for better resilience

### Debug Mode
Enable detailed logging by modifying the logger configuration in the script.

## Dependencies

Required packages (already in requirements.txt):
- `pandas` - For Excel file creation
- `openpyxl` - Excel file engine
- `loguru` - Logging
- Other dependencies from the main project

## Running Examples

To see different usage patterns, run the example script:

```bash
python example_batch_usage.py
```

Uncomment the desired example function in the main() function to run it. 