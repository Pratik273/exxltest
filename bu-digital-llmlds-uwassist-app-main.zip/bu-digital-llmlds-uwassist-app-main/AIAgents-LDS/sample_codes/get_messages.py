import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from scripts.database.check_db_conn import connect_to_db

