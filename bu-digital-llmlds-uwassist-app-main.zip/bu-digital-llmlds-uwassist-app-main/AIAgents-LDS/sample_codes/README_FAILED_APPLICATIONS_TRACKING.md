# Failed Applications Tracking & Retry System

This directory contains enhanced batch processing scripts that automatically track failed applications and provide a retry mechanism for processing them.

## Files

- `run_summaries_batch.py` - Enhanced batch script with failed applications tracking
- `retry_failed_applications.py` - Dedicated retry script for failed applications
- `failed_applications.json` - Generated file containing failed applications (auto-created)
- `successful_applications.json` - Generated file containing successful applications (auto-created)

## 🎯 Key Features

### ✅ **Automatic Failed Applications Tracking**
- Failed applications are automatically saved to `failed_applications.json`
- Successful applications are saved to `successful_applications.json`
- Detailed metadata including timestamps and error information

### ✅ **Dedicated Retry System**
- `retry_failed_applications.py` reads failed applications and retries them
- Increased retry attempts for previously failed applications
- Separate session tracking for retry operations

### ✅ **Comprehensive Error Information**
- Original error messages preserved
- Retry attempt counts tracked
- Worker information for debugging

## 📁 File Structure

### Generated Files (After Running Batch Processing)

```
📁 Your Directory/
├── 📄 batch_summary_results.xlsx          # Main Excel output
├── 📄 successful_applications.json        # Successful applications
├── 📄 failed_applications.json            # Failed applications (for retry)
├── 📄 summary_results_9218062.json        # Individual results (if enabled)
└── 📄 summary_results_9218063.json        # Individual results (if enabled)
```

### After Running Retry Script

```
📁 Your Directory/
├── 📄 retry_results.xlsx                  # Retry Excel output
├── 📄 retry_successful_applications.json  # Successfully retried apps
├── 📄 retry_failed_applications.json      # Still failed after retry
└── 📄 failed_applications.json            # Original failed apps (preserved)
```

## 🚀 Quick Start

### Step 1: Run Batch Processing
```bash
cd AIAgents-LDS/sample_codes
python run_summaries_batch.py
```

This will generate:
- `batch_summary_results.xlsx` - All results
- `successful_applications.json` - Successful applications
- `failed_applications.json` - Failed applications

### Step 2: Retry Failed Applications
```bash
python retry_failed_applications.py
```

This will:
- Read `failed_applications.json`
- Retry all failed applications
- Generate `retry_results.xlsx`
- Create `retry_successful_applications.json` and `retry_failed_applications.json`

## 📋 Configuration Options

### Batch Processing Configuration (`run_summaries_batch.py`)

```python
# Failed applications tracking
SAVE_FAILED_APPS = True           # Save failed applications to separate JSON file
SAVE_SUCCESSFUL_APPS = True       # Save successful applications to separate JSON file
FAILED_APPS_FILENAME = "failed_applications.json"
SUCCESSFUL_APPS_FILENAME = "successful_applications.json"

# Application numbers
APPLICATION_NUMBERS = [
    "9218062",
    "9218063", 
    "9218064",
    # Add more as needed
]
```

### Retry Configuration (`retry_failed_applications.py`)

```python
# Retry settings
FAILED_APPS_FILE = "failed_applications.json"  # File to read failed apps from
RETRY_ATTEMPTS = 5                             # More retry attempts for failed apps
MAX_WORKERS = 3                                # Parallel processes for retry
RETRY_EXCEL_FILENAME = "retry_results.xlsx"    # Excel output for retry results
```

## 📊 JSON File Formats

### Failed Applications JSON Structure

```json
{
  "metadata": {
    "total_failed": 2,
    "timestamp": "2024-01-15T10:30:45.123456",
    "description": "Failed application summaries that need to be retried"
  },
  "failed_applications": [
    {
      "ApplicationNumber": "9218062",
      "Demographics Summary": null,
      "Medical Summary": null,
      "Overall Summary": null,
      "Status": "Failed after 3 attempts: Network timeout",
      "Attempts": 3
    },
    {
      "ApplicationNumber": "9218063",
      "Demographics Summary": null,
      "Medical Summary": null,
      "Overall Summary": null,
      "Status": "Worker failed: Application not found",
      "Attempts": 0,
      "Worker": "ForkPoolWorker-1"
    }
  ]
}
```

### Successful Applications JSON Structure

```json
{
  "metadata": {
    "total_successful": 3,
    "timestamp": "2024-01-15T10:30:45.123456",
    "description": "Successfully processed application summaries"
  },
  "successful_applications": [
    {
      "ApplicationNumber": "9218064",
      "Demographics Summary": "Patient is a 45-year-old male...",
      "Medical Summary": "Patient has a history of...",
      "Overall Summary": "Based on the demographics and medical information...",
      "Status": "Success",
      "Attempts": 1
    }
  ]
}
```

## 🔄 Retry Workflow

### 1. Initial Batch Processing
```
Applications: [9218062, 9218063, 9218064, 9218065]
Results:
✅ 9218064, 9218065 (Success)
❌ 9218062, 9218063 (Failed)
```

### 2. Generated Files
```
successful_applications.json: [9218064, 9218065]
failed_applications.json: [9218062, 9218063]
```

### 3. Retry Failed Applications
```
Retry: [9218062, 9218063]
Results:
✅ 9218062 (Retry Success)
❌ 9218063 (Still Failed)
```

### 4. Final Files
```
retry_successful_applications.json: [9218062]
retry_failed_applications.json: [9218063]
```

## 🛠️ Advanced Usage

### Custom Retry Configuration

```python
from retry_failed_applications import retry_failed_applications, load_failed_applications

# Load failed applications
app_numbers, failed_data = load_failed_applications("my_failed_apps.json")

# Custom retry with different settings
results = retry_failed_applications(
    application_numbers=app_numbers,
    session_id="custom_retry_session",
    user_id="custom_user",
    save_to_excel=True,
    excel_filename="custom_retry_results.xlsx"
)
```

### Manual Retry of Specific Applications

```python
# Retry specific applications manually
specific_failed_apps = ["9218062", "9218063"]

results = retry_failed_applications(
    application_numbers=specific_failed_apps,
    session_id="manual_retry",
    user_id="manual_user"
)
```

### Analyze Failed Applications

```python
import json

# Load and analyze failed applications
with open("failed_applications.json", "r") as f:
    failed_data = json.load(f)

failed_apps = failed_data["failed_applications"]

# Analyze failure reasons
failure_reasons = {}
for app in failed_apps:
    reason = app["Status"]
    failure_reasons[reason] = failure_reasons.get(reason, 0) + 1

print("Failure Analysis:")
for reason, count in failure_reasons.items():
    print(f"  {reason}: {count} applications")
```

## 📈 Performance Benefits

### Automatic Tracking
- **No manual tracking** required
- **Immediate identification** of failed applications
- **Detailed error information** for debugging

### Efficient Retry System
- **Targeted retries** - only retry what failed
- **Increased retry attempts** for problematic applications
- **Parallel processing** for faster retry completion

### Time Savings
```
Without tracking: Re-run entire batch to find failures
With tracking: Retry only failed applications

Example:
- 100 applications, 10 failed
- Without tracking: Re-process all 100
- With tracking: Retry only 10 failed ones
- Time savings: 90% for retry operations
```

## 🔍 Error Analysis

### Common Failure Reasons
1. **Network Timeout** - API connection issues
2. **Application Not Found** - Invalid application numbers
3. **Rate Limiting** - API quota exceeded
4. **Memory Issues** - System resource constraints
5. **Worker Failures** - Process crashes

### Debugging Tips
1. **Check failed_applications.json** for detailed error messages
2. **Review worker information** for process-specific issues
3. **Monitor system resources** during processing
4. **Adjust retry settings** based on failure patterns

## 🚨 Troubleshooting

### No Failed Applications File
```
❌ Error: Failed applications file 'failed_applications.json' not found.
```
**Solution**: Run the batch processing first to generate the file.

### Empty Failed Applications File
```
📋 Loaded 0 failed applications from failed_applications.json
```
**Solution**: All applications were successful in the previous run.

### Retry Still Failing
- Check if the original issues are resolved
- Increase `RETRY_ATTEMPTS` in retry configuration
- Review error messages in `retry_failed_applications.json`
- Consider manual intervention for persistent failures

## 📊 Monitoring & Reporting

### Success Rate Tracking
- **Initial batch success rate**: Tracked in batch summary
- **Retry success rate**: Tracked in retry summary
- **Overall success rate**: Combined statistics

### Progress Monitoring
- **Real-time progress** during both batch and retry
- **Worker status** tracking
- **Time estimation** for completion

### Final Reports
- **Excel files** with complete results
- **JSON files** with detailed metadata
- **Success/failure summaries** with statistics

## 🔄 Best Practices

### 1. Regular Monitoring
- Check failed applications after each batch run
- Review error patterns for system improvements
- Monitor retry success rates

### 2. Configuration Optimization
- Adjust retry attempts based on failure types
- Optimize worker count for your system
- Set appropriate delays to avoid rate limiting

### 3. Error Analysis
- Regularly analyze failure reasons
- Update application numbers if needed
- Monitor system resources during processing

### 4. Backup and Recovery
- Keep copies of successful results
- Archive failed applications for later analysis
- Document retry strategies for different error types 