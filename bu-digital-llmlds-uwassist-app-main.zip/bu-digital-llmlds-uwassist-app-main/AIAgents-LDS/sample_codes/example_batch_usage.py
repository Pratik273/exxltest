#!/usr/bin/env python3
"""
Example script showing how to use the batch summary processing.
This demonstrates different ways to configure and run batch processing.
"""

import sys
import os
import uuid

# Add the project root to the path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from run_summaries_batch import run_batch_summary_pipeline

def example_1_basic_usage():
    """Example 1: Basic usage with a list of application numbers."""
    print("="*60)
    print("EXAMPLE 1: Basic Batch Processing")
    print("="*60)
    
    # Define your application numbers
    application_numbers = [
        "9218062",
        "9218063", 
        "9218064",
        # Add more as needed
    ]
    
    # Run the batch pipeline
    results = run_batch_summary_pipeline(
        application_numbers=application_numbers,
        session_id=str(uuid.uuid4()),
        user_id="batch_user_1",
        save_to_excel=True,
        save_json=False,
        excel_filename="example_1_results.xlsx"
    )
    
    print(f"Processed {len(results)} applications")
    return results


def example_2_with_retry_and_delays():
    """Example 2: Custom retry attempts and delays."""
    print("="*60)
    print("EXAMPLE 2: Custom Retry and Delay Settings")
    print("="*60)
    
    # Import the retry function
    from run_summaries_batch import run_single_application_with_retry
    
    application_numbers = [
        "9218065",
        "9218066",
    ]
    
    all_results = []
    
    for app_number in application_numbers:
        # Custom retry settings for each application
        result = run_single_application_with_retry(
            application_number=app_number,
            session_id=str(uuid.uuid4()),
            user_id="batch_user_2",
            max_retries=5  # More retry attempts
        )
        all_results.append(result)
    
    # Save to Excel
    from run_summaries_batch import save_to_excel
    save_to_excel(all_results, "example_2_results.xlsx")
    
    return all_results


def example_3_from_file():
    """Example 3: Load application numbers from a file."""
    print("="*60)
    print("EXAMPLE 3: Load Application Numbers from File")
    print("="*60)
    
    # Create a sample file with application numbers
    sample_file = "application_numbers.txt"
    with open(sample_file, "w") as f:
        f.write("9218067\n")
        f.write("9218068\n")
        f.write("9218069\n")
        f.write("# This is a comment\n")
        f.write("9218070\n")
    
    # Read application numbers from file
    application_numbers = []
    with open(sample_file, "r") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                application_numbers.append(line)
    
    print(f"Loaded {len(application_numbers)} application numbers from file")
    
    # Run batch processing
    results = run_batch_summary_pipeline(
        application_numbers=application_numbers,
        session_id=str(uuid.uuid4()),
        user_id="batch_user_3",
        save_to_excel=True,
        excel_filename="example_3_results.xlsx"
    )
    
    # Clean up sample file
    os.remove(sample_file)
    
    return results


def example_4_selective_processing():
    """Example 4: Process only specific applications based on conditions."""
    print("="*60)
    print("EXAMPLE 4: Selective Processing")
    print("="*60)
    
    # All available application numbers
    all_apps = [
        "9218071", "9218072", "9218073", "9218074", "9218075",
        "9218076", "9218077", "9218078", "9218079", "9218080"
    ]
    
    # Filter applications (example: only even numbers)
    selected_apps = [app for app in all_apps if int(app) % 2 == 0]
    
    print(f"All applications: {all_apps}")
    print(f"Selected applications (even numbers): {selected_apps}")
    
    # Process only selected applications
    results = run_batch_summary_pipeline(
        application_numbers=selected_apps,
        session_id=str(uuid.uuid4()),
        user_id="batch_user_4",
        save_to_excel=True,
        excel_filename="example_4_even_apps.xlsx"
    )
    
    return results


def main():
    """Run all examples."""
    print("BATCH PROCESSING EXAMPLES")
    print("="*80)
    
    # Uncomment the example you want to run:
    
    # Example 1: Basic usage
    # example_1_basic_usage()
    
    # Example 2: Custom retry settings
    # example_2_with_retry_and_delays()
    
    # Example 3: Load from file
    # example_3_from_file()
    
    # Example 4: Selective processing
    # example_4_selective_processing()
    
    print("\nTo run an example, uncomment the desired function call above.")
    print("Make sure to update the application numbers with valid ones from your system.")


if __name__ == "__main__":
    main() 