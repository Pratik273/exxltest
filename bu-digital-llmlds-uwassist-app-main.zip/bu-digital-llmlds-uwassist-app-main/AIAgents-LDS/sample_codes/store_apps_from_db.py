import os
import sys
import json
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from scripts.database.check_db_conn import connect_to_db
from loguru import logger

cur, conn = connect_to_db()
query = """
SELECT application_id, raw_content
FROM documents
WHERE application_id IN (
    SELECT application_id
    FROM documents
    GROUP BY application_id
    ORDER BY application_id
    LIMIT 1000
)
ORDER BY application_id;
"""
cur.execute(query)
conn.commit()
rows = cur.fetchall()


apps = {}
for app_id, raw_content in rows:
    apps.setdefault(app_id, []).append(raw_content)

# Convert to JSON array
json_data = [
    {"application_id": app_id, "documents": docs}
    for app_id, docs in apps.items()
]

# Write to file
with open("data_sources/lds_1000_apps.json", "w", encoding="utf-8") as f:
    json.dump(json_data, f, indent=2)
