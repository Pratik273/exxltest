import os
import uuid
from loguru import logger
import pandas as pd
import sys
import math
import traceback
import json
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from agents.workflow import graph
from agents.dataset_workflow import dataset_graph
from agents.state import AgentState

# Configure Loguru to only show INFO and higher
logger.remove()
logger.add(sys.stdout, level="INFO")

# Global locks for thread-safe operations
excel_lock = threading.Lock()
error_lock = threading.Lock()


def process_faqs_for_sheet(app_number, questions_df):
    """Process FAQs for a specific application and return results in a DataFrame format 
    suitable for writing to an Excel sheet.
    
    Args:
        app_number: The application number to process
        questions_df: DataFrame containing questions
        
    Returns:
        A tuple containing:
        - DataFrame with columns Question, Thought, Answer, Confidence
        - A list of errors encountered during processing.
    """
    logger.info(f"Starting processing for application: {app_number}")
    
    session_id = str(uuid.uuid4())
    user_id = "user_123"
    
    # Create a copy of questions for this application
    questions_to_process = questions_df.copy()
    
    # Initialize the results dataframe with the questions
    results_df = pd.DataFrame({
        'Question': questions_to_process['Qn'],
        'Thought': [""] * len(questions_to_process),
        'Answer': [""] * len(questions_to_process),
        'Confidence': [0] * len(questions_to_process)
    })

    errors = []
    
    # Process each question sequentially within this application
    for i, row_data in enumerate(questions_to_process.iterrows()):
        idx, row = row_data
        question = row.get('Qn', '')
        if not question:
            continue
            
        logger.info(f"App {app_number}: Processing question {i+1}/{len(questions_to_process)}")
        
        # Create conversation app_state
        app_state = AgentState()
        app_state.application_number = app_number
        app_state.input_message = question
        app_state.session_id = session_id
        app_state.user_id = user_id
        
        # Run the workflow
        try:
            thought, answer, confidence = None, None, 0
            answer_generated = False  # Flag to track if an answer was generated
            
            for output in dataset_graph.stream(app_state):
                for value in output.values():
                    app_state.current_step = value.get("current_step", None)
                    if app_state.current_step == "Reasoning & Refining the answer":
                        thought = value.get('ai_thought', None)
                        logger.debug(f"App {app_number} - Thought: {thought}")
                        answer = value.get('ai_response', None)
                        confidence = value.get('confidence_score', None)
                        logger.debug(f"App {app_number} - Raw confidence score: {confidence}")
            
                        if thought is not None and answer is not None:
                            # Process confidence score
                            processed_confidence = 0
                            if isinstance(confidence, str):
                                try:
                                    # Remove '%' and convert to integer
                                    processed_confidence = int(float(confidence.strip().replace('%', '')))
                                except (ValueError, TypeError):
                                    # If conversion fails, default to 0
                                    processed_confidence = 0
                            elif isinstance(confidence, (int, float)):
                                processed_confidence = int(confidence)
                            
                            # Update row with results for this application
                            results_df.at[idx, 'Thought'] = thought
                            results_df.at[idx, 'Answer'] = answer
                            results_df.at[idx, 'Confidence'] = processed_confidence
                            answer_generated = True
                        
            # After the stream, check if an answer was ever generated
            if not answer_generated:
                errors.append({
                    "app_number": app_number,
                    "question": question,
                    "error": "Agent did not produce a valid thought and answer."
                })

            # Pause to avoid rate limiting
            time.sleep(1)
            
        except Exception as e:
            logger.error(f"Error processing question for app {app_number}: '{question}'")
            logger.error(f"Current enumerate index 'i': {i}, DataFrame index 'idx': {idx}")
            logger.error(f"Error details: {e}")
            traceback.print_exc()
            errors.append({"app_number": app_number, "question": question, "error": str(e)})
    
    logger.info(f"Completed processing for application {app_number}: {len(results_df)} questions processed")
    return results_df, errors


def write_application_results(app_number, app_data, output_path, excel_path):
    """Thread-safe function to write application results to Excel file."""
    with excel_lock:
        try:
            # Check if file exists to determine mode
            mode = 'a' if os.path.exists(output_path) else 'w'
            
            # For append mode, we need to load existing workbook
            if mode == 'a':
                from openpyxl import load_workbook
                try:
                    book = load_workbook(output_path)
                    with pd.ExcelWriter(output_path, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
                        writer.book = book
                        # Limit sheet name length (Excel has a 31 character limit)
                        sheet_name = f"{app_number}"[:31]
                        app_data.to_excel(writer, sheet_name=sheet_name, index=False)
                except Exception as e:
                    logger.warning(f"Error appending to existing file, creating new file: {e}")
                    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                        sheet_name = f"{app_number}"[:31]
                        app_data.to_excel(writer, sheet_name=sheet_name, index=False)
            else:
                with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                    sheet_name = f"{app_number}"[:31]
                    app_data.to_excel(writer, sheet_name=sheet_name, index=False)
            
            logger.info(f"Results for application {app_number} successfully saved to {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error saving results for application {app_number}: {e}")
            
            # Fallback save for this application
            backup_path = os.path.join(os.path.dirname(excel_path), f'FAQs_Results_{app_number}_backup.xlsx')
            
            try:
                with pd.ExcelWriter(backup_path, engine='openpyxl') as writer:
                    sheet_name = f"App_{app_number}"[:31]
                    app_data.to_excel(writer, sheet_name=sheet_name, index=False)
                logger.info(f"Results for application {app_number} saved to backup file: {backup_path}")
                return True
            except Exception as backup_err:
                logger.error(f"Error saving backup file for application {app_number}: {backup_err}")
                return False


def log_errors_thread_safe(app_errors, error_file_path, app_number):
    """Thread-safe function to log errors."""
    if not app_errors:
        return
        
    with error_lock:
        try:
            # Read existing errors
            if os.path.exists(error_file_path):
                with open(error_file_path, 'r') as f:
                    all_errors_list = json.load(f)
            else:
                all_errors_list = []
            
            # Append new errors
            all_errors_list.extend(app_errors)
            
            # Write back to file
            with open(error_file_path, 'w') as f:
                json.dump(all_errors_list, f, indent=4)
            
            logger.info(f"Logged {len(app_errors)} error(s) for application {app_number}")
            
        except Exception as e:
            logger.error(f"Failed to update error log for {app_number}: {e}")


def process_single_application(app_folder, questions_df, output_path, error_file_path, excel_path):
    """Process a single application - wrapper function for parallel execution."""
    if app_folder == "9218559":  # Skip this specific application
        logger.info(f"Skipping application {app_folder} as requested")
        return f"Skipped application {app_folder}"
    
    try:
        logger.info(f"Processing application: {app_folder}")
        
        # Process this application with the questions dataframe
        app_data, app_errors = process_faqs_for_sheet(app_folder, questions_df)
        
        # Log errors in a thread-safe manner
        if app_errors:
            log_errors_thread_safe(app_errors, error_file_path, app_folder)
        
        # Write results in a thread-safe manner
        if app_data is not None:
            success = write_application_results(app_folder, app_data, output_path, excel_path)
            if success:
                return f"Successfully processed application {app_folder}"
            else:
                return f"Failed to save results for application {app_folder}"
        else:
            return f"No data generated for application {app_folder}"
            
    except Exception as e:
        logger.error(f"Error processing application {app_folder}: {e}")
        traceback.print_exc()
        return f"Error processing application {app_folder}: {e}"


def process_all_applications_parallel(max_workers=6):
    """Process FAQs for all applications using parallel execution."""
    
    prod_samples_dir = "data_sources_new"
    if not os.path.exists(prod_samples_dir):
        logger.error(f"Directory {prod_samples_dir} does not exist")
        sys.exit(1)

    # List all directories in the prod_samples directory
    application_folders = []
    for item_name in sorted(os.listdir(prod_samples_dir)):
        item_path = os.path.join(prod_samples_dir, item_name)
        if os.path.isdir(item_path):
            application_folders.append(item_name)
    
    logger.info(f"Found {len(application_folders)} application folders: {application_folders}")
    
    # First load the questions
    excel_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                           'data_sources', 'FAQs_Division_2.xlsx')
    sheet_name = 'FAQs'
    try:
        # Read questions from Excel
        questions_df = pd.read_excel(excel_path, sheet_name=sheet_name, header=1)
        logger.info(f"Successfully loaded {len(questions_df)} questions from Excel file.")
    except Exception as e:
        logger.error(f"Error reading Excel file: {e}")
        return
    
    # Create output paths
    output_path = os.path.join(os.path.dirname(excel_path), 'FAQs_Results_By_Application_Parallel.xlsx')
    error_file_path = os.path.join(os.path.dirname(excel_path), 'FAQs_Errors_Parallel.json')

    # Clear/initialize the error log at the start of the run
    with open(error_file_path, 'w') as f:
        json.dump([], f, indent=4)
    
    # Remove output file if it exists to start fresh
    if os.path.exists(output_path):
        os.remove(output_path)
    
    # Process applications starting from index 2 (as in original code)
    applications_to_process = application_folders[2:]
    
    logger.info(f"Starting parallel processing of {len(applications_to_process)} applications with {max_workers} workers")
    
    # Use ThreadPoolExecutor for parallel processing
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all applications for processing
        future_to_app = {
            executor.submit(
                process_single_application, 
                app_folder, 
                questions_df.copy(),  # Pass a copy to avoid sharing issues
                output_path, 
                error_file_path, 
                excel_path
            ): app_folder 
            for app_folder in applications_to_process
        }
        
        # Process completed futures
        completed_count = 0
        for future in as_completed(future_to_app):
            app_folder = future_to_app[future]
            try:
                result = future.result()
                completed_count += 1
                logger.info(f"[{completed_count}/{len(applications_to_process)}] {result}")
            except Exception as exc:
                completed_count += 1
                logger.error(f"[{completed_count}/{len(applications_to_process)}] Application {app_folder} generated an exception: {exc}")
    
    logger.info("Parallel processing of all applications completed.")


if __name__ == "__main__":
    start_time = time.time()
    
    # Use 6 workers to leave some CPU headroom (out of 8 vCPUs)
    # You can adjust this based on your system's performance
    max_workers = 6
    
    logger.info(f"Starting parallel dataset generation with {max_workers} workers")
    process_all_applications_parallel(max_workers=max_workers)
    
    end_time = time.time()

    # --- Calculate and format the total execution time ---
    elapsed_seconds = end_time - start_time
    hours, rem = divmod(elapsed_seconds, 3600)
    minutes, seconds = divmod(rem, 60)

    # Create a beautiful, human-readable time string
    time_parts = []
    if hours > 0:
        time_parts.append(f"{int(hours)} hour{'s' if int(hours) != 1 else ''}")
    if minutes > 0:
        time_parts.append(f"{int(minutes)} minute{'s' if int(minutes) != 1 else ''}")
    # Only show seconds if the total time is less than a minute, or if there are seconds to report.
    if elapsed_seconds < 60 or seconds > 0:
        time_parts.append(f"{int(seconds)} second{'s' if int(seconds) != 1 else ''}")
    
    if not time_parts:
        beautiful_time_str = "less than a second"
    else:
        beautiful_time_str = " and ".join(filter(None, [", ".join(time_parts[:-1]), time_parts[-1]]))

    # --- Log the final, beautified output ---
    logger.info("=" * 60)
    logger.info("🎉 All parallel tasks completed!")
    logger.info(f"⏱️  Total Time Taken: {beautiful_time_str}")
    logger.info(f"🚀 Processed with {max_workers} parallel workers")
    logger.info("=" * 60) 