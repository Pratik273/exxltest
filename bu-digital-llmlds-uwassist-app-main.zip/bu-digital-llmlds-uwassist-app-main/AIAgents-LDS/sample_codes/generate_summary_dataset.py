import os
import sys
import asyncio
import uuid
import time
from loguru import logger
from dotenv import load_dotenv
import traceback
import pandas as pd
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from agents.dataset_workflow import dataset_graph
from agents.state import AgentState
# ...existing imports and code...

async def get_summary_for_app(question, application_number):
    session_id = str(uuid.uuid4())
    user_id = "user_test"
    app_state = AgentState()
    app_state.application_number = application_number
    app_state.input_message = question
    app_state.session_id = session_id
    app_state.user_id = user_id

    try:
        answer, confidence = None, 0
        for output in dataset_graph.stream(app_state):
            for value in output.values():
                if value.get("current_step", None) == "Reasoning & Refining the answer":
                    answer = value.get('ai_response', None)
                    #thought = value.get('ai_thought', None)
                    confidence = value.get('confidence_score', None)
        time.sleep(1)
        return {"Answer": answer, "Confidence_Score": confidence}
    except Exception as e:
        print(f"Error for app {application_number}: {e}")
        return {"Answer": answer, "Confidence_Score": confidence}

async def main():
    summary_prompt = "Write a summary on the medical and lifestyle history of the applicant, especially if any concerning prescription, diagnosis, lab results etc"
    #application_numbers = ["9217523", "9217639", "9217744"]  # Add more as needed
    application_numbers = [
    "9217523",
    "9217639",
    "9217744",
    "9217937",
    "9217938",
    "9218062",
    "9218159",
    "9222406",
    "9222517",
    "9230523"
    ]

    data = {}
    for app_num in application_numbers:
        result = await get_summary_for_app(summary_prompt, app_num)
        data[app_num] = result

    # Create DataFrame: one row, columns are application numbers, cells are dicts
    df = pd.DataFrame([data], index=[summary_prompt])
    df.index.name = "Summary Prompt"
    df.to_excel("sectional_summaries_10.xlsx")

if __name__ == "__main__":
    asyncio.run(main())