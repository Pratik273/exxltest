#!/usr/bin/env python3
"""
Simple script to run both summaries (demographics + medical) and then overall summary.
Configure the variables below and run the script.
"""

import sys
import os
import json
import uuid
from loguru import logger
import traceback
import time

# Add the project root to the path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from agents.summary_workflow import (
    create_demographics_workflow,
    create_medical_workflow, 
    create_overall_summary_workflow
)
from agents.state import AgentState
from utils.summary_parser import (
    parse_summary_sections,
    validate_required_sections,
    combine_demographics_and_medical_summaries,
    get_section_names
)

# =============================================================================
# CONFIGURATION VARIABLES - MODIFY THESE AS NEEDED
# =============================================================================

# Application details
APPLICATION_NUMBER = "9218062"  # Change this to your application number
SESSION_ID = str(uuid.uuid4())      # Change this to your session ID
USER_ID = "user_test"             # Change this to your user ID

# Options
SAVE_TO_FILE = True               # Set to False if you don't want to save results to file

# =============================================================================


def run_demographics_summary(application_number: str, session_id: str = None, user_id: str = None):
    """Run demographics summary workflow."""
    logger.info(f"Starting demographics summary for application {application_number}")
    
    app_state = AgentState(
        input_message="Write a summary on demographics, MVR, Miscellaneous and Additional Notes section.",
        application_number=application_number,
        session_id=session_id or "demo_session",
        user_id=user_id or "demo_user"
    )
    
    thought, answer, confidence = None, None, 0
    demographics_graph = create_demographics_workflow()
    try:
        
        for output in demographics_graph.stream(app_state):
            for value in output.values():
                app_state.current_step = value.get("current_step", None)
                if app_state.current_step == "Reasoning & Refining the answer":
                    thought = value.get('ai_thought', None)
                    logger.info(f"Thought: {thought}")
                    answer = value.get('ai_response', None)
                    logger.info(f"Answer: {answer}")
                    confidence = value.get('confidence_score', None)
                    logger.info(f"Confidence score: {confidence}")
        
               
                    
        # Pause to avoid rate limiting
        time.sleep(1)
        
    except Exception as e:
        print(f"Error processing question for app {application_number}")
        # print(f"Current enumerate index 'i': {i}, DataFrame index 'idx': {idx}")
        print(f"Error details: {e}")
        traceback.print_exc()
    
    logger.info("Demographics summary completed")
    return answer


def run_medical_summary(application_number: str, session_id: str = None, user_id: str = None):
    """Run medical summary workflow."""
    logger.info(f"Starting medical summary for application {application_number}")
    
    app_state = AgentState(
        input_message="Write a summary on Physical Metrics, Medical History, Substance Use and Additional Notes section.",
        application_number=application_number,
        session_id=session_id or "demo_session", 
        user_id=user_id or "demo_user"
    )
    thought, answer, confidence = None, None, 0
    medical_graph = create_medical_workflow()
    try:
        
        for output in medical_graph.stream(app_state):
            for value in output.values():
                app_state.current_step = value.get("current_step", None)
                if app_state.current_step == "Reasoning & Refining the answer":
                    thought = value.get('ai_thought', None)
                    logger.info(f"Thought: {thought}")
                    answer = value.get('ai_response', None)
                    logger.info(f"Answer: {answer}")
                    confidence = value.get('confidence_score', None)
                    logger.info(f"Confidence score: {confidence}")
        
               
                    
        # Pause to avoid rate limiting
        time.sleep(1)
        
    except Exception as e:
        print(f"Error processing question for app {application_number}")
        # print(f"Current enumerate index 'i': {i}, DataFrame index 'idx': {idx}")
        print(f"Error details: {e}")
        traceback.print_exc()
    
    logger.info("Medical summary completed")
    return answer


def run_overall_summary(demographics_summary: str, medical_summary: str, application_number: str, session_id: str = None, user_id: str = None):
    """Run overall summary using parsing-based combination (no LLM call)."""
    logger.info("Starting overall summary using parsing-based combination")
    
    try:
        # Validate demographics summary sections
        demographics_sections = parse_summary_sections(demographics_summary)
        demographics_expected = ["Demographics", "MVR", "Miscellaneous", "Additional Notes"]
        demo_valid, demo_missing = validate_required_sections(demographics_sections, demographics_expected)
        
        if not demo_valid:
            logger.warning(f"Demographics summary validation failed. Missing sections: {demo_missing}")
            logger.warning("Available sections: " + str(get_section_names(demographics_summary)))
        else:
            logger.info("Demographics summary validation passed")
        
        # Validate medical summary sections
        medical_sections = parse_summary_sections(medical_summary)
        medical_expected = ["Physical Metrics", "Medical History", "Substance Use", "Miscellaneous", "Additional Notes"]
        medical_valid, medical_missing = validate_required_sections(medical_sections, medical_expected)
        
        if not medical_valid:
            logger.warning(f"Medical summary validation failed. Missing sections: {medical_missing}")
            logger.warning("Available sections: " + str(get_section_names(medical_summary)))
        else:
            logger.info("Medical summary validation passed")
        
        # Combine the summaries using parsing
        combined_summary = combine_demographics_and_medical_summaries(demographics_summary, medical_summary)
        
        logger.info("Overall summary completed using parsing-based combination")
        logger.info(f"Combined summary: {combined_summary}")
        return combined_summary
        
    except Exception as e:
        logger.error(f"Error in parsing-based overall summary for app {application_number}")
        logger.error(f"Error details: {e}")
        traceback.print_exc()
        
        # Fallback: return simple concatenation if parsing fails
        logger.info("Falling back to simple concatenation of summaries")
        fallback_summary = f"""
Demographics Summary:
{demographics_summary}

Medical Summary:
{medical_summary}
"""
        return fallback_summary


def save_results(application_number: str, results: dict):
    """Save results to a JSON file."""
    filename = f"summary_results_{application_number}.json"
    with open(filename, "w") as f:
        json.dump(results, f, indent=2)
    logger.info(f"Results saved to {filename}")


def run_complete_summary_pipeline(application_number: str, session_id: str = None, user_id: str = None, save_to_file: bool = True):
    """
    Run the complete pipeline: demographics -> medical -> overall summary.
    Always runs all three steps in sequence.
    """
    logger.info(f"Starting complete summary pipeline for application {application_number}")
    
    try:
        # Step 1: Run demographics summary
        print("\n" + "="*60)
        print("STEP 1: RUNNING DEMOGRAPHICS SUMMARY")
        print("="*60)
        demographics_result = run_demographics_summary(application_number, session_id, user_id)
        print(f"\nDemographics Summary:\n{demographics_result}\n")
        
        # Step 2: Run medical summary
        print("\n" + "="*60)
        print("STEP 2: RUNNING MEDICAL SUMMARY")
        print("="*60)
        medical_result = run_medical_summary(application_number, session_id, user_id)
        print(f"\nMedical Summary:\n{medical_result}\n")
        
        # Step 3: Run overall summary (using parsing-based combination)
        print("\n" + "="*60)
        print("STEP 3: RUNNING OVERALL SUMMARY (PARSING-BASED)")
        print("="*60)
        overall_result = run_overall_summary(
            demographics_result,
            medical_result,
            application_number, session_id, user_id
        )
        print(f"\nOverall Summary:\n{overall_result}\n")
        
        # Prepare results
        results = {
            "demographics_summary": demographics_result,
            "medical_summary": medical_result,
            "overall_summary": overall_result,
            "application_number": application_number,
            "session_id": session_id or "demo_session",
            "user_id": user_id or "demo_user"
        }
        
        # Save results if requested
        if save_to_file:
            save_results(application_number, results)
        
        # Print final summary
        print("\n" + "="*60)
        print("SUMMARY PIPELINE COMPLETED SUCCESSFULLY")
        print("="*60)
        print(f"Application Number: {application_number}")
        print(f"Session ID: {session_id or 'demo_session'}")
        print(f"User ID: {user_id or 'demo_user'}")
        if save_to_file:
            print(f"Results saved to: summary_results_{application_number}.json")
        print("="*60)
        
        return results
        
    except Exception as e:
        logger.error(f"Error in summary pipeline: {e}")
        print(f"\n❌ Error occurred: {e}")
        raise


def main():
    """
    Main function - uses the configuration variables defined at the top.
    """
    print("="*60)
    print("SUMMARY PIPELINE RUNNER")
    print("="*60)
    print(f"Application Number: {APPLICATION_NUMBER}")
    print(f"Session ID: {SESSION_ID}")
    print(f"User ID: {USER_ID}")
    print(f"Save to file: {SAVE_TO_FILE}")
    print("="*60)
    
    try:
        results = run_complete_summary_pipeline(
            APPLICATION_NUMBER, 
            SESSION_ID, 
            USER_ID, 
            SAVE_TO_FILE
        )
        print("\n✅ All summaries completed successfully!")
        
    except Exception as e:
        logger.error(f"Pipeline failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main() 