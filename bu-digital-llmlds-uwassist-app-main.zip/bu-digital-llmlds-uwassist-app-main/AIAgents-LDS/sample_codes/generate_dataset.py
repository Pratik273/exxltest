import os
import uuid
from loguru import logger
import pandas as pd
import sys
import math
import traceback
import json
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from agents.workflow import graph
from agents.dataset_workflow import dataset_graph
from agents.state import AgentState
import time


# Configure Loguru to only show INFO and higher
logger.remove()
logger.add(sys.stdout, level="INFO")


def process_faqs_for_sheet(app_number, questions_df=None):
    """Process FAQs for a specific application and return results in a DataFrame format 
    suitable for writing to an Excel sheet.
    
    Args:
        app_number: The application number to process
        questions_df: DataFrame containing questions (if None, will read from Excel)
        
    Returns:
        A tuple containing:
        - DataFrame with columns Question, Thought, Answer, Confidence
        - A list of errors encountered during processing.
    """
    # Path to the Excel file
    excel_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                             'data_sources', 'FAQs_Division_2.xlsx')
    
    # If questions_df not provided, read from Excel
    if questions_df is None:
        # Read the Excel file
        sheet_name = 'FAQs'
        try:
            questions_df = pd.read_excel(excel_path, sheet_name=sheet_name, header=1)  # Start reading from row 2
            print(f"Successfully loaded {len(questions_df)} questions from Excel file.")
        except Exception as e:
            print(f"Error reading Excel file: {e}")
            return None, []
    
    # Ensure we have the Question column
    if 'Qn' not in questions_df.columns:
        print("Error: 'Question' column not found in Excel file.")
        return None, []
    
    session_id = str(uuid.uuid4())
    user_id = "user_123"
    
    # Create a dataframe for this app's results
    # Only use the first 5 questions
    # questions_to_process = questions_df.head(1).copy()
    questions_to_process = questions_df.copy()
    
    # Initialize the results dataframe with the questions
    results_df = pd.DataFrame({
        'Question': questions_to_process['Qn'],
        'Thought': [""] * len(questions_to_process),
        'Answer': [""] * len(questions_to_process),
        'Confidence': [0] * len(questions_to_process)
    })

    errors = []
    # Process each question
    for i, row_data in enumerate(questions_to_process.iterrows()):
        idx, row = row_data
        question = row.get('Qn', '')
        if not question:
            continue
        logger.info(f"Processing application {app_number}, question_number: {i}")
        # print(f"Processing application {app_number}, question: {question}")
        
        # Create conversation app_state
        app_state = AgentState()
        app_state.application_number = app_number
        app_state.input_message = question
        app_state.session_id = session_id
        app_state.user_id = user_id
        
        # Run the workflow
        try:
            thought, answer, confidence = None, None, 0
            answer_generated = False  # Flag to track if an answer was generated
            for output in dataset_graph.stream(app_state):
                for value in output.values():
                    app_state.current_step = value.get("current_step", None)
                    if app_state.current_step == "Reasoning & Refining the answer":
                        thought = value.get('ai_thought', None)
                        logger.debug(f"Thought: {thought}")
                        answer = value.get('ai_response', None)
                        confidence = value.get('confidence_score', None)
                        logger.debug(f"Raw confidence score: {confidence}")
            
                        if thought is not None and answer is not None:
                            # Process confidence score
                            processed_confidence = 0
                            if isinstance(confidence, str):
                                try:
                                    # Remove '%' and convert to integer
                                    processed_confidence = int(float(confidence.strip().replace('%', '')))
                                except (ValueError, TypeError):
                                    # If conversion fails, default to 0
                                    processed_confidence = 0
                            elif isinstance(confidence, (int, float)):
                                processed_confidence = int(confidence)
                            
                            # Update row with results for this application
                            results_df.at[idx, 'Thought'] = thought
                            results_df.at[idx, 'Answer'] = answer
                            results_df.at[idx, 'Confidence'] = processed_confidence
                            answer_generated = True
                        
            # After the stream, check if an answer was ever generated
            if not answer_generated:
                errors.append({
                    "app_number": app_number,
                    "question": question,
                    "error": "Agent did not produce a valid thought and answer."
                })

            # Pause to avoid rate limiting
            time.sleep(1)
            
        except Exception as e:
            print(f"Error processing question for app {app_number}: '{question}'")
            print(f"Current enumerate index 'i': {i}, DataFrame index 'idx': {idx}")
            print(f"Error details: {e}")
            traceback.print_exc()
            errors.append({"app_number": app_number, "question": question, "error": str(e)})
    
    logger.info(f"Final results: {results_df}")
    # Return the results DataFrame
    return results_df, errors


def process_all_applications():
    """Process FAQs for all applications and create a separate sheet for each application."""
    application_folders = ["9222517"]
    # "9217639", "9217744", "9217937", "9217938", "9218062", "9218159", "9222406", "9222517","9230523"    
    
    # prod_samples_dir = "data_sources_new"
    # if not os.path.exists(prod_samples_dir):
    #     print(f"Directory {prod_samples_dir} does not exist")
    #     sys.exit(1)

    # # # List all directories in the prod_samples directory
    # application_folders = []
    # for item_name in sorted(os.listdir(prod_samples_dir)):
    #     item_path = os.path.join(prod_samples_dir, item_name)
    #     if os.path.isdir(item_path):
    #         application_folders.append(item_name)
    
    
    print(f"Found {len(application_folders)} application folders: {application_folders}")
    
    # First load the questions
    excel_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                           'data_sources', 'FAQs_Division_2.xlsx')
    sheet_name = 'FAQs'
    try:
        # Read questions from Excel
        questions_df = pd.read_excel(excel_path, sheet_name=sheet_name, header=1)
        print(f"Successfully loaded {len(questions_df)} questions from Excel file.")
    except Exception as e:
        print(f"Error reading Excel file: {e}")
        return
    
    # Create an output Excel file with a sheet for each application
    output_path = os.path.join(os.path.dirname(excel_path), 'FAQs_Results_By_Application.xlsx')
    error_file_path = os.path.join(os.path.dirname(excel_path), 'FAQs_Errors.json')

    # Clear/initialize the error log at the start of the run
    with open(error_file_path, 'w') as f:
        json.dump([], f, indent=4)
    
    # Process each application and save results immediately
    for app_folder in application_folders[2:]:
        # if app_folder == "9218559":
        #     continue
        print(f"Processing application: {app_folder}")
        
        # Process this application with the questions dataframe
        app_data, app_errors = process_faqs_for_sheet(app_folder, questions_df)

        if app_errors:
            try:
                # Read the entire log file
                with open(error_file_path, 'r') as f:
                    all_errors_list = json.load(f)
                
                # Append the new errors
                all_errors_list.extend(app_errors)
                
                # Write the whole thing back
                with open(error_file_path, 'w') as f:
                    json.dump(all_errors_list, f, indent=4)
                print(f"Logged {len(app_errors)} error(s) for application {app_folder}.")
            except Exception as e:
                print(f"Failed to update error log for {app_folder}: {e}")
        
        if app_data is not None:
            try:
                # Check if file exists to determine mode
                mode = 'a' if os.path.exists(output_path) else 'w'
                with pd.ExcelWriter(output_path, engine='openpyxl', mode=mode) as writer:
                    # Limit sheet name length (Excel has a 31 character limit)
                    sheet_name = f"{app_folder}"[:31]
                    
                    # Write the application data to its sheet
                    app_data.to_excel(writer, sheet_name=sheet_name, index=False)
                
                print(f"Results for application {app_folder} successfully saved to {output_path}")
                
            except Exception as e:
                print(f"Error saving results for application {app_folder}: {e}")
                
                # Fallback save for this application
                backup_path = os.path.join(os.path.dirname(excel_path), f'FAQs_Results_{app_folder}_backup.xlsx')
                
                try:
                    with pd.ExcelWriter(backup_path, engine='openpyxl') as writer:
                        sheet_name = f"App_{app_folder}"[:31]
                        app_data.to_excel(writer, sheet_name=sheet_name, index=False)
                    print(f"Results for application {app_folder} saved to backup file: {backup_path}")
                except Exception as backup_err:
                    print(f"Error saving backup file for application {app_folder}: {backup_err}")
                
        # break

    print("Processing of all applications completed.")


if __name__ == "__main__":
    start_time = time.time()
    process_all_applications()
    end_time = time.time()

    # --- Calculate and format the total execution time ---
    elapsed_seconds = end_time - start_time
    hours, rem = divmod(elapsed_seconds, 3600)
    minutes, seconds = divmod(rem, 60)

    # Create a beautiful, human-readable time string
    time_parts = []
    if hours > 0:
        time_parts.append(f"{int(hours)} hour{'s' if int(hours) != 1 else ''}")
    if minutes > 0:
        time_parts.append(f"{int(minutes)} minute{'s' if int(minutes) != 1 else ''}")
    # Only show seconds if the total time is less than a minute, or if there are seconds to report.
    if elapsed_seconds < 60 or seconds > 0:
        time_parts.append(f"{int(seconds)} second{'s' if int(seconds) != 1 else ''}")
    
    if not time_parts:
        beautiful_time_str = "less than a second"
    else:
        beautiful_time_str = " and ".join(filter(None, [", ".join(time_parts[:-1]), time_parts[-1]]))

    # --- Log the final, beautified output ---
    logger.info("=" * 60)
    logger.info("All tasks completed!")
    logger.info(f"Total Time Taken: {beautiful_time_str}")
    logger.info("=" * 60)
