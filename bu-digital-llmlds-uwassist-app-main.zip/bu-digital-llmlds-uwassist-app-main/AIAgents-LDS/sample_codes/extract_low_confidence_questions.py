import os
import sys
import pandas as pd
import json

# Usage: python extract_low_confidence_questions.py <application_number>
if len(sys.argv) != 2:
    print("Usage: python extract_low_confidence_questions.py <application_number>")
    sys.exit(1)

application_number = sys.argv[1]

# Path to the Excel file
excel_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                         'data_sources', 'FAQs_Results_By_Application.xlsx')

# Read all sheets
try:
    all_sheets = pd.read_excel(excel_path, sheet_name=None, engine='openpyxl')
except Exception as e:
    print(f"Error reading Excel file: {e}")
    sys.exit(1)

if application_number not in all_sheets:
    print(f"Application number {application_number} not found in Excel file.")
    sys.exit(1)

sheet_df = all_sheets[application_number]

# Normalize column names (strip spaces, lower)
sheet_df.columns = [str(col).strip().lower() for col in sheet_df.columns]

# Find the right column names
question_col = next((col for col in sheet_df.columns if 'question' in col), None)
confidence_col = next((col for col in sheet_df.columns if 'confidence' in col), None)

if not question_col or not confidence_col:
    print("Could not find required columns in the sheet.")
    sys.exit(1)

# Filter rows with confidence == 0
low_conf_df = sheet_df[sheet_df[confidence_col] == 0]

# Output as JSON list
questions_list = low_conf_df[question_col].dropna().tolist()

output = {
    "application_number": application_number,
    "low_confidence_questions": questions_list
}

print(json.dumps(output, indent=2)) 