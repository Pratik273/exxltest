import pandas as pd


def count_excel_sheets(excel_path):
    try:
        # Use pandas ExcelFile to get sheet names
        xls = pd.ExcelFile(excel_path)
        sheet_names = xls.sheet_names
        print(f"Number of sheets: {len(sheet_names)}")
        print("Sheet names:", sheet_names)
        # Write to samples_processed.txt, appending if it exists
        with open("samples_processed.txt", "a") as f:
            f.write(f"Excel file: {excel_path}\n")
            f.write(f"Sheet names: {sheet_names}\n\n")
    except Exception as e:
        print(f"Error reading Excel file: {e}")


def main():
    # Set your Excel file path here
    excel_path = "data_sources/FAQs_Results_By_Application_Multiprocessing_100_11.xlsx"  # <-- Replace with your file path
    count_excel_sheets(excel_path)


if __name__ == "__main__":
    main() 