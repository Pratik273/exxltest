import boto3
import os
import sys
import json
from dotenv import load_dotenv
from loguru import logger
import base64

logger.debug("Loading environment variables")
load_dotenv(override=True)

# Only do when running the file locally
# Initialize a session with the specified profile
# session = boto3.Session(profile_name='524390297261_AWS_UCI_524390297261_Developr_PS')
# bedrock_client = session.client('bedrock-runtime', region_name="us-east-1", verify=False)

bedrock_client = boto3.client('bedrock-runtime', region_name="us-east-1") # "us-west-2" "us-east-1"
# claude_sonnet_profile = os.environ['BrAipClaude35SonnetV2Cri']
# claude_sonnet_profile = os.environ['BrAipClaude35SonnetV2Cri_35_V2']
claude_sonnet_profile = os.environ['BrAipClaude37Sonnet']
messages = [
        {"role": "user", "content": "Be friendly and helpful"},
        {"role": "user", "content": "Hi, how are you?"}
    ]
    
logger.debug("Constructed messages for Claude")

payload = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 4096,  # Required parameter specifying the maximum number of tokens to generate
        "messages": messages
    }
    
logger.debug("Constructed payload for Bedrock:")

claude_sonnet_response = bedrock_client.invoke_model(body=json.dumps(payload), modelId=claude_sonnet_profile)
logger.debug("Invoked Claude model")
response_body = claude_sonnet_response["body"].read().decode('utf-8')
response_data = json.loads(response_body)
logger.debug(f"Received response: {response_data}")
    
print(response_data["content"][0]["text"])




# print(os.path.dirname(__file__))
# image_file = os.path.join(os.path.dirname(__file__), "F39414621/pages/page_1.png")
# print(image_file)

# with open(image_file, 'rb') as image_file:
#         encoded_image = base64.b64encode(image_file.read()).decode('utf-8')
#         logger.debug(f"Encoded image file {image_file.name} to base64")

# bedrock_client = boto3.client('bedrock-runtime', region_name="us-east-1")
# claude_sonnet_profile = os.environ['BrAipClaude35SonnetV2Cri']
# messages_image = [
#         {
#             "role": "user",
#             "content": [
#                 {
#                     "type": "image",
#                     "source": {
#                         "type": "base64",
#                         "media_type": "image/png",  # Adjust based on image type
#                         "data": encoded_image
#                     }
#                 },
#                 {
#                     "type": "text",
#                     "text": "what is this image?"
#                 }
#             ]
#         }
#     ]

    
# logger.debug("Constructed messages for Claude")

# payload = {
#         "anthropic_version": "bedrock-2023-05-31",
#         "max_tokens": 2084,
#         "temperature": 0.2,
#         "top_p": 0.7,
#         "top_k": 250,
#         "messages": messages_image
#     }
    
# logger.debug("Constructed payload for Bedrock:")

# claude_sonnet_response = bedrock_client.invoke_model(body=json.dumps(payload), modelId=claude_sonnet_profile)
# logger.debug("Invoked Claude model")
# response_body = claude_sonnet_response["body"].read().decode('utf-8')
# response_data = json.loads(response_body)
# logger.debug(f"Received response: {response_data}")

# print(response_data["content"][0]["text"])