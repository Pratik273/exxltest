#!/usr/bin/env python3
"""
Script to retry failed applications from a previous batch run.
This script reads the failed_applications.json file and retries only the failed applications.
"""

import sys
import os
import json
import uuid
from loguru import logger
import traceback
import time
import pandas as pd
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp

# Add the project root to the path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from agents.summary_workflow import (
    create_demographics_workflow,
    create_medical_workflow, 
    create_overall_summary_workflow
)
from agents.state import AgentState

# =============================================================================
# CONFIGURATION VARIABLES - MODIFY THESE AS NEEDED
# =============================================================================

# Retry configuration
FAILED_APPS_FILE = "failed_applications.json"  # File containing failed applications
RETRY_SESSION_ID = str(uuid.uuid4())           # New session ID for retry
RETRY_USER_ID = "retry_user"                   # User ID for retry

# Multiprocessing options
MAX_WORKERS = 3                                # Number of parallel processes for retry
RETRY_ATTEMPTS = 5                             # More retry attempts for failed apps
DELAY_BETWEEN_APPS = 2                         # Delay between applications

# Output options
SAVE_TO_EXCEL = True                           # Save retry results to Excel
RETRY_EXCEL_FILENAME = "retry_results.xlsx"    # Excel filename for retry results
SAVE_JSON_FILES = False                        # Save individual JSON files
SAVE_FAILED_APPS = True                        # Save failed applications to separate JSON file
SAVE_SUCCESSFUL_APPS = True                    # Save successful applications to separate JSON file

# =============================================================================


def load_failed_applications(filename: str = FAILED_APPS_FILE):
    """Load failed applications from JSON file."""
    try:
        with open(filename, 'r') as f:
            data = json.load(f)
        
        # Extract application numbers from failed applications
        failed_apps = data.get('failed_applications', [])
        application_numbers = [app['ApplicationNumber'] for app in failed_apps]
        
        print(f"📋 Loaded {len(application_numbers)} failed applications from {filename}")
        print(f"Failed applications: {application_numbers}")
        
        return application_numbers, failed_apps
        
    except FileNotFoundError:
        print(f"❌ Error: Failed applications file '{filename}' not found.")
        print("Make sure to run the batch processing first to generate this file.")
        return [], []
    except Exception as e:
        print(f"❌ Error loading failed applications: {e}")
        return [], []


def run_demographics_summary(application_number: str, session_id: str = None, user_id: str = None):
    """Run demographics summary workflow."""
    logger.info(f"Starting demographics summary for application {application_number}")
    
    app_state = AgentState(
        input_message="Write a summary on demographics, MVR, Miscellaneous and Additional Notes section.",
        application_number=application_number,
        session_id=session_id or "demo_session",
        user_id=user_id or "demo_user"
    )
    
    thought, answer, confidence = None, None, 0
    demographics_graph = create_demographics_workflow()
    try:
        
        for output in demographics_graph.stream(app_state):
            for value in output.values():
                app_state.current_step = value.get("current_step", None)
                if app_state.current_step == "Reasoning & Refining the answer":
                    thought = value.get('ai_thought', None)
                    logger.info(f"Thought: {thought}")
                    answer = value.get('ai_response', None)
                    logger.info(f"Answer: {answer}")
                    confidence = value.get('confidence_score', None)
                    logger.info(f"Confidence score: {confidence}")
        
        # Pause to avoid rate limiting
        time.sleep(1)
        
    except Exception as e:
        print(f"Error processing demographics for app {application_number}")
        print(f"Error details: {e}")
        traceback.print_exc()
        return None
    
    logger.info("Demographics summary completed")
    return answer


def run_medical_summary(application_number: str, session_id: str = None, user_id: str = None):
    """Run medical summary workflow."""
    logger.info(f"Starting medical summary for application {application_number}")
    
    app_state = AgentState(
        input_message="Write a summary on Physical Metrics, Medical History, Substance Use and Additional Notes section.",
        application_number=application_number,
        session_id=session_id or "demo_session", 
        user_id=user_id or "demo_user"
    )
    thought, answer, confidence = None, None, 0
    medical_graph = create_medical_workflow()
    try:
        
        for output in medical_graph.stream(app_state):
            for value in output.values():
                app_state.current_step = value.get("current_step", None)
                if app_state.current_step == "Reasoning & Refining the answer":
                    thought = value.get('ai_thought', None)
                    logger.info(f"Thought: {thought}")
                    answer = value.get('ai_response', None)
                    logger.info(f"Answer: {answer}")
                    confidence = value.get('confidence_score', None)
                    logger.info(f"Confidence score: {confidence}")
        
        # Pause to avoid rate limiting
        time.sleep(1)
        
    except Exception as e:
        print(f"Error processing medical for app {application_number}")
        print(f"Error details: {e}")
        traceback.print_exc()
        return None
    
    logger.info("Medical summary completed")
    return answer


def run_overall_summary(demographics_summary: str, medical_summary: str, application_number: str, session_id: str = None, user_id: str = None):
    """Run overall summary workflow using provided summaries."""
    logger.info("Starting overall summary")
    
    # Create state with stored summaries
    app_state = AgentState(
        demographics_summary=demographics_summary,
        medical_summary=medical_summary,
        application_number=application_number,
        session_id=session_id or "demo_session",
        user_id=user_id or "demo_user"
    )
    thought, answer, confidence = None, None, 0
    overall_graph = create_overall_summary_workflow()
    try:
        
        for output in overall_graph.stream(app_state):
            for value in output.values():
                app_state.current_step = value.get("current_step", None)
                if app_state.current_step == "Reasoning & Refining the answer":
                    thought = value.get('ai_thought', None)
                    logger.info(f"Thought: {thought}")
                    answer = value.get('ai_response', None)
                    logger.info(f"Answer: {answer}")
                    confidence = value.get('confidence_score', None)
                    logger.info(f"Confidence score: {confidence}")
        
        # Pause to avoid rate limiting
        time.sleep(1)
        
    except Exception as e:
        print(f"Error processing overall summary for app {application_number}")
        print(f"Error details: {e}")
        traceback.print_exc()
        return None
    
    logger.info("Overall summary completed")
    return answer


def run_single_application_with_retry(application_number: str, session_id: str = None, user_id: str = None, max_retries: int = 3):
    """Run complete summary pipeline for a single application with retry logic."""
    logger.info(f"Retrying application {application_number} (attempts: {max_retries})")
    
    for attempt in range(max_retries):
        try:
            print(f"\n{'='*60}")
            print(f"RETRYING APPLICATION: {application_number} (Attempt {attempt + 1}/{max_retries})")
            print(f"{'='*60}")
            
            # Step 1: Run demographics summary
            print(f"\n📋 Step 1: Demographics Summary for {application_number}")
            demographics_result = run_demographics_summary(application_number, session_id, user_id)
            
            if demographics_result is None:
                raise Exception("Demographics summary failed")
            
            # Step 2: Run medical summary
            print(f"\n🏥 Step 2: Medical Summary for {application_number}")
            medical_result = run_medical_summary(application_number, session_id, user_id)
            
            if medical_result is None:
                raise Exception("Medical summary failed")
            
            # Step 3: Run overall summary
            print(f"\n📊 Step 3: Overall Summary for {application_number}")
            overall_result = run_overall_summary(
                demographics_result,
                medical_result,
                application_number, session_id, user_id
            )
            
            if overall_result is None:
                raise Exception("Overall summary failed")
            
            # Success - return results
            return {
                "ApplicationNumber": application_number,
                "Demographics Summary": demographics_result,
                "Medical Summary": medical_result,
                "Overall Summary": overall_result,
                "Status": "Success",
                "Attempts": attempt + 1,
                "RetrySession": session_id
            }
            
        except Exception as e:
            logger.error(f"Retry attempt {attempt + 1} failed for application {application_number}: {e}")
            if attempt < max_retries - 1:
                print(f"⚠️  Retry attempt {attempt + 1} failed. Retrying in {DELAY_BETWEEN_APPS} seconds...")
                time.sleep(DELAY_BETWEEN_APPS)
            else:
                print(f"❌ All retry attempts failed for application {application_number}")
                return {
                    "ApplicationNumber": application_number,
                    "Demographics Summary": None,
                    "Medical Summary": None,
                    "Overall Summary": None,
                    "Status": f"Failed after {max_retries} retry attempts: {str(e)}",
                    "Attempts": max_retries,
                    "RetrySession": session_id
                }


def process_application_worker(args):
    """Worker function for multiprocessing - processes a single application."""
    application_number, session_id, user_id, max_retries = args
    
    # Set up process-specific logging
    worker_name = mp.current_process().name
    print(f"🚀 Worker {worker_name} retrying application {application_number}")
    
    try:
        result = run_single_application_with_retry(
            application_number, session_id, user_id, max_retries
        )
        print(f"✅ Worker {worker_name} completed retry for application {application_number}")
        return result
    except Exception as e:
        print(f"❌ Worker {worker_name} failed on retry for application {application_number}: {e}")
        return {
            "ApplicationNumber": application_number,
            "Demographics Summary": None,
            "Medical Summary": None,
            "Overall Summary": None,
            "Status": f"Worker retry failed: {str(e)}",
            "Attempts": 0,
            "RetrySession": session_id,
            "Worker": worker_name
        }


def save_failed_applications_json(failed_results: list, filename: str = "retry_failed_applications.json"):
    """Save failed application results to a separate JSON file."""
    if not failed_results:
        logger.info("No failed applications to save")
        return
    
    # Add metadata to failed applications file
    failed_data = {
        "metadata": {
            "total_failed": len(failed_results),
            "timestamp": datetime.now().isoformat(),
            "description": "Failed application summaries from retry attempt",
            "retry_session": RETRY_SESSION_ID
        },
        "failed_applications": failed_results
    }
    
    with open(filename, "w") as f:
        json.dump(failed_data, f, indent=2)
    logger.info(f"Failed applications from retry saved to {filename}")
    print(f"📋 Failed applications from retry ({len(failed_results)}) saved to: {filename}")


def save_successful_applications_json(successful_results: list, filename: str = "retry_successful_applications.json"):
    """Save successful application results to a separate JSON file."""
    if not successful_results:
        logger.info("No successful applications to save")
        return
    
    # Add metadata to successful applications file
    successful_data = {
        "metadata": {
            "total_successful": len(successful_results),
            "timestamp": datetime.now().isoformat(),
            "description": "Successfully retried application summaries",
            "retry_session": RETRY_SESSION_ID
        },
        "successful_applications": successful_results
    }
    
    with open(filename, "w") as f:
        json.dump(successful_data, f, indent=2)
    logger.info(f"Successful applications from retry saved to {filename}")
    print(f"✅ Successful applications from retry ({len(successful_results)}) saved to: {filename}")


def save_to_excel(all_results: list, filename: str = "retry_results.xlsx"):
    """Save all results to an Excel file with the specified structure."""
    logger.info(f"Saving retry results to Excel file: {filename}")
    
    # Create DataFrame with the requested structure
    df = pd.DataFrame(all_results)
    
    # Reorder columns to match requested structure
    column_order = ['ApplicationNumber', 'Demographics Summary', 'Medical Summary', 'Overall Summary']
    df = df[column_order]
    
    # Save to Excel
    df.to_excel(filename, index=False, engine='openpyxl')
    logger.info(f"Retry Excel file saved successfully: {filename}")
    
    # Print summary
    print(f"\n📊 Retry Excel Summary:")
    print(f"   - Total applications retried: {len(df)}")
    print(f"   - Successful applications: {len(df[df['Demographics Summary'].notna()])}")
    print(f"   - Failed applications: {len(df[df['Demographics Summary'].isna()])}")
    print(f"   - File saved as: {filename}")


def retry_failed_applications(application_numbers: list, session_id: str = None, user_id: str = None, 
                            save_to_excel: bool = True, save_json: bool = False, excel_filename: str = None):
    """
    Retry failed applications using multiprocessing.
    """
    logger.info(f"Starting retry for {len(application_numbers)} failed applications")
    
    if not application_numbers:
        print("❌ No failed applications to retry.")
        return []
    
    all_results = []
    successful_count = 0
    failed_count = 0
    
    print(f"\n🔄 RETRY PROCESSING STARTED")
    print(f"   - Failed applications to retry: {len(application_numbers)}")
    print(f"   - Application numbers: {application_numbers}")
    print(f"   - Retry session ID: {session_id or 'retry_session'}")
    print(f"   - User ID: {user_id or 'retry_user'}")
    print(f"   - Max workers: {MAX_WORKERS}")
    print(f"   - Retry attempts: {RETRY_ATTEMPTS}")
    
    start_time = datetime.now()
    
    # Use ProcessPoolExecutor for multiprocessing
    with ProcessPoolExecutor(max_workers=MAX_WORKERS) as executor:
        # Submit all retry tasks
        future_to_app = {
            executor.submit(process_application_worker, args): args[0] 
            for args in [(app_num, session_id, user_id, RETRY_ATTEMPTS) for app_num in application_numbers]
        }
        
        # Process completed tasks
        for i, future in enumerate(as_completed(future_to_app), 1):
            app_number = future_to_app[future]
            
            try:
                result = future.result()
                all_results.append(result)
                
                # Track success/failure
                if result["Status"] == "Success":
                    successful_count += 1
                    print(f"✅ Application {app_number} retry successful")
                else:
                    failed_count += 1
                    print(f"❌ Application {app_number} retry failed: {result['Status']}")
                
                # Progress update
                print(f"📊 Retry Progress: {i}/{len(application_numbers)} applications processed")
                
            except Exception as e:
                print(f"❌ Error retrying application {app_number} in worker: {e}")
                traceback.print_exc()
                all_results.append({
                    "ApplicationNumber": app_number,
                    "Demographics Summary": None,
                    "Medical Summary": None,
                    "Overall Summary": None,
                    "Status": f"Retry worker failed: {str(e)}",
                    "Attempts": 0,
                    "RetrySession": session_id
                })
                failed_count += 1
                print(f"❌ Application {app_number} retry failed: {e}")
    
    # Calculate processing time
    end_time = datetime.now()
    processing_time = end_time - start_time
    
    # Separate successful and failed results
    successful_results = [result for result in all_results if result["Status"] == "Success"]
    failed_results = [result for result in all_results if result["Status"] != "Success"]
    
    # Save successful and failed applications to separate JSON files
    if SAVE_SUCCESSFUL_APPS:
        save_successful_applications_json(successful_results, "retry_successful_applications.json")
    if SAVE_FAILED_APPS:
        save_failed_applications_json(failed_results, "retry_failed_applications.json")
    
    # Save to Excel if requested
    if save_to_excel:
        excel_filename = excel_filename or RETRY_EXCEL_FILENAME
        save_to_excel(all_results, excel_filename)
    
    # Print final summary
    print(f"\n{'='*80}")
    print(f"🔄 RETRY PROCESSING COMPLETED")
    print(f"{'='*80}")
    print(f"📊 Retry Summary:")
    print(f"   - Total applications retried: {len(application_numbers)}")
    print(f"   - Successful retries: {successful_count}")
    print(f"   - Failed retries: {failed_count}")
    print(f"   - Retry success rate: {(successful_count/len(application_numbers)*100):.1f}%")
    print(f"   - Processing time: {processing_time}")
    print(f"   - Workers used: {MAX_WORKERS}")
    print(f"   - Excel file: {excel_filename if save_to_excel else 'Not saved'}")
    print(f"{'='*80}")
    
    return all_results


def main():
    """
    Main function - retries failed applications from the failed_applications.json file.
    """
    print("="*80)
    print("FAILED APPLICATIONS RETRY PIPELINE")
    print("="*80)
    print(f"Failed apps file: {FAILED_APPS_FILE}")
    print(f"Retry session ID: {RETRY_SESSION_ID}")
    print(f"Retry user ID: {RETRY_USER_ID}")
    print(f"Max workers: {MAX_WORKERS}")
    print(f"Retry attempts: {RETRY_ATTEMPTS}")
    print(f"Save to Excel: {SAVE_TO_EXCEL}")
    print(f"Excel filename: {RETRY_EXCEL_FILENAME}")
    print("="*80)
    
    # Load failed applications
    application_numbers, failed_apps_data = load_failed_applications(FAILED_APPS_FILE)
    
    if not application_numbers:
        print("❌ No failed applications found to retry.")
        print("Make sure to run the batch processing first to generate failed_applications.json")
        sys.exit(1)
    
    try:
        results = retry_failed_applications(
            application_numbers, 
            RETRY_SESSION_ID, 
            RETRY_USER_ID, 
            SAVE_TO_EXCEL,
            SAVE_JSON_FILES,
            RETRY_EXCEL_FILENAME
        )
        print("\n✅ Retry processing completed!")
        
    except Exception as e:
        logger.error(f"Retry pipeline failed: {e}")
        print(f"\n❌ Retry processing failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main() 