# Multiprocessing Batch Summary Processing

This directory contains scripts for processing multiple application numbers in parallel using multiprocessing, significantly speeding up batch processing operations.

## Files

- `run_summaries_batch_multiprocessing.py` - Main multiprocessing batch script
- `example_multiprocessing_usage.py` - Examples showing different multiprocessing configurations
- `run_summaries_batch.py` - Sequential batch processing script (for comparison)
- `run_summaries.py` - Original single application processing script

## 🚀 Performance Benefits

### Sequential vs Multiprocessing
- **Sequential**: Processes applications one by one
- **Multiprocessing**: Processes multiple applications simultaneously
- **Speed Improvement**: 2-4x faster depending on system capabilities

### Example Performance
```
Sequential Processing:
- 10 applications × 2 minutes each = 20 minutes total

Multiprocessing (3 workers):
- 10 applications ÷ 3 workers = ~7 minutes total
- 65% time savings!
```

## Quick Start

### 1. Basic Multiprocessing Usage

Edit the configuration in `run_summaries_batch_multiprocessing.py`:

```python
# Add your application numbers here
APPLICATION_NUMBERS = [
    "9218062",
    "9218063", 
    "9218064",
    "9218065",
    # Add more as needed
]

# Multiprocessing configuration
MAX_WORKERS = 3                    # Number of parallel processes
DELAY_BETWEEN_APPS = 1            # Delay between applications (per worker)
RETRY_ATTEMPTS = 3                # Retry attempts if an application fails

# Output options
SAVE_TO_EXCEL = True              # Save results to Excel
EXCEL_FILENAME = "multiprocessing_summary_results.xlsx"
```

### 2. Run the Script

```bash
cd AIAgents-LDS/sample_codes
python run_summaries_batch_multiprocessing.py
```

## Excel Output Structure

The script generates an Excel file with the same structure as the sequential version:

| ApplicationNumber | Demographics Summary | Medical Summary | Overall Summary |
|-------------------|---------------------|-----------------|-----------------|
| 9218062           | Summary text...     | Summary text... | Summary text... |
| 9218063           | Summary text...     | Summary text... | Summary text... |

## Configuration Options

### Multiprocessing Settings
```python
MAX_WORKERS = 3                    # Number of parallel processes
CHUNK_SIZE = 1                     # Applications per worker (usually 1)
```

### Application Numbers
```python
APPLICATION_NUMBERS = [
    "9218062",
    "9218063",
    # Add more application numbers
]
```

### Processing Options
```python
DELAY_BETWEEN_APPS = 1            # Delay between applications (per worker)
RETRY_ATTEMPTS = 3                # Number of retry attempts per application
```

### Output Options
```python
SAVE_TO_EXCEL = True              # Save results to Excel file
EXCEL_FILENAME = "multiprocessing_summary_results.xlsx"
SAVE_JSON_FILES = False           # Save individual JSON files
```

## Advanced Usage Examples

### Example 1: Basic Multiprocessing
```python
from run_summaries_batch_multiprocessing import run_multiprocessing_batch_pipeline

application_numbers = ["9218062", "9218063", "9218064", "9218065"]

results = run_multiprocessing_batch_pipeline(
    application_numbers=application_numbers,
    session_id="my_session",
    user_id="my_user",
    save_to_excel=True,
    excel_filename="my_multiprocessing_results.xlsx",
    max_workers=3
)
```

### Example 2: Adaptive Worker Configuration
```python
import multiprocessing as mp

# Calculate optimal workers based on system
cpu_count = mp.cpu_count()
optimal_workers = min(cpu_count - 1, len(application_numbers), 4)

results = run_multiprocessing_batch_pipeline(
    application_numbers=application_numbers,
    max_workers=optimal_workers
)
```

### Example 3: Large Batch Processing
```python
# For large batches, use more workers
large_batch = [f"9218{str(i).zfill(3)}" for i in range(100, 120)]

results = run_multiprocessing_batch_pipeline(
    application_numbers=large_batch,
    max_workers=6,  # More workers for larger batches
    save_json=True  # Save individual files for large batches
)
```

## System Requirements & Optimization

### CPU Cores
- **Minimum**: 2 cores (1 worker)
- **Recommended**: 4+ cores (2-3 workers)
- **Optimal**: 8+ cores (4-6 workers)

### Memory Usage
- Each worker uses ~500MB-1GB RAM
- Total memory = Number of workers × Memory per worker
- Monitor system resources during processing

### Rate Limiting
- Built-in delays prevent API rate limiting
- Each worker has independent delays
- Adjust `DELAY_BETWEEN_APPS` if needed

## Worker Configuration Guidelines

### Small Batches (1-5 applications)
```python
MAX_WORKERS = 2  # Conservative approach
```

### Medium Batches (6-20 applications)
```python
MAX_WORKERS = 3-4  # Good balance
```

### Large Batches (20+ applications)
```python
MAX_WORKERS = 4-6  # Maximum efficiency
```

### System-Specific Recommendations
```python
# For high-end systems (8+ cores, 16GB+ RAM)
MAX_WORKERS = 6

# For mid-range systems (4 cores, 8GB RAM)
MAX_WORKERS = 3

# For low-end systems (2 cores, 4GB RAM)
MAX_WORKERS = 1  # Use sequential processing instead
```

## Error Handling & Resilience

### Automatic Retry Logic
- Failed applications are retried automatically
- Configurable retry attempts per application
- Graceful failure handling

### Worker Isolation
- Each worker processes independently
- Worker failures don't affect other workers
- Comprehensive error logging

### Progress Tracking
- Real-time progress updates
- Success/failure counts
- Processing time estimation

## Performance Monitoring

### Built-in Metrics
- Processing time per application
- Success/failure rates
- Worker utilization
- Memory usage tracking

### Optimization Tips
1. **Monitor CPU usage**: Keep below 80%
2. **Monitor memory**: Ensure sufficient RAM
3. **Adjust workers**: Start conservative, increase gradually
4. **Check API limits**: Monitor for rate limiting

## Troubleshooting

### Common Issues

1. **Memory Errors**
   - Reduce `MAX_WORKERS`
   - Process smaller batches
   - Monitor system resources

2. **API Rate Limiting**
   - Increase `DELAY_BETWEEN_APPS`
   - Reduce `MAX_WORKERS`
   - Check API quotas

3. **Worker Failures**
   - Check application numbers exist
   - Verify network connectivity
   - Review error logs

4. **Performance Issues**
   - Monitor CPU/memory usage
   - Adjust worker count
   - Check system resources

### Debug Mode
Enable detailed logging by modifying the logger configuration in the script.

## Comparison with Sequential Processing

### When to Use Multiprocessing
- ✅ 3+ applications to process
- ✅ 4+ CPU cores available
- ✅ Sufficient RAM (8GB+)
- ✅ Stable network connection

### When to Use Sequential
- ⚠️ 1-2 applications only
- ⚠️ Limited system resources
- ⚠️ Network connectivity issues
- ⚠️ API rate limiting concerns

## Dependencies

Required packages (already in requirements.txt):
- `pandas` - For Excel file creation
- `openpyxl` - Excel file engine
- `multiprocessing` - Built-in Python module
- `concurrent.futures` - Built-in Python module
- `loguru` - Logging
- Other dependencies from the main project

## Running Examples

To see different multiprocessing patterns, run the example script:

```bash
python example_multiprocessing_usage.py
```

Uncomment the desired example function in the main() function to run it.

## Best Practices

### 1. Start Conservative
```python
MAX_WORKERS = 2  # Start with 2 workers
```

### 2. Monitor Resources
- Watch CPU usage during processing
- Monitor memory consumption
- Check for API rate limiting

### 3. Scale Gradually
- Increase workers if system handles load well
- Decrease workers if you see errors or performance issues

### 4. Batch Size Considerations
- Small batches (< 10): 2-3 workers
- Medium batches (10-50): 3-4 workers  
- Large batches (50+): 4-6 workers

### 5. Error Handling
- Always check success rates
- Review failed applications
- Adjust retry settings if needed 