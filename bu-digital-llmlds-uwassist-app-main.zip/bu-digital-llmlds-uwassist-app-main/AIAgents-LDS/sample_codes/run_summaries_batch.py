#!/usr/bin/env python3
"""
Batch script to run summaries for multiple application numbers and output to Excel.
Configure the variables below and run the script.
"""

import sys
import os
import json
import uuid
from loguru import logger
import traceback
import time
import pandas as pd
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp

# Add the project root to the path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from agents.summary_workflow import (
    create_demographics_workflow,
    create_medical_workflow, 
    create_overall_summary_workflow
)
from agents.state import AgentState

# =============================================================================
# CONFIGURATION VARIABLES - MODIFY THESE AS NEEDED
# =============================================================================

# Application details - ADD YOUR APPLICATION NUMBERS HERE
APPLICATION_NUMBERS = ["9217523"]
#["9217523", "9217639", "9217744", "9217937", "9217938", "9218062", "9218159", "9222406", "9222517", "9230523"]

SESSION_ID = str(uuid.uuid4())      # Change this to your session ID
USER_ID = "user_test"             # Change this to your user ID

# Options
SAVE_TO_EXCEL = True              # Set to False if you don't want to save results to Excel
EXCEL_FILENAME = "batch_summary_results_10.xlsx"  # Excel output filename
APPEND_TO_EXCEL = True            # Set to True to append to existing Excel file, False to overwrite
SAVE_JSON_FILES = False           # Set to True if you also want individual JSON files
SAVE_FAILED_APPS = True           # Set to True to save failed applications to separate JSON file
SAVE_SUCCESSFUL_APPS = False       # Set to True to save successful applications to separate JSON file
FAILED_APPS_FILENAME = "failed_applications.json"  # Filename for failed applications
SUCCESSFUL_APPS_FILENAME = "successful_applications.json"  # Filename for successful applications

# Processing options
DELAY_BETWEEN_APPS = 2            # Delay in seconds between processing applications
RETRY_ATTEMPTS = 3                # Number of retry attempts if an application fails

# =============================================================================


def run_demographics_summary(application_number: str, session_id: str = None, user_id: str = None):
    """Run demographics summary workflow."""
    logger.info(f"Starting demographics summary for application {application_number}")
    
    app_state = AgentState(
        input_message="Write a summary on demographics, MVR, Miscellaneous and Additional Notes section.",
        application_number=application_number,
        session_id=session_id or "demo_session",
        user_id=user_id or "demo_user"
    )
    
    thought, answer, confidence = None, None, 0
    demographics_graph = create_demographics_workflow()
    try:
        
        for output in demographics_graph.stream(app_state):
            for value in output.values():
                app_state.current_step = value.get("current_step", None)
                if app_state.current_step == "Reasoning & Refining the answer":
                    thought = value.get('ai_thought', None)
                    logger.info(f"Thought: {thought}")
                    answer = value.get('ai_response', None)
                    logger.info(f"Answer: {answer}")
                    confidence = value.get('confidence_score', None)
                    logger.info(f"Confidence score: {confidence}")
        
        # Pause to avoid rate limiting
        time.sleep(1)
        
    except Exception as e:
        print(f"Error processing demographics for app {application_number}")
        print(f"Error details: {e}")
        traceback.print_exc()
        return None
    
    logger.info("Demographics summary completed")
    return answer


def run_medical_summary(application_number: str, session_id: str = None, user_id: str = None):
    """Run medical summary workflow."""
    logger.info(f"Starting medical summary for application {application_number}")
    
    app_state = AgentState(
        input_message="Write a summary on Physical Metrics, Medical History, Substance Use and Additional Notes section.",
        application_number=application_number,
        session_id=session_id or "demo_session", 
        user_id=user_id or "demo_user"
    )
    thought, answer, confidence = None, None, 0
    medical_graph = create_medical_workflow()
    try:
        
        for output in medical_graph.stream(app_state):
            for value in output.values():
                app_state.current_step = value.get("current_step", None)
                if app_state.current_step == "Reasoning & Refining the answer":
                    thought = value.get('ai_thought', None)
                    logger.info(f"Thought: {thought}")
                    answer = value.get('ai_response', None)
                    logger.info(f"Answer: {answer}")
                    confidence = value.get('confidence_score', None)
                    logger.info(f"Confidence score: {confidence}")
        
        # Pause to avoid rate limiting
        time.sleep(1)
        
    except Exception as e:
        print(f"Error processing medical for app {application_number}")
        print(f"Error details: {e}")
        traceback.print_exc()
        return None
    
    logger.info("Medical summary completed")
    return answer


def run_overall_summary(demographics_summary: str, medical_summary: str, application_number: str, session_id: str = None, user_id: str = None):
    """Run overall summary workflow using provided summaries."""
    logger.info("Starting overall summary")
    
    # Create state with stored summaries
    app_state = AgentState(
        demographics_summary=demographics_summary,
        medical_summary=medical_summary,
        application_number=application_number,
        session_id=session_id or "demo_session",
        user_id=user_id or "demo_user"
    )
    thought, answer, confidence = None, None, 0
    overall_graph = create_overall_summary_workflow()
    try:
        
        for output in overall_graph.stream(app_state):
            for value in output.values():
                app_state.current_step = value.get("current_step", None)
                if app_state.current_step == "Reasoning & Refining the answer":
                    thought = value.get('ai_thought', None)
                    logger.info(f"Thought: {thought}")
                    answer = value.get('ai_response', None)
                    logger.info(f"Answer: {answer}")
                    confidence = value.get('confidence_score', None)
                    logger.info(f"Confidence score: {confidence}")
        
        # Pause to avoid rate limiting
        time.sleep(1)
        
    except Exception as e:
        print(f"Error processing overall summary for app {application_number}")
        print(f"Error details: {e}")
        traceback.print_exc()
        return None
    
    logger.info("Overall summary completed")
    return answer


def save_individual_json(application_number: str, results: dict):
    """Save individual results to a JSON file."""
    filename = f"summary_results_{application_number}.json"
    with open(filename, "w") as f:
        json.dump(results, f, indent=2)
    logger.info(f"Individual results saved to {filename}")


def save_failed_applications_json(failed_results: list, filename: str = "failed_applications.json"):
    """Save failed application results to a separate JSON file."""
    if not failed_results:
        logger.info("No failed applications to save")
        return
    
    # Add metadata to failed applications file
    failed_data = {
        "metadata": {
            "total_failed": len(failed_results),
            "timestamp": datetime.now().isoformat(),
            "description": "Failed application summaries that need to be retried"
        },
        "failed_applications": failed_results
    }
    
    with open(filename, "w") as f:
        json.dump(failed_data, f, indent=2)
    logger.info(f"Failed applications saved to {filename}")
    print(f"📋 Failed applications ({len(failed_results)}) saved to: {filename}")


def save_successful_applications_json(successful_results: list, filename: str = "successful_applications.json"):
    """Save successful application results to a separate JSON file."""
    if not successful_results:
        logger.info("No successful applications to save")
        return
    
    # Add metadata to successful applications file
    successful_data = {
        "metadata": {
            "total_successful": len(successful_results),
            "timestamp": datetime.now().isoformat(),
            "description": "Successfully processed application summaries"
        },
        "successful_applications": successful_results
    }
    
    with open(filename, "w") as f:
        json.dump(successful_data, f, indent=2)
    logger.info(f"Successful applications saved to {filename}")
    print(f"✅ Successful applications ({len(successful_results)}) saved to: {filename}")


def save_results_to_excel(all_results: list, filename: str = "batch_summary_results.xlsx", append: bool = True):
    """Save all results to an Excel file with the specified structure."""
    logger.info(f"Saving results to Excel file: {filename} (append={append})")
    
    # Create DataFrame with the requested structure
    df = pd.DataFrame(all_results)
    
    # Reorder columns to match requested structure
    column_order = ['ApplicationNumber', 'Demographics Summary', 'Medical Summary', 'Overall Summary']
    df = df[column_order]
    
    # If append is False or file doesn't exist, create/overwrite file
    if not append or not os.path.exists(filename):
        # Create new file or overwrite existing
        df.to_excel(filename, index=False, engine='openpyxl')
        logger.info(f"Excel file created/overwritten: {filename}")
        print(f"📊 Excel Summary (New/Overwritten File):")
        print(f"   - Total applications processed: {len(df)}")
        print(f"   - File: {filename}")
    else:
        # Append to existing file
        try:
            # Read existing Excel file
            with pd.ExcelWriter(filename, mode='a', engine='openpyxl', if_sheet_exists='overlay') as writer:
                # Get the existing sheet or create new one
                try:
                    # Try to read existing data
                    existing_df = pd.read_excel(filename, sheet_name='Summary Results')
                    # Combine existing and new data
                    combined_df = pd.concat([existing_df, df], ignore_index=True)
                    # Remove duplicates based on ApplicationNumber
                    combined_df = combined_df.drop_duplicates(subset=['ApplicationNumber'], keep='last')
                    # Write back to Excel
                    combined_df.to_excel(writer, sheet_name='Summary Results', index=False)
                    logger.info(f"Appended to existing Excel file: {filename}")
                    print(f"📊 Excel Summary (Appended):")
                    print(f"   - Total applications in file: {len(combined_df)}")
                    print(f"   - New applications added: {len(df)}")
                    print(f"   - File: {filename}")
                except:
                    # Sheet doesn't exist, create new sheet
                    df.to_excel(writer, sheet_name='Summary Results', index=False)
                    logger.info(f"Created new sheet in existing Excel file: {filename}")
                    print(f"📊 Excel Summary (New Sheet):")
                    print(f"   - Total applications processed: {len(df)}")
                    print(f"   - File: {filename}")
        except Exception as e:
            logger.error(f"Error appending to Excel file: {e}")
            # Fallback to overwrite if append fails
            df.to_excel(filename, index=False, engine='openpyxl')
            logger.info(f"Excel file overwritten due to append error: {filename}")
            print(f"📊 Excel Summary (Fallback Overwrite):")
            print(f"   - Total applications processed: {len(df)}")
            print(f"   - File: {filename}")
    
    # Print summary of current batch
    print(f"   - Successful applications in this batch: {len(df[df['Demographics Summary'].notna()])}")
    print(f"   - Failed applications in this batch: {len(df[df['Demographics Summary'].isna()])}")


def run_single_application_with_retry(application_number: str, session_id: str = None, user_id: str = None, max_retries: int = 3):
    """Run complete summary pipeline for a single application with retry logic."""
    logger.info(f"Processing application {application_number} (attempts: {max_retries})")
    
    for attempt in range(max_retries):
        try:
            print(f"\n{'='*60}")
            print(f"PROCESSING APPLICATION: {application_number} (Attempt {attempt + 1}/{max_retries})")
            print(f"{'='*60}")
            
            # Step 1: Run demographics summary
            print(f"\n📋 Step 1: Demographics Summary for {application_number}")
            demographics_result = run_demographics_summary(application_number, session_id, user_id)
            
            if demographics_result is None:
                raise Exception("Demographics summary failed")
            
            # Step 2: Run medical summary
            print(f"\n🏥 Step 2: Medical Summary for {application_number}")
            medical_result = run_medical_summary(application_number, session_id, user_id)
            
            if medical_result is None:
                raise Exception("Medical summary failed")
            
            # Step 3: Run overall summary
            print(f"\n📊 Step 3: Overall Summary for {application_number}")
            overall_result = run_overall_summary(
                demographics_result,
                medical_result,
                application_number, session_id, user_id
            )
            
            if overall_result is None:
                raise Exception("Overall summary failed")
            
            # Success - return results
            return {
                "ApplicationNumber": application_number,
                "Demographics Summary": demographics_result,
                "Medical Summary": medical_result,
                "Overall Summary": overall_result,
                "Status": "Success",
                "Attempts": attempt + 1
            }
            
        except Exception as e:
            logger.error(f"Attempt {attempt + 1} failed for application {application_number}: {e}")
            if attempt < max_retries - 1:
                print(f"⚠️  Attempt {attempt + 1} failed. Retrying in {DELAY_BETWEEN_APPS} seconds...")
                time.sleep(DELAY_BETWEEN_APPS)
            else:
                print(f"❌ All attempts failed for application {application_number}")
                return {
                    "ApplicationNumber": application_number,
                    "Demographics Summary": None,
                    "Medical Summary": None,
                    "Overall Summary": None,
                    "Status": f"Failed after {max_retries} attempts: {str(e)}",
                    "Attempts": max_retries
                }


def process_application_worker(args):
    """Worker function for multiprocessing - processes a single application."""
    application_number, session_id, user_id, max_retries = args
    
    # Set up process-specific logging
    worker_name = mp.current_process().name
    print(f"🚀 Worker {worker_name} starting application {application_number}")
    
    try:
        result = run_single_application_with_retry(
            application_number, session_id, user_id, max_retries
        )
        print(f"✅ Worker {worker_name} completed application {application_number}")
        return result
    except Exception as e:
        print(f"❌ Worker {worker_name} failed on application {application_number}: {e}")
        return {
            "ApplicationNumber": application_number,
            "Demographics Summary": None,
            "Medical Summary": None,
            "Overall Summary": None,
            "Status": f"Worker failed: {str(e)}",
            "Attempts": 0,
            "Worker": worker_name
        }


def run_batch_summary_pipeline(application_numbers: list, session_id: str = None, user_id: str = None, 
                             save_to_excel: bool = True, save_json: bool = False, excel_filename: str = None):
    """
    Run the complete pipeline for multiple application numbers.
    """
    logger.info(f"Starting batch summary pipeline for {len(application_numbers)} applications")
    
    all_results = []
    successful_count = 0
    failed_count = 0
    
    print(f"\n🚀 BATCH PROCESSING STARTED")
    print(f"   - Total applications: {len(application_numbers)}")
    print(f"   - Session ID: {session_id or 'demo_session'}")
    print(f"   - User ID: {user_id or 'demo_user'}")
    print(f"   - Save to Excel: {save_to_excel}")
    print(f"   - Save JSON files: {save_json}")
    
    start_time = datetime.now()
    
    # Use ProcessPoolExecutor for multiprocessing
    with ProcessPoolExecutor(max_workers=6) as executor:
        # Submit all tasks
        future_to_app = {
            executor.submit(process_application_worker, args): args[0] 
            for args in [(app_num, session_id, user_id, RETRY_ATTEMPTS) for app_num in application_numbers]
        }
        
        # Process completed tasks
        for i, future in enumerate(as_completed(future_to_app), 1):
            app_number = future_to_app[future]
            
            try:
                result = future.result()
                all_results.append(result)
                
                # Track success/failure
                if result["Status"] == "Success":
                    successful_count += 1
                    print(f"✅ Application {app_number} completed successfully")
                else:
                    failed_count += 1
                    print(f"❌ Application {app_number} failed: {result['Status']}")
                
                # Save individual JSON if requested
                if save_json and result["Status"] == "Success":
                    save_individual_json(app_number, result)
                
                # Progress update
                print(f"📊 Progress: {i}/{len(application_numbers)} applications processed")
                
            except Exception as e:
                print(f"❌ Error processing application {app_number} in worker: {e}")
                traceback.print_exc()
                all_results.append({
                    "ApplicationNumber": app_number,
                    "Demographics Summary": None,
                    "Medical Summary": None,
                    "Overall Summary": None,
                    "Status": f"Worker failed: {str(e)}",
                    "Attempts": 0,
                    "Worker": mp.current_process().name
                })
                failed_count += 1
                print(f"❌ Application {app_number} failed: {e}")
    
    # Calculate processing time
    end_time = datetime.now()
    processing_time = end_time - start_time
    
    # Separate successful and failed results
    successful_results = [result for result in all_results if result["Status"] == "Success"]
    failed_results = [result for result in all_results if result["Status"] != "Success"]
    
    # Save successful and failed applications to separate JSON files
    if SAVE_SUCCESSFUL_APPS:
        save_successful_applications_json(successful_results, SUCCESSFUL_APPS_FILENAME)
    if SAVE_FAILED_APPS:
        save_failed_applications_json(failed_results, FAILED_APPS_FILENAME)
    
    # Save to Excel if requested
    if save_to_excel:
        excel_filename = excel_filename or EXCEL_FILENAME
        save_results_to_excel(all_results, excel_filename, APPEND_TO_EXCEL)
    
    # Print final summary
    print(f"\n{'='*80}")
    print(f"🎉 BATCH PROCESSING COMPLETED")
    print(f"{'='*80}")
    print(f"📊 Summary:")
    print(f"   - Total applications: {len(application_numbers)}")
    print(f"   - Successful: {successful_count}")
    print(f"   - Failed: {failed_count}")
    print(f"   - Success rate: {(successful_count/len(application_numbers)*100):.1f}%")
    print(f"   - Processing time: {processing_time}")
    print(f"   - Excel file: {excel_filename if save_to_excel else 'Not saved'}")
    print(f"{'='*80}")
    
    return all_results


def main():
    """
    Main function - uses the configuration variables defined at the top.
    """
    print("="*80)
    print("BATCH SUMMARY PIPELINE RUNNER")
    print("="*80)
    print(f"Application Numbers: {APPLICATION_NUMBERS}")
    print(f"Session ID: {SESSION_ID}")
    print(f"User ID: {USER_ID}")
    print(f"Save to Excel: {SAVE_TO_EXCEL}")
    print(f"Append to Excel: {APPEND_TO_EXCEL}")
    print(f"Save JSON files: {SAVE_JSON_FILES}")
    print(f"Excel filename: {EXCEL_FILENAME}")
    print(f"Delay between apps: {DELAY_BETWEEN_APPS} seconds")
    print(f"Retry attempts: {RETRY_ATTEMPTS}")
    print("="*80)
    
    # Validate input
    if not APPLICATION_NUMBERS:
        print("❌ Error: No application numbers specified. Please add application numbers to the APPLICATION_NUMBERS list.")
        sys.exit(1)
    
    try:
        results = run_batch_summary_pipeline(
            APPLICATION_NUMBERS, 
            SESSION_ID, 
            USER_ID, 
            SAVE_TO_EXCEL,
            SAVE_JSON_FILES,
            EXCEL_FILENAME
        )
        print("\n✅ Batch processing completed!")
        
    except Exception as e:
        logger.error(f"Batch pipeline failed: {e}")
        print(f"\n❌ Batch processing failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main() 