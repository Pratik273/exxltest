#!/usr/bin/env python3
"""
Optimized multiprocessing batch script to run summaries for multiple application numbers in parallel.
Configure the variables below and run the script.

Performance improvements:
1. Process pool reuse with persistent workflows
2. Reduced memory leaks through proper cleanup
3. Structured JSON logging for failures and metrics
4. Better resource management
5. Optimized retry logic
"""

import sys
import os
import json
import uuid
import logging
import traceback
import time
import pandas as pd
from datetime import datetime
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor, as_completed
import psutil
import gc
from pathlib import Path
from run_summaries import run_overall_summary

# Add the project root to the path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from agents.summary_workflow import (
    create_demographics_workflow,
    create_medical_workflow
)
from agents.state import AgentState
from loguru import logger
logger.remove()
logger.add(sys.stderr, level="INFO")
# =============================================================================
# CONFIGURATION VARIABLES - MODIFY THESE AS NEEDED
# =============================================================================

# Application details - ADD YOUR APPLICATION NUMBERS HERE
APPLICATION_NUMBERS = ["9219826", "9219891", "9219903", "9221911", "9219820", "9219833", "9219852", "9219853", "9221912", "9219884"]
#["9217523", "9217639", "9217744", "9217937", "9217938", "9218062", "9218159", "9222406", "9222517", "9230523"]
#"9218062"

SESSION_ID = str(uuid.uuid4())      # Change this to your session ID
USER_ID = "user_test"             # Change this to your user ID

# Multiprocessing options
MAX_WORKERS = 6 #min(4, mp.cpu_count())  # Reduced from 6 to prevent resource exhaustion
CHUNK_SIZE = 1                     # Number of applications per worker (usually 1 for this use case)

# Options
SAVE_TO_EXCEL = True            # Set to False if you don't want to save results to Excel
EXCEL_FILENAME = "summary_results_100_3.xlsx"  # Excel output filename
APPEND_TO_EXCEL = True          # Set to True to append to existing Excel file, False to overwrite
SAVE_JSON_FILES = False           # Set to True if you also want individual JSON files

# Processing options - OPTIMIZED
DELAY_BETWEEN_APPS = 0.1          # Reduced from 1 second to 100ms
RETRY_ATTEMPTS = 3                # Number of retry attempts if an application fails
WORKFLOW_DELAY = 0.5              # Reduced from 1 second to 500ms between workflow steps

# Performance monitoring
ENABLE_PERFORMANCE_MONITORING = True
LOG_LEVEL = logging.INFO

# =============================================================================
# APPLICATION NUMBERS FROM data_sources_batch3 (auto-populated)
# =============================================================================

# Directory containing application folders
# DATA_SOURCES_BATCH3_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data_sources_batch4'))

# # Slicing options (edit as needed)
# SLICE_START = 399   # inclusive
# SLICE_END = 405  # exclusive (change as needed)

# # Get all application folder names, strip, and slice
# if os.path.exists(DATA_SOURCES_BATCH3_DIR):
#     _all_app_folders = [name.strip() for name in sorted(os.listdir(DATA_SOURCES_BATCH3_DIR)) if os.path.isdir(os.path.join(DATA_SOURCES_BATCH3_DIR, name))]
#     APPLICATION_NUMBERS = _all_app_folders[SLICE_START:SLICE_END]
# else:
#     print(f"❌ Error: Directory not found: {DATA_SOURCES_BATCH3_DIR}")
#     APPLICATION_NUMBERS = []

# =============================================================================
# LOGGING SETUP
# =============================================================================

def setup_json_logger():
    """Setup structured JSON logger for failures and metrics."""
    logger = logging.getLogger('batch_processor')
    logger.setLevel(LOG_LEVEL)
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # Create JSON formatter
    class JsonFormatter(logging.Formatter):
        def format(self, record):
            log_data = {
                'timestamp': datetime.now().isoformat(),
                'level': record.levelname,
                'message': record.getMessage(),
                'module': record.module,
                'function': record.funcName,
                'line': record.lineno
            }
            
            # Add extra fields if they exist
            if hasattr(record, 'application_number'):
                log_data['application_number'] = record.application_number
            if hasattr(record, 'worker_id'):
                log_data['worker_id'] = record.worker_id
            if hasattr(record, 'attempt'):
                log_data['attempt'] = record.attempt
            if hasattr(record, 'processing_time'):
                log_data['processing_time'] = record.processing_time
            if hasattr(record, 'memory_usage'):
                log_data['memory_usage'] = record.memory_usage
            if hasattr(record, 'error_type'):
                log_data['error_type'] = record.error_type
            if hasattr(record, 'traceback'):
                log_data['traceback'] = record.traceback
                
            return json.dumps(log_data)
    
    # File handler for all logs
    file_handler = logging.FileHandler('batch_processing.log')
    file_handler.setFormatter(JsonFormatter())
    logger.addHandler(file_handler)
    
    # Separate handler for failures only
    failure_handler = logging.FileHandler('batch_failures.log')
    failure_handler.setLevel(logging.ERROR)
    failure_handler.setFormatter(JsonFormatter())
    logger.addHandler(failure_handler)
    
    return logger

# Global logger instance
batch_logger = setup_json_logger()

# Suppress all debug logs globally - set for all loggers
logging.getLogger().setLevel(logging.WARNING)
# Specifically suppress debug logs from common modules
logging.getLogger('agents').setLevel(logging.WARNING)
logging.getLogger('scripts').setLevel(logging.WARNING)
logging.getLogger('utils').setLevel(logging.WARNING)
logging.getLogger('database').setLevel(logging.WARNING)

# =============================================================================
# PERFORMANCE MONITORING
# =============================================================================

class PerformanceMonitor:
    """Monitor resource usage and performance metrics."""
    
    def __init__(self):
        self.process = psutil.Process()
        self.start_time = None
        self.start_memory = None
    
    def start_monitoring(self):
        """Start monitoring session."""
        self.start_time = time.time()
        self.start_memory = self.process.memory_info().rss / 1024 / 1024  # MB
    
    def get_metrics(self):
        """Get current performance metrics."""
        current_memory = self.process.memory_info().rss / 1024 / 1024  # MB
        cpu_percent = self.process.cpu_percent()
        
        metrics = {
            'memory_usage_mb': current_memory,
            'memory_change_mb': current_memory - (self.start_memory or current_memory),
            'cpu_percent': cpu_percent,
            'open_files': len(self.process.open_files()) if hasattr(self.process, 'open_files') else 0
        }
        
        if self.start_time:
            metrics['elapsed_time'] = time.time() - self.start_time
            
        return metrics

# =============================================================================
# OPTIMIZED WORKFLOW FUNCTIONS
# =============================================================================

# Global workflow objects (created once per process)
_demographics_workflow = None
_medical_workflow = None

def get_demographics_workflow():
    """Get or create demographics workflow (singleton per process)."""
    global _demographics_workflow
    if _demographics_workflow is None:
        _demographics_workflow = create_demographics_workflow()
    return _demographics_workflow

def get_medical_workflow():
    """Get or create medical workflow (singleton per process)."""
    global _medical_workflow
    if _medical_workflow is None:
        _medical_workflow = create_medical_workflow()
    return _medical_workflow

def run_demographics_summary_optimized(application_number: str, session_id: str = None, user_id: str = None):
    """Run demographics summary workflow with optimizations."""
    monitor = PerformanceMonitor()
    monitor.start_monitoring()
    
    app_state = AgentState(
        input_message="Write a summary on demographics, MVR, Miscellaneous and Additional Notes section.",
        application_number=application_number,
        session_id=session_id or "demo_session",
        user_id=user_id or "demo_user"
    )
    
    thought, answer, confidence = None, None, 0
    demographics_graph = get_demographics_workflow()
    
    try:
        for output in demographics_graph.stream(app_state):
            for value in output.values():
                app_state.current_step = value.get("current_step", None)
                if app_state.current_step == "Reasoning & Refining the answer":
                    thought = value.get('ai_thought', None)
                    answer = value.get('ai_response', None)
                    confidence = value.get('confidence_score', None)
        
        # Reduced pause to avoid rate limiting
        time.sleep(WORKFLOW_DELAY)
        
        # Log success metrics
        metrics = monitor.get_metrics()
        batch_logger.info("Demographics summary completed", 
                         extra={'application_number': application_number, 
                               'processing_time': metrics.get('elapsed_time'),
                               'memory_usage': metrics.get('memory_usage_mb')})
        
        return answer
        
    except Exception as e:
        metrics = monitor.get_metrics()
        batch_logger.error("Demographics summary failed",
                          extra={'application_number': application_number,
                                'error_type': type(e).__name__,
                                'traceback': traceback.format_exc(),
                                'processing_time': metrics.get('elapsed_time'),
                                'memory_usage': metrics.get('memory_usage_mb')})
        return None

def run_medical_summary_optimized(application_number: str, session_id: str = None, user_id: str = None):
    """Run medical summary workflow with optimizations."""
    monitor = PerformanceMonitor()
    monitor.start_monitoring()
    
    app_state = AgentState(
        input_message="Write a summary on Physical Metrics, Medical History, Substance Use, Miscellaneous and Additional Notes section.",
        application_number=application_number,
        session_id=session_id or "demo_session", 
        user_id=user_id or "demo_user"
    )
    
    thought, answer, confidence = None, None, 0
    medical_graph = get_medical_workflow()
    
    try:
        for output in medical_graph.stream(app_state):
            for value in output.values():
                app_state.current_step = value.get("current_step", None)
                if app_state.current_step == "Reasoning & Refining the answer":
                    thought = value.get('ai_thought', None)
                    medical_answer = value.get('ai_response', None)
                    confidence = value.get('confidence_score', None)
        
        # Reduced pause to avoid rate limiting
        time.sleep(WORKFLOW_DELAY)
        
        # Log success metrics
        metrics = monitor.get_metrics()
        batch_logger.info("Medical summary completed",
                         extra={'application_number': application_number,
                               'processing_time': metrics.get('elapsed_time'),
                               'memory_usage': metrics.get('memory_usage_mb')})
        
        return medical_answer
        
    except Exception as e:
        metrics = monitor.get_metrics()
        batch_logger.error("Medical summary failed",
                          extra={'application_number': application_number,
                                'error_type': type(e).__name__,
                                'traceback': traceback.format_exc(),
                                'processing_time': metrics.get('elapsed_time'),
                                'memory_usage': metrics.get('memory_usage_mb')})
        return None

def cleanup_workflow_resources():
    """Clean up workflow resources to prevent memory leaks."""
    global _demographics_workflow, _medical_workflow
    
    # Force garbage collection
    gc.collect()
    
    # Note: We keep workflows alive for reuse, but ensure proper cleanup
    # If memory becomes an issue, uncomment the following:
    # _demographics_workflow = None
    # _medical_workflow = None

# =============================================================================
# OPTIMIZED PROCESSING FUNCTIONS
# =============================================================================

def run_single_application_optimized(application_number: str, session_id: str = None, user_id: str = None, max_retries: int = 3):
    """Run complete summary pipeline for a single application with optimizations."""
    overall_monitor = PerformanceMonitor()
    overall_monitor.start_monitoring()
    
    worker_id = mp.current_process().name
    
    for attempt in range(max_retries):
        try:
            batch_logger.info("Starting application processing",
                             extra={'application_number': application_number,
                                   'worker_id': worker_id,
                                   'attempt': attempt + 1})
            
            # Step 1: Run demographics summary
            demographics_result = run_demographics_summary_optimized(application_number, session_id, user_id)
            if demographics_result is None:
                raise Exception("Demographics summary failed")
            
            # Step 2: Run medical summary
            medical_result = run_medical_summary_optimized(application_number, session_id, user_id)
            if medical_result is None:
                raise Exception("Medical summary failed")
            
            # Step 3: Run overall summary
            overall_result = run_overall_summary(
                demographics_result,
                medical_result,
                application_number, session_id, user_id
            )
            if overall_result is None:
                raise Exception("Overall summary failed")
            
            # Success - log metrics and return results
            metrics = overall_monitor.get_metrics()
            batch_logger.info("Application processing completed successfully",
                             extra={'application_number': application_number,
                                   'worker_id': worker_id,
                                   'attempt': attempt + 1,
                                   'processing_time': metrics.get('elapsed_time'),
                                   'memory_usage': metrics.get('memory_usage_mb')})
            
            # Clean up resources
            cleanup_workflow_resources()
            
            return {
                "ApplicationNumber": application_number,
                "Demographics Summary": demographics_result,
                "Medical Summary": medical_result,
                "Overall Summary": overall_result,
                "Status": "Success",
                "Attempts": attempt + 1,
                "Worker": worker_id,
                "ProcessingTime": metrics.get('elapsed_time'),
                "MemoryUsage": metrics.get('memory_usage_mb')
            }
            
        except Exception as e:
            metrics = overall_monitor.get_metrics()
            batch_logger.error("Application processing attempt failed",
                              extra={'application_number': application_number,
                                    'worker_id': worker_id,
                                    'attempt': attempt + 1,
                                    'error_type': type(e).__name__,
                                    'traceback': traceback.format_exc(),
                                    'processing_time': metrics.get('elapsed_time'),
                                    'memory_usage': metrics.get('memory_usage_mb')})
            
            if attempt < max_retries - 1:
                print(f"⚠️  Attempt {attempt + 1} failed for {application_number}. Retrying in {DELAY_BETWEEN_APPS} seconds...")
                time.sleep(DELAY_BETWEEN_APPS)
                # Clean up resources before retry
                cleanup_workflow_resources()
            else:
                print(f"❌ All attempts failed for application {application_number}")
                # Final cleanup
                cleanup_workflow_resources()
                
                return {
                    "ApplicationNumber": application_number,
                    "Demographics Summary": None,
                    "Medical Summary": None,
                    "Overall Summary": None,
                    # "Status": f"Failed after {max_retries} attempts: {str(e)}",
                    # "Attempts": max_retries,
                    # "Worker": worker_id,
                    # "ProcessingTime": metrics.get('elapsed_time'),
                    # "MemoryUsage": metrics.get('memory_usage_mb')
                }

def process_application_worker_optimized(args):
    """Optimized worker function for multiprocessing - ensures one worker processes one application entirely."""
    application_number, session_id, user_id, max_retries = args
    
    worker_name = mp.current_process().name
    print(f"🚀 Worker {worker_name} assigned to process application {application_number}")
    
    try:
        result = run_single_application_optimized(
            application_number, session_id, user_id, max_retries
        )
        print(f"✅ Worker {worker_name} completed application {application_number}")
        return result
    except Exception as e:
        print(f"❌ Worker {worker_name} failed on application {application_number}: {e}")
        batch_logger.error("Worker failed completely",
                          extra={'application_number': application_number,
                                'worker_id': worker_name,
                                'error_type': type(e).__name__,
                                'traceback': traceback.format_exc()})
        return {
            "ApplicationNumber": application_number,
            "Demographics Summary": None,
            "Medical Summary": None,
            "Overall Summary": None,
            # "Status": f"Worker failed: {str(e)}",
            # "Attempts": 0,
            # "Worker": worker_name,
            # "ProcessingTime": 0,
            # "MemoryUsage": 0
        }

# =============================================================================
# EXCEL SAVE FUNCTION (UNCHANGED)
# =============================================================================

def save_results_to_excel(all_results: list, filename: str = "multiprocessing_summary_results.xlsx", append: bool = True):
    """Save all results to an Excel file with the specified structure."""
    batch_logger.info(f"Saving results to Excel file: {filename} (append={append})")
    
    # Create DataFrame with the requested structure
    df = pd.DataFrame(all_results)
    
    # Reorder columns to match requested structure
    column_order = ['ApplicationNumber', 'Demographics Summary', 'Medical Summary', 'Overall Summary', 'Status', 'Attempts', 'Worker', 'ProcessingTime', 'MemoryUsage']
    # Only include columns that exist
    available_columns = [col for col in column_order if col in df.columns]
    df = df[available_columns]
    
    # If append is False or file doesn't exist, create/overwrite file
    if not append or not os.path.exists(filename):
        df.to_excel(filename, index=False, engine='openpyxl')
        batch_logger.info(f"Excel file created/overwritten: {filename}")
        print(f"📊 Excel Summary (New/Overwritten File):")
        print(f"   - Total applications processed: {len(df)}")
        print(f"   - File: {filename}")
    else:
        try:
            with pd.ExcelWriter(filename, mode='a', engine='openpyxl', if_sheet_exists='overlay') as writer:
                try:
                    existing_df = pd.read_excel(filename)
                    combined_df = pd.concat([existing_df, df], ignore_index=True)
                    combined_df = combined_df.drop_duplicates(subset=['ApplicationNumber'], keep='last')
                    combined_df.to_excel(writer, sheet_name='Summary Missing', index=False)
                    batch_logger.info(f"Appended to existing Excel file: {filename}")
                    print(f"📊 Excel Summary (Appended):")
                    print(f"   - Total applications in file: {len(combined_df)}")
                    print(f"   - New applications added: {len(df)}")
                    print(f"   - File: {filename}")
                except:
                    df.to_excel(writer, sheet_name='Summary Missing', index=False)
                    batch_logger.info(f"Created new sheet in existing Excel file: {filename}")
                    print(f"📊 Excel Summary (New Sheet):")
                    print(f"   - Total applications processed: {len(df)}")
                    print(f"   - File: {filename}")
        except Exception as e:
            batch_logger.error(f"Error appending to Excel file: {e}")
            df.to_excel(filename, index=False, engine='openpyxl')
            batch_logger.info(f"Excel file overwritten due to append error: {filename}")
            print(f"📊 Excel Summary (Fallback Overwrite):")
            print(f"   - Total applications processed: {len(df)}")
            print(f"   - File: {filename}")
    
    # Print summary of current batch
    successful = len(df[df['Status'] == 'Success'])
    failed = len(df[df['Status'] != 'Success'])
    print(f"   - Successful applications in this batch: {successful}")
    print(f"   - Failed applications in this batch: {failed}")

# =============================================================================
# MAIN PROCESSING FUNCTION
# =============================================================================

def run_multiprocessing_batch_pipeline_optimized(application_numbers: list, session_id: str = None, user_id: str = None, 
                                                 save_to_excel: bool = True, save_json: bool = False, 
                                                 excel_filename: str = None, max_workers: int = None):
    """
    Run the optimized complete pipeline for multiple application numbers using multiprocessing.
    """
    batch_logger.info(f"Starting optimized multiprocessing batch pipeline for {len(application_numbers)} applications")
    
    if max_workers is None:
        max_workers = min(MAX_WORKERS, len(application_numbers))
    
    print(f"\n🚀 OPTIMIZED MULTIPROCESSING BATCH PROCESSING STARTED")
    print(f"   - Total applications: {len(application_numbers)}")
    print(f"   - Max workers: {max_workers}")
    print(f"   - CPU cores available: {mp.cpu_count()}")
    print(f"   - Session ID: {session_id or 'demo_session'}")
    print(f"   - User ID: {user_id or 'demo_user'}")
    print(f"   - Performance monitoring: {ENABLE_PERFORMANCE_MONITORING}")
    print(f"   - Workflow delay: {WORKFLOW_DELAY}s")
    print(f"   - App delay: {DELAY_BETWEEN_APPS}s")
    
    start_time = datetime.now()
    all_results = []
    successful_count = 0
    failed_count = 0
    
    # Prepare arguments for workers
    worker_args = [
        (app_number, session_id, user_id, RETRY_ATTEMPTS) 
        for app_number in application_numbers
    ]
    
    # Performance monitoring
    if ENABLE_PERFORMANCE_MONITORING:
        main_monitor = PerformanceMonitor()
        main_monitor.start_monitoring()
    
    # Use ProcessPoolExecutor for multiprocessing
    print(f"📋 Worker Assignment Strategy: Each worker processes exactly one application from start to finish")
    print(f"📋 Applications will be distributed among {max_workers} workers")
    
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        # Submit all tasks - each args tuple contains (app_number, session_id, user_id, max_retries)
        future_to_app = {
            executor.submit(process_application_worker_optimized, args): args[0] 
            for args in worker_args
        }
        
        print(f"📋 Submitted {len(future_to_app)} applications to worker pool")
        
        # Process completed tasks
        for i, future in enumerate(as_completed(future_to_app), 1):
            app_number = future_to_app[future]
            
            try:
                result = future.result()
                all_results.append(result)
                
                if result["Status"] == "Success":
                    successful_count += 1
                    print(f"✅ Application {app_number} completed successfully (Worker: {result.get('Worker', 'Unknown')})")
                else:
                    failed_count += 1
                    print(f"❌ Application {app_number} failed: {result['Status']}")
                
                # Progress update with performance info
                if ENABLE_PERFORMANCE_MONITORING and i % 5 == 0:  # Every 5 applications
                    metrics = main_monitor.get_metrics()
                    print(f"📊 Progress: {i}/{len(application_numbers)} | Memory: {metrics.get('memory_usage_mb', 0):.1f}MB | CPU: {metrics.get('cpu_percent', 0):.1f}%")
                else:
                    print(f"📊 Progress: {i}/{len(application_numbers)} applications processed")
                
            except Exception as e:
                failed_count += 1
                batch_logger.error("Future result exception",
                                  extra={'application_number': app_number,
                                        'error_type': type(e).__name__,
                                        'traceback': traceback.format_exc()})
                print(f"❌ Exception for application {app_number}: {e}")
                all_results.append({
                    "ApplicationNumber": app_number,
                    "Demographics Summary": None,
                    "Medical Summary": None,
                    "Overall Summary": None,
                    "Status": f"Exception: {str(e)}",
                    "Attempts": 0,
                    "Worker": "Unknown",
                    "ProcessingTime": 0,
                    "MemoryUsage": 0
                })
    
    # Calculate processing time
    end_time = datetime.now()
    processing_time = end_time - start_time
    
    # Final performance metrics
    if ENABLE_PERFORMANCE_MONITORING:
        final_metrics = main_monitor.get_metrics()
        batch_logger.info("Batch processing completed",
                         extra={'total_applications': len(application_numbers),
                               'successful_count': successful_count,
                               'failed_count': failed_count,
                               'processing_time': processing_time.total_seconds(),
                               'final_memory_usage': final_metrics.get('memory_usage_mb')})
    
    # Save failed applications summary
    failed_apps = [result for result in all_results if result["Status"] != "Success"]
    if failed_apps:
        with open('failed_applications_summary.json', 'w') as f:
            json.dump({
                'batch_summary': {
                    'total_applications': len(application_numbers),
                    'failed_count': len(failed_apps),
                    'failure_rate': len(failed_apps) / len(application_numbers) * 100,
                    'processing_time': str(processing_time),
                    'timestamp': datetime.now().isoformat()
                },
                'failed_applications': failed_apps
            }, f, indent=2)
        print(f"💾 Failed applications summary saved to failed_applications_summary.json")
    
    # Save to Excel if requested
    if save_to_excel:
        excel_filename = excel_filename or EXCEL_FILENAME
        save_results_to_excel(all_results, excel_filename, APPEND_TO_EXCEL)
    
    # Print final summary
    print(f"\n{'='*80}")
    print(f"🎉 OPTIMIZED MULTIPROCESSING BATCH PROCESSING COMPLETED")
    print(f"{'='*80}")
    print(f"📊 Summary:")
    print(f"   - Total applications: {len(application_numbers)}")
    print(f"   - Successful: {successful_count}")
    print(f"   - Failed: {failed_count}")
    print(f"   - Success rate: {(successful_count/len(application_numbers)*100):.1f}%")
    print(f"   - Processing time: {processing_time}")
    print(f"   - Average time per app: {processing_time.total_seconds()/len(application_numbers):.1f}s")
    print(f"   - Workers used: {max_workers}")
    print(f"   - Excel file: {excel_filename if save_to_excel else 'Not saved'}")
    if ENABLE_PERFORMANCE_MONITORING:
        print(f"   - Final memory usage: {final_metrics.get('memory_usage_mb', 0):.1f}MB")
    print(f"{'='*80}")
    
    return all_results

def validate_applications_exist():
    """Validate that all application numbers exist in the database."""
    from scripts.database.check_db_conn import connect_to_db
    
    print(f"🔍 Validating {len(APPLICATION_NUMBERS)} applications exist in database...")
    
    try:
        cur, conn = connect_to_db()
        valid_apps = []
        invalid_apps = []
        
        for app_num in APPLICATION_NUMBERS:
            cur.execute(f"SELECT application_id, type FROM applications WHERE application_number = '{app_num}'")
            data = cur.fetchone()
            
            if data:
                valid_apps.append(app_num)
                print(f"✅ {app_num} - Found (ID: {data[0]}, Type: {data[1]})")
            else:
                invalid_apps.append(app_num)
                print(f"❌ {app_num} - NOT FOUND")
        
        conn.close()
        
        if invalid_apps:
            print(f"\n⚠️  WARNING: {len(invalid_apps)} applications not found in database:")
            for app in invalid_apps:
                print(f"   - {app}")
            
            # Show some valid examples
            cur, conn = connect_to_db()
            cur.execute("SELECT application_number FROM applications LIMIT 10")
            examples = cur.fetchall()
            conn.close()
            
            print(f"\n📋 Example valid application numbers:")
            for ex in examples:
                print(f"   - {ex[0]}")
            
            choice = input(f"\nContinue with only {len(valid_apps)} valid applications? (y/n): ")
            if choice.lower() != 'y':
                sys.exit(1)
            
            return valid_apps
        else:
            print(f"✅ All {len(valid_apps)} applications found in database!")
            return valid_apps
            
    except Exception as e:
        print(f"❌ Database validation error: {e}")
        sys.exit(1)

def main():
    """
    Main function - uses the configuration variables defined at the top.
    """
    print("="*80)
    print("OPTIMIZED MULTIPROCESSING BATCH SUMMARY PIPELINE RUNNER")
    print("="*80)
    print(f"Application Numbers: {APPLICATION_NUMBERS}")
    print(f"Session ID: {SESSION_ID}")
    print(f"User ID: {USER_ID}")
    print(f"Max Workers: {MAX_WORKERS}")
    print(f"CPU Cores: {mp.cpu_count()}")
    print(f"Save to Excel: {SAVE_TO_EXCEL}")
    print(f"Append to Excel: {APPEND_TO_EXCEL}")
    print(f"Save JSON files: {SAVE_JSON_FILES}")
    print(f"Excel filename: {EXCEL_FILENAME}")
    print(f"Workflow delay: {WORKFLOW_DELAY} seconds")
    print(f"App delay: {DELAY_BETWEEN_APPS} seconds")
    print(f"Retry attempts: {RETRY_ATTEMPTS}")
    print(f"Performance monitoring: {ENABLE_PERFORMANCE_MONITORING}")
    print("="*80)
    
    # Validate input
    if not APPLICATION_NUMBERS:
        print("❌ Error: No application numbers specified. Please add application numbers to the APPLICATION_NUMBERS list.")
        sys.exit(1)
    
    # Validate applications exist in database
    valid_applications = validate_applications_exist()
    
    if not valid_applications:
        print("❌ Error: No valid applications found in database.")
        sys.exit(1)
    
    try:
        results = run_multiprocessing_batch_pipeline_optimized(
            valid_applications,  # Use validated applications instead of original list
            SESSION_ID, 
            USER_ID, 
            SAVE_TO_EXCEL,
            SAVE_JSON_FILES,
            EXCEL_FILENAME,
            MAX_WORKERS
        )
        
        print("\n✅ Optimized batch processing completed!")
        
    except Exception as e:
        batch_logger.error(f"Batch pipeline failed: {e}", 
                          extra={'error_type': type(e).__name__,
                                'traceback': traceback.format_exc()})
        print(f"\n❌ Batch processing failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    # Set multiprocessing start method
    mp.set_start_method('spawn', force=True)
    main() 