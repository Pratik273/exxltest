#!/usr/bin/env python3
"""
Test script to verify the modified get_mib_json function works with modified JSON files.
"""

import sys
import os

# Add the current directory to the path so we can import from xml_to_excel_2
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from xml_to_excel_2 import get_mib_json

def test_mib_json_parsing():
    """Test the MIB JSON parsing function with a sample file."""
    
    # Test with a modified JSON file that has ResponseData
    test_file = "../data_sources_batch4/9223638/9223638_modified_MWA_MIB.json"
    
    if not os.path.exists(test_file):
        print(f"Test file not found: {test_file}")
        return
    
    print(f"Testing MIB JSON parsing with: {test_file}")
    print("-" * 50)
    
    try:
        mib_fields, codes = get_mib_json(test_file)
        
        print("MIB Fields extracted:")
        for key, value in mib_fields.items():
            print(f"  {key}: {value}")
        
        print(f"\nMIB Codes extracted ({len(codes)} codes):")
        for i, code in enumerate(codes, 1):
            print(f"  {i}. MIBCode: {code.get('MIBCode', 'N/A')}")
            print(f"     MIBCodeMeaning: {code.get('MIBCodeMeaning', 'N/A')}")
        
        print(f"\nTest completed successfully!")
        
    except Exception as e:
        print(f"Error during testing: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_mib_json_parsing() 