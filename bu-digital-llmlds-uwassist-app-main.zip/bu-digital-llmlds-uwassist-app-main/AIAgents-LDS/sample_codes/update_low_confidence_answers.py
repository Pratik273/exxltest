import os
import sys
import pandas as pd
import traceback
from openpyxl import load_workbook
import uuid
import time
import json
from loguru import logger
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from agents.dataset_workflow import dataset_graph
from agents.state import AgentState

# Configure Loguru to only show INFO and higher
logger.remove()
logger.add(sys.stdout, level="INFO")

# Path to the Excel file
excel_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                         'data_sources', 'FAQs_Results_By_Application_Multiprocessing_100_2.xlsx')

def update_low_confidence_for_app(app_number):
    errors = []
    try:
        # Load all sheets
        all_sheets = pd.read_excel(excel_path, sheet_name=None, engine='openpyxl')
    except FileNotFoundError:
        logger.error(f"Excel file not found at {excel_path}")
        errors.append({"application_number": app_number, "question": "N/A", "error": "FAQs_Results_By_Application.xlsx not found."})
        return None, errors
    except Exception as e:
        logger.error(f"Error reading Excel file: {e}")
        errors.append({"application_number": app_number, "question": "N/A", "error": f"Failed to read Excel file: {e}"})
        return None, errors

    if app_number not in all_sheets:
        logger.warning(f"Application number {app_number} not found in Excel file.")
        # No error to log here, just skipping.
        return None, []
        
    df = all_sheets[app_number]
    # Normalize columns
    df.columns = [str(col).strip().lower() for col in df.columns]
    question_col = next((col for col in df.columns if 'question' in col), None)
    thought_col = next((col for col in df.columns if 'thought' in col), None)
    answer_col = next((col for col in df.columns if 'answer' in col), None)
    confidence_col = next((col for col in df.columns if 'confidence' in col), None)
    if not question_col or not confidence_col or not thought_col or not answer_col:
        logger.error(f"Sheet for '{app_number}' is missing required columns.")
        errors.append({"application_number": app_number, "question": "N/A", "error": "Could not find required columns."})
        return None, errors

    # Define the specific question to always re-run
    # SPECIFIC_QUESTION = "Any inforce coverage present in the application?"

    # Find rows with confidence == 0 OR the specific question
    low_confidence_condition = df[confidence_col] == 0
    # specific_question_condition = df[question_col] == SPECIFIC_QUESTION
    
    # indices_to_process = df[low_confidence_condition | specific_question_condition].index
    indices_to_process = df[low_confidence_condition].index


    if len(indices_to_process) == 0:
        logger.info(f"No questions to update for application {app_number}.")
        return df, []
        
    logger.info(f"Found {len(indices_to_process)} questions to re-process for application {app_number}.")
    session_id = str(uuid.uuid4())
    user_id = "user_123_90_update"
    for i, idx in enumerate(indices_to_process):
        question = df.at[idx, question_col]
        logger.info(f"  -> Processing Q{i+1}/{len(indices_to_process)}: '{question}'")
        answer_generated = False
        try:
            app_state = AgentState(
                application_number=app_number,
                input_message=question,
                session_id=session_id,
                user_id=user_id
            )
            for output in dataset_graph.stream(app_state):
                for value in output.values():
                    if value.get("current_step") == "Reasoning & Refining the answer":
                        thought = value.get('ai_thought')
                        answer = value.get('ai_response')
                        confidence = value.get('confidence_score')
                        if thought is not None and answer is not None:
                            processed_confidence = 0
                            if isinstance(confidence, str):
                                try:
                                    processed_confidence = int(float(confidence.strip().replace('%', '')))
                                except (ValueError, TypeError):
                                    processed_confidence = 0
                            elif isinstance(confidence, (int, float)):
                                processed_confidence = int(confidence)
                            df.at[idx, thought_col] = thought
                            df.at[idx, answer_col] = answer
                            df.at[idx, confidence_col] = processed_confidence
                            answer_generated = True
                            if processed_confidence == 0:
                                errors.append({
                                    "app_number": app_number,
                                    "question": question,
                                    "error": "Agent returned a confidence score of 0 after re-processing."
                                })
            time.sleep(1)
            if not answer_generated:
                errors.append({
                    "app_number": app_number,
                    "question": question,
                    "error": "Agent did not produce a valid thought and answer."
                })
        except Exception as e:
            logger.error(f"Error updating question for app {app_number}: '{question}' - {e}")
            traceback.print_exc()
            errors.append({"app_number": app_number, "question": question, "error": str(e)})

    return df, errors

def process_all_applications():
    """
    Iterates through all application folders in data_sources_new and updates
    low-confidence answers for each.
    """
    prod_samples_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data_sources_batch3')
    error_file_path = os.path.join(os.path.dirname(excel_path), 'Update_Low_Confidence_Errors.json')

    # Initialize the error log
    with open(error_file_path, 'w') as f:
        json.dump([], f, indent=4)
        
    if not os.path.exists(prod_samples_dir):
        logger.critical(f"Directory {prod_samples_dir} does not exist. Exiting.")
        sys.exit(1)
        
    application_folders = sorted([item for item in os.listdir(prod_samples_dir) if os.path.isdir(os.path.join(prod_samples_dir, item))])
    
    logger.info(f"Found {len(application_folders)} application folders to process.")
    for app_number in application_folders:
        logger.info("=" * 60)
        logger.info(f"Processing application: {app_number}")
        
        updated_df, app_errors = update_low_confidence_for_app(app_number.strip())

        if app_errors:
            try:
                with open(error_file_path, 'r') as f:
                    all_errors = json.load(f)
                all_errors.extend(app_errors)
                with open(error_file_path, 'w') as f:
                    json.dump(all_errors, f, indent=4)
                logger.warning(f"Logged {len(app_errors)} error(s) for application {app_number}.")
            except Exception as e:
                logger.error(f"Failed to write to error log: {e}")
        
        if updated_df is not None:
            try:
                # Write back only this sheet to the Excel file in place
                with pd.ExcelWriter(excel_path, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
                    updated_df.to_excel(writer, sheet_name=app_number.strip(), index=False)
                logger.info(f"Successfully updated sheet for application {app_number}.")
            except Exception as e:
                logger.error(f"Error saving updated sheet for application {app_number}: {e}")

        logger.info(f"Finished processing application: {app_number}")
        
    logger.info("=" * 60)
    logger.info("All applications have been processed.")

if __name__ == "__main__":
    process_all_applications() 