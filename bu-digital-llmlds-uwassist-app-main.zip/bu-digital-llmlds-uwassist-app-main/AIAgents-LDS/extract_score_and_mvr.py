#!/usr/bin/env python3
"""
Script to extract ScoreResult.Result.Score and MVRResults from modified MWA risk classifier JSON files.
Repeated violations are eliminated, keeping only unique ones.
"""

import json
import os
import glob
from pathlib import Path
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_violation_key(violation):
    """
    Create a unique key for a violation based on its identifying characteristics.
    
    Args:
        violation (dict): Violation dictionary
        
    Returns:
        str: Unique key for the violation
    """
    # Extract key fields for uniqueness
    description = violation.get('Description', '')
    state_code = violation.get('StateViolationCode', '')
    standard_code = ''
    
    # Get standard violation code if available
    if 'StandardViolations' in violation and violation['StandardViolations']:
        standard_code = violation['StandardViolations'][0].get('StandardViolationCode', '')
    
    # Create key based on description, state code, and standard code
    key = f"{description}|{state_code}|{standard_code}"
    return key

def deduplicate_violations(mvr_results):
    """
    Remove duplicate violations from MVR results, keeping only unique ones.
    
    Args:
        mvr_results (dict): MVR results dictionary
        
    Returns:
        dict: MVR results with deduplicated violations
    """
    if not mvr_results or 'Result' not in mvr_results:
        return mvr_results
    
    # Deep copy to avoid modifying original
    deduplicated_mvr = json.loads(json.dumps(mvr_results))
    
    for result_group in deduplicated_mvr['Result']:
        for result in result_group:
            if 'MVRReport' in result and 'Response' in result['MVRReport']:
                violations = result['MVRReport']['Response'].get('MVRViolations', [])
                
                # Track unique violations
                unique_violations = []
                seen_keys = set()
                
                for violation in violations:
                    violation_key = create_violation_key(violation)
                    if violation_key not in seen_keys:
                        unique_violations.append(violation)
                        seen_keys.add(violation_key)
                
                # Replace with deduplicated violations
                result['MVRReport']['Response']['MVRViolations'] = unique_violations
    
    return deduplicated_mvr

def extract_score_and_mvr_from_file(file_path):
    """
    Extract ScoreResult.Result.Score and MVRResults from a single JSON file.
    
    Args:
        file_path (str): Path to the JSON file
        
    Returns:
        dict: Dictionary containing certificate number, score, and MVR results
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Extract certificate number
        certificate_number = data.get('CertificateNumber', 'Unknown')
        
        # Extract score from ScoreResult.Result[0][0].Models[0].Score
        score = None
        try:
            score_result = data.get('Content', {}).get('ProductResults', {}).get('ScoreResult', {})
            if score_result and 'Result' in score_result:
                result_array = score_result['Result']
                if result_array and len(result_array) > 0:
                    first_result = result_array[0]
                    if first_result and len(first_result) > 0:
                        first_item = first_result[0]
                        if 'Models' in first_item and first_item['Models']:
                            score = first_item['Models'][0].get('Score')
        except (KeyError, IndexError, TypeError) as e:
            logger.warning(f"Error extracting score from {file_path}: {e}")
        
        # Extract MVRResults and deduplicate violations
        mvr_results = None
        original_violation_count = 0
        deduplicated_violation_count = 0
        
        try:
            mvr_results = data.get('Content', {}).get('ProductResults', {}).get('MVRResults')
            if mvr_results:
                # Count original violations
                if 'Result' in mvr_results and mvr_results['Result']:
                    first_mvr = mvr_results['Result'][0][0] if mvr_results['Result'][0] else None
                    if first_mvr and 'MVRReport' in first_mvr:
                        violations = first_mvr['MVRReport'].get('Response', {}).get('MVRViolations', [])
                        original_violation_count = len(violations)
                
                # Deduplicate violations
                mvr_results = deduplicate_violations(mvr_results)
                
                # Count deduplicated violations
                if 'Result' in mvr_results and mvr_results['Result']:
                    first_mvr = mvr_results['Result'][0][0] if mvr_results['Result'][0] else None
                    if first_mvr and 'MVRReport' in first_mvr:
                        violations = first_mvr['MVRReport'].get('Response', {}).get('MVRViolations', [])
                        deduplicated_violation_count = len(violations)
        except (KeyError, TypeError) as e:
            logger.warning(f"Error extracting MVR results from {file_path}: {e}")
        
        return {
            'certificate_number': certificate_number,
            'score': score,
            'mvr_results': mvr_results,
            'file_path': file_path,
            'original_violation_count': original_violation_count,
            'deduplicated_violation_count': deduplicated_violation_count
        }
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error in {file_path}: {e}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error processing {file_path}: {e}")
        return None

def process_all_modified_files(base_dir):
    """
    Process all modified MWA risk classifier files in the given directory and subdirectories.
    
    Args:
        base_dir (str): Base directory to search for files
        
    Returns:
        list: List of extracted data dictionaries
    """
    # Find all modified MWA risk classifier files
    pattern = os.path.join(base_dir, "**", "*_modified_MWA_RISKCLASSIFIER.json")
    files = glob.glob(pattern, recursive=True)
    
    logger.info(f"Found {len(files)} modified MWA risk classifier files")
    
    results = []
    for file_path in files:
        logger.info(f"Processing: {file_path}")
        result = extract_score_and_mvr_from_file(file_path)
        if result:
            results.append(result)
            logger.info(f"Extracted - Certificate: {result['certificate_number']}, Score: {result['score']}, "
                       f"Violations: {result['original_violation_count']} -> {result['deduplicated_violation_count']} unique")
        else:
            logger.warning(f"Failed to extract data from: {file_path}")
    
    return results

def save_results_to_json(results, output_file):
    """
    Save the extracted results to a JSON file.
    
    Args:
        results (list): List of extracted data dictionaries
        output_file (str): Output file path
    """
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        logger.info(f"Results saved to: {output_file}")
    except Exception as e:
        logger.error(f"Error saving results to {output_file}: {e}")

def save_results_to_csv(results, output_file):
    """
    Save the extracted results to a CSV file (score and violation counts for easy analysis).
    
    Args:
        results (list): List of extracted data dictionaries
        output_file (str): Output file path
    """
    try:
        import csv
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['CertificateNumber', 'Score', 'OriginalViolations', 'UniqueViolations', 'DuplicatesRemoved', 'FilePath'])
            for result in results:
                duplicates_removed = result['original_violation_count'] - result['deduplicated_violation_count']
                writer.writerow([
                    result['certificate_number'],
                    result['score'],
                    result['original_violation_count'],
                    result['deduplicated_violation_count'],
                    duplicates_removed,
                    result['file_path']
                ])
        logger.info(f"CSV results saved to: {output_file}")
    except Exception as e:
        logger.error(f"Error saving CSV results to {output_file}: {e}")

def main():
    """Main function to run the extraction process."""
    # Base directory containing the data
    base_dir = "data_sources_batch3"
    
    # Check if directory exists
    if not os.path.exists(base_dir):
        logger.error(f"Directory {base_dir} does not exist")
        return
    
    # Process all files
    results = process_all_modified_files(base_dir)
    
    if not results:
        logger.warning("No results extracted")
        return
    
    # Save results
    output_json = "extracted_score_and_mvr_results_deduplicated.json"
    output_csv = "extracted_scores_deduplicated.csv"
    
    save_results_to_json(results, output_json)
    save_results_to_csv(results, output_csv)
    
    # Print summary
    logger.info(f"Processing complete. Extracted data from {len(results)} files.")
    logger.info(f"Results saved to {output_json} and {output_csv}")
    
    # Print some statistics
    scores = [r['score'] for r in results if r['score'] is not None]
    mvr_count = sum(1 for r in results if r['mvr_results'] is not None)
    total_original_violations = sum(r['original_violation_count'] for r in results)
    total_unique_violations = sum(r['deduplicated_violation_count'] for r in results)
    total_duplicates_removed = total_original_violations - total_unique_violations
    
    logger.info(f"Files with scores: {len(scores)}")
    logger.info(f"Files with MVR results: {mvr_count}")
    logger.info(f"Total original violations: {total_original_violations}")
    logger.info(f"Total unique violations after deduplication: {total_unique_violations}")
    logger.info(f"Total duplicates removed: {total_duplicates_removed}")
    
    if scores:
        logger.info(f"Score range: {min(scores)} - {max(scores)}")

if __name__ == "__main__":
    main() 