import streamlit as st
from loguru import logger
from streamlit_feedback import streamlit_feedback
from streamlit_chat import message
import uuid
import json
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
from agents.workflow import graph
from agents.state import AgentState

# ------------------------- Streamlit UI -------------------------
try:
    st.title(":speech_balloon: Underwriting Assist")
    
    with st.sidebar:
        app_numbers = ['F11248249', 'F14612930', 'F33529572', 'F39414621', 'F41307451', "9217523", "9217639", "9217744", "9217937", "9217938", "9218062", "9218159", "9222406", "9222517","9230523"]
        application_number = st.sidebar.selectbox('Enter application number:', app_numbers)
        
        
    if "state" not in st.session_state:
        st.session_state.state = AgentState()
    
    if "messages" not in st.session_state:
        st.session_state.messages = []
        
    if 'session_id' not in st.session_state:
        st.session_state.session_id = str(uuid.uuid4())
        
    if 'user_id' not in st.session_state:
        st.session_state.user_id = "user_123"
    
    # Chat input for the question
    question = st.chat_input("Ask your question here...")
    
    
    
    # Function to display chat messages
    def display_chat_messages():
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                # if message["role"] == "user":
                    # message(message["content"], is_user=True)
                # else:
                    # message(message["content"])
                st.markdown(message["content"])
    
    
    
    if question:
        st.session_state.state.application_number = application_number
        st.session_state.state.input_message = question
        st.session_state.state.session_id = st.session_state.session_id
        st.session_state.state.user_id = st.session_state.user_id
        st.session_state.messages.append({"role": "user", "content": question})
        
        # Display chat messages from history
        display_chat_messages()
        
            
        
    # Create placeholders for dynamic updates
        # status_placeholder = st.empty()
        # step_status_placeholder = st.empty()
    
        def update_progress(state):
            # with status_placeholder.container():
                # st.write(f"➡️ **Current Step:** {state.current_step}")
        
                # Show completed steps 
                # for step in state.steps_completed:
           
            # st.session_state.messages.append({"role": "assistant", "content": f":white_check_mark: **{st.session_state.state.current_step}** "})
            # st.session_state.steps_completed.append(f":white_check_mark: **{st.session_state.state.current_step}** ")
            st.write(f":white_check_mark: **{st.session_state.state.current_step}** ")
        
                # Show loading step if not completed
                # if state.current_step and state.current_step not in state.steps_completed:
                #     st.write(f"⏳ {state.current_step} in progress...")S
     
        previous_session_thoughts = []
      # Stream the graph flow
        for output in graph.stream(st.session_state.state):
            with st.spinner("Processing... Please wait."):
                # logger.info(f"Output: {output}")
                for value in output.values():
                    # logger.info(f"Value: {value}")
                    st.session_state.state.ai_thought = value.get('ai_thought', None)
                    st.session_state.state.ai_response = value.get('ai_response', None)
                    st.session_state.state.confidence_score = value.get('confidence_score', None)
                    st.session_state.state.current_step = value.get('current_step', None)
                    st.session_state.state.steps_completed = value.get('steps_completed', None)
                    st.session_state.state.interim_response = value.get('interim_response', None)
                    
                    if st.session_state.state.ai_thought is not None and st.session_state.state.ai_thought not in previous_session_thoughts:
                        # with st.chat_message("assistant"):
                        with st.expander(":thought_balloon: **Thought**"):
                            st.markdown(st.session_state.state.ai_thought)
                    update_progress(st.session_state.state)
                    if st.session_state.state.ai_thought not in previous_session_thoughts:
                        previous_session_thoughts.append(st.session_state.state.ai_thought)
                        # st.session_state.thoughts.append(st.session_state.state.ai_thought)
                        
            # stat = output.get('state', None
            # if state:
          
                # st.session_state.state = state
            
        # logger.info(f"Session thoughts: {previous_session_thoughts}")
        # Final update after completion
        # update_progress(st.session_state.state)
    
    
    
        
    # ---------------------- Display Assistant Thoughts ----------------------
    # if st.session_state.state.ai_thought is not None:
    #     # with st.chat_message("assistant"):
    #     with st.expander("💭 **Thought**"):
    #         st.markdown(st.session_state.state.ai_thought)
    
    # ---------------------- Display Final Answer ----------------------
    # Custom CSS to resize feedback buttons
    
    if st.session_state.state.ai_response is not None:
        # st.subheader("🤖 Answer")
        with st.chat_message("assistant"):
            st.markdown(st.session_state.state.ai_response)
            st.session_state.messages.append({"role": "assistant", "content": st.session_state.state.ai_response})
            
            if st.session_state.state.confidence_score is not None:
                confidence = int(st.session_state.state.confidence_score.split('%')[0])
                logger.debug(f"Confidence_Score: {confidence}")
                # st.caption(f"Confidence Score: {st.session_state.state.confidence_score}")
                # confidence = st.session_state.state.confidence_score.split("%")[0]
                # logger.debug(f"Score: {confidence} Type: {type(confidence)}")
                # Determine color and label based on confidence score
                if confidence >= 85 :
                    color = "green"
                    # label = "High"
                elif confidence >= 70:
                    color = "orange"
                    # label = "Medium"
                else:
                    color = "red"
                    # label = "Low"
                
                st.caption(f"Confidence Score: :{color}[{confidence}%]")
                # st.progress(int(confidence))
                # st.markdown(custom_css, unsafe_allow_html=True)
                # feedback = streamlit_feedback(
                #     feedback_type="thumbs",  # Apply the selected feedback style
                #     optional_text_label="How helpful was this answer?",  # Allow for additional comments
                #     align="flex-start",
                # )
    else:
        if st.session_state.state.interim_response is not None:
            try:
                response_json = json.loads(st.session_state.state.interim_response)
            except (json.JSONDecodeError, TypeError) as e:
                logger.error(f"Error parsing interim_response as JSON: {e}")
                response_json = None
            if response_json and "Recommendation" in response_json:
                with st.chat_message("assistant"):
                    st.markdown(response_json["Recommendation"])
                    st.session_state.messages.append({"role": "assistant", "content": response_json["Recommendation"]})
                    
except Exception as e:
    logger.error(f"Error occurred: {str(e)}")
    with st.chat_message("assistant"):
        st.markdown("Oops! Something went wrong on our end. Try again in a moment.")
        