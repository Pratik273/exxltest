# 🛠️ Python 3.12 venv + no_proxy Setup Guide (Ubuntu + EC2)

A quick reference for setting up Python 3.12 virtual environments and configuring no-proxy for AWS EC2 environments (e.g. when using Bedrock or Metadata services).

---

## 📌 Part 0: Screen Session Management

**💡 Why Use Screen?** When you run long tasks over SSH, your connection can drop due to network issues, timeouts, or closing your laptop. This kills your running processes. Screen creates persistent sessions that survive SSH disconnections - your tasks keep running even when you're disconnected!

### ✅ Start a New Screen Session
```bash
screen -S mysession
```

### ✅ Run Your Code in the Screen Session
Once inside the screen session, run your long-running commands or scripts:
```bash
# Navigate to your project directory
cd /path/to/your/project

# Activate your virtual environment if needed
source venv/bin/activate

# Run your Python script or any long-running process
python your_script.py
# or
python -m your_module
```

### ✅ Detach from Screen Session
Press `Ctrl + A`, then `D` to detach from the current screen session while keeping it running in the background.

### ✅ List All Screen Sessions
```bash
screen -ls
```

### ✅ Reattach to a Screen Session
```bash
screen -r mysession
```
### ✅ Check Screen Logs & Output

**💡 Why Check Logs?** When you reattach to a screen session, you'll see the current output. But what if you want to see what happened while you were detached? Or save logs for later review?

#### Method 1: View Recent Output in Screen Session
When you're attached to a screen session, you can scroll back to see recent output:
1. **Scroll back:** Press `Ctrl + A`, then `[` to enter copy mode
2. **Navigate:** Use arrow keys or `Page Up/Down` to scroll through recent output
3. **Exit scroll mode:** Press `Esc` or `q`

#### Method 2: Enable Screen Logging (Recommended)
Start screen with logging enabled to automatically save all output:

**Option A: Start screen with logging enabled**
```bash
screen -L -S mysession
```
This creates a log file `screenlog.0` in your current directory that captures all output.

**Option B: Enable logging in an existing screen session**
1. While attached to your screen session, press `Ctrl + A`, then `H`
2. Screen will display "Creating logfile 'screenlog.0'" 
3. All subsequent output will be logged to the file

**Option C: Custom log file name**
```bash
# Start with custom log file name
screen -L -Logfile myproject.log -S mysession

# Or set log file name in existing session
# Press Ctrl + A, then type: :logfile myproject.log
# Then press Ctrl + A, then H to start logging
```

**View your logs:**
```bash
# View logs in real-time (while your task is running)
tail -f screenlog.0

# View complete log file
cat screenlog.0
less screenlog.0
```

### ✅ Kill a Screen Session
```bash
screen -X -S mysession quit
```

### 🛡️ SSH Disconnection Protection
**The key benefit:** Screen sessions run independently on the server - your processes continue running whether you're attached or detached, even if:
- Your SSH connection drops
- Your laptop goes to sleep
- Your internet connection is lost
- You close your terminal

**Scenario 1 - Detached workflow:**
1. SSH into your server
2. Start a screen session: `screen -S long_task`
3. Run your long-running Python script
4. Detach: `Ctrl+A, D`
5. Close your laptop/disconnect - your task keeps running!
6. Later, SSH back in and reattach: `screen -r long_task`

**Scenario 2 - Watching logs (staying attached):**
1. SSH into your server
2. Start a screen session: `screen -S long_task`
3. Run your long-running Python script
4. Stay attached to watch logs in real-time
5. If SSH disconnects unexpectedly - **your task keeps running!**
6. SSH back in and reattach: `screen -r long_task`
7. You'll see all the logs that accumulated while disconnected

**🔑 Key Point:** Screen sessions survive SSH disconnections whether you're attached or detached to them!

---

## 📌 Part 1: Set `no_proxy` for AWS Metadata & Services

### ✅ Temporary (Current Shell Only)
```bash
export https_proxy="http://epot.corp.exlservice.com:8080"
export http_proxy="http://epot.corp.exlservice.com:8080"
export no_proxy=169.254.169.254,.amazonaws.com,ucgithub.exlservice.com
export NO_PROXY=169.254.169.254,.amazonaws.com,ucgithub.exlservice.com
```

### ✅ Permanent (Across Reboots & Shells)
Append this to your shell profile (e.g., `~/.bashrc`, `~/.bash_profile`, or `~/.zshrc`):
```bash
export no_proxy=169.254.169.254,.amazonaws.com,ucgithub.exlservice.com
export NO_PROXY=169.254.169.254,.amazonaws.com,ucgithub.exlservice.com
```

Then reload:
```bash
source ~/.bashrc
```

---

## 📌 Part 2: Install Python 3.12 from Source

### ✅ Install Build Dependencies
```bash
sudo apt update
sudo apt install -y \
  make build-essential libssl-dev zlib1g-dev libbz2-dev \
  libreadline-dev libsqlite3-dev wget curl llvm \
  libncursesw5-dev xz-utils tk-dev libxml2-dev libxmlsec1-dev \
  libffi-dev liblzma-dev
```

### ✅ Download & Build Python 3.12
```bash
cd /usr/src
sudo wget https://www.python.org/ftp/python/3.12.3/Python-3.12.3.tgz
sudo tar xzf Python-3.12.3.tgz
cd Python-3.12.3
sudo ./configure --enable-optimizations --with-ensurepip=install
sudo make -j$(nproc)
sudo make altinstall
```

### ✅ Verify Installation
```bash
/usr/local/bin/python3.12 --version
```

---

## 📌 Part 3: Create and Use a Virtual Environment

### ✅ Create venv
```bash
/usr/local/bin/python3.12 -m venv myenv
```

### ✅ Activate venv
```bash
source venv/bin/activate
```

### ✅ Install Packages
```bash
python -m pip install --upgrade pip
python -m pip install <your-package>
```

### ✅ Deactivate venv
```bash
deactivate
```

---

## ✅ Bonus: Confirm You're Using the Correct Pip and Python
```bash
which python
which pip
```

Expected output should point to:
```
/path/to/myenv/bin/python
/path/to/myenv/bin/pip
```

---

## 📎 Notes

- `169.254.169.254` is the AWS metadata IP — essential for EC2 IAM role-based credential access.
- `.amazonaws.com` helps bypass proxy for AWS APIs (e.g. Bedrock, S3, STS).
- Use `no_proxy` and not just `http_proxy` for internal metadata access to succeed.

---