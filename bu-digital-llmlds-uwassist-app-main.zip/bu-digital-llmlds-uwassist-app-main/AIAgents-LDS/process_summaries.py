#!/usr/bin/env python3
"""
Script to process Claude summary results and generate comprehensive summaries.
This script reads the Excel file, separates demographics and medical summaries,
combines them, and generates comprehensive summaries using Claude.
"""

import pandas as pd
import json
import re
from typing import Dict, List, Optional
import os
import sys

# Add the current directory to the path to import config and utils
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    from config import *
    from utils.summaries_claude_caller import generate_comprehensive_summary_with_retries
except ImportError as e:
    print(f"Import error: {e}")
    print("Please ensure all required packages are installed:")
    print("pip install -r requirements_summaries.txt")
    sys.exit(1)

def extract_answer_from_claude_response(claude_answer: str) -> str:
    """Extract the actual answer content from Claude's JSON response."""
    try:
        # Parse the JSON response
        response_data = json.loads(claude_answer)
        return response_data.get("Answer", "")
    except (json.JSONDecodeError, KeyError):
        # If JSON parsing fails, try to extract content between <!-- Section: --> tags
        sections = re.findall(r'<!-- Section: ([^>]+) -->\s*(.*?)(?=<!-- Section:|$)', 
                             claude_answer, re.DOTALL)
        if sections:
            return "\n\n".join([f"<!-- Section: {section} -->\n{content.strip()}" 
                               for section, content in sections])
        return claude_answer

def combine_summaries(demo_summary: str, med_summary: str) -> str:
    """Manually combine demographics and medical summaries."""
    combined = f"""<!-- Combined Summary -->

<!-- Demographics Summary -->
{demo_summary}

<!-- Medical Summary -->
{med_summary}"""
    return combined

def generate_comprehensive_summary(demo_summary: str, med_summary: str) -> str:
    """Generate comprehensive summary using Claude with retry logic and the specified system prompt."""
    
    print("  Generating comprehensive summary using Claude with retry logic...")
    
    # Use the retry-enabled function
    comprehensive_summary = generate_comprehensive_summary_with_retries(
        demo_summary=demo_summary,
        med_summary=med_summary,
        system_prompt=SYSTEM_PROMPT,
        user_prompt_template=USER_PROMPT_TEMPLATE,
        max_retries=3
    )
    
    if comprehensive_summary:
        print("  ✓ Comprehensive summary generated successfully")
        return comprehensive_summary
    else:
        print("  ✗ Failed to generate comprehensive summary after all retries")
        return "Error: Failed to generate comprehensive summary after all retry attempts"

def process_excel_file(input_file: str, output_file: str, api_key: str) -> None:
    """Process the Excel file and generate the required columns."""
    
    print(f"Reading input file: {input_file}")
    df = pd.read_excel(input_file)
    
    print(f"Input file shape: {df.shape}")
    print(f"Columns: {df.columns.tolist()}")
    
    # Get unique application numbers
    app_numbers = df['ApplicationNumber'].unique()
    print(f"Found {len(app_numbers)} unique application numbers")
    
    # Initialize results list
    results = []
    
    # Process each application
    for app_num in app_numbers:
        print(f"Processing application {app_num}...")
        
        # Get subsets for this application
        app_data = df[df['ApplicationNumber'] == app_num]
        
        # Find demographics summary (subset 1)
        demo_data = app_data[app_data['Subset'] == 1]
        if demo_data.empty:
            print(f"  Warning: No demographics data (subset 1) found for application {app_num}")
            demo_summary = "No demographics data available"
        else:
            demo_summary = extract_answer_from_claude_response(demo_data.iloc[0]['ClaudeAnswer'])
        
        # Find medical summary (subset 2)
        med_data = app_data[app_data['Subset'] == 2]
        if med_data.empty:
            print(f"  Warning: No medical data (subset 2) found for application {app_num}")
            med_summary = "No medical data available"
        else:
            med_summary = extract_answer_from_claude_response(med_data.iloc[0]['ClaudeAnswer'])
        
        # Combine summaries manually
        combined_summary = combine_summaries(demo_summary, med_summary)
        
        # Generate comprehensive summary using Claude with retry logic
        comprehensive_summary = generate_comprehensive_summary(demo_summary, med_summary)
        
        # Add to results
        results.append({
            'ApplicationNumber': app_num,
            'DemographicsSummary': demo_summary,
            'MedicalSummary': med_summary,
            'CombinedSummary': combined_summary,
            'ComprehensiveSummary': comprehensive_summary
        })
        
        print(f"  Completed application {app_num}")
    
    # Create output DataFrame
    output_df = pd.DataFrame(results)
    
    # Save to Excel
    print(f"Saving results to: {output_file}")
    output_df.to_excel(output_file, index=False)
    print(f"Successfully processed {len(results)} applications")
    print(f"Output saved to: {output_file}")

def main():
    """Main function to run the script."""
    
    # Check if API key is provided
    api_key = get_api_key()
    if not api_key:
        print("Error: ANTHROPIC_API_KEY environment variable not set")
        print("Please set your Anthropic API key:")
        print("export ANTHROPIC_API_KEY='your-api-key-here'")
        sys.exit(1)
    
    # File paths
    input_file = INPUT_FILE
    output_file = OUTPUT_FILE
    
    # Check if input file exists
    if not os.path.exists(input_file):
        print(f"Error: Input file '{input_file}' not found")
        print(f"Current working directory: {os.getcwd()}")
        sys.exit(1)
    
    try:
        process_excel_file(input_file, output_file, api_key)
        print("Script completed successfully!")
    except Exception as e:
        print(f"Error running script: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
