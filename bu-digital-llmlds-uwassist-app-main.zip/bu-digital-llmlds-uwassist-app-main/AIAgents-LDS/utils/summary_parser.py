#!/usr/bin/env python3
"""
Utility functions for parsing markdown summaries with hidden headers.
Used for validating sections and combining demographics and medical summaries.
"""

import re
from typing import Dict, List, Optional, Callable
from loguru import logger
import json
import time
import random
from botocore.exceptions import ClientError


def parse_summary_sections(summary_text: str) -> Dict[str, str]:
    """
    Parse a summary text with hidden markdown headers to extract sections.
    
    Args:
        summary_text: The summary text containing hidden markdown headers
        
    Returns:
        Dictionary mapping section names to their content
    """
    if not summary_text:
        logger.warning("Empty summary text provided")
        return {}
    
    sections = {}
    
    # Pattern to match hidden markdown headers: <!-- Section: <section_name> -->
    section_pattern = r'<!-- Section: ([^>]+) -->'
    
    # Split text by hidden headers
    parts = re.split(section_pattern, summary_text)
    
    if len(parts) < 2:
        logger.warning("No hidden markdown headers found in summary")
        return {"content": summary_text.strip()}
    
    # First part is content before any section header (usually empty)
    current_section = None
    
    for i in range(1, len(parts), 2):
        if i + 1 < len(parts):
            section_name = parts[i].strip()
            section_content = parts[i + 1].strip()
            sections[section_name] = section_content
            logger.debug(f"Extracted section: {section_name}")
    
    return sections


def validate_required_sections(sections: Dict[str, str], required_sections: List[str]) -> tuple[bool, List[str]]:
    """
    Validate that all required sections are present in the parsed sections.
    
    Args:
        sections: Dictionary of parsed sections
        required_sections: List of required section names
        
    Returns:
        Tuple of (is_valid, missing_sections)
    """
    missing_sections = []
    
    for required_section in required_sections:
        if required_section not in sections:
            missing_sections.append(required_section)
    
    is_valid = len(missing_sections) == 0
    
    if not is_valid:
        logger.warning(f"Missing required sections: {missing_sections}")
    else:
        logger.info("All required sections found")
    
    return is_valid, missing_sections


def combine_demographics_and_medical_summaries(demographics_summary: str, medical_summary: str) -> str:
    """
    Combine demographics and medical summaries into an overall summary.
    Merges Additional Notes sections from both summaries.
    
    Args:
        demographics_summary: Demographics summary with hidden headers
        medical_summary: Medical summary with hidden headers
        
    Returns:
        Combined overall summary
    """
    logger.info("Combining demographics and medical summaries")
    
    # Parse both summaries
    demographics_sections = parse_summary_sections(demographics_summary)
    medical_sections = parse_summary_sections(medical_summary)
    
    # Define expected sections
    demographics_expected = ["Demographics", "MVR", "Miscellaneous", "Additional Notes"]
    medical_expected = ["Physical Metrics", "Medical History", "Substance Use", "Miscellaneous", "Additional Notes"]
    
    # Validate sections
    demo_valid, demo_missing = validate_required_sections(demographics_sections, demographics_expected)
    medical_valid, medical_missing = validate_required_sections(medical_sections, medical_expected)
    
    if demographics_sections:
        if not demo_valid :
            logger.warning(f"Demographics summary missing sections: {demo_missing}")
    if medical_sections:
        if not medical_valid:
            logger.warning(f"Medical summary missing sections: {medical_missing}")
    
    # Combine sections
    combined_sections = {}
    
    # Add sections from demographics summary
    for section_name in ["Demographics", "MVR"]:
        if section_name in demographics_sections:
            combined_sections[section_name] = demographics_sections[section_name]
    
    # Add sections from medical summary
    for section_name in ["Physical Metrics", "Medical History", "Substance Use"]:
        if section_name in medical_sections:
            combined_sections[section_name] = medical_sections[section_name]
    
    # Combine Additional Notes from both summaries
    combined_additional_notes = []
    combined_miscellaneous = []

    if "Miscellaneous" in medical_sections and medical_sections["Miscellaneous"]:
        combined_miscellaneous.append(medical_sections["Miscellaneous"])

    if "Miscellaneous" in demographics_sections and demographics_sections["Miscellaneous"]:
        combined_miscellaneous.append(demographics_sections["Miscellaneous"])

    if combined_miscellaneous:
        combined_sections["Miscellaneous"] = "\n".join(combined_miscellaneous)

    if "Additional Notes" in demographics_sections and demographics_sections["Additional Notes"]:
        combined_additional_notes.append("**From Demographics:**")
        combined_additional_notes.append(demographics_sections["Additional Notes"])
    
    if "Additional Notes" in medical_sections and medical_sections["Additional Notes"]:
        combined_additional_notes.append("**From Medical:**")
        combined_additional_notes.append(medical_sections["Additional Notes"])
    
    if combined_additional_notes:
        combined_sections["Additional Notes"] = "\n".join(combined_additional_notes)
    
    # Build the final combined summary
    combined_summary_parts = []
    
    # Order sections logically
    section_order = [
        "Demographics",
        "Physical Metrics", 
        "Medical History",
        "Substance Use",
        "MVR",
        "Miscellaneous",
        "Additional Notes"
    ]
    
    for section_name in section_order:
        if section_name in combined_sections:
            combined_summary_parts.append(section_name)
            combined_summary_parts.append(combined_sections[section_name])
            combined_summary_parts.append("")  # Empty line between sections
    
    combined_summary = "\n".join(combined_summary_parts).strip()
    
    logger.info("Successfully combined demographics and medical summaries")
    return combined_summary


def extract_section_content(summary_text: str, section_name: str) -> Optional[str]:
    """
    Extract content for a specific section from a summary with hidden headers.
    
    Args:
        summary_text: The summary text containing hidden markdown headers
        section_name: Name of the section to extract
        
    Returns:
        Section content or None if not found
    """
    sections = parse_summary_sections(summary_text)
    return sections.get(section_name)


def format_section_with_header(section_name: str, content: str) -> str:
    """
    Format a section with its hidden markdown header.
    
    Args:
        section_name: Name of the section
        content: Content of the section
        
    Returns:
        Formatted section with header
    """
    return f"<!-- Section: {section_name} -->\n{content}"


def get_section_names(summary_text: str) -> List[str]:
    """
    Get all section names from a summary with hidden headers.
    
    Args:
        summary_text: The summary text containing hidden markdown headers
        
    Returns:
        List of section names found
    """
    sections = parse_summary_sections(summary_text)
    return list(sections.keys())


def call_llm_with_section_validation(
    llm_function: Callable,
    system_prompt: str,
    user_prompt: str,
    required_sections: List[str],
    max_retries: int = 3,
    summary_type: str = "summary"
) -> Optional[str]:
    """
    Call LLM with retry logic specifically for summary generation with section validation.
    
    Args:
        llm_function: The LLM function to call (e.g., invoking_claude)
        system_prompt: System prompt for the LLM
        user_prompt: User prompt for the LLM
        required_sections: List of required section names to validate
        max_retries: Maximum number of retry attempts
        summary_type: Type of summary for logging (e.g., "demographics", "medical")
        
    Returns:
        Valid summary text with all required sections or None if all retries failed
    """
    retries = 0
    
    while retries <= max_retries:
        try:
            logger.info(f"Generating {summary_type} summary (attempt {retries + 1}/{max_retries + 1})")
            
            # Call the LLM
            response_text = llm_function(system_prompt, user_prompt)
            
            if not response_text:
                logger.warning(f"Empty response from LLM on attempt {retries + 1}")
                retries += 1
                continue
            
            # Parse the response to extract the answer if it's JSON
            summary_content = response_text
            if response_text.strip().startswith('{'):
                try:
                    json_response = json.loads(response_text)
                    if "Answer" in json_response:
                        summary_content = json_response["Answer"]
                    else:
                        logger.warning("No 'Answer' field found in JSON response")
                        retries += 1
                        continue
                except json.JSONDecodeError:
                    logger.warning("Invalid JSON response, treating as plain text")
                    summary_content = response_text
            
            # Validate sections
            sections = parse_summary_sections(summary_content)
            is_valid, missing_sections = validate_required_sections(sections, required_sections)
            
            if is_valid:
                logger.info(f"✅ {summary_type.capitalize()} summary validation passed on attempt {retries + 1}")
                return summary_content
            else:
                logger.warning(f"❌ {summary_type.capitalize()} summary validation failed on attempt {retries + 1}")
                logger.warning(f"Missing sections: {missing_sections}")
                logger.warning(f"Found sections: {list(sections.keys())}")
                
                # Add guidance to the user prompt for retry
                if retries < max_retries:
                    user_prompt += f"\n\nIMPORTANT: Previous attempt was missing these sections: {missing_sections}. Please ensure ALL required sections are included with proper hidden markdown headers: {required_sections}"
                
                retries += 1
                
        except ClientError as e:
            if e.response['Error']['Code'] in ['ThrottlingException', 'TooManyRequestsException']:
                wait = (2 ** retries) + random.uniform(0, 1)  # exponential backoff + jitter
                logger.warning(f"Throttled. Retrying in {wait:.2f} seconds...")
                time.sleep(wait)
                retries += 1
            else:
                logger.error(f"ClientError occurred while calling LLM: {e}")
                retries += 1
                
        except Exception as e:
            logger.error(f"Error occurred while calling LLM: {e}")
            retries += 1
    
    logger.error(f"❌ Failed to generate valid {summary_type} summary after {max_retries + 1} attempts")
    return None


# Test function for development
def test_parser():
    """Test the parser functions with sample data."""
    sample_demographics = """
    <!-- Section: Demographics -->
    • Age: 46
    • Gender: Male
    • Occupation: Other
    • US Citizen: Yes
    
    <!-- Section: MVR -->
    • MVR Status: Cancelled (Status 5)
    • LexisNexis Clear indicated
    
    <!-- Section: Miscellaneous -->
    • Coverage: MyLife Term Insurance 20 Year Option
    • Base Amount: $300,000
    
    <!-- Section: Additional Notes -->
    • Recommend underwriter review of cancelled driving status
    """
    
    sample_medical = """
    <!-- Section: Physical Metrics -->
    • Height: 5'7" (67 inches)
    • Weight: 185 lbs
    • BMI: 29.0 (Overweight)
    
    <!-- Section: Medical History -->
    • Lab Tests: Glucose: 103 mg/dL (Elevated)
    • Diagnosis: Melanocytic nevi of scalp and neck
    
    <!-- Section: Substance Use -->
    • Tobacco user - current
    • Marijuana use - weekly THC usage
    
    <!-- Section: Additional Notes -->
    • Follow-up needed on recent skin lesion pathology
    • Monitor elevated glucose levels
    """
    
    print("Testing parser functions...")
    
    # Test parsing
    demo_sections = parse_summary_sections(sample_demographics)
    medical_sections = parse_summary_sections(sample_medical)
    
    print(f"Demographics sections: {list(demo_sections.keys())}")
    print(f"Medical sections: {list(medical_sections.keys())}")
    
    # Test combining
    combined = combine_demographics_and_medical_summaries(sample_demographics, sample_medical)
    print("\nCombined summary:")
    print(combined)
    
    return combined


if __name__ == "__main__":
    test_parser() 