from transformers import AutoTokenizer, AutoModel
import torch

# Load Model
model_name = "BAAI/bge-large-en"
# model_name = "sentence-transformers/all-MiniLM-L6-v2"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModel.from_pretrained(model_name)

# Function to generate embeddings
def get_embedding(text):
    inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True)
    with torch.no_grad():
        embedding = model(**inputs).last_hidden_state[:, 0, :].squeeze().tolist()
    return embedding


if __name__ == "__main__":
    # Test Example
    sample_text = "Hello from AWS Cloud9!"
    embedding = get_embedding(sample_text)
    
    print("Generated Embedding (First 5 Values):", embedding[:5])