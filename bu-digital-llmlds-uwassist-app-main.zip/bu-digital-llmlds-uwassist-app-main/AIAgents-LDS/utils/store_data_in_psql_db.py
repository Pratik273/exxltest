from loguru import logger
from typing import List, Dict, Any
from datetime import datetime
import os
import sys
import json
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from utils.embeddings import get_embedding

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
from scripts.convert_MIB_excel_to_json.main import mib_parsing
from scripts.database.check_db_conn import connect_to_db


def application_exists(cur, conn, certificate_number):
    """
    Check if an application/certificate number already exists in the database.
    
    Args:
        certificate_number: The certificate number to check
        
    Returns:
        bool: True if the certificate number exists, False otherwise
    """
    try:
        
        # Execute query to check if certificate number exists
        cur.execute(
            "SELECT EXISTS(SELECT 1 FROM applications WHERE application_number = %s)",
            (certificate_number,)
        )
        
        # Fetch result (will be a tuple with one boolean value)
        exists = cur.fetchone()[0]
        
        # # Close cursor and connection
        # cur.close()
        # conn.close()
        
        return exists
        
    except (Exception, psycopg2.DatabaseError) as error:
        print(f"Database error: {error}")
        return False


def fetch_data_source_id(cur, conn, data_source_name):
    try:
        cur.execute(
            "SELECT data_source_id FROM data_sources WHERE name = %s;",
            (data_source_name,)
        )
        data_source_id = cur.fetchone()
        logger.debug(f"Successful in fetching data source id for {data_source_name}")
        return data_source_id[0]
    except Exception as e:
        logger.error(f"Error occurred while fetching data source id: {e}")
        conn.rollback()
        return None
        
def fetch_application_id(cur, conn, application_number):
    try:
        cur.execute(
            "SELECT application_id FROM applications WHERE application_number = %s;",
            (application_number,)
        )
        application_id = cur.fetchone()
        logger.debug(f"Got Application Id for application number : {application_number}")
        if application_id is not None:
            return application_id[0]
        else:
            return None
    except Exception as e:
        logger.error(f"Error occurred while fetching application id: {e}")
        conn.rollback()
        return None

def store_data_in_applications_table(cur, conn, data: List[Dict[str, Any]]=None, file_format=None, app_number=None):
    if not app_number and data:
        application_number = data['application_number']
    else:
        application_number = app_number
    if not file_format and data:
        app_type = data['type']
    else:
        app_type = file_format
    status = "AVAILABLE"
    try:
        cur.execute(
            "INSERT INTO applications (application_number, status, type) VALUES (%s, %s, %s);",
            (application_number, status, app_type)
        )
        conn.commit()
        logger.debug(f"Successful in storing {application_number} to applications table")
    except Exception as e:
        logger.error(f"Error occurred while inserting data: {e}")
        conn.rollback()

def store_data_in_data_sources_table(cur, conn):
    data_sources = ["MIB", "Part A", "Part B", "Lab Tests", "Rx", "Dx", "MVR", "Other"]
    # data_sources = ["Dx"]
    for data_source in data_sources:
        try:
            cur.execute(
                "INSERT INTO data_sources (name) VALUES (%s);",
                (data_source,)
            )
            conn.commit()
            logger.debug(f"Data source {data_source} inserted successfully")
        except Exception as e:
            logger.error(f"Error occurred while inserting data: {e}")
            conn.rollback()

def store_data_in_pages_table(cur, conn, application_number, page_data: Dict[str, Any]):
    try:
        # Get application ID
        application_id = fetch_application_id(cur, conn, application_number)
        if not application_id:
            logger.error(f"Application ID not found for application number: {page_data['application_number']}")
            return False
            
        # Process page categories
        categories = page_data.get('categories', [])
        if not categories:
            logger.warning(f"No categories found for page {page_data.get('page_number')}")
            
        # Format extracted date properly
        extracted_date = page_data.get('extracted_date')
        if extracted_date:
            try:
                # Convert string to Python date object
                extracted_date = datetime.strptime(extracted_date, "%Y-%m-%d").date()
            except AttributeError:
                logger.warning(f"Invalid date format for extracted_date: {extracted_date}")
                extracted_date = None
        else:
            extracted_date = None
                
        # Get raw content and validate
        raw_content = page_data.get('extracted_content', '')
        if not raw_content:
            logger.warning(f"Empty content for page {page_data.get('page_number')}")
            
        success = True
        # Process each category
        for category in categories:
            data_source_id = fetch_data_source_id(cur, conn, category)
            if not data_source_id:
                logger.error(f"Data source ID not found for category: {category}")
                continue
                
            # Generate embeddings for content
            try:
                text_input = json.dumps(raw_content, ensure_ascii=False)
                embedding = get_embedding(text_input)
            except Exception as e:
                logger.error(f"Failed to generate embeddings: {e}")
                continue
                
            # Insert data into pages table
            try:
                cur.execute(
                    "INSERT INTO pages (application_id, data_source_id, page_number, extracted_date, raw_content, embedding) "
                    "VALUES (%s, %s, %s, %s, %s, %s);",
                    (application_id, data_source_id, page_data.get('page_number'), 
                     extracted_date, text_input, embedding)
                )
                conn.commit()
                logger.debug(f"Successfully inserted page {page_data.get('page_number')} with category {category}")
            except Exception as e:
                logger.error(f"Error inserting page data: {e}")
                conn.rollback()
                success = False
                
        return success
                
    except Exception as e:
        logger.error(f"Unexpected error in store_data_in_pages_table: {e}")
        conn.rollback()
        return False
        

def store_mib_code_meanings(cur, conn, application_number, mib_code):
    application_id = fetch_application_id(cur, conn, application_number)
    
    if not application_id:
        logger.error(f"Application ID not found for application number: {application_number}")
        return False
    meaning = mib_parsing(mib_code)
    meaning_text = json.dumps(meaning, ensure_ascii=False)
    try:
        cur.execute(
            "INSERT INTO mib_codes (application_id, mib_code, meaning) VALUES (%s, %s, %s);",
            (application_id, mib_code, meaning_text)
        )
        conn.commit()
        logger.debug(f"Successfully stored MIB code {mib_code} meaning for application {application_id} in mib_codes table")
        return True
    except Exception as e:
        logger.error(f"Error occurred while inserting data: {str(e)}")
        conn.rollback()
        return False


def store_data_in_postgres_db(data: List[Dict[str, Any]]):
    """
    Store application data in PostgreSQL database with proper transaction handling.
    
    Args:
        data: List of dictionaries containing application data
    
    Returns:
        bool: True if successful, False if any operation failed
    """
    logger.debug("Storing data in PostgreSQL database...")
    cur, conn = None, None
    success = False
    
    try:
        cur, conn = connect_to_db()
        if not cur or not conn:
            logger.error("Failed to establish database connection")
            return False
            
        # Start transaction
        conn.autocommit = False
        
        application_number = data["application_number"]
        # Store application data
        if application_exists(cur, conn, application_number):
                logger.debug(f"Application Number: {application_number} already exists")
        else:
            store_data_in_applications_table(cur, conn, data)
            
        
        
        # cur.execute("SELECT application_id FROM applications WHERE application_number = 'F14612930';")
        # conn.commit()
        # apps = cur.fetchone()
        # logger.debug(f"App ID: {apps}")
            
        # Process pages for PDF documents
        if data['type'] == "PDF" and 'pages' in data:
            logger.debug(f"First Page: {data['pages'][0]}")
            for page in data['pages']:
                page_stored = store_data_in_pages_table(cur, conn, application_number, page)
                if not page_stored:
                    logger.warning(f"Failed to store page {page.get('page_number', 'unknown')}")
                    
                # Store MIB code meanings if available
            # a = "MIB" in data['pages'][0].get('categories', [])
            # b = 'mib_codes' in data['pages'][0]['extracted_content'].get('insured_information')
            # logger.debug(f"A: {a}, B: {b}")
                if page_stored and "MIB" in page.get('categories', []) and 'mib_codes' in page['extracted_content'].get('insured_information', {}):
                    # logger.debug("Inside the MIB part")
                    store_mib_code_meanings(cur, conn, data['application_number'], page['extracted_content']['insured_information']['mib_codes'])
                elif page_stored and "MIB" in page.get('categories', []) and 'mib_codes' in page.get('extracted_content', {}):
                    # logger.debug("Inside the MIB part")
                    store_mib_code_meanings(cur, conn, data['application_number'], page['extracted_content']['mib_codes'])
        # Commit transaction
        conn.commit()
        success = True
        logger.debug(f"Successfully stored data for application {data.get('application_number', 'unknown')}")
        
    except Exception as e:
        logger.error(f"Error storing data in database: {str(e)}")
        if conn:
            conn.rollback()
    finally:
        # Ensure resources are properly released
        if cur:
            cur.close()
        if conn:
            conn.close()
        logger.debug("Database connection closed")
        
    return success
    
    
def store_conversation(user_id, session_id, application_number=None):
    """
    Store conversation data in PostgreSQL database.
    
    Args:
        user_id: User ID of the person having the conversation
        application_number: Application number associated with the conversation (optional)
    
    Returns:
        bool: True if successful, False if any operation failed
    """
    
    # cur, conn = connect_to_db()
    success = False
    
    try:
        logger.debug("Storing conversation data in PostgreSQL database...")
        cur, conn = connect_to_db()
        if not cur or not conn:
            logger.error("Failed to establish database connection")
            return False
        
        # Start transaction
        conn.autocommit = False
        
        # Fetch application ID if application number is provided
        application_id = None
        if application_number:
            application_id = fetch_application_id(cur, conn, application_number)
            if not application_id:
                logger.error(f"Application ID not found for application number: {application_number}")
                return False
        
        # Insert conversation data into conversations table
        cur.execute(
            "INSERT INTO conversations (user_id, application_id, session_id) VALUES (%s, %s, %s);",
            (user_id, application_id, session_id)
        )
        # conversation_id = cur.fetchone()[0]
        
        # Commit transaction
        conn.commit()
        success = True
        logger.debug(f"Successfully stored conversation for user {user_id}")
        
    except Exception as e:
        logger.error(f"Error storing conversation data in database: {str(e)}")
        if conn:
            conn.rollback()
    finally:
        # Ensure resources are properly released
        if cur:
            cur.close()
        if conn:
            conn.close()
        logger.debug("Database connection closed")
        
    return success
    
    
def fetch_conversation_id(user_id, session_id, application_number=None):
    """
    Fetch conversation ID based on user ID and session ID.
    
    Args:
        user_id: User ID of the person having the conversation
        session_id: Session ID of the conversation
        application_number: Application number associated with the conversation (optional)
    
    Returns:
        str: Conversation ID if found, None otherwise
    """
    logger.debug("Fetching conversation ID from PostgreSQL database...")
    cur, conn = connect_to_db()
    conversation_id = None
    
    try:
        cur, conn = connect_to_db()
        if not cur or not conn:
            logger.error("Failed to establish database connection")
            return None
        
        # Fetch conversation ID based on user ID and session ID
        cur.execute(
            "SELECT id FROM conversations WHERE user_id = %s AND session_id = %s;",
            (user_id, session_id)
        )
        conversation_id = cur.fetchone()
        
        if not conversation_id:
            logger.warning(f"No conversation found for user {user_id} with session {session_id}")
            return None
        
        logger.debug(f"Fetched conversation ID: {conversation_id[0]}")
        
    except Exception as e:
        logger.error(f"Error fetching conversation ID from database: {str(e)}")
    finally:
        # Ensure resources are properly released
        if cur:
            cur.close()
        if conn:
            conn.close()
        logger.debug("Database connection closed")
        
    return conversation_id[0] if conversation_id else None
    

def store_messages(conversation_id, sender, message_text, message_type, thoughts=None):
    """
    Store messages in PostgreSQL database.
    
    Args:
        conversation_id: ID of the conversation
        sender: Sender of the message (user or agent)
        message_text: Text of the message
        message_type: Type of the message (question, intermediate_answer, final_answer)
        thoughts: Reasoning steps for the message (optional)
    
    Returns:
        bool: True if successful, False if any operation failed
    """
    logger.debug("Storing messages in PostgreSQL database...")
    cur, conn = connect_to_db()
    success = False
    
    try:
        cur, conn = connect_to_db()
        if not cur or not conn:
            logger.error("Failed to establish database connection")
            return False
        
        # Start transaction
        conn.autocommit = False
        
        # Insert message data into messages table
        cur.execute(
            "INSERT INTO messages (conversation_id, sender, message_text, message_type, thought_process) "
            "VALUES (%s, %s, %s, %s, %s);",
            (conversation_id, sender, message_text, message_type, thoughts)
        )
        
        # Commit transaction
        conn.commit()
        success = True
        logger.debug(f"Successfully stored message from {sender} in conversation {conversation_id}")
        
    except Exception as e:
        logger.error(f"Error storing messages in database: {str(e)}")
        if conn:
            conn.rollback()
    finally:
        # Ensure resources are properly released
        if cur:
            cur.close()
        if conn:
            conn.close()
        logger.debug("Database connection closed")
        
    return success

def fetch_extracted_date(application_number):
    try:
        cur, conn = connect_to_db()
        application_id = fetch_application_id(cur, conn, application_number)
        
        if not application_id:
            logger.error(f"Application ID not found for application number: {application_number}")
            return False
        
        date_query = f"""
                    SELECT DISTINCT p.extracted_date
                    FROM pages p
                    JOIN applications a ON a.application_id = p.application_id
                    JOIN data_sources ds ON ds.data_source_id = p.data_source_id
                    WHERE a.application_id = '{application_id}' AND ds.name = 'MIB'
                    AND p.extracted_date IS NOT NULL
                    ORDER BY p.extracted_date DESC
                    LIMIT 1;
                    """
        cur.execute(date_query)
        conn.commit()
        logger.debug("Successfully fetched the date extracted")
        extracted_date = cur.fetchone()
        
    except Exception as e:
        logger.error(f"Error storing messages in database: {str(e)}")
        if conn:
            conn.rollback()
    finally:
        # Ensure resources are properly released
        if cur:
            cur.close()
        if conn:
            conn.close()
        logger.debug("Database connection closed")
        
    return extracted_date if extracted_date else None
                

if __name__ == "__main__":
    cur, conn = connect_to_db()

    # Need to run this when data sources are newly added in PostgresDB
    store_data_in_data_sources_table(cur, conn)

