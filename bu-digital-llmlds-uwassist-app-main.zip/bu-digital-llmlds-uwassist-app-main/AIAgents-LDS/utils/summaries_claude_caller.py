#!/usr/bin/env python3
"""
Specialized Claude caller for summaries processing.
This module provides functions to call Claude with retry logic and fallback options.
"""

import os
import json
import time
import random
from typing import Optional, Dict, Any
from loguru import logger

try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False
    logger.warning("anthropic package not available, using AWS Bedrock only")

try:
    import boto3
    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False
    logger.warning("boto3 package not available, using standard Anthropic API only")

def call_claude_with_retries(
    system_prompt: str,
    user_prompt: str,
    max_retries: int = 3,
    use_bedrock: bool = True,
    model_name: str = "claude-3-5-sonnet-20241022"
) -> Optional[str]:
    """
    Call Claude with retry logic and fallback options.
    
    Args:
        system_prompt: The system prompt for Claude
        user_prompt: The user prompt for Claude
        max_retries: Maximum number of retry attempts
        use_bedrock: Whether to use AWS Bedrock (if available)
        model_name: Model name for standard Anthropic API
    
    Returns:
        Claude's response text or None if all retries failed
    """
    
    retries = 0
    last_error = None
    
    while retries <= max_retries:
        try:
            logger.info(f"Attempting to call Claude (attempt {retries + 1}/{max_retries + 1})")
            
            if use_bedrock and BOTO3_AVAILABLE:
                response = _call_claude_bedrock(system_prompt, user_prompt)
            elif ANTHROPIC_AVAILABLE:
                response = _call_claude_anthropic(system_prompt, user_prompt, model_name)
            else:
                raise ImportError("Neither boto3 nor anthropic packages are available")
            
            if response:
                logger.info("Successfully received response from Claude")
                return response
            else:
                raise ValueError("Empty response received from Claude")
                
        except Exception as e:
            last_error = e
            logger.warning(f"Attempt {retries + 1} failed: {str(e)}")
            
            if retries < max_retries:
                # Exponential backoff with jitter
                wait_time = (2 ** retries) + random.uniform(0, 1)
                logger.info(f"Waiting {wait_time:.2f} seconds before retry...")
                time.sleep(wait_time)
                
                # Switch to alternative method on retry
                if use_bedrock and ANTHROPIC_AVAILABLE:
                    logger.info("Switching to standard Anthropic API for retry")
                    use_bedrock = False
                elif not use_bedrock and BOTO3_AVAILABLE:
                    logger.info("Switching to AWS Bedrock for retry")
                    use_bedrock = True
                    
            retries += 1
    
    logger.error(f"All {max_retries + 1} attempts failed. Last error: {str(last_error)}")
    return None

def _call_claude_bedrock(system_prompt: str, user_prompt: str) -> Optional[str]:
    """Call Claude using AWS Bedrock."""
    try:
        # Check for required environment variables
        model_id = os.getenv('BrAipClaude35SonnetV2Cri')
        if not model_id:
            logger.warning("BrAipClaude35SonnetV2Cri environment variable not set")
            return None
        
        bedrock_client = boto3.client('bedrock-runtime', region_name="us-east-1")
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        payload = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 4096,
            "messages": messages
        }
        
        logger.debug("Calling Claude via AWS Bedrock")
        response = bedrock_client.invoke_model(
            body=json.dumps(payload), 
            modelId=model_id
        )
        
        response_body = response["body"].read().decode('utf-8')
        response_data = json.loads(response_body)
        
        return response_data["content"][0]["text"]
        
    except Exception as e:
        logger.error(f"Error calling Claude via AWS Bedrock: {str(e)}")
        return None

def _call_claude_anthropic(system_prompt: str, user_prompt: str, model_name: str) -> Optional[str]:
    """Call Claude using standard Anthropic API."""
    try:
        api_key = os.getenv('ANTHROPIC_API_KEY')
        if not api_key:
            logger.warning("ANTHROPIC_API_KEY environment variable not set")
            return None
        
        client = anthropic.Anthropic(api_key=api_key)
        
        logger.debug("Calling Claude via standard Anthropic API")
        message = client.messages.create(
            model=model_name,
            max_tokens=4000,
            system=system_prompt,
            messages=[
                {
                    "role": "user",
                    "content": user_prompt
                }
            ]
        )
        
        return message.content[0].text
        
    except Exception as e:
        logger.error(f"Error calling Claude via standard Anthropic API: {str(e)}")
        return None

def call_claude_simple(
    system_prompt: str,
    user_prompt: str,
    model_name: str = "claude-3-5-sonnet-20241022"
) -> Optional[str]:
    """
    Simple Claude call without retries (for demo/testing purposes).
    
    Args:
        system_prompt: The system prompt for Claude
        user_prompt: The user prompt for Claude
        model_name: Model name for standard Anthropic API
    
    Returns:
        Claude's response text or None if failed
    """
    
    if ANTHROPIC_AVAILABLE:
        return _call_claude_anthropic(system_prompt, user_prompt, model_name)
    elif BOTO3_AVAILABLE:
        return _call_claude_bedrock(system_prompt, user_prompt)
    else:
        logger.error("No Claude calling method available")
        return None

# Convenience function for the summaries processing
def generate_comprehensive_summary_with_retries(
    demo_summary: str,
    med_summary: str,
    system_prompt: str,
    user_prompt_template: str,
    max_retries: int = 3
) -> Optional[str]:
    """
    Generate comprehensive summary using Claude with retry logic.
    
    Args:
        demo_summary: Demographics summary text
        med_summary: Medical summary text
        system_prompt: System prompt for Claude
        user_prompt_template: User prompt template with placeholders
        max_retries: Maximum number of retry attempts
    
    Returns:
        Comprehensive summary text or None if failed
    """
    
    # Format the user prompt with the summaries
    user_prompt = user_prompt_template.format(
        demo_summary=demo_summary,
        med_summary=med_summary
    )
    
    # Call Claude with retries
    return call_claude_with_retries(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        max_retries=max_retries
    )

