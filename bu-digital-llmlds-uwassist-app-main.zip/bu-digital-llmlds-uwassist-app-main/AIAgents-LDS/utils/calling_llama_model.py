import boto3
import os
import json
from dotenv import load_dotenv
from loguru import logger
from pydantic import ValidationError
import base64
import re


logger.info("Loading environment variables")
load_dotenv()


def invoking_llama(user_prompt, system_prompt):
    bedrock_client = boto3.client('bedrock-runtime', region_name="us-east-1")
    llama_profile = os.environ['BRAIPLlama3290BVisionInstruct']


    messages_payload = [
        {
            "role": "user",
            "content": [
                {
                    "text": system_prompt
                }
            ]
        },
        {
            "role": "user",
            "content": [
                {
                    "text": user_prompt
                }
            ]
        }
    ]
    # messages_image = {"prompt": user_prompt, "image": encoded_image}
    logger.debug("Constructed messages for Llama")

    config = {
        "maxTokens": 4096,
        "temperature": 0,
        "topP": .1
        }
    
    logger.debug("Constructed payload for Bedrock:")

    response = bedrock_client.converse(
        modelId=llama_profile,
        messages=messages_payload,
        inferenceConfig=config
    )
    logger.debug("Invoked Llama model")

    # response_body = response["body"].read().decode('utf-8')
    # response_data = json.loads(response_body)
    
    logger.debug(f"Received response: {response}")

    json_data = response['output']['message']['content'][0]['text']

    return json_data


def using_llama_for_image_analysis(image_file, user_prompt):
    bedrock_client = boto3.client('bedrock-runtime', region_name="us-east-1")
    llama_profile = os.environ['BRAIPLlama318BInstruct']


    try:
        # resize_image(image_file, 'data_source/F11248249/pages/page_15_resize.png')
        with open(image_file, 'rb') as image_file:
                encoded_image = image_file.read()
                logger.debug(f"Reading image file {image_file.name}")
    except FileNotFoundError:
        logger.error(f"File not found: {image_file}")
        return None


    messages_image = [
        {
            "role": "user",
            "content": [
                {                
                "image": {
                    "format": "png",
                    "source": {
                        "bytes":encoded_image
                    }
                }
            },
                {
                    "text": user_prompt
                }
            ]
        }
    ]
    # messages_image = {"prompt": user_prompt, "image": encoded_image}
    logger.debug("Constructed messages for Llama")

    config = {
        "maxTokens": 4096,
        "temperature": 0,
        "topP": .1
        }
    
    logger.debug("Constructed payload for Bedrock:")

    response = bedrock_client.converse(
        modelId=llama_profile,
        messages=messages_image,
        inferenceConfig=config
    )
    logger.debug("Invoked Llama model")

    # response_body = response["body"].read().decode('utf-8')
    # response_data = json.loads(response_body)
    
    logger.debug(f"Received response: {response}")

    json_data = response['output']['message']['content'][0]['text']

    return json_data



# def invoking_llama(system_prompt: str, user_prompt: str) -> str:
#     bedrock_client = boto3.client('bedrock-runtime', region_name="us-east-1")
#     claude_sonnet_profile = os.environ['BRAIPLlama318BInstruct']
#     messages = [
#             {"role": "user", "content": system_prompt},
#             {"role": "user", "content": user_prompt}
#         ]
        
#     logger.debug("Constructed messages for Claude")
    
#     payload = {
#             "anthropic_version": "bedrock-2023-05-31",
#             "max_tokens": 4096,  # Required parameter specifying the maximum number of tokens to generate
#             "messages": messages
#         }
        
#     logger.debug("Constructed payload for Bedrock:")
    
#     claude_sonnet_response = bedrock_client.invoke_model(body=json.dumps(payload), modelId=claude_sonnet_profile)
#     logger.debug("Invoked Claude model")
#     response_body = claude_sonnet_response["body"].read().decode('utf-8')
#     response_data = json.loads(response_body)
#     logger.debug(f"Received response: {response_data}")
    
#     return response_data["content"][0]["text"]
    

# def invoking_claude_for_image_analysis(image_file: str, user_prompt: str) -> str:

#     # image_file = os.path.join(os.path.dirname(__file__), "F39414621/pages/page_1.png")
#     # print(image_file)
    
#     with open(image_file, 'rb') as image_file:
#             encoded_image = base64.b64encode(image_file.read()).decode('utf-8')
#             logger.debug(f"Encoded image file {image_file.name} to base64")
    
#     bedrock_client = boto3.client('bedrock-runtime', region_name="us-east-1")
#     claude_sonnet_profile = os.environ['BrAipClaude35SonnetV2Cri']
#     messages_image = [
#             {
#                 "role": "user",
#                 "content": [
#                     {
#                         "type": "image",
#                         "source": {
#                             "type": "base64",
#                             "media_type": "image/png",  # Adjust based on image type
#                             "data": encoded_image
#                         }
#                     },
#                     {
#                         "type": "text",
#                         "text": user_prompt
#                     }
#                 ]
#             }
#         ]
    
        
#     logger.debug("Constructed messages for Claude")
    
#     payload = {
#             "anthropic_version": "bedrock-2023-05-31",
#             "max_tokens": 2084,
#             "temperature": 0.2,
#             "top_p": 0.7,
#             "top_k": 250,
#             "messages": messages_image
#         }
        
#     logger.debug("Constructed payload for Bedrock:")
    
#     claude_sonnet_response = bedrock_client.invoke_model(body=json.dumps(payload), modelId=claude_sonnet_profile)
#     logger.debug("Invoked Claude model")
#     response_body = claude_sonnet_response["body"].read().decode('utf-8')
#     response_data = json.loads(response_body)
#     logger.debug(f"Received response: {response_data}")
    
#     return response_data["content"][0]["text"]


if __name__ == "__main__":
    response = invoking_llama("How are you?", "Provide a friendly response")
    print(response)