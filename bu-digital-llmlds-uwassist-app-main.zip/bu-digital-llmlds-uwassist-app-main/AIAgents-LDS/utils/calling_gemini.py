import os
import google.generativeai as genai
from dotenv import load_dotenv
from loguru import logger

load_dotenv(override=True)

# Load API key from environment
api_key = os.getenv("GEMINI_API_KEY")
if not api_key:
    raise ValueError("API key not found. Set GEMINI_API_KEY environment variable.")

genai.configure(api_key=api_key)
logger.debug(f"API key loaded: {api_key}")

# Choose a model
model = genai.GenerativeModel("gemini-1.5-pro")
logger.debug(f"Model loaded: {model}")

# Send a simple test prompt
response = model.generate_content("Hello Gemini, running from AWS EC2!")
print(response.text)
