import json
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
import string
import heapq

# Download necessary NLTK data (only needs to be done once)
try:
    stopwords.words('english')
except LookupError:
    nltk.download('stopwords')
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

try:
    # As requested, adding download for punkt_tab
    nltk.data.find('tokenizers/punkt_tab')
except LookupError:
    nltk.download('punkt_tab')

def reduce_context_with_sliding_window(text: str, query: str, num_sentences: int = 15) -> str:
    """
    Reduces a large text to a smaller number of the most relevant sentences
    based on keyword scoring from a user query.

    Args:
        text: The large context to reduce.
        query: The user query to find relevant sentences for.
        num_sentences: The number of top sentences to return.

    Returns:
        A string containing the most relevant sentences.
    """
    # 1. Pre-process the query to get keywords
    stop_words = set(stopwords.words('english'))
    query_tokens = word_tokenize(query.lower())
    keywords = [word for word in query_tokens if word.isalpha() and word not in stop_words]

    # 2. Split the text into sentences
    sentences = sent_tokenize(text)
    if not sentences:
        return ""

    # 3. Score each sentence
    sentence_scores = []
    for sentence in sentences:
        sentence_tokens = word_tokenize(sentence.lower())
        score = 0
        for keyword in keywords:
            if keyword in sentence_tokens:
                score += 1
        if score > 0:
            sentence_scores.append((score, sentence))
    
    # 4. Get the top N sentences using a heap for efficiency
    top_sentences = heapq.nlargest(num_sentences, sentence_scores, key=lambda x: x[0])

    # 5. Sort by original appearance to maintain context flow
    top_sentences.sort(key=lambda x: sentences.index(x[1]))

    # 6. Join the sentences back into a single string
    return " ".join([sentence for score, sentence in top_sentences]) 

def reduce_json_with_keyword_scoring(json_string: str, query: str, num_pairs: int = 50) -> str:
    """
    Reduces a large JSON object by extracting the most relevant key-value
    pairs based on keyword scoring from a user query.

    Args:
        json_string: The string representation of the JSON object.
        query: The user query to find relevant pairs for.
        num_pairs: The number of top key-value pairs to return.

    Returns:
        A string containing the most relevant key-value pairs.
    """
    # 1. Pre-process the query to get keywords
    stop_words = set(stopwords.words('english'))
    query_tokens = word_tokenize(query.lower())
    keywords = [word for word in query_tokens if word.isalpha() and word not in stop_words]

    # 2. Parse the JSON
    try:
        data = json.loads(json_string)
    except json.JSONDecodeError:
        # If it's not valid JSON, treat it as plain text as a fallback.
        return reduce_context_with_sliding_window(json_string, query)

    # 3. Recursively find and score all key-value pairs
    scored_pairs = []
    
    def find_and_score(obj, path=""):
        if isinstance(obj, dict):
            for key, value in obj.items():
                new_path = f"{path}.{key}" if path else key
                find_and_score(value, new_path)
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                new_path = f"{path}[{i}]"
                find_and_score(item, new_path)
        else:
            # This is a leaf node (a primitive value)
            value_str = str(obj)
            text_to_score = f"{path} {value_str}".lower()
            score = 0
            for keyword in keywords:
                if keyword in text_to_score:
                    score += 1
            if score > 0:
                scored_pairs.append((score, f"{path}: {value_str}"))

    find_and_score(data)

    # 4. Get the top N key-value pairs
    top_pairs = heapq.nlargest(num_pairs, scored_pairs, key=lambda x: x[0])

    # 5. Join them into a readable string
    return "\n".join([pair_text for score, pair_text in top_pairs]) 