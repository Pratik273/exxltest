from pydantic import BaseModel
from typing import List, Optional
from enum import Enum

        
class MetadataResponse(BaseModel):
    categories: List[str]
    extracted_date: str
    
class IntentType(str, Enum):
    application = "Underwriting Application"
    general = "General"
    unrelated = "Unrelated"

class IntentClassifyResponse(BaseModel):
    Type: IntentType
    Thought: Optional[str] = None
    Answer: Optional[str] = None

class QueryBreakdown(BaseModel):
      Query_text: str
      Data_source: List[str]

class QueryProcessResponse(BaseModel):
    Thought: str
    Search_query_texts: List[QueryBreakdown]
    
class ChunkResponse(BaseModel):
    Data_source: str
    Extracted_date: Optional[str] = None
    Relevant_text: str
        
class RelevancyCheckResponse(BaseModel):
    Results: List[ChunkResponse]
    
class ChiefReasoningResponse(BaseModel):
    Thought: str
    Answer: Optional[str] = None
    Critic: Optional[str] = None
    Recommendation: Optional[str] = None
    Rewrite_Query: Optional[str] = None
    Confidence_Score: Optional[str] = None 
    