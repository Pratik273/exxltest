import json
import re
import heapq
from collections import Counter
from difflib import SequenceMatcher

# Simple English stop words - no external downloads needed
STOP_WORDS = {
    'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
    'is', 'was', 'are', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did',
    'will', 'would', 'could', 'should', 'may', 'might', 'can', 'this', 'that', 'these', 'those',
    'i', 'you', 'he', 'she', 'it', 'we', 'they', 'me', 'him', 'her', 'us', 'them', 'my', 'your',
    'his', 'our', 'their', 'what', 'which', 'who', 'when', 'where', 'why', 'how'
}

def simple_tokenize(text):
    """Lightweight tokenization without NLTK"""
    # Remove punctuation and split by whitespace
    text = re.sub(r'[^\w\s]', ' ', text.lower())
    return [word for word in text.split() if word and len(word) > 2]

def simple_sentence_split(text):
    """Simple sentence splitting without NLTK"""
    # Split on sentence boundaries
    sentences = re.split(r'[.!?]+', text)
    return [s.strip() for s in sentences if s.strip()]

def extract_keywords(query):
    """Extract meaningful keywords from query"""
    tokens = simple_tokenize(query)
    return [word for word in tokens if word not in STOP_WORDS]

def fuzzy_match_score(keyword, text, threshold=0.8):
    """Calculate fuzzy matching score for better word matching"""
    words = simple_tokenize(text)
    best_score = 0
    
    for word in words:
        if keyword == word:
            return 1.0  # Exact match
        elif len(word) > 3 and len(keyword) > 3:
            # Use fuzzy matching for longer words
            similarity = SequenceMatcher(None, keyword, word).ratio()
            if similarity >= threshold:
                best_score = max(best_score, similarity)
    
    return best_score

def reduce_context_with_sliding_window_lite(text: str, query: str, num_sentences: int = 15) -> str:
    """
    Lightweight version of context reduction without NLTK
    Uses fuzzy matching for better keyword detection
    """
    # Extract keywords from query
    keywords = extract_keywords(query)
    if not keywords:
        return text[:4000]  # Fallback truncation
    
    # Split into sentences
    sentences = simple_sentence_split(text)
    if not sentences:
        return text[:4000]
    
    # Score each sentence with fuzzy matching
    sentence_scores = []
    for sentence in sentences:
        score = 0
        for keyword in keywords:
            # Use fuzzy matching instead of exact matching
            fuzzy_score = fuzzy_match_score(keyword, sentence)
            if fuzzy_score > 0:
                score += fuzzy_score
        
        if score > 0:
            sentence_scores.append((score, sentence))
    
    # Get top sentences
    if not sentence_scores:
        # If no matches, return first few sentences
        return " ".join(sentences[:num_sentences])
    
    top_sentences = heapq.nlargest(num_sentences, sentence_scores, key=lambda x: x[0])
    top_sentences.sort(key=lambda x: sentences.index(x[1]))
    
    return " ".join([sentence for score, sentence in top_sentences])

def reduce_json_with_smart_scoring(json_string: str, query: str, max_pairs: int = 50) -> str:
    """
    Efficient JSON reduction with smart scoring and fuzzy matching
    Memory-friendly approach for large JSON objects
    """
    keywords = extract_keywords(query)
    if not keywords:
        return json_string[:4000]
    
    try:
        data = json.loads(json_string)
    except json.JSONDecodeError:
        # Fallback to text processing
        return reduce_context_with_sliding_window_lite(json_string, query)
    
    # Use streaming approach for large JSON
    scored_pairs = []
    
    def score_and_extract(obj, path="", max_depth=10):
        """Recursively score JSON elements with depth limiting"""
        if max_depth <= 0:
            return
            
        if isinstance(obj, dict):
            for key, value in obj.items():
                new_path = f"{path}.{key}" if path else key
                
                # Score the key-value pair
                text_to_score = f"{key} {str(value)}".lower()
                score = calculate_relevance_score(text_to_score, keywords)
                
                if score > 0:
                    # Limit value length to prevent memory issues
                    value_str = str(value)
                    if len(value_str) > 200:
                        value_str = value_str[:200] + "..."
                    scored_pairs.append((score, f"{new_path}: {value_str}"))
                
                # Recurse for nested objects
                if isinstance(value, (dict, list)) and len(str(value)) < 10000:
                    score_and_extract(value, new_path, max_depth - 1)
                    
        elif isinstance(obj, list):
            for i, item in enumerate(obj[:20]):  # Limit list processing
                new_path = f"{path}[{i}]"
                score_and_extract(item, new_path, max_depth - 1)
    
    score_and_extract(data)
    
    if not scored_pairs:
        # If no relevant pairs found, return truncated original
        return json_string[:4000]
    
    # Get top scoring pairs
    top_pairs = heapq.nlargest(max_pairs, scored_pairs, key=lambda x: x[0])
    
    return "\n".join([pair_text for score, pair_text in top_pairs])

def calculate_relevance_score(text, keywords):
    """Calculate relevance score with fuzzy matching"""
    total_score = 0
    
    for keyword in keywords:
        # Exact match bonus
        if keyword in text:
            total_score += 2.0
        else:
            # Fuzzy match
            fuzzy_score = fuzzy_match_score(keyword, text, threshold=0.7)
            total_score += fuzzy_score
    
    return total_score

def intelligent_json_chunker(json_content, query, max_size=4500):
    """
    Intelligent JSON chunking that's multiprocessing-friendly with MVR optimizations
    """
    try:
        # Quick size check
        if len(json_content) <= max_size:
            return json_content
        
        # MVR-specific optimization: extract only essential information
        if 'MVR' in str(query).upper() or 'MVRResults' in json_content:
            mvr_optimized = extract_mvr_essentials_fast(json_content, max_size)
            if mvr_optimized:
                return mvr_optimized
        
        # Try smart reduction first
        reduced = reduce_json_with_smart_scoring(json_content, query, max_pairs=30)
        
        if len(reduced) <= max_size:
            return reduced
        
        # If still too large, apply size-based chunking
        return smart_truncate_preserving_structure(reduced, max_size)
        
    except Exception as e:
        # Safe fallback
        return json_content[:max_size]

def extract_mvr_essentials_fast(json_content, max_size):
    """Fast extraction of essential MVR information only"""
    try:
        # Look for key MVR patterns without full JSON parsing
        essential_parts = []
        
        # Extract Score information
        score_match = re.search(r'"Score":\s*(\d+)', json_content)
        if score_match:
            essential_parts.append(f"Score: {score_match.group(1)}")
        
        # Extract MVR Status
        status_match = re.search(r'"MVRStatus":\s*(\w+)', json_content)
        if status_match:
            essential_parts.append(f"MVRStatus: {status_match.group(1)}")
        
        # Extract State information
        state_match = re.search(r'"StatePostalCode":\s*"([^"]+)"', json_content)
        if state_match:
            essential_parts.append(f"State: {state_match.group(1)}")
        
        # Extract violation descriptions ONLY from MVRViolations section (not from ScoreResult)
        mvr_violations_pattern = r'"MVRViolations":\s*\[(.*?)\]'
        mvr_violations_match = re.search(mvr_violations_pattern, json_content, re.DOTALL | re.IGNORECASE)
        
        violation_matches = []
        if mvr_violations_match:
            mvr_violations_section = mvr_violations_match.group(1)
            # Only extract from StandardViolationCodeDesc within MVRViolations section
            standard_violation_pattern = r'"StandardViolationCodeDesc":\s*"([^"]+)"'
            violations = re.findall(standard_violation_pattern, mvr_violations_section, re.IGNORECASE)
            
            # Filter out placeholder violations
            for violation in violations[:5]:
                if not any(keyword in violation.upper() for keyword in [
                    'LEXISNEXIS CLEAR', 'VIOLATION_RECORD_INFO', 'PLACEHOLDER'
                ]):
                    violation_matches.append(violation)
        
        if violation_matches:
            essential_parts.append("Violations:")
            for i, violation in enumerate(violation_matches, 1):
                essential_parts.append(f"  {i}. {violation}")
        else:
            essential_parts.append("Violations: No violations found")
        
        # Combine and check size
        result = "\n".join(essential_parts)
        if len(result) <= max_size:
            return result + f"\n\n[Extracted from {len(json_content):,} character MVR data]"
        
        return None  # Fall back to normal processing
        
    except Exception:
        return None

def smart_truncate_preserving_structure(content, max_size):
    """Truncate while preserving JSON/text structure"""
    if len(content) <= max_size:
        return content
    
    # Try to find a good break point
    truncated = content[:max_size]
    
    # Look for natural break points (sentence endings, JSON boundaries)
    for break_char in ['\n', '.', '}', ']']:
        last_break = truncated.rfind(break_char)
        if last_break > max_size * 0.8:  # Don't truncate too much
            return content[:last_break + 1]
    
    return truncated 