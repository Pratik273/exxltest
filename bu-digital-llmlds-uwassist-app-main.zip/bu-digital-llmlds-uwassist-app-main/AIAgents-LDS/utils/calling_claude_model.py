import boto3
import os
import json
from dotenv import load_dotenv
from loguru import logger
from pydantic import ValidationError
import base64
import re


logger.info("Loading environment variables")
load_dotenv()

def invoking_claude(system_prompt: str, user_prompt: str, model_id: str = "") -> str:
    bedrock_client = boto3.client('bedrock-runtime', region_name="us-east-1")
    if model_id != "":
        claude_sonnet_profile = model_id
    else:
        claude_sonnet_profile = os.environ['BrAipClaude35SonnetV2Cri']
        
    messages = [
            {"role": "user", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
    logger.debug("Constructed messages for Claude")
    
    payload = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 4096,  # Required parameter specifying the maximum number of tokens to generate
            "messages": messages
        }
        
    logger.debug("Constructed payload for Bedrock:")
    
    claude_sonnet_response = bedrock_client.invoke_model(body=json.dumps(payload), modelId=claude_sonnet_profile)
    logger.debug("Invoked Claude model")
    response_body = claude_sonnet_response["body"].read().decode('utf-8')
    response_data = json.loads(response_body)
    logger.debug(f"Received response: {response_data}")
    
    return response_data["content"][0]["text"]
    

def invoking_claude_for_image_analysis(image_file: str, user_prompt: str) -> str:

    # image_file = os.path.join(os.path.dirname(__file__), "F39414621/pages/page_1.png")
    # print(image_file)
    
    with open(image_file, 'rb') as image_file:
            encoded_image = base64.b64encode(image_file.read()).decode('utf-8')
            logger.debug(f"Encoded image file {image_file.name} to base64")
    
    bedrock_client = boto3.client('bedrock-runtime', region_name="us-east-1")
    claude_sonnet_profile = os.environ['BrAipClaude35SonnetV2Cri']
    messages_image = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/png",  # Adjust based on image type
                            "data": encoded_image
                        }
                    },
                    {
                        "type": "text",
                        "text": user_prompt
                    }
                ]
            }
        ]
    
        
    logger.debug("Constructed messages for Claude")
    
    payload = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 2084,
            "temperature": 0.2,
            "top_p": 0.7,
            "top_k": 250,
            "messages": messages_image
        }
        
    logger.debug("Constructed payload for Bedrock:")
    
    claude_sonnet_response = bedrock_client.invoke_model(body=json.dumps(payload), modelId=claude_sonnet_profile)
    logger.debug("Invoked Claude model")
    response_body = claude_sonnet_response["body"].read().decode('utf-8')
    response_data = json.loads(response_body)
    logger.debug(f"Received response: {response_data}")
    
    return response_data["content"][0]["text"]
