import boto3
import tempfile
from loguru import logger
import os
import json
from botocore.exceptions import ClientError

def calling_s3(bucket, key):
     # Initialize S3 client
    s3_client = boto3.client('s3')
    logger.info("connected to S3")
    logger.debug(f"{bucket}/{key}")
    
    try:
        # Create a temporary file with .png extension
        logger.info("Creating temporary file")
        temp = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
        local_path = temp.name
        temp.close()
    
        logger.info(f"Downloading S3 file s3://{bucket}/{key} to {local_path}")
        s3_client.download_file(bucket, key, local_path)
        
        return local_path
        
    except ClientError as e:
        logger.error(f"Error working with S3: {e}")
        raise
    except Exception as e:
        logger.error(f"Error processing PDF: {e}")
        raise
    
    
def upload_json_to_s3(json_data, bucket_name, object_key):
    """
    Upload JSON data to an S3 bucket.
    
    Args:
        json_data (dict): The JSON data to upload
        bucket_name (str): Name of the S3 bucket
        object_key (str): S3 object key (path/filename.json)
        
    Returns:
        bool: True if upload was successful, False otherwise
    """
    try:
        # Initialize S3 client
        s3_client = boto3.client('s3')
        
        # Convert dictionary to JSON string
        json_string = json.dumps(json_data, indent=4)
        
        # Upload JSON to S3
        s3_client.put_object(
            Body=json_string,
            Bucket=bucket_name,
            Key=object_key,
            ContentType='application/json'
        )
        
        logger.info(f"Successfully uploaded JSON to s3://{bucket_name}/{object_key}")
        return True
        
    except ClientError as e:
        logger.error(f"Error uploading JSON to S3: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error uploading JSON to S3: {e}")
        return False

def upload_file_to_s3(local_file_path, bucket_name, s3_key):
    """
    Upload a file to an S3 bucket
    
    :param local_file_path: File to upload
    :param bucket_name: Bucket to upload to
    :param s3_key: S3 object key name
    :return: True if file was uploaded, else False
    """
    s3_client = boto3.client('s3')
    try:
        s3_client.upload_file(local_file_path, bucket_name, s3_key)
        logger.info(f"Successfully uploaded {local_file_path} to {bucket_name}/{s3_key}")
        return True
    except ClientError as e:
        logger.error(f"Error uploading {local_file_path} to S3: {e}")
        return False

if __name__ == "__main__":
    import os
    from dotenv import load_dotenv
    load_dotenv(override=True)
    json_file_path_download = f"lds-friendly-applications/F14612930/extracted_content.json"
    json_file_path_upload = f"lds-friendly-applications/F14612930"
    calling_s3(os.getenv('BUCKET_NAME'), json_file_path_download)
    upload_json_to_s3("/tmp/tmpvtz5gm5d.png",os.getenv('BUCKET_NAME'), json_file_path_upload)      