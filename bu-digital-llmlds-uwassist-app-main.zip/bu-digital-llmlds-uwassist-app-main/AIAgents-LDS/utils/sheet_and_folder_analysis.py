import os
import ast

# Paths
base_dir = os.path.dirname(os.path.dirname(__file__))
samples_file = os.path.join(base_dir, 'samples_processed.txt')
batch3_dir = os.path.join(base_dir, 'data_sources_batch3')
batch4_dir = os.path.join(base_dir, 'data_sources_batch4')

def parse_sheet_names(samples_file):
    sheet_to_files = {}
    with open(samples_file, 'r') as f:
        lines = f.readlines()
    current_file = None
    for line in lines:
        line = line.strip()
        if line.startswith('Excel file:'):
            current_file = line.split(':', 1)[1].strip()
        elif line.startswith('Sheet names:') and current_file:
            sheets = ast.literal_eval(line.split(':', 1)[1].strip())
            for sheet in sheets:
                if sheet not in sheet_to_files:
                    sheet_to_files[sheet] = set()
                sheet_to_files[sheet].add(current_file)
    return sheet_to_files

def get_folder_names(folder):
    return set([name for name in os.listdir(folder) if os.path.isdir(os.path.join(folder, name))])

def main():
    # Sheet name analysis
    sheet_to_files = parse_sheet_names(samples_file)
    unique_sheets = set(sheet_to_files.keys())
    redundant_sheets = [sheet for sheet, files in sheet_to_files.items() if len(files) > 1]
    print(f"Total unique sheet names: {len(unique_sheets)}")
    print(f"Redundant sheet names (appear in multiple files): {redundant_sheets}")
    print(f"Number of redundant sheet names: {len(redundant_sheets)}")

    # Folder comparison
    batch3_folders = get_folder_names(batch3_dir)
    batch4_folders = get_folder_names(batch4_dir)
    not_in_batch4 = batch3_folders - batch4_folders
    print(f"Folders in data_sources_batch3 not in data_sources_batch4: {sorted(list(not_in_batch4))}")
    print(f"Number of such folders: {len(not_in_batch4)}")

if __name__ == "__main__":
    main() 