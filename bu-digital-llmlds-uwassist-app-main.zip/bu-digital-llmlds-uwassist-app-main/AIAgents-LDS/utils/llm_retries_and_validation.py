import re
import json
from loguru import logger
from pydantic import ValidationError
from botocore.exceptions import ClientError
import time
import random
import os
import sys
from json_repair import repair_json
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from utils.calling_claude_model import invoking_claude
from utils.response_structures import ChiefReasoningResponse
from dotenv import load_dotenv
load_dotenv(override=True)



def clean_text(text):
    """Removes control characters and ensures valid JSON formatting."""
    text = re.sub(r'[\x00-\x1F]+', " ", text)  # Remove control characters
    text = text.strip()  # Remove extra spaces or newlines
    return text


def fix_json_quotes(json_string:str):
    # Convert single quotes to double quotes for valid JSON
    fixed_string = re.sub(r"(?<!\\)'", '"', json_string)
    try:
        # Validate if it's now a valid JSON
        return json.loads(fixed_string)
    except json.JSONDecodeError as e:
        print("Invalid JSON even after fixing quotes:", e)
        return None
        

# Function to validate if the LLM output is in the correct JSON format
def is_valid_dict_format(response_text, response_pydantic_class):
    try:
        modified_text = clean_text(response_text)
        response_pydantic_class.model_validate_json(modified_text)
        logger.debug("The extracted text is in the correct format.")
        return True, modified_text
    except (ValidationError, json.JSONDecodeError):
        logger.warning("Initial validation failed. Attempting to repair JSON.")
        try:
            repaired_json_string = repair_json(response_text)
            response_pydantic_class.model_validate_json(repaired_json_string)
            logger.info("Successfully repaired and validated JSON.")
            return True, repaired_json_string
        except (ValidationError, json.JSONDecodeError) as e:
            logger.error(f"Failed to validate JSON even after repair: {e}")
            return False, None
    


def is_valid_json(json_string):
    try:
        valid_json = json.loads(json_string)
        logger.debug("The extracted text is in the correct format")
        return True, valid_json
    except json.JSONDecodeError:
        logger.warning("Initial JSON parsing failed. Attempting to repair.")
        try:
            repaired_json_string = repair_json(json_string)
            valid_json = json.loads(repaired_json_string)
            logger.info("Successfully repaired and parsed JSON.")
            return True, valid_json
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON even after repair: {e}")
            return False, {}
        
            

def call_llm_with_retries(llm_client, file_path, prompt, response_pydantic_class=None, max_retries=4):
    retries = 0
    while retries <= max_retries:
        try:
            if retries == 2:
                logger.warning("Retry attempt using Claude 4 Sonnet")
                model_id = os.environ['BrAipClaude35SonnetV2Cri_4']
                response_text = invoking_claude(file_path, prompt, model_id)

            elif retries == 3:
                logger.warning("Retry attempt using Claude 3.7 Sonnet")
                model_id = os.environ['BrAipClaude37Sonnet']
                response_text = invoking_claude(file_path, prompt, model_id)
            
            elif retries == 4:
                logger.warning("Retrying again using Claude 3.5 Sonnet V2")
                model_id = os.environ['BrAipClaude35SonnetV2Cri']
                response_text = invoking_claude(file_path, prompt, model_id)
            

            response_text = llm_client(file_path, prompt)
            if response_pydantic_class:
                response, modified_data = is_valid_dict_format(response_text, response_pydantic_class)
                if response:
                    return modified_data
                else:
                    logger.error("The extracted text is not in the correct format.")
                    retries += 1
            else:
                response, modified_data = is_valid_json(response_text)
                if response:
                    return modified_data
                else:
                    logger.error("The extracted text is not in the correct format.")
                    retries += 1
        except ClientError as e:
            if e.response['Error']['Code'] in ['ThrottlingException', 'TooManyRequestsException']:
                wait = (2 ** retries) + random.uniform(0, 1)  # exponential backoff + jitter
                print(f"Throttled. Retrying in {wait:.2f} seconds...")
                time.sleep(wait)
                retries += 1
            else:
                logger.error(f"Error occurred while calling LLM: {e}")
                retries += 1
                raise
                
        except Exception as e:
            logger.error(f"Error occurred while calling LLM: {e}")
            retries += 1
    return None


if __name__ == "__main__":
    system_prompt = "You are a helpful assistant that can answer questions and help with tasks."
    user_prompt = "What is the MIB code for the application?"
    call_llm_with_retries(invoking_claude, system_prompt, user_prompt, ChiefReasoningResponse)