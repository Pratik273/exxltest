from langgraph.graph import StateGraph
from langgraph.graph import StateGraph, END, START
from loguru import logger
import os
import sys
import json
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from agents.agent_types.intent_classification import IntentClassificationAgent
from agents.agent_types.query_processing import QueryProcessingAgent
from agents.agent_types.extract_data_source import fetch_data_source
from agents.agent_types.extract_text_from_db import extract_text_from_data_sources
from agents.agent_types.relevancy_checker import RelevancyCheckerAgent
from agents.agent_types.chief_reasoning import ChiefReasoningAgent
from agents.state import AgentState


def update_state_after_data_sources(state: AgentState) -> AgentState:
    """
    Update state after Extract Data Sources step to prepare for Extracting Relevant Text.
    This function transforms the available_data_sources into the Search_query_texts format
    that the extract_text_from_data_sources function expects.
    """
    logger.info("Updating state after Extract Data Sources step")
    state.input_message = "Write a summary on demographics, MVR, Miscellaneous and Additional Notes section. The additional notes should only include recommendations for underwriters if there are any. Format the response with hidden markdown headers: start each section with <!-- Section: <section_name> --> where section names are Demographics, MVR, Miscellaneous, Additional Notes."
    # Update current step
    state.current_step = "Preparing query structure for text extraction"
    
    # Create Search_query_texts structure based on available data sources
    state.interim_response = '{"Search_query_texts": [\n    {\n      "Query_text": "Get demographic information summary",\n      "Data_source": ["Part A"]\n    },\n    {       "Query_text": "Find MVR status number indicating license validity",       "Data_source": ["MVR"]     }, \n    {       "Query_text": "Find driving violations and risk class score",       "Data_source": ["MVR"]     },\n    {\n      "Query_text": "Get miscellaneous information not covered in standard categories",\n      "Data_source": ["Part A"]\n    },\n    {\n      "Query_text": "Identify any risk factors or notable findings that require underwriter attention",\n      "Data_source": ["Part A"]\n    }\n  ]\n}'
    #'{"Search_query_texts": [\n    {\n      "Query_text": "Get demographic information summary",\n      "Data_source": ["Part A"]\n    },\n    {\n      "Query_text": "Check MVRStatus, driving license validity, riskclass score and violations",\n      "Data_source": ["MVR"]\n    },\n    {\n      "Query_text": "Get miscellaneous information not covered in standard categories",\n      "Data_source": ["Part A"]\n    },\n    {\n      "Query_text": "Identify any risk factors or notable findings that require underwriter attention",\n      "Data_source": ["Part A"]\n    }\n  ]\n}'

    #'{"Search_query_texts": [\n    {\n      "Query_text": "Find physical metrics information including height, weight, and build measurements",\n      "Data_source": ["Lab Tests", "MIB", "Part B"]\n    },\n    {\n      "Query_text": "Gather medical history including past and current health conditions",\n      "Data_source": ["Part B", "MIB", "Dx"]\n    },\n    {\n      "Query_text": "Check for substance use history including tobacco, alcohol, and drug usage",\n      "Data_source": ["Part A", "Part B", "Rx"]\n    },\n    {\n      "Query_text": "Review for any specific underwriting considerations or concerns that need attention",\n      "Data_source": ["Part A", "Part B", "MIB", "Rx"]\n    }\n  ]\n}'
    #'{"Search_query_texts": [\n    {\n      "Query_text": "Get demographic information summary",\n      "Data_source": ["Part A"]\n    },\n    {\n      "Query_text": "Check MVRStatus, driving license validity and violations",\n      "Data_source": ["MVR"]\n    },\n    {\n      "Query_text": "Get miscellaneous information not covered in standard categories",\n      "Data_source": ["Part A"]\n    },\n    {\n      "Query_text": "Identify any risk factors or notable findings that require underwriter attention",\n      "Data_source": ["Part A"]\n    }\n  ]\n}'
    #'{"Search_query_texts": [\n    {\n      "Query_text": "Get applicant\'s demographic and financial information",\n      "Data_source": ["Part A"]\n    },\n    {\n      "Query_text": "Get applicant\'s current and past medical conditions",\n      "Data_source": ["Part B", "MIB"]\n    },\n    {\n      "Query_text": "Get medication and prescription history",\n      "Data_source": ["Rx"]\n    },\n    {\n      "Query_text": "Get laboratory test results and physical measurements",\n      "Data_source": ["Lab Tests", "Dx"]\n    },\n    {\n      "Query_text": "Get MVR status and violations",\n      "Data_source": ["MVR"]\n    }\n  ]\n}'
    
    # state.interim_response = json.dumps(response_structure, indent=2)
    state.messages.append({"role": "State Transformer", "content": f"{state.interim_response}"})
    state.steps_completed.append(state.current_step)
    
    logger.info(f"Updated state with query structure")
    
    return state

def update_state_for_medical_summary(state: AgentState) -> AgentState:
    """
    Update state for medical summary.
    """
    logger.info("Updating state for medical summary")
    state.input_message = "Write a summary on Physical Metrics, Medical History, Substance Use, Miscellaneous and Additional Notes section. For medical history, include prescription date last filled, date first filled, total number of refills allowed, total number of refills taken and drug class for each major prescrption you put in the summary. Also include lab tests, diagnosis, scores. For physical metrics include the height, weight, bmi, blood pressure, pulse. For substance use inclue tobacco, alcohol, drug, nicotine, marihuana or any other substance. For Miscellaneous, include beneficiary type information. The additional notes should only include recommendations for underwriters if there are any. The additional notes should be concise and to the point. Format the response with hidden markdown headers: start each section with <!-- Section: <section_name> --> where section names are Physical Metrics, Medical History, Substance Use, Miscellaneous, Additional Notes."
    state.current_step = "Preparing query structure for medical summary"
    
    state.interim_response = '{"Search_query_texts": [     {       "Query_text": "Find height, weight, BMI, blood pressure, and pulse measurements",       "Data_source": ["Lab Tests", "MIB"]     },     {       "Query_text": "Find medical conditions and diagnoses",       "Data_source": ["Part B"]     },     {       "Query_text": "Find prescription medications including fill dates, refills, and drug classifications",       "Data_source": ["Rx"]     },     {       "Query_text": "Find lab test results and medical test scores",       "Data_source": ["Lab Tests"]     },     {       "Query_text": "Find usage history of tobacco, alcohol, nicotine, marijuana, and other substances",       "Data_source": ["Part B", "MIB"]     }, {"Query_text": "Find beneficiary type information", "Data_source": ["Part B"]}   ] }'
    #'{"Search_query_texts": [\n    {\n      "Query_text": "Find physical metrics information including height, weight, and build measurements",\n      "Data_source": ["Lab Tests", "MIB", "Part B"]\n    },\n    {\n      "Query_text": "Gather medical history including past and current health conditions",\n      "Data_source": ["Part B", "MIB", "Dx"]\n    },\n    {\n      "Query_text": "Check for substance use history including tobacco, alcohol, and drug usage",\n      "Data_source": ["Part A", "Part B", "Rx"]\n    },\n    {\n      "Query_text": "Review for any specific underwriting considerations or concerns that need attention",\n      "Data_source": ["Part A", "Part B", "MIB", "Rx"]\n    }\n  ]\n}'
    
    state.messages.append({"role": "State Transformer", "content": f"{state.interim_response}"})
    state.steps_completed.append(state.current_step)
    
    logger.info(f"Updated state with medical summary query structure")

    return state

def update_state_for_overall_summary(state: AgentState) -> AgentState:
    """
    Update state for overall summary.
    """
    logger.info("Updating state for overall summary")
    state.input_message = "Write an overall summary of the application."
    state.current_step = "Preparing query structure for overall summary"

    state.interim_response = state.overall_summary
    state.messages.append({"role": "State Transformer", "content": f"{state.interim_response}"})
    state.steps_completed.append(state.current_step)
    
    logger.info(f"Updated state with overall summary query structure")

    return state

def set_summary_generation_mode(state: AgentState) -> AgentState:
    """
    Set environment variable to indicate summary generation mode.
    """
    logger.info("Setting summary generation mode")
    os.environ['generating_summary'] = "True"
    state.current_step = "Setting summary generation mode"
    state.messages.append({"role": "System", "content": "Summary generation mode enabled"})
    return state

def unset_summary_generation_mode(state: AgentState) -> AgentState:
    """
    Unset environment variable for summary generation mode.
    """
    logger.info("Unsetting summary generation mode")
    os.environ['generating_summary'] = "False"
    state.current_step = "Unsetting summary generation mode"
    state.messages.append({"role": "System", "content": "Summary generation mode disabled"})
    return state

def store_demographics_summary(state: AgentState) -> AgentState:
    """
    Store the demographics summary result.
    """
    logger.info("Storing demographics summary")
    state.demographics_summary = state.ai_response
    state.messages.append({"role": "System", "content": f"Demographics summary stored: {state.demographics_summary}"})
    return state

def store_medical_summary(state: AgentState) -> AgentState:
    """
    Store the medical summary result.
    """
    logger.info("Storing medical summary")
    state.medical_summary = state.ai_response
    state.messages.append({"role": "System", "content": f"Medical summary stored: {state.medical_summary}"})
    return state

def prepare_overall_summary_input(state: AgentState) -> AgentState:
    """
    Prepare the input for overall summary by combining stored summaries.
    """
    logger.info("Preparing overall summary input")
    combined_summaries = f"""
Demographics Summary:
{state.demographics_summary}

Medical Summary:
{state.medical_summary}

Please provide an overall summary of the application based on the above summaries.
"""
    state.input_message = combined_summaries
    state.current_step = "Preparing for overall summary"
    state.messages.append({"role": "System", "content": f"Prepared combined input for overall summary"})
    return state

# Create separate workflows for each summary type
def create_demographics_workflow():
    """Create workflow for demographics summary only."""
    workflow = StateGraph(AgentState)
    
    relevancy_checker_agent = RelevancyCheckerAgent()
    chief_reasoning_agent = ChiefReasoningAgent()
    
    workflow.add_node("Extract Data Sources", fetch_data_source)
    workflow.add_node("Update State After Data Sources", update_state_after_data_sources)
    workflow.add_node("Extracting Relevant Text", extract_text_from_data_sources)
    workflow.add_node("Relevancy Checker Agent", relevancy_checker_agent)
    workflow.add_node("Set Summary Generation Mode", set_summary_generation_mode)
    workflow.add_node("Chief Reasoning Agent", chief_reasoning_agent)
    workflow.add_node("Unset Summary Generation Mode", unset_summary_generation_mode)
    workflow.add_node("Store Demographics Summary", store_demographics_summary)
    
    workflow.set_entry_point("Extract Data Sources")
    workflow.add_edge(START, "Extract Data Sources")
    workflow.add_edge("Extract Data Sources", "Update State After Data Sources")
    workflow.add_edge("Update State After Data Sources", "Extracting Relevant Text")
    workflow.add_edge("Extracting Relevant Text", "Relevancy Checker Agent")
    workflow.add_edge("Relevancy Checker Agent", "Set Summary Generation Mode")
    workflow.add_edge("Set Summary Generation Mode", "Chief Reasoning Agent")
    workflow.add_edge("Chief Reasoning Agent", "Unset Summary Generation Mode")
    workflow.add_edge("Unset Summary Generation Mode", "Store Demographics Summary")
    workflow.add_edge("Store Demographics Summary", END)
    
    return workflow.compile()

def create_medical_workflow():
    """Create workflow for medical summary only."""
    workflow = StateGraph(AgentState)
    
    relevancy_checker_agent = RelevancyCheckerAgent()
    chief_reasoning_agent = ChiefReasoningAgent()
    
    workflow.add_node("Extract Data Sources", fetch_data_source)
    workflow.add_node("Update State For Medical Summary", update_state_for_medical_summary)
    workflow.add_node("Extracting Relevant Text", extract_text_from_data_sources)
    workflow.add_node("Relevancy Checker Agent", relevancy_checker_agent)
    workflow.add_node("Set Summary Generation Mode", set_summary_generation_mode)
    workflow.add_node("Chief Reasoning Agent", chief_reasoning_agent)
    workflow.add_node("Unset Summary Generation Mode", unset_summary_generation_mode)
    workflow.add_node("Store Medical Summary", store_medical_summary)
    
    workflow.set_entry_point("Extract Data Sources")
    workflow.add_edge(START, "Extract Data Sources")
    workflow.add_edge("Extract Data Sources", "Update State For Medical Summary")
    workflow.add_edge("Update State For Medical Summary", "Extracting Relevant Text")
    workflow.add_edge("Extracting Relevant Text", "Relevancy Checker Agent")
    workflow.add_edge("Relevancy Checker Agent", "Set Summary Generation Mode")
    workflow.add_edge("Set Summary Generation Mode", "Chief Reasoning Agent")
    workflow.add_edge("Chief Reasoning Agent", "Unset Summary Generation Mode")
    workflow.add_edge("Unset Summary Generation Mode", "Store Medical Summary")
    workflow.add_edge("Store Medical Summary", END)
    
    return workflow.compile()

def create_overall_summary_workflow():
    """Create workflow for overall summary only."""
    workflow = StateGraph(AgentState)
    
    chief_reasoning_agent = ChiefReasoningAgent()
    
    workflow.add_node("Prepare Overall Summary Input", prepare_overall_summary_input)
    workflow.add_node("Chief Reasoning Agent", chief_reasoning_agent)
    
    workflow.set_entry_point("Prepare Overall Summary Input")
    workflow.add_edge(START, "Prepare Overall Summary Input")
    workflow.add_edge("Prepare Overall Summary Input", "Chief Reasoning Agent")
    workflow.add_edge("Chief Reasoning Agent", END)
    
    return workflow.compile()

# Original complete workflow (kept for reference)
workflow = StateGraph(AgentState)

# Initialize agents
# intent_classify_agent = IntentClassificationAgent()
# query_process_agent = QueryProcessingAgent()
relevancy_checker_agent = RelevancyCheckerAgent()
chief_reasoning_agent = ChiefReasoningAgent()

# Add agents to the workflow
# workflow.add_node("Intent Classification Agent", intent_classify_agent)
workflow.add_node("Extract Data Sources", fetch_data_source)
workflow.add_node("Update State After Data Sources", update_state_after_data_sources)
# workflow.add_node("Query Processing Agent", query_process_agent)
workflow.add_node("Update State For Medical Summary", update_state_for_medical_summary)
workflow.add_node("Update State For Overall Summary", update_state_for_overall_summary)
workflow.add_node("Extracting Relevant Text", extract_text_from_data_sources)
workflow.add_node("Relevancy Checker Agent", relevancy_checker_agent)
workflow.add_node("Chief Reasoning Agent", chief_reasoning_agent)

# Add edges to the workflow
# workflow.set_entry_point("Intent Classification Agent")
# workflow.add_edge(START, "Intent Classification Agent")

# # Conditional edge after database check
# def decide_next_step(state: AgentState) -> str:
#     logger.info(f"Deciding next step basis on {state.ai_response}")
#     if state.ai_response:
#         return "END" # Call Extract MIB Code if MIB Codes in state is None
#     return "Extract Data Sources"  # Skip to agent if database_result is populated

# workflow.add_conditional_edges("Intent Classification Agent", decide_next_step,
#                                {"END": END, "Extract Data Sources": "Extract Data Sources"})

workflow.set_entry_point("Extract Data Sources")
workflow.add_edge(START, "Extract Data Sources")
workflow.add_edge("Extract Data Sources", "Update State After Data Sources")
# workflow.add_edge("Extract Data Sources", "Query Processing Agent")
# workflow.add_edge("Query Processing Agent", "Extracting Relevant Text")
workflow.add_edge("Update State After Data Sources", "Extracting Relevant Text")
workflow.add_edge("Extracting Relevant Text", "Relevancy Checker Agent")
workflow.add_edge("Relevancy Checker Agent", "Chief Reasoning Agent")
workflow.add_edge("Chief Reasoning Agent", "Update State For Medical Summary")
workflow.add_edge("Update State For Medical Summary", "Extracting Relevant Text")
workflow.add_edge("Extracting Relevant Text", "Relevancy Checker Agent")
workflow.add_edge("Relevancy Checker Agent", "Chief Reasoning Agent")
workflow.add_edge("Chief Reasoning Agent", "Update State For Overall Summary")
workflow.add_edge("Update State For Overall Summary", "Chief Reasoning Agent")
workflow.add_edge("Chief Reasoning Agent", END)

summary_graph = workflow.compile()
