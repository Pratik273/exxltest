from pydantic import BaseModel
from typing import List, Optional, Annotated
# from langgraph.graph import add_messages


# class InputState(BaseModel):
#     input_message: str = None
#     application_number: str = None
#     session_id: str = None
#     user_id: str = None

# class OutputState(BaseModel):
#     ai_thought: Optional[str] = None
#     ai_response: Optional[str] = None
#     confidence_score: Optional[str] = None

class AgentState(BaseModel):
    messages: List[dict] = []
    interim_response: Optional[str] = None
    available_data_sources: List[str] = None
    steps_completed: List[str] = []
    conversation_id: str = None
    current_step: str = "start"
    demographics_summary: Optional[str] = ""
    medical_summary: Optional[str] = ""
    overall_summary: Optional[str] = ""
    ai_thought: Optional[str] = None
    ai_response: Optional[str] = None
    confidence_score: Optional[str] = None
    input_message: str = None
    application_number: str = None
    session_id: str = None
    user_id: str = None
