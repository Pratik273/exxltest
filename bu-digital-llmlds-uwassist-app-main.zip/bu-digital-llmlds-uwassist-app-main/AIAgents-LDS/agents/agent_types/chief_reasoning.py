import os
import sys
from typing import List
from dotenv import load_dotenv
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
from agents.state import AgentState
from agents.agent_types.general_agent import BaseAgent
from utils.calling_claude_model import invoking_claude
from utils.llm_retries_and_validation import call_llm_with_retries
from utils.response_structures import ChiefReasoningResponse
from prompts.multi_agent_prompts import CHIEF_REASONING_SYSTEM_PROMPT, CHIEF_REASONING_DATA_SYSTEM_PROMPT, CHIEF_REASONING_SUMMARY_SYSTEM_PROMPT
from utils.store_data_in_psql_db import store_messages, fetch_extracted_date
from utils.summary_parser import call_llm_with_section_validation
from loguru import logger
import json


class ChiefReasoningAgent(BaseAgent):
    load_dotenv(override=True)
    def __init__(self):
        super().__init__("Chief Reasoning Agent")

    def __call__(self, state: AgentState):
        state.current_step = "Reasoning & Refining the answer"
        is_generating_data = os.getenv('generating_data')
        is_generating_summary = os.getenv('generating_summary')
        #logger.debug(f"Generating data flag: {is_generating_data}")
        
        if is_generating_data == "True":
            system_prompt = CHIEF_REASONING_DATA_SYSTEM_PROMPT
        elif is_generating_summary == "True":
            system_prompt = CHIEF_REASONING_SUMMARY_SYSTEM_PROMPT
        else:
            system_prompt = CHIEF_REASONING_SYSTEM_PROMPT
            
        extracted_date = fetch_extracted_date(state.application_number)
        user_prompt = state.input_message + "Application Date: " + str(extracted_date) + "Available answers " + str(state.interim_response)
        
        # Use section validation retry for summaries
        if is_generating_summary == "True":
            # Determine required sections based on the input message
            required_sections = self._get_required_sections(state.input_message)
            summary_type = self._get_summary_type(state.input_message)
            
            logger.debug(f"Using section validation retry for {summary_type} summary")
            logger.debug(f"Required sections: {required_sections}")
            
            # Use the section validation retry function
            response = call_llm_with_section_validation(
                invoking_claude,
                system_prompt,
                user_prompt,
                required_sections,
                max_retries=3,
                summary_type=summary_type
            )
            
            if response:
                # For summaries, we need to wrap the response in the expected JSON format
                state.interim_response = json.dumps({
                    "Thought": f"Generated {summary_type} summary with section validation",
                    "Answer": response,
                    "Confidence_Score": "85%"
                })
                # state.interim_response = response
            else:
                # Fallback to regular retry if section validation fails
                logger.warning("Section validation retry failed, falling back to regular retry")
                response = call_llm_with_retries(invoking_claude, system_prompt, user_prompt, ChiefReasoningResponse)
                state.interim_response = response
        else:
            # Use regular retry for non-summary tasks
            response = call_llm_with_retries(invoking_claude, system_prompt, user_prompt, ChiefReasoningResponse)
            state.interim_response = response
        
        self.update_state(state)
        self.store_responses_in_db(state)
        return state

    def _get_required_sections(self, input_message: str) -> List[str]:
        """
        Determine required sections based on the input message.
        
        Args:
            input_message: The input message to analyze
            
        Returns:
            List of required section names
        """
        input_lower = input_message.lower()
        
        # Demographics summary sections
        if any(keyword in input_lower for keyword in ['demographics', 'mvr']):
            return ["Demographics", "MVR", "Miscellaneous", "Additional Notes"]
        
        # Medical summary sections
        elif any(keyword in input_lower for keyword in ['physical metrics', 'medical history', 'substance use']):
            return ["Physical Metrics", "Medical History", "Substance Use", "Miscellaneous", "Additional Notes"]
        
        # Default to demographics if unclear
        else:
            logger.warning(f"Could not determine summary type from input: {input_message}")
            return ["Demographics", "MVR", "Miscellaneous", "Additional Notes"]

    def _get_summary_type(self, input_message: str) -> str:
        """
        Determine summary type based on the input message.
        
        Args:
            input_message: The input message to analyze
            
        Returns:
            Summary type string for logging
        """
        input_lower = input_message.lower()
        
        if any(keyword in input_lower for keyword in ['demographics', 'mvr']):
            return "demographics"
        elif any(keyword in input_lower for keyword in ['physical metrics', 'medical history', 'substance use']):
            return "medical"
        else:
            return "unknown"

    def update_state(self, state):
        # response_json = fix_json_quotes(state.interim_response)
        response_json = json.loads(state.interim_response)
        state.ai_thought = response_json["Thought"]
        if "Answer" in response_json and response_json["Answer"]:
            state.ai_response = response_json["Answer"]
            if response_json["Confidence_Score"]:
                state.confidence_score = response_json["Confidence_Score"]
        else:
            logger.debug("Chief Reasoning Agent didn't give any answer")
        
        state.messages.append({"role": "Chief Reasoning Agent", "content": state.interim_response})
        state.steps_completed.append(state.current_step)
        return state
    
    def store_responses_in_db(self, state: AgentState):
        is_message_stored = store_messages(state.conversation_id, "Chief Reasoning Agent", state.interim_response, "final_answer", state.ai_thought)
        if not is_message_stored:
            logger.error("Couldn't store response from Chief Reasoning Agent in DB")

if __name__ == "__main__":
    # 
    state = AgentState(input_message = "Provide an overall summary of the application.", application_number = "9218062")
    # state.available_data_sources = ["Page A", "Part B", "Rx", "MIB", "Lab Tests", "Other"]
    # state.interim_response = '{   "Results": [     {       "Data_source": "Part B",       "Extracted_date": null,       "Relevant_text": "Has the Proposed Insured had a change in weight greater than 10 pounds? Answer: No"     },     {       "Data_source": "Lab Tests",       "Extracted_date": "2023-03-22",       "Relevant_text": "weight: 228"     }   ] }'
    state.interim_response = """
    Demographics:
- Age: 46
- Gender: Male
- Occupation: Other
- US Citizen: Yes
- Birth Country: USA
- Residence: USA

MVR:
- MVR Status: Cancelled (Status 5)
- LexisNexis Clear indicated

Miscellaneous:
- Coverage: MyLife Term Insurance 20 Year Option
- Base Amount: $300,000
- Annual Premium: $2,058.00
- Aviation: Not provided
- Avocation: Not provided
- Foreign Travel: Not provided
- Criminal Background: Not provided

Additional Notes:
- Recommend underwriter review of cancelled driving status

Physical Metrics:
• Height: 5'7" (67 inches)
• Weight: 185 lbs
• BMI: 29.0 (Overweight)

Medical History:
• Lab Tests:
  - Glucose: 103 mg/dL (Elevated)
  - Cholesterol: 144 mg/dL (Normal)
  - HDL: 49 mg/dL (Normal)
  - LDL: 78 mg/dL (Normal)
  - Triglycerides: 83 mg/dL (Normal)
  - TSH: 1.17 mIU/L (Normal)
• Diagnosis:
  - Melanocytic nevi of scalp and neck (D224)
  - Surgical pathology examination in May 2023

Substance Use:
• Tobacco user - current
  - Non-inhaled forms (chew/patches) within last 12 months
  - 5-year history of use
• Marijuana use
  - Weekly THC usage through inhalation (non-vaping)

Additional Notes:
• Follow-up needed on recent skin lesion pathology
• Monitor elevated glucose levels
• Drug questionnaire recommended for marijuana use details
• Consider impact of multiple substance use (tobacco and marijuana)

    """
    agent = ChiefReasoningAgent()
    updated_state = agent(state)
    logger.debug(updated_state.current_step)
    print(updated_state.interim_response)
    logger.debug(updated_state.application_number)
    # logger.info(state.available_data_sources)