import os
import sys
import re
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
from agents.state import AgentState
from loguru import logger
from scripts.database.check_db_conn import connect_to_db
from utils.embeddings import get_embedding
from utils.store_data_in_psql_db import store_messages
from utils.text_processing_lite import reduce_context_with_sliding_window_lite, intelligent_json_chunker
import json
import hashlib
from difflib import SequenceMatcher
import copy

# Set a threshold for context length to trigger reduction
CONTEXT_LENGTH_THRESHOLD = 15000
CHUNK_LENGTH_THRESHOLD = 4500  # Set threshold for individual chunk size
SIMILARITY_THRESHOLD = 0.85  # Threshold for considering chunks as duplicates
DEDUPLICATION_THRESHOLD = 200000  # Only apply deduplication if total content exceeds 200k characters

def calculate_content_hash(text):
    """Calculate SHA-256 hash of normalized text content."""
    # Normalize text by removing extra whitespace and converting to lowercase
    normalized_text = ' '.join(text.lower().split())
    return hashlib.sha256(normalized_text.encode()).hexdigest()

def calculate_similarity(text1, text2):
    """Calculate similarity ratio between two text strings."""
    return SequenceMatcher(None, text1.lower(), text2.lower()).ratio()

def extract_json_sections(text, query=None):
    """
    Extract key-value sections from JSON-like text content.
    Returns a dictionary of sections that can be compared for similarity.
    If a query is provided, sections matching query keywords are prioritized, including inline key-value pairs.
    """
    sections = {}
    query_keywords = set()
    stopwords = {'the', 'and', 'or', 'for', 'to', 'of', 'in', 'on', 'with', 'a', 'an', 'is', 'are', 'was', 'were', 'by', 'at', 'as', 'from', 'that', 'this', 'it', 'be'}

    # Extract keywords from query
    if query:
        query_keywords = set(
            word.lower() for word in re.findall(r'\w+', query)
            if word.lower() not in stopwords and len(word) > 2
        )

    def extract_inline_pairs(line, keywords):
        """
        Extracts key-value pairs from a line for the given keywords.
        Returns a dict of {keyword_info: value}.
        """
        found = {}
        # Look for patterns like 'Height: 170 cm' or 'Weight = 70kg'
        for kw in keywords:
            # Regex: keyword followed by :, =, or - and then value
            match = re.search(rf'{kw}[:=\-]\s*([^,;\n]+)', line, re.IGNORECASE)
            if match:
                found[f"{kw}_info"] = match.group(1).strip()
            # Also catch cases like 'height 170 cm' (no colon)
            else:
                match2 = re.search(rf'{kw}\s+([\d\.]+\s*\w*)', line, re.IGNORECASE)
                if match2:
                    found[f"{kw}_info"] = match2.group(1).strip()
        return found

    try:
        # Try to parse as JSON first
        if text.strip().startswith('{') or text.strip().startswith('['):
            json_data = json.loads(text)
            if isinstance(json_data, dict):
                for key, value in json_data.items():
                    sections[key] = str(value)
            elif isinstance(json_data, list):
                for i, item in enumerate(json_data):
                    sections[f"item_{i}"] = str(item)
        else:
            # For non-JSON text, split into logical sections
            lines = text.split('\n')
            current_section = ""
            section_name = "general"
            query_sections = {}  # For query-matched sections

            for line in lines:
                line = line.strip()
                if not line:
                    continue

                # Inline key-value extraction for query keywords
                if query_keywords:
                    inline_pairs = extract_inline_pairs(line, query_keywords)
                    for k, v in inline_pairs.items():
                        # Add the full line as value for context
                        query_sections[f"query_{k}"] = f"{k.replace('_info','').capitalize()}: {v} (from line: {line})"

                # Check for query keyword match anywhere in the line
                matched_keywords = [kw for kw in query_keywords if kw in line.lower()]
                if matched_keywords:
                    # Save current section if not empty
                    if current_section:
                        sections[section_name] = current_section
                    # Start a new section for each matched keyword (if not already added by inline extraction)
                    for kw in matched_keywords:
                        key = f"query_{kw}_info"
                        if key not in query_sections:
                            query_sections[key] = line + "\n"
                    section_name = "general"  # Reset to general for next lines
                    current_section = ""
                    continue

                # Detect section headers (default logic)
                if any(keyword in line.lower() for keyword in ['physician', 'doctor', 'specialty', 'provider', 'clinic']):
                    if current_section:
                        sections[section_name] = current_section
                    section_name = "physician_info"
                    current_section = line + "\n"
                elif any(keyword in line.lower() for keyword in ['MVRStatus', 'driving', 'license', 'violations', 'MVR', 'MVRReport', 'DriversLicense', 'expiration', 'suspension', 'conviction', 'violation']):
                    if current_section:
                        sections[section_name] = current_section
                    section_name = "MVR_info"
                    current_section = line + "\n"
                elif any(keyword in line.lower() for keyword in ['diagnosis', 'condition', 'disease', 'icd']):
                    if current_section:
                        sections[section_name] = current_section
                    section_name = "diagnosis_info"
                    current_section = line + "\n"
                elif any(keyword in line.lower() for keyword in ['medication', 'drug', 'prescription', 'PrescriptionLabel', 'PrescriptionDrug', 'rx']):
                    if current_section:
                        sections[section_name] = current_section
                    section_name = "medication_info"
                    current_section = line + "\n"
                elif any(keyword in line.lower() for keyword in ['test', 'lab', 'result', 'value', 'PrescriptionLabel', 'PrescriptionDrug']):
                    if current_section:
                        sections[section_name] = current_section
                    section_name = "test_info"
                    current_section = line + "\n"
                elif any(keyword in line.lower() for keyword in ['Prescription', 'drug', 'compliance', 'doctor', 'visit', 'Rx']):
                    if current_section:
                        sections[section_name] = current_section
                    section_name = "prescriptions"
                    current_section = line + "\n"
                
                else:
                    current_section += line + "\n"

            # Add the last section
            if current_section:
                sections[section_name] = current_section
            # Add query-matched sections at the beginning (prioritized)
            if query_sections:
                prioritized = {**query_sections, **sections}
                sections = prioritized
    except Exception as e:
        logger.debug(f"Error extracting JSON sections: {e}")
        # Fallback: treat entire text as one section
        sections["content"] = text

    return sections

def find_similar_sections(sections1, sections2, threshold=0.8):
    """
    Find sections that are similar between two section dictionaries.
    Returns list of (section_name1, section_name2, similarity_score) tuples.
    """
    similar_sections = []
    
    for name1, content1 in sections1.items():
        for name2, content2 in sections2.items():
            similarity = calculate_similarity(content1, content2)
            if similarity >= threshold:
                similar_sections.append((name1, name2, similarity))
    
    return similar_sections

def deduplicate_chunk_content(chunks):
    """
    Advanced deduplication that compares sections within JSON chunks
    and removes redundant information at the field level.
    """
    if not chunks:
        return chunks
    
    # Extract sections from each chunk
    chunk_sections = []
    for i, chunk in enumerate(chunks):
        sections = extract_json_sections(chunk["Data"])
        chunk_sections.append((i, sections))
    
    # Track which sections to keep/remove
    sections_to_remove = set()  # (chunk_index, section_name)
    
    # Compare sections across all chunks
    for i, (chunk_idx1, sections1) in enumerate(chunk_sections):
        for j, (chunk_idx2, sections2) in enumerate(chunk_sections[i+1:], i+1):
            similar_sections = find_similar_sections(sections1, sections2, threshold=0.8)
            
            for section1, section2, similarity in similar_sections:
                # Since we don't have reliable date info, use a different heuristic
                # Keep the longer, more detailed section and remove the shorter one
                section1_len = len(sections1[section1])
                section2_len = len(sections2[section2])
                
                if section1_len >= section2_len:
                    sections_to_remove.add((chunk_idx2, section2))
                    logger.debug(f"[DEDUP] Marking section '{section2}' from chunk {chunk_idx2} for removal (similarity: {similarity:.2f}, shorter section)")
                else:
                    sections_to_remove.add((chunk_idx1, section1))
                    logger.debug(f"[DEDUP] Marking section '{section1}' from chunk {chunk_idx1} for removal (similarity: {similarity:.2f}, shorter section)")
    
    # Reconstruct chunks with deduplicated content
    deduplicated_chunks = []
    original_total_length = sum(len(chunk["Data"]) for chunk in chunks)
    
    for i, chunk in enumerate(chunks):
        sections = chunk_sections[i][1]
        
        # Remove marked sections
        filtered_sections = {
            name: content for name, content in sections.items()
            if (i, name) not in sections_to_remove
        }
        
        if filtered_sections:
            # Reconstruct the content
            if len(filtered_sections) == 1 and "content" in filtered_sections:
                # Single content section - use as is
                new_content = filtered_sections["content"]
            else:
                # Multiple sections - combine them
                new_content = ""
                for section_name, section_content in filtered_sections.items():
                    if section_name != "general":
                        new_content += f"\n--- {section_name.replace('_', ' ').title()} ---\n"
                    new_content += section_content + "\n"
            
            # Only add if there's meaningful content left
            if new_content.strip():
                deduplicated_chunk = chunk.copy()
                deduplicated_chunk["Data"] = new_content.strip()
                deduplicated_chunks.append(deduplicated_chunk)
        else:
            logger.debug(f"Chunk {i} from source '{chunk['source']}' was completely removed due to duplication")
    
    # Log deduplication results
    new_total_length = sum(len(chunk["Data"]) for chunk in deduplicated_chunks)
    reduction_percentage = ((original_total_length - new_total_length) / original_total_length * 100) if original_total_length > 0 else 0
    
    logger.debug(f"Content deduplication completed:")
    logger.debug(f"  - Original chunks: {len(chunks)}, Final chunks: {len(deduplicated_chunks)}")
    logger.debug(f"  - Original content length: {original_total_length}, Final length: {new_total_length}")
    logger.debug(f"  - Content reduction: {reduction_percentage:.1f}%")
    logger.debug(f"  - Sections removed: {len(sections_to_remove)}")
    
    return deduplicated_chunks

def apply_additional_reduction(chunks, state, target_length=DEDUPLICATION_THRESHOLD):
    """
    Apply additional reduction techniques when content is still too large after deduplication.
    Uses fuzzy matching to score and keep most relevant content across all sources.
    Query-focused scoring: prioritizes chunks with high density of query keyword matches.
    """
    if not chunks:
        return chunks

    current_length = sum(len(chunk["Data"]) for chunk in chunks)
    if current_length <= target_length:
        return chunks

    logger.debug(f"Applying additional reduction. Current length: {current_length:,}, Target: {target_length:,}")

    # Get the original query from state if available
    query_text = ""
    try:
        if hasattr(state, 'input_message') and state.input_message:
            query_text = state.input_message
        elif hasattr(state, 'interim_response') and state.interim_response:
            json_query = json.loads(state.interim_response)
            if "Search_query_texts" in json_query:
                query_texts = json_query["Search_query_texts"]
                query_text = " ".join([q["Query_text"] for q in query_texts])
    except Exception as e:
        logger.debug(f"Could not extract query text: {e}")

    # Extract query keywords
    stopwords = {'the', 'and', 'or', 'for', 'to', 'of', 'in', 'on', 'with', 'a', 'an', 'is', 'are', 'was', 'were', 'by', 'at', 'as', 'from', 'that', 'this', 'it', 'be'}
    query_keywords = set(
        word.lower() for word in re.findall(r'\w+', query_text)
        if word.lower() not in stopwords and len(word) > 2
    )

    # Score chunks by relevance to query and important content markers
    scored_chunks = []
    important_keywords = [
        'positive', 'negative', 'abnormal', 'elevated', 'diagnosis', 
        'critical', 'medication', 'treatment', 'prescription', 'test', 
        'result', 'value', 'finding', 'history', 'assessment', 'height', 
        'weight', 'violations', 'policy', 'insurance', 'mortality', 'status', 
        'responseData', 'meaning', 'code', 'physician', 'specialty', 'requirements', 
        'citizen', 'age', 'gender', 'expiration', 'credit score', 'description', 
        'MVRStatus', 'MVR', 'DriversLicense', 'suspension', 'conviction', 'license', 'driving']

    for i, chunk in enumerate(chunks):
        content = chunk["Data"]
        score = 0
        content_lower = content.lower()
        content_length = len(content)

        # Query keyword match density
        if query_keywords:
            query_match_count = sum(content_lower.count(word) for word in query_keywords)
            query_density = (query_match_count / (content_length / 1000 + 1))  # matches per 1000 chars
            score += int(query_density * 20)  # scale as needed
            # Bonus if all query keywords are present
            if all(word in content_lower for word in query_keywords):
                score += 30

        # Presence of important medical/insurance keywords (lower weight)
        for keyword in important_keywords:
            if keyword in content_lower:
                score += 1  # reduced from 3 to 1

        # Data point density (numbers, dates, key terms)
        if content_length > 0:
            data_points = len([m for m in re.finditer(r'\b\d+\b|\b\d{1,2}/\d{1,2}/\d{2,4}\b|\b(diagnosed|prescribed|tested)\b', content)])
            density_score = min(data_points * 2, 10)  # Cap at 10 points, reduced
            score += density_score

        # Cap the influence of chunk length
        score = min(score, 100)

        scored_chunks.append((chunk, score, content_length))
        logger.debug(f"Chunk {i} from source {chunk['source']} scored {score} points, length: {content_length}")

    # Sort chunks by score (highest first)
    scored_chunks.sort(key=lambda x: x[1], reverse=True)

    # Build reduced set, taking highest scored chunks until we hit the target length
    reduced_chunks = []
    total_length = 0

    for chunk, score, length in scored_chunks:
        remaining_budget = target_length - total_length

        if length <= remaining_budget:
            # Chunk fits completely
            reduced_chunks.append(chunk)
            total_length += length
            logger.debug(f"Added complete chunk from source {chunk['source']}, score: {score}")
            if target_length - total_length < 5000:  # Allow small margin under target
                break
        else:
            # See if it's worth truncating this chunk
            if remaining_budget > 1000 and score > 30:  # Only truncate high-value chunks
                truncated_content = intelligent_truncate(chunk["Data"], remaining_budget)
                if truncated_content:
                    truncated_chunk = chunk.copy()
                    truncated_chunk["Data"] = truncated_content
                    reduced_chunks.append(truncated_chunk)
                    total_length += len(truncated_content)
                    logger.debug(f"Added truncated chunk from source {chunk['source']}, score: {score}")
                    break

    final_length = sum(len(chunk["Data"]) for chunk in reduced_chunks)
    reduction_percentage = ((current_length - final_length) / current_length * 100) if current_length > 0 else 0

    # Sort final chunks back to original source order before returning
    reduced_chunks.sort(key=lambda x: x.get("source", ""))

    logger.debug(f"Additional reduction completed:")
    logger.debug(f"  - Original chunks: {len(chunks)}, Final chunks: {len(reduced_chunks)}")
    logger.debug(f"  - Original length: {current_length:,}, Final length: {final_length:,}")
    logger.debug(f"  - Additional reduction: {reduction_percentage:.1f}%")
    logger.debug(f"  - Sources kept: {', '.join(sorted(set(chunk['source'] for chunk in reduced_chunks)))}")

    return reduced_chunks

def intelligent_truncate(content, max_length):
    """
    Intelligently truncate content while preserving important information.
    Prioritizes keeping key sections and maintains readability.
    """
    if len(content) <= max_length:
        return content
    
    # Strategy: Keep beginning and end, truncate middle if possible
    if max_length < 100:
        return content[:max_length] + "..."
    
    # Try to preserve JSON structure if it's JSON
    if content.strip().startswith('{') or content.strip().startswith('['):
        try:
            json_data = json.loads(content)
            # Keep only most important fields
            if isinstance(json_data, dict):
                important_keys = ['diagnosis', 'medication', 'test_result', 'condition', 'value', 'violations', 'prescriptions', 'PrescriptionLabel', 'PrescriptionDrug', 'policy', 'insurance', 'lab tests', 'diagnosis', 'physicians', 'ResponseData', 'meaning', 'code', 'specialty', 'requirements', 'citizen', 'age', 'gender', 'expiration', 'credit score', 'description', 'MVRStatus', 'MVRResults', 'MVRReport',  'DriversLicense']
                filtered_data = {k: v for k, v in json_data.items() 
                               if any(key in k.lower() for key in important_keys)}
                if filtered_data:
                    truncated_json = json.dumps(filtered_data, indent=2)
                    if len(truncated_json) <= max_length:
                        return truncated_json
        except:
            pass
    
    # Fallback: Keep beginning and add truncation marker
    keep_length = max_length - 50  # Reserve space for truncation message
    truncated = content[:keep_length]
    
    # Try to break at a sensible point (end of sentence, line, etc.)
    for break_char in ['\n\n', '\n', '. ', ', ']:
        break_point = truncated.rfind(break_char)
        if break_point > keep_length * 0.7:  # Don't break too early
            truncated = truncated[:break_point + len(break_char)]
            break
    
    return truncated + f"\n\n[TRUNCATED - Original length: {len(content)} chars]"

def extract_mvr_specific_fields(cur, application_id):
    """
    OPTIMIZED MVR extraction: Eliminates duplicates, reduces processing time from 15-20mins to 1-2mins.
    Returns formatted text with Score, MVRStatus mapping, violation details, and essential MVR information.
    """
    try:
        # Query to get MVR data from documents table
        mvr_query = f"""
        SELECT d.raw_content
        FROM documents d
        JOIN applications a ON a.application_id = d.application_id
        JOIN data_sources ds ON ds.data_source_id = d.data_source_id
        WHERE a.application_id = '{application_id}' AND ds.name = 'MVR'
        ORDER BY d.extracted_date DESC
        LIMIT 1;
        """
        
        cur.execute(mvr_query)
        mvr_result = cur.fetchone()
        
        if not mvr_result or not mvr_result[0]:
            logger.debug(f"No MVR data found for application {application_id}")
            return None
        
        raw_content = mvr_result[0]
        
        # Early size check to prevent massive processing
        if len(raw_content) > 10_000_000:  # 10MB limit
            logger.warning(f"MVR data too large ({len(raw_content)} chars), using fast pattern extraction")
            return extract_mvr_essentials_from_large_file(raw_content)
        
        # Try to parse as JSON
        try:
            mvr_data = json.loads(raw_content)
            
            # Extract MVR-specific information
            extracted_info = []
            
            # === SCORE EXTRACTION (unchanged) ===
            score = None
            try:
                score_result = mvr_data.get('ProductResults', {}).get('ScoreResult', {})
                if score_result and 'Result' in score_result:
                    result_array = score_result['Result']
                    if result_array and len(result_array) > 0:
                        first_result = result_array[0]
                        if first_result and len(first_result) > 0:
                            first_item = first_result[0]
                            if 'Models' in first_item and first_item['Models']:
                                score = first_item['Models'][0].get('Score')
            except Exception as e:
                logger.debug(f"Error extracting score: {e}")
            if score is not None:
                extracted_info.append(f"=== RISK CLASSIFIER SCORE ===\nScore: {score}\n")

            # MVR Status mappings (unchanged)
            mvr_status_mapping = {
                1: "Valid", 2: "Suspended", 3: "Revoked", 4: "Expired", 5: "Cancelled",
                6: "Denied", 7: "Limited", 8: "Military", 9: "ID Only",
                "A": "Disqualified", "B": "Eligible", "D": "Deceased", 
                "U": "Unavailable", "X": "No valid LIC"
            }
            
            # === OPTIMIZED MVR PROCESSING ===
            # Track unique violations globally to eliminate duplicates
            unique_violations = {}
            mvr_status = None
            state_info = None
            license_info = {}
            
            def process_mvr_results_optimized(obj, max_depth=3, current_depth=0):
                """Optimized recursive search ONLY within MVRResults section"""
                nonlocal mvr_status, state_info, license_info
                
                if current_depth > max_depth:
                    return
                    
                if isinstance(obj, dict):
                    # Check if this is the MVRResults structure
                    if "MVRResults" in obj:
                        mvr_results = obj["MVRResults"]
                        if "Result" in mvr_results and isinstance(mvr_results["Result"], list):
                            # Limit processing to first few result groups to avoid duplicates
                            for idx, result_group in enumerate(mvr_results["Result"][:3]):  # Limit to first 3
                                if isinstance(result_group, list):
                                    for result in result_group[:5]:  # Limit to first 5 per group
                                        if isinstance(result, dict) and "MVRReport" in result:
                                            extract_mvr_report_optimized(result["MVRReport"])
                        # STOP here - don't process other parts of JSON after finding MVRResults
                        return
                    
                    # Only search for MVRResults structure, don't process other sections
                    # This prevents processing ScoreResult Messages as violations
                    if current_depth == 0:  # Only search top level for MVRResults
                        for key, value in list(obj.items())[:10]:
                            if key in ['ProductResults', 'MVRResults']:  # Only look in relevant sections
                                process_mvr_results_optimized(value, max_depth, current_depth + 1)
            
            def extract_mvr_report_optimized(mvr_report):
                """Optimized extraction focusing on essential data only"""
                nonlocal mvr_status, state_info, license_info
                
                # Extract ProcessingInfo (essential data only)
                if "ProcessingInfo" in mvr_report:
                    processing_info = mvr_report["ProcessingInfo"]
                    
                    # MVR Status (only extract once)
                    if not mvr_status and "MVRStatus" in processing_info and processing_info["MVRStatus"] is not None:
                        status_code = processing_info["MVRStatus"]
                        status_text = mvr_status_mapping.get(status_code, f"Unknown Status")
                        mvr_status = f"MVR Status: {status_code} ({status_text})"
                
                    # State information (only extract once)
                    if not state_info and "StatePostalCode" in processing_info:
                        state_info = f"State: {processing_info['StatePostalCode']}"
                    
                    # License info (extract key fields only)
                    if "DriversLicense" in processing_info and not license_info:
                        dl_info = processing_info["DriversLicense"]
                        if "DriversLicenseState" in dl_info:
                            license_info["state"] = dl_info["DriversLicenseState"]
                        if "IssueDate" in dl_info:
                            license_info["issue_date"] = dl_info["IssueDate"]
                
                # Extract violations (with aggressive deduplication)
                if "Response" in mvr_report and "MVRViolations" in mvr_report["Response"]:
                    violations = mvr_report["Response"]["MVRViolations"]
                    if violations:
                        process_violations_optimized(violations)
            
            def process_violations_optimized(violations):
                """Process violations with aggressive deduplication"""
                
                for violation in violations[:20]:  # Limit to first 20 violations to prevent huge datasets
                    # Create unique key for violation deduplication
                    description = violation.get('Description', 'Unknown')
                    date_key = ""
                    
                    # Create date key
                    if "ViolationSuspensionDate" in violation:
                        v_date = violation["ViolationSuspensionDate"]
                        if isinstance(v_date, dict):
                            date_key = f"{v_date.get('Year', '')}-{v_date.get('Month', '')}-{v_date.get('Day', '')}"
                    
                    # Get primary standard violation code for uniqueness
                    primary_std_code = ""
                    if 'StandardViolations' in violation and violation['StandardViolations']:
                        primary_std_code = violation['StandardViolations'][0].get('StandardViolationCode', '')
                    
                    # Create comprehensive unique key
                    violation_key = f"{description}|{date_key}|{primary_std_code}|{violation.get('StateViolationCode', '')}"
                    
                    # Only process if not already seen
                    if violation_key not in unique_violations:
                        unique_violations[violation_key] = {
                            'description': description,
                            'date': date_key,
                            'state_code': violation.get('StateViolationCode', ''),
                            'points': violation.get('Points'),
                            'standard_code': primary_std_code,
                            'standard_desc': '',
                            'severity': '',
                            'classification': ''
                        }
                        
                        # Extract key standard violation info (first one only)
                        if 'StandardViolations' in violation and violation['StandardViolations']:
                            std_viol = violation['StandardViolations'][0]
                            unique_violations[violation_key].update({
                                'standard_desc': std_viol.get('StandardViolationCodeDesc', ''),
                                'severity': std_viol.get('ViolationSeverityCode', ''),
                                'classification': std_viol.get('ViolationClassification', '')
                            })
            
            # Start optimized processing
            process_mvr_results_optimized(mvr_data)
            
            # === GENERATE OPTIMIZED OUTPUT ===
            
            # Basic MVR information
            if mvr_status or state_info:
                extracted_info.append("=== MVR PROCESSING INFORMATION ===")
                if mvr_status:
                    extracted_info.append(mvr_status)
                if state_info:
                    extracted_info.append(state_info)
                if license_info:
                    if license_info.get('state'):
                        extracted_info.append(f"License State: {license_info['state']}")
                    if license_info.get('issue_date'):
                        extracted_info.append(f"License Issue Date: {license_info['issue_date']}")
                extracted_info.append("")
            
            # Violations summary (optimized)
            if unique_violations:
                extracted_info.append("=== MVR VIOLATIONS ===")
                
                for idx, (key, violation) in enumerate(unique_violations.items(), 1):
                    if idx > 10:  # Limit to top 10 violations for readability
                        extracted_info.append(f"... and {len(unique_violations) - 10} more violations (truncated for performance)")
                        break
                        
                    violation_details = [f"Violation {idx}:"]
                    violation_details.append(f"  Description: {violation['description']}")
                    
                    if violation['date']:
                        violation_details.append(f"  Date: {violation['date']}")
                    if violation['state_code']:
                        violation_details.append(f"  State Code: {violation['state_code']}")
                    if violation['standard_code']:
                        violation_details.append(f"  Standard Code: {violation['standard_code']}")
                    if violation['standard_desc']:
                        violation_details.append(f"  Standard Description: {violation['standard_desc']}")
                    if violation['points'] is not None:
                        violation_details.append(f"  Points: {violation['points']}")
                    
                    extracted_info.append('\n'.join(violation_details))
                
                extracted_info.append(f"\nSummary: {len(unique_violations)} unique violations found")
                extracted_info.append("")
            else:
                extracted_info.append("=== MVR VIOLATIONS ===")
                extracted_info.append("No violations found\n")
            
            # === ESSENTIAL MVR RESULTS ONLY (No complete JSON dump) ===
            # Instead of dumping the entire JSON, provide just a summary
            extracted_info.append("=== MVR DATA SUMMARY ===")
            extracted_info.append(f"Total MVR data size: {len(raw_content):,} characters")
            extracted_info.append(f"Unique violations processed: {len(unique_violations)}")
            if mvr_status:
                extracted_info.append(f"License status: {mvr_status.split(': ')[1] if ': ' in mvr_status else 'Unknown'}")
            
            if extracted_info:
                return "\n".join(extracted_info)
            else:
                return f"MVR Data Available: {len(raw_content)} characters of MVR information"
                
        except json.JSONDecodeError:
            logger.debug("MVR data is not in JSON format, returning raw content summary")
            return f"MVR Data Available (non-JSON): {len(raw_content)} characters"
            
    except Exception as e:
        logger.error(f"Error extracting MVR specific fields: {e}")
        return None

def extract_mvr_essentials_from_large_file(raw_content):
    """
    Fast extraction of essential MVR information from large files using regex patterns.
    Returns formatted MVR data that LLM can process without expensive JSON parsing.
    """
    try:
        logger.info(f"Extracting essentials from large MVR file ({len(raw_content):,} chars)")
        
        # Initialize extracted information
        extracted_info = []
        
        # === EXTRACT RISK CLASSIFIER SCORE ===
        score_patterns = [
            r'"Score":\s*(\d+)',
            r'"Score":\s*"(\d+)"',
            r'Score.*?(\d{3,4})',  # 3-4 digit scores
        ]
        
        score = None
        for pattern in score_patterns:
            score_matches = re.findall(pattern, raw_content, re.IGNORECASE)
            if score_matches:
                score = score_matches[0]
                break
        
        if score:
            extracted_info.append(f"=== RISK CLASSIFIER SCORE ===\nScore: {score}\n")
        
        # === EXTRACT MVR STATUS ===
        mvr_status_patterns = [
            r'"MVRStatus":\s*(\d+)',
            r'"MVRStatus":\s*"([^"]+)"',
            r'MVRStatus.*?(\d+)',
        ]
        
        mvr_status_mapping = {
            "1": "Valid", "2": "Suspended", "3": "Revoked", "4": "Expired", "5": "Cancelled",
            "6": "Denied", "7": "Limited", "8": "Military", "9": "ID Only",
            "A": "Disqualified", "B": "Eligible", "D": "Deceased", 
            "U": "Unavailable", "X": "No valid LIC"
        }
        
        mvr_status = None
        for pattern in mvr_status_patterns:
            status_matches = re.findall(pattern, raw_content, re.IGNORECASE)
            if status_matches:
                status_code = str(status_matches[0])
                status_text = mvr_status_mapping.get(status_code, f"Status {status_code}")
                mvr_status = f"MVR Status: {status_code} ({status_text})"
                break
        
        # === EXTRACT STATE INFORMATION ===
        state_patterns = [
            r'"StatePostalCode":\s*"([^"]+)"',
            r'"State":\s*"([^"]+)"',
            r'StatePostalCode.*?"([A-Z]{2})"',
        ]
        
        state_info = None
        for pattern in state_patterns:
            state_matches = re.findall(pattern, raw_content, re.IGNORECASE)
            if state_matches:
                state_info = f"State: {state_matches[0]}"
                break
        
        # === EXTRACT VIOLATIONS FROM MVRViolations SECTION ONLY ===
        # Look for violations specifically within MVRViolations context
        mvr_violations_pattern = r'"MVRViolations":\s*\[(.*?)\]'
        mvr_violations_match = re.search(mvr_violations_pattern, raw_content, re.DOTALL | re.IGNORECASE)
        
        violations = []
        if mvr_violations_match:
            mvr_violations_section = mvr_violations_match.group(1)
            
            # Extract violation descriptions ONLY from StandardViolations within MVRViolations section
            # Focus on StandardViolationCodeDesc which contains the actual violation descriptions
            standard_violation_pattern = r'"StandardViolationCodeDesc":\s*"([^"]+)"'
            violation_matches = re.findall(standard_violation_pattern, mvr_violations_section, re.IGNORECASE)
            
            # Filter out placeholder/generic descriptions
            filtered_violations = []
            for violation in violation_matches[:20]:  # Limit to prevent huge datasets
                # Skip generic placeholder descriptions
                if not any(keyword in violation.upper() for keyword in [
                    'LEXISNEXIS CLEAR', 'VIOLATION_RECORD_INFO', 'PLACEHOLDER'
                ]):
                    filtered_violations.append(violation)
            
            violations = filtered_violations[:10]  # Limit to top 10
            
            # If no meaningful violations found in StandardViolationCodeDesc, try ViolationDescriptions
            if not violations:
                violation_desc_pattern = r'"ViolationDescriptions":\s*"([^"]+)"'
                desc_matches = re.findall(violation_desc_pattern, mvr_violations_section, re.IGNORECASE)
                # Filter out placeholder descriptions
                for desc in desc_matches[:10]:
                    if not any(keyword in desc.upper() for keyword in [
                        'VIOLATION_RECORD_INFO', 'PLACEHOLDER', '_'
                    ]):
                        violations.append(desc)
        
        # NO FALLBACK - Only extract from MVRViolations section to avoid pulling 
        # descriptions from other parts of the JSON (risk classifier, etc.)
        
        # Remove duplicates while preserving order
        unique_violations = []
        seen = set()
        for violation in violations:
            if violation.lower() not in seen:
                unique_violations.append(violation)
                seen.add(violation.lower())
                if len(unique_violations) >= 5:  # Limit to top 5
                    break
        
        # === EXTRACT MISCELLANEOUS ITEMS (non-violations) ===
        # misc_items = []
        # misc_patterns = [
        #     r'"Description":\s*"([^"]*(?:lexisnexis|risk classifier|addresses found|property ownership|inquiries.*finance|account.*not paid|presence of)[^"]*)"'
        # ]
        
        # for pattern in misc_patterns:
        #     misc_matches = re.findall(pattern, raw_content, re.IGNORECASE)[:5]
        #     for match in misc_matches:
        #         if match.lower() not in [v.lower() for v in unique_violations]:  # Don't duplicate actual violations
        #             misc_items.append(match)
        
        # # Remove duplicates from misc items
        # unique_misc_items = []
        # misc_seen = set()
        # for item in misc_items:
        #     if item.lower() not in misc_seen:
        #         unique_misc_items.append(item)
        #         misc_seen.add(item.lower())
        #         if len(unique_misc_items) >= 5:
        #             break
        
        # === EXTRACT VIOLATION DATES ===
        date_patterns = [
            r'"Year":\s*(\d{4}).*?"Month":\s*(\d{1,2}).*?"Day":\s*(\d{1,2})',
            r'(\d{4})-(\d{1,2})-(\d{1,2})',
        ]
        
        violation_dates = []
        for pattern in date_patterns:
            date_matches = re.findall(pattern, raw_content)[:5]  # Limit to 5
            for match in date_matches:
                if len(match) == 3:
                    violation_dates.append(f"{match[0]}-{match[1]:0>2}-{match[2]:0>2}")
            if len(violation_dates) >= 3:
                break
        
        # === FORMAT OUTPUT ===
        extracted_info.append("=== MVR PROCESSING INFORMATION ===")
        if mvr_status:
            extracted_info.append(mvr_status)
        if state_info:
            extracted_info.append(state_info)
        extracted_info.append("")
        
        if unique_violations:
            extracted_info.append("=== MVR VIOLATIONS ===")
            for i, violation in enumerate(unique_violations, 1):
                violation_info = f"Violation {i}: {violation}"
                if i <= len(violation_dates):
                    violation_info += f" (Date: {violation_dates[i-1]})"
                extracted_info.append(violation_info)
            extracted_info.append("")
        else:
            extracted_info.append("=== MVR VIOLATIONS ===")
            extracted_info.append("No violations found")
            extracted_info.append("")
        
        # Add miscellaneous items section
        # if unique_misc_items:
        #     extracted_info.append("=== MISCELLANEOUS MVR INFORMATION ===")
        #     for i, item in enumerate(unique_misc_items, 1):
        #         extracted_info.append(f"Item {i}: {item}")
        #     extracted_info.append("")
        
        # extracted_info.append("")
        # extracted_info.append("=== MVR DATA SUMMARY ===")
        # extracted_info.append(f"Total MVR data size: {len(raw_content):,} characters")
        # extracted_info.append("Extraction method: Fast pattern matching (large file optimization)")
        
        result = "\n".join(extracted_info)
        logger.info(f"Successfully extracted MVR essentials: {result}")
        
        return result
        
    except Exception as e:
        logger.error(f"Error in fast MVR extraction: {e}")
        # Fallback to minimal but useful information
        return f"""=== MVR PROCESSING INFORMATION ===
MVR Status: Unable to determine (data processing error)
=== MVR VIOLATIONS ===
Unable to extract violations (data processing error)
=== RISK CLASSIFIER SCORE ===
Unable to extract score (data processing error)
=== MVR DATA SUMMARY ===
Total MVR data size: {len(raw_content):,} characters
Extraction failed due to: {str(e)}
"""

def is_duplicate_chunk(new_chunk, existing_chunks, similarity_threshold=SIMILARITY_THRESHOLD):
    """
    Check if a new chunk is a duplicate of existing chunks.
    Returns True if duplicate, False otherwise.
    """
    new_content = new_chunk["Data"]
    new_hash = calculate_content_hash(new_content)
    
    for existing_chunk in existing_chunks:
        existing_content = existing_chunk["Data"]
        existing_hash = calculate_content_hash(existing_content)
        
        # First check exact hash match (fastest)
        if new_hash == existing_hash:
            logger.debug(f"Found exact duplicate chunk from source: {new_chunk['source']}")
            return True
        
        # Then check similarity for near-duplicates (less strict for initial filtering)
        similarity = calculate_similarity(new_content, existing_content)
        if similarity >= 0.95:  # Only skip very similar chunks at this stage
            logger.debug(f"Found very similar chunk (similarity: {similarity:.2f}) from source: {new_chunk['source']}")
            return True
    
    return False

def clean_rx_raw_content(raw_text):
    """
    Cleans Rx raw_content by:
    - Removing 'PrescriptionSideEffect' from each Drug in Risk->DrugDetail->Drug
    - Keeping only top 5 items in 'DiseaseDescription' list
    Handles both list and dict cases for DrugDetail['Drug'].
    Returns cleaned JSON string if input is JSON, else returns original text.
    """
    try:
        data = json.loads(raw_text)
        # print(f"Raw text: {raw_text}")
        data = copy.deepcopy(data)  # Avoid mutating original
        # Remove PrescriptionSideEffect
        risk = data.get('Risk')
        if risk and isinstance(risk, dict):
            drug_detail = risk.get('DrugDetail')
            if drug_detail and isinstance(drug_detail, dict):
                drugs = drug_detail.get('Drug')
                if isinstance(drugs, list):
                    for drug in drugs:
                        if isinstance(drug, dict) and 'PrescriptionSideEffect' in drug:
                            del drug['PrescriptionSideEffect']
                        if isinstance(drug, dict) and 'DiseaseDescription' in drug:
                            disease_desc = drug['DiseaseDescription']
                            drug['DiseaseDescription'] = disease_desc[:5]
                            # logger.debug(f"DiseaseDescription after truncation: {drug['DiseaseDescription']}")

                elif isinstance(drugs, dict):
                    if 'PrescriptionSideEffect' in drugs:
                        del drugs['PrescriptionSideEffect']
                    if isinstance(drugs, dict) and 'DiseaseDescription' in drugs:
                        disease_desc = drugs['DiseaseDescription']
                        drugs['DiseaseDescription'] = disease_desc[:5]
                        # logger.debug(f"DiseaseDescription after truncation: {drugs['DiseaseDescription']}")

        # Extract and store refills/last filled info
        rx_prescription_summary = extract_rx_refills_and_last_filled(data)
        logger.debug(f"Rx prescription summary: {rx_prescription_summary}")
        
        data["IndividualPrescriptionInformation"] = rx_prescription_summary
                
        return json.dumps(data, ensure_ascii=False)
    except Exception as e:
        logger.error(f"Rx cleaning failed or not JSON: {e}")
        return raw_text

def extract_rx_refills_and_last_filled(data):
    """
    For each prescription in Rx data, extract number of refills and fill dates using PrescriptionLabel and PrescriptionFillDate.
    Handles both list and dict cases for DrugDetail['Drug'].
    Returns a list of dicts with prescription info.
    """
    try:
        # data = json.loads(raw_text)
        risk = data.get('Risk')
        if not risk or not isinstance(risk, dict):
            logger.debug("No Risk section found in Rx data.")
            return []
        drug_detail = risk.get('PrescriptionDrug')
        if isinstance(drug_detail, list):
            drugs = drug_detail
        elif isinstance(drug_detail, dict):
            drugs = [drug_detail]
        else:
            logger.debug("No PrescriptionDrug section found in Rx data.")
            return []
        # Handle both list and dict cases
        # if isinstance(drugs, dict):
        #     drugs = [drugs]
        # Group fill dates by PrescriptionLabel
        prescription_fills = {}
        drug_details = {}
        for drug in drugs:
            label = drug.get('PrescriptionLabel')
            fills = drug.get('PrescriptionFill')
            fill_date = fills.get('PrescriptionFillDate')
            if label:
                if label not in prescription_fills:
                    prescription_fills[label] = []
                    drug_details[label] = fills
                if fill_date:
                    prescription_fills[label].append(fill_date)
        result = []
        for prescription_label, fill_dates in prescription_fills.items():
            results = {}
            drug = drug_details[prescription_label]
            results["PrescriptionLabel"] = prescription_label
            results["TotalNumberOfRefillsTaken"] = len(fill_dates)
            if "PrescriptionTotalRefillsAllowed" in drug:
                results["TotalNumberOfRefillsAllowed"] = drug["PrescriptionTotalRefillsAllowed"]
            if "PrescriptionDaysSupply" in drug:
                results["PrescriptionDaysSupply"] = drug["PrescriptionDaysSupply"]
            fill_dates_sorted = sorted(fill_dates)
            print(f"Fill dates sorted: {fill_dates_sorted}")
            results["DateFirstFilled"] = fill_dates_sorted[0]
            if len(fill_dates_sorted) > 1:
                results["DateLastFilled"] = fill_dates_sorted[-1]
            else:
                results["DateLastFilled"] = fill_dates_sorted[0]
            result.append(results)
        logger.debug(f"Rx prescription summary: {result}")
        return result
    except Exception as e:
        logger.debug(f"Error parsing Rx data for refills/last filled: {e}")
        return []


def extract_text_from_data_sources(state: AgentState) -> AgentState:
    """Extracts text from the data sources."""
    
    cur, conn = connect_to_db()
    cur.execute(f"SELECT application_id, type FROM applications WHERE application_number = '{state.application_number}'")
    conn.commit()
    logger.debug("Successfully executed query to fetch app id and type")
    app_info = cur.fetchone()

    # Fetch application date from Part A for this application number
    application_date = None
    try:
        app_date_query = f"""
        SELECT d.extracted_date
        FROM documents d
        JOIN applications a ON a.application_id = d.application_id
        JOIN data_sources ds ON ds.data_source_id = d.data_source_id
        WHERE a.application_id = '{app_info[0]}' AND ds.name = 'Part A' AND d.extracted_date IS NOT NULL
        ORDER BY d.extracted_date DESC
        LIMIT 1;
        """
        cur.execute(app_date_query)
        conn.commit()
        app_date_result = cur.fetchone()
        if app_date_result:
            application_date = app_date_result[0]
        logger.debug(f"Fetched application date from Part A: {application_date}")
    except Exception as e:
        logger.error(f"Error fetching application date from Part A: {e}")
    
    relevant_chunks = []

    if state.interim_response is None:
        logger.error("interim_response is None - cannot parse JSON")
        return state
    
    try:
        json_query = json.loads(state.interim_response)
    except (json.JSONDecodeError, TypeError) as e:
        logger.error(f"Error parsing interim_response as JSON: {e}")
        return state
    query_texts = json_query["Search_query_texts"]
    logger.debug(f"Query texts: {query_texts}")
    relevant_data_sources = []
    for query in query_texts:
        for source in query['Data_source']:
            relevant_data_sources.append(source)
    logger.debug(f"Relevant data sources: {list(set(relevant_data_sources))}")
    state.current_step = f"Extracting text from {list(set(relevant_data_sources))}"

    for query in query_texts:
        search_query = query["Query_text"]
        # vector_query = get_embedding(search_query)
        # logger.debug("Converted query to vector")
  
        for source in query["Data_source"]:
            if app_info[1] == 'PDF':
                query_block = f"""
                SELECT p.raw_content
                FROM pages p
                JOIN applications a ON a.application_id = p.application_id
                JOIN data_sources ds ON ds.data_source_id = p.data_source_id
                WHERE a.application_id = '{app_info[0]}' AND ds.name = '{source}'
              
                """
            
            elif app_info[1] == 'JSON':
                query_block = f"""
                SELECT d.raw_content
                FROM documents d
                JOIN applications a ON a.application_id = d.application_id
                JOIN data_sources ds ON ds.data_source_id = d.data_source_id
                WHERE a.application_id = '{app_info[0]}' AND ds.name = '{source}';   
                """
                
            cur.execute(query_block)
            conn.commit()
            logger.debug(f"Successfully executed vector query for source: {source}")
            data_chunk = cur.fetchall()
            logger.debug(f"Fetched {len(data_chunk)} rows for source: {source}")
            if data_chunk:
                logger.debug(f"Sample raw data for {source}: {str(data_chunk[0])[:300]}")

            if source == 'MIB':
                query_block = f"""
                SELECT m.meaning
                FROM mib_codes m
                WHERE application_id = '{app_info[0]}'
                """
                cur.execute(query_block)
                conn.commit()
                logger.debug("Successfully executed MIB query")
                mib_chunk = cur.fetchall()
                data_chunk.append(mib_chunk)
            
            elif source == 'MVR':
                # Special handling for MVR to extract specific fields with size optimization
                try:
                    # Quick size check before processing
                    size_check_query = f"""
                    SELECT LENGTH(d.raw_content) as content_size
                    FROM documents d
                    JOIN applications a ON a.application_id = d.application_id
                    JOIN data_sources ds ON ds.data_source_id = d.data_source_id
                    WHERE a.application_id = '{app_info[0]}' AND ds.name = 'MVR'
                    ORDER BY d.extracted_date DESC
                    LIMIT 1;
                    """
                    cur.execute(size_check_query)
                    size_result = cur.fetchone()
                    
                    if size_result and size_result[0] > 50_000_000:  # 50MB absolute limit
                        logger.warning(f"MVR data too large ({size_result[0]:,} chars), using fast pattern extraction")
                        # Get raw content for fast extraction
                        raw_query = f"""
                        SELECT d.raw_content
                        FROM documents d
                        JOIN applications a ON a.application_id = d.application_id
                        JOIN data_sources ds ON ds.data_source_id = d.data_source_id
                        WHERE a.application_id = '{app_info[0]}' AND ds.name = 'MVR'
                        ORDER BY d.extracted_date DESC
                        LIMIT 1;
                        """
                        cur.execute(raw_query)
                        raw_result = cur.fetchone()
                        if raw_result and raw_result[0]:
                            mvr_summary = extract_mvr_essentials_from_large_file(raw_result[0])
                        else:
                            mvr_summary = "MVR Data: Unable to retrieve content for processing"
                        data_chunk.append((mvr_summary,))
                    else:
                        mvr_extracted_data = extract_mvr_specific_fields(cur, app_info[0])
                        if mvr_extracted_data:
                            data_chunk.append((mvr_extracted_data,))
                except Exception as e:
                    logger.error(f"Error in MVR size check: {e}")
                    # Fallback to normal extraction
                    mvr_extracted_data = extract_mvr_specific_fields(cur, app_info[0])
                    if mvr_extracted_data:
                        data_chunk.append((mvr_extracted_data,))

            # Rx cleaning: apply before any reduction/chunking
            rx_prescription_summary = None
            if source == 'Rx' and data_chunk:
                cleaned_data_chunk = []
                for chunk_tuple in data_chunk:
                    if chunk_tuple:
                        cleaned_text = clean_rx_raw_content(str(chunk_tuple[0]))
                        cleaned_data_chunk.append((cleaned_text,))
                    else:
                        cleaned_data_chunk.append(chunk_tuple)
                data_chunk = cleaned_data_chunk

            # Process and reduce each chunk as it's fetched
            for chunk_tuple in data_chunk:
                if chunk_tuple and chunk_tuple[0]:
                    raw_text = str(chunk_tuple[0])
                    processed_text = ""

                    # AGGRESSIVE MVR OPTIMIZATION: Skip heavy processing for large MVR files
                    if source == 'MVR' and len(raw_text) > 5_000_000:  # 5MB limit for MVR
                        logger.warning(f"MVR data extremely large ({len(raw_text)} chars), using fast pattern extraction")
                        processed_text = extract_mvr_essentials_from_large_file(raw_text)
                    elif source == 'MVR' or source == 'MIB':
                        # Conditionally reduce the context based on individual chunk size and type
                        if len(raw_text) > CHUNK_LENGTH_THRESHOLD:
                            logger.debug(f"Chunk from source '{source}' is too large ({len(raw_text)} chars). Reducing it.")
                            if app_info[1] == 'JSON':
                                if source == 'MVR' and len(raw_text) > 1_000_000:  # 1MB limit for MVR JSON chunking
                                    logger.info(f"MVR JSON too large for chunking ({len(raw_text)} chars), using truncated version")
                                    processed_text = raw_text[:50000] + f"\n\n[TRUNCATED: Original size {len(raw_text):,} characters]"
                                else:
                                    processed_text = intelligent_json_chunker(raw_text, state.input_message, CHUNK_LENGTH_THRESHOLD)
                            else: # It's a PDF
                                processed_text = reduce_context_with_sliding_window_lite(raw_text, state.input_message)
                        else:
                            processed_text = raw_text
                    else:
                        processed_text = raw_text
                    
                    if processed_text:
                        # Append the reduced and structured text
                        if app_info[1] == 'PDF':
                            date_query = f"""
                            SELECT DISTINCT p.extracted_date
                            FROM pages p
                            JOIN applications a ON a.application_id = p.application_id
                            JOIN data_sources ds ON ds.data_source_id = p.data_source_id
                            WHERE a.application_id = '{app_info[0]}' AND ds.name = '{source}'
                            AND p.extracted_date IS NOT NULL
                            ORDER BY p.extracted_date DESC
                            LIMIT 1;
                            """
                        elif app_info[1] == 'JSON':
                            date_query = f"""
                            SELECT DISTINCT d.extracted_date
                            FROM documents d
                            JOIN applications a ON a.application_id = d.application_id
                            JOIN data_sources ds ON ds.data_source_id = d.data_source_id
                            WHERE a.application_id = '{app_info[0]}' AND ds.name = '{source}'
                            AND d.extracted_date IS NOT NULL
                            ORDER BY d.extracted_date DESC
                            LIMIT 1;
                            """
                        cur.execute(date_query)
                        conn.commit()
                        extracted_date = cur.fetchone()

                        json_chunk = {
                            "Data": processed_text,
                            "source": source,
                            "extracted_date": extracted_date[0] if extracted_date else None
                        }
                        # If Rx, append prescription summary
                        if source == 'Rx' and rx_prescription_summary is not None:
                            json_chunk["RxPrescriptionSummary"] = rx_prescription_summary
                        # Debug: show extracted sections for this chunk
                        try:
                            sections_debug = extract_json_sections(processed_text, query=search_query)
                            logger.debug(f"Extracted sections for source {source}: {list(sections_debug.keys())}")
                        except Exception as e:
                            logger.debug(f"Error extracting sections for debug: {e}")

                        # Use improved duplicate detection
                        if not is_duplicate_chunk(json_chunk, relevant_chunks):
                            relevant_chunks.append(json_chunk)
                        else:
                            logger.debug(f"Skipped duplicate chunk from source: {source}")
                else:
                    logger.debug(f"Empty or invalid chunk_tuple for source: {source}")
                
    logger.debug(f"Length of chunks before processing: {len(relevant_chunks)}")
    
    # Calculate initial total character length
    initial_character_length = sum(len(chunk["Data"]) for chunk in relevant_chunks)
    logger.debug(f"Initial character length: {initial_character_length:,} characters")
    
    # Stage 1: Always apply deduplication first (as initial cleanup)
    logger.debug("Stage 1: Applying deduplication to remove redundant content...")
    relevant_chunks = deduplicate_chunk_content(relevant_chunks)
    
    # Check length after deduplication
    after_dedup_length = sum(len(chunk["Data"]) for chunk in relevant_chunks)
    logger.debug(f"After deduplication: {after_dedup_length:,} characters")
    
    # Stage 2: Apply additional reduction if still over threshold
    if after_dedup_length > DEDUPLICATION_THRESHOLD:
        logger.debug(f"Stage 2: Content still exceeds {DEDUPLICATION_THRESHOLD:,} characters. Applying additional reduction...")
        relevant_chunks = apply_additional_reduction(relevant_chunks, state, DEDUPLICATION_THRESHOLD)
    else:
        logger.debug(f"Content is now within {DEDUPLICATION_THRESHOLD:,} character limit. No additional reduction needed.")
    
    # Log final results
    final_character_length = sum(len(chunk["Data"]) for chunk in relevant_chunks)
    total_reduction_percentage = ((initial_character_length - final_character_length) / initial_character_length * 100) if initial_character_length > 0 else 0
    
    logger.debug(f"=== FINAL PROCESSING SUMMARY ===")
    logger.debug(f"Initial length: {initial_character_length:,} characters")
    logger.debug(f"Final length: {final_character_length:,} characters")
    logger.debug(f"Total reduction: {total_reduction_percentage:.1f}%")
    logger.debug(f"Final chunk count: {len(relevant_chunks)}")
    logger.debug(f"Within 200k limit: {'✓' if final_character_length <= DEDUPLICATION_THRESHOLD else '✗'}")
    
    for chunk in relevant_chunks:
        logger.debug(f"Source: {chunk['source']}, Data length: {len(chunk['Data'])}")
    
    # Prepare final response with application_date as a top-level field
    final_response = {
        "application_date": application_date,
        "chunks": relevant_chunks
    }
    state.interim_response = str(final_response)
    # logger.debug(f"Final response: {final_response}")
    state.messages.append({"role": "Query Processing Agent", "content": final_response})
    state.steps_completed.append(state.current_step)
    
    return state

if __name__ == "__main__":
    state = AgentState()
    state.application_number = "9217787"
    state.available_data_sources = [('Dx',), ('Lab Tests',), ('MIB',), ('MVR',), ('Part A',), ('Part B',), ('Rx',)]
    state.interim_response = '{"Search_query_texts": [     {       "Query_text": "Find height, weight, BMI, blood pressure, and pulse measurements",       "Data_source": ["Lab Tests", "MIB"]     },     {       "Query_text": "Find medical conditions and diagnoses",       "Data_source": ["Part B"]     },     {       "Query_text": "Find prescription medications including fill dates, refills, and drug classifications",       "Data_source": ["Rx"]     },     {       "Query_text": "Find lab test results and medical test scores",       "Data_source": ["Lab Tests"]     },     {       "Query_text": "Find usage history of tobacco, alcohol, nicotine, marijuana, and other substances",       "Data_source": ["Part B", "MIB"]     }, {"Query_text": "Find beneficiary type information", "Data_source": ["Part B"]}   ] }'
    extract_text_from_data_sources(state)
    # logger.debug(state.current_step)
    # logger.info(state.interim_response)
    # logger.info(state.application_number)
    # logger.info(state.available_data_sources)


    #    ORDER BY embedding <-> '{vector_query}'
    #             LIMIT 2;

      # ORDER BY embedding <-> '{vector_query}'
                # LIMIT 2;