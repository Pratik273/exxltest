import os
import sys
from dotenv import load_dotenv
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
from agents.state import AgentState
from agents.agent_types.general_agent import BaseAgent
from utils.calling_claude_model import invoking_claude
from utils.llm_retries_and_validation import call_llm_with_retries
from utils.response_structures import QueryProcessResponse
from prompts.multi_agent_prompts import QUERY_PROCESS_SYSTEM_PROMPT, QUERY_PROCESS_DATA_SYSTEM_PROMPT, QUERY_PROCESS_SUMMARY_SYSTEM_PROMPT
from utils.store_data_in_psql_db import store_messages
from loguru import logger
import json


class QueryProcessingAgent(BaseAgent):
    load_dotenv(override=True)
    
    def __init__(self):
        super().__init__("Query Processing Agent")

    def __call__(self, state: AgentState):
        state.current_step = "Identifying key data sources"
        is_data_generation = os.getenv('is_generating_data')
        is_summary_generation = os.getenv('is_generating_summary')
        if is_data_generation == "True":
            system_prompt = QUERY_PROCESS_DATA_SYSTEM_PROMPT
        # elif is_summary_generation == "True":
        #     system_prompt = QUERY_PROCESS_SUMMARY_SYSTEM_PROMPT
        else:
            system_prompt = QUERY_PROCESS_SYSTEM_PROMPT
        user_prompt = state.input_message + "Available data sources: " + str(state.available_data_sources)
        state.messages.append({"role": "user", "content": user_prompt})
        response = call_llm_with_retries(invoking_claude, system_prompt, user_prompt, QueryProcessResponse)
        response_json = json.loads(response)
        state.interim_response = response
        state.ai_thought = response_json['Thought']
        self.update_state(state)
        self.store_responses_in_db(state)
        return state


    def update_state(self, state):
        state.messages.append({"role": "Query Processing Agent", "content": state.interim_response})
        state.steps_completed.append(state.current_step)
        return state
        
    def store_responses_in_db(self, state: AgentState):
        is_message_stored = store_messages(state.conversation_id, "Query Processing Agent", state.interim_response, "intermediate_answer", state.ai_thought)
        if not is_message_stored:
            logger.error("Couldn't store response from Query Processing Agent in DB")

if __name__ == "__main__":
    agent = QueryProcessingAgent()
    state = AgentState(input_message="Write a summary on demographics, MVR, Miscellaneous and Additional Notes section. The additional notes should only include recommendations for underwriters if there are any. For MVR, include the MVRSTatus information showcasing the driving license ivalid information which is going to be a number, any violations if found and risk class score.", application_number="9217523")
    state.available_data_sources = ["Page A", "Part B", "Rx", "MIB", "Lab Tests", "Dx", "MVR"]
    print(agent(state))