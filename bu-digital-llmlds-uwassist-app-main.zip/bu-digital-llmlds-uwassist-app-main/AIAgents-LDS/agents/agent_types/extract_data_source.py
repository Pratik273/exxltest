import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
from agents.state import AgentState
from scripts.database.check_db_conn import connect_to_db
from utils.store_data_in_psql_db import fetch_conversation_id, store_messages, store_conversation
from loguru import logger


def fetch_data_source(state: AgentState):
    """
    Extracts data source from the agent's data.
    """
    state.current_step = "Checking available data sources"
    app_number = state.application_number
    cur, conn = connect_to_db()
    cur.execute(f"SELECT application_id, type FROM applications WHERE application_number = '{app_number}'")
    conn.commit()
    logger.debug("Successfully executed query to fetch app id and type")
    data = cur.fetchone()
    logger.debug(f"Data fetched: {data}")
    conn.autocommit = True
    if data[1] == 'PDF':
        query_block = f"""
        SELECT DISTINCT ds.name
        FROM data_sources ds
        JOIN pages p ON p.data_source_id = ds.data_source_id
        JOIN applications a ON a.application_id = p.application_id
        WHERE a.application_id = '{data[0]}';
        """
    else:
        query_block = f"""
        SELECT DISTINCT ds.name
        FROM data_sources ds
        JOIN documents doc ON doc.data_source_id = ds.data_source_id
        JOIN applications a ON a.application_id = doc.application_id
        WHERE a.application_id = '{data[0]}';
        """
    cur.execute(query_block)
    # cur.execute('SELECT data_source_id FROM pages;')
    # conn.commit()
    data_source = cur.fetchall()
    logger.debug(f"Data soures available: {data_source}")
    
    cur.close()
    conn.close()
    logger.debug("Session closed")
    data_source_new = [str(t[0]) for t in data_source] 
    logger.debug(f"available data source: {data_source_new}")
    state.available_data_sources = data_source_new
    logger.debug(f"Interm response: {data_source}")
    state.interim_response = str(data_source)
    state.messages.append({"role": "Data Source Checker", "content": "data_source"})
    state.steps_completed.append(state.current_step)
    
    # Storing messages in DB
    is_convo_stored = store_conversation(state.user_id, state.session_id)
    if is_convo_stored:
        conversation_id = fetch_conversation_id(state.user_id, state.session_id)
    else:
        logger.error(f"Couldn't store {state.session_id} in conversations table")
    if conversation_id:
        state.conversation_id = conversation_id
        is_message_stored = store_messages(state.conversation_id, "Extract Data Sources", state.interim_response, "intermediate_answer")
        if not is_message_stored:
            logger.error("Couldn't store response from extract data sources in DB")
    return state
    

if __name__ == "__main__":
    state = AgentState()
    state.application_number = "9222517"
    fetch_data_source(state)