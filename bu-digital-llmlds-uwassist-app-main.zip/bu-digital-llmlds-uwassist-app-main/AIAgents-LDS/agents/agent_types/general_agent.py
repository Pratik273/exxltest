from abc import ABC, abstractmethod

class BaseAgent(ABC):
    def __init__(self, agent_name):
        self.agent_name = agent_name

    @abstractmethod
    def update_state(self):
        pass
    
    @abstractmethod
    def store_responses_in_db(self):
        pass
    