import json
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from agent_types.general_agent import BaseAgent
# from general_agent import BaseAgent
# from agents.agent_state.state import AgentState
from state import AgentState
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
from utils.calling_claude_model import invoking_claude
from utils.llm_retries_and_validation import call_llm_with_retries
from prompts.multi_agent_prompts import INTENT_CLASSIFY_SYSTEM_PROMPT
from utils.response_structures import IntentClassifyResponse
from utils.store_data_in_psql_db import store_conversation, fetch_conversation_id, store_messages
from loguru import logger
from typing import Dict, Any 

class IntentClassificationAgent(BaseAgent):
    def __init__(self):
        super().__init__("Intent Classification Agent")
        
        
    def __call__(self, state: AgentState):
        state.current_step = "Understanding your query"
        system_prompt = INTENT_CLASSIFY_SYSTEM_PROMPT
        user_prompt = state.input_message
        state.messages.append({"role": "User", "content": user_prompt})
        response = call_llm_with_retries(invoking_claude, system_prompt, user_prompt, IntentClassifyResponse)
        response_json = json.loads(response)
        if response_json["Type"] == "Underwriting Application":
            is_final = False
        else:
            is_final = True
        self.update_state(response, state, is_final)
        self.store_responses_in_db(state, response_json, is_final)
        return state

    
    def update_state(self, response: Dict[str, Any], state: AgentState, final: bool=False):
        state.interim_response = response
        json_response = json.loads(response)
        state.messages.append({"role": "Intent Classify Agent", "content": json_response["Answer"]})
        state.steps_completed.append(state.current_step)
        if final is True:
            state.ai_response = json_response["Answer"]
            if json_response["Thought"] is not None:
                state.ai_thought = json_response["Thought"]
            
    def store_responses_in_db(self, state: AgentState, response_json: Dict[str, Any], final: bool=False):
        conversation_id = None
        if response_json["Type"] == "Underwriting Application":
            is_convo_stored = store_conversation(state.user_id, state.session_id, state.application_number)
            if is_convo_stored:
                conversation_id = fetch_conversation_id(state.user_id, state.session_id, state.application_number)
                    
            else:
                logger.error(f"Couldn't store {state.session_id} in conversations table")
        else:
            is_convo_stored = store_conversation(state.user_id, state.session_id)
            if is_convo_stored:
                conversation_id = fetch_conversation_id(state.user_id, state.session_id)
            else:
                logger.error(f"Couldn't store {state.session_id} in conversations table")
            
        if conversation_id:
            state.conversation_id = conversation_id
            is_message_stored = store_messages(conversation_id, "User", state.input_message, "question")
            if is_message_stored:
                if final:
                    is_intent_stored = store_messages(conversation_id, "Intent Classify Agent", state.ai_response, "final_answer", state.ai_thought)
                else: 
                    is_intent_stored = store_messages(conversation_id, "Intent Classify Agent", state.interim_response, "intermediate_answer")
                if not is_intent_stored:
                    logger.error(f"Was the response final: {final} Problem in storing Intent Classification Agent's response in DB")
            else:
                logger.error(f"Couldn't store {state.input_message} in messages table")
        else:
             logger.error(f"Couldn't fetch conversation id for {state.session_id} from conversations table")
        
        
        


if __name__ == "__main__":
    agent = IntentClassificationAgent()
    state = AgentState(input_message="what is the BP for this?", application_number="9218593")  
    logger.debug(agent(state))