from langgraph.graph import StateGraph
from langgraph.graph import StateGraph, END, START
from loguru import logger
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from agents.agent_types.intent_classification import IntentClassificationAgent
from agents.agent_types.query_processing import QueryProcessingAgent
from agents.agent_types.extract_data_source import fetch_data_source
from agents.agent_types.extract_text_from_db import extract_text_from_data_sources
from agents.agent_types.relevancy_checker import RelevancyCheckerAgent
from agents.agent_types.chief_reasoning import ChiefReasoningAgent
from agents.state import AgentState, InputState, OutputState


workflow = StateGraph(AgentState, input=InputState, output=OutputState)

# Initialize agents
# intent_classify_agent = IntentClassificationAgent()
query_process_agent = QueryProcessingAgent()
relevancy_checker_agent = RelevancyCheckerAgent()
chief_reasoning_agent = ChiefReasoningAgent()

# Add agents to the workflow
# workflow.add_node("Intent Classification Agent", intent_classify_agent)
workflow.add_node("Extract Data Sources", fetch_data_source)
workflow.add_node("Query Processing Agent", query_process_agent)
workflow.add_node("Extracting Relevant Text", extract_text_from_data_sources)
workflow.add_node("Relevancy Checker Agent", relevancy_checker_agent)
workflow.add_node("Chief Reasoning Agent", chief_reasoning_agent)

# Add edges to the workflow
# workflow.set_entry_point("Intent Classification Agent")
# workflow.add_edge(START, "Intent Classification Agent")

# # Conditional edge after database check
# def decide_next_step(state: AgentState) -> str:
#     logger.info(f"Deciding next step basis on {state.ai_response}")
#     if state.ai_response:
#         return "END" # Call Extract MIB Code if MIB Codes in state is None
#     return "Extract Data Sources"  # Skip to agent if database_result is populated

# workflow.add_conditional_edges("Intent Classification Agent", decide_next_step,
#                                {"END": END, "Extract Data Sources": "Extract Data Sources"})

workflow.set_entry_point("Extract Data Sources")
workflow.add_edge(START, "Extract Data Sources")
workflow.add_edge("Extract Data Sources", "Query Processing Agent")
workflow.add_edge("Query Processing Agent", "Extracting Relevant Text")
workflow.add_edge("Extracting Relevant Text", "Relevancy Checker Agent")
workflow.add_edge("Relevancy Checker Agent", "Chief Reasoning Agent")
workflow.add_edge("Chief Reasoning Agent", END)

dataset_graph = workflow.compile()
