#!/usr/bin/env python3
"""
Script to count total rows in all sheets of an Excel file
"""

import pandas as pd
import sys
import os

def count_rows_in_excel_file(file_path):
    """
    Count total rows in all sheets of an Excel file
    
    Args:
        file_path (str): Path to the Excel file
        
    Returns:
        dict: Dictionary with sheet names as keys and row counts as values
        int: Total row count across all sheets
    """
    try:
        # Read all sheets from the Excel file
        excel_file = pd.ExcelFile(file_path)
        
        sheet_counts = {}
        total_rows = 0
        
        print(f"📊 Analyzing Excel file: {file_path}")
        print(f"📋 Found {len(excel_file.sheet_names)} sheets")
        print("-" * 50)
        
        for sheet_name in excel_file.sheet_names:
            # Read the sheet
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            
            # Count rows (excluding header)
            row_count = len(df)
            sheet_counts[sheet_name] = row_count
            total_rows += row_count
            
            print(f"📄 Sheet: '{sheet_name}' - {row_count:,} rows")
        
        print("-" * 50)
        print(f"📈 TOTAL ROWS ACROSS ALL SHEETS: {total_rows:,}")
        
        return sheet_counts, total_rows
        
    except FileNotFoundError:
        print(f"❌ Error: File '{file_path}' not found")
        return {}, 0
    except Exception as e:
        print(f"❌ Error reading Excel file: {e}")
        return {}, 0

def main():
    # File to analyze
    file_path = "summary_results_100_3.xlsx"
    
    # Check if file exists
    if not os.path.exists(file_path):
        print(f"❌ File '{file_path}' not found in current directory")
        print("Available Excel files:")
        for file in os.listdir("."):
            if file.endswith(".xlsx"):
                print(f"  - {file}")
        return
    
    # Count rows
    sheet_counts, total_rows = count_rows_in_excel_file(file_path)
    
    if total_rows > 0:
        print(f"\n✅ Analysis complete!")
        print(f"📊 File: {file_path}")
        print(f"📋 Sheets analyzed: {len(sheet_counts)}")
        print(f"📈 Total rows: {total_rows:,}")

if __name__ == "__main__":
    main() 