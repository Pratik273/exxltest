#!/usr/bin/env python3
"""
Simple script to extract ScoreResult.Result.Score and MVRResults from a single modified MWA risk classifier JSON file.
Repeated violations are eliminated, keeping only unique ones.
"""

import json
import sys

def create_violation_key(violation):
    """
    Create a unique key for a violation based on its identifying characteristics.
    
    Args:
        violation (dict): Violation dictionary
        
    Returns:
        str: Unique key for the violation
    """
    # Extract key fields for uniqueness
    description = violation.get('Description', '')
    state_code = violation.get('StateViolationCode', '')
    standard_code = ''
    
    # Get standard violation code if available
    if 'StandardViolations' in violation and violation['StandardViolations']:
        standard_code = violation['StandardViolations'][0].get('StandardViolationCode', '')
    
    # Create key based on description, state code, and standard code
    key = f"{description}|{state_code}|{standard_code}"
    return key

def deduplicate_violations(mvr_results):
    """
    Remove duplicate violations from MVR results, keeping only unique ones.
    
    Args:
        mvr_results (dict): MVR results dictionary
        
    Returns:
        dict: MVR results with deduplicated violations
    """
    if not mvr_results or 'Result' not in mvr_results:
        return mvr_results
    
    # Deep copy to avoid modifying original
    deduplicated_mvr = json.loads(json.dumps(mvr_results))
    
    for result_group in deduplicated_mvr['Result']:
        for result in result_group:
            if 'MVRReport' in result and 'Response' in result['MVRReport']:
                violations = result['MVRReport']['Response'].get('MVRViolations', [])
                
                # Track unique violations
                unique_violations = []
                seen_keys = set()
                
                for violation in violations:
                    violation_key = create_violation_key(violation)
                    if violation_key not in seen_keys:
                        unique_violations.append(violation)
                        seen_keys.add(violation_key)
                
                # Replace with deduplicated violations
                result['MVRReport']['Response']['MVRViolations'] = unique_violations
    
    return deduplicated_mvr

def extract_score_and_mvr(file_path):
    """
    Extract ScoreResult.Result.Score and MVRResults from a single JSON file.
    
    Args:
        file_path (str): Path to the JSON file
        
    Returns:
        dict: Dictionary containing certificate number, score, and MVR results
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Extract certificate number
        certificate_number = data.get('CertificateNumber', 'Unknown')
        print(f"Certificate Number: {certificate_number}")
        
        # Extract score from ScoreResult.Result[0][0].Models[0].Score
        score = None
        try:
            score_result = data.get('Content', {}).get('ProductResults', {}).get('ScoreResult', {})
            if score_result and 'Result' in score_result:
                result_array = score_result['Result']
                if result_array and len(result_array) > 0:
                    first_result = result_array[0]
                    if first_result and len(first_result) > 0:
                        first_item = first_result[0]
                        if 'Models' in first_item and first_item['Models']:
                            score = first_item['Models'][0].get('Score')
                            print(f"Score: {score}")
                        else:
                            print("No Models found in ScoreResult")
                    else:
                        print("No items found in first result array")
                else:
                    print("No results found in ScoreResult")
            else:
                print("No ScoreResult found")
        except (KeyError, IndexError, TypeError) as e:
            print(f"Error extracting score: {e}")
        
        # Extract MVRResults and deduplicate violations
        mvr_results = None
        original_violation_count = 0
        deduplicated_violation_count = 0
        
        try:
            mvr_results = data.get('Content', {}).get('ProductResults', {}).get('MVRResults')
            if mvr_results:
                print(f"MVRResults found: {len(str(mvr_results))} characters")
                
                # Count original violations
                if 'Result' in mvr_results and mvr_results['Result']:
                    first_mvr = mvr_results['Result'][0][0] if mvr_results['Result'][0] else None
                    if first_mvr and 'MVRReport' in first_mvr:
                        processing_info = first_mvr['MVRReport'].get('ProcessingInfo', {})
                        print(f"MVR State: {processing_info.get('StatePostalCode', 'Unknown')}")
                        print(f"MVR Status: {processing_info.get('MVRStatus', 'Unknown')}")
                        print(f"Record Count: {processing_info.get('RecordCount', 'Unknown')}")
                        
                        # Count original violations
                        violations = first_mvr['MVRReport'].get('Response', {}).get('MVRViolations', [])
                        original_violation_count = len(violations)
                        print(f"Original number of violations: {original_violation_count}")
                
                # Deduplicate violations
                mvr_results = deduplicate_violations(mvr_results)
                
                # Count deduplicated violations
                if 'Result' in mvr_results and mvr_results['Result']:
                    first_mvr = mvr_results['Result'][0][0] if mvr_results['Result'][0] else None
                    if first_mvr and 'MVRReport' in first_mvr:
                        violations = first_mvr['MVRReport'].get('Response', {}).get('MVRViolations', [])
                        deduplicated_violation_count = len(violations)
                        print(f"Number of unique violations after deduplication: {deduplicated_violation_count}")
                        print(f"Removed {original_violation_count - deduplicated_violation_count} duplicate violations")
            else:
                print("No MVRResults found")
        except (KeyError, TypeError) as e:
            print(f"Error extracting MVR results: {e}")
        
        return {
            'certificate_number': certificate_number,
            'score': score,
            'mvr_results': mvr_results,
            'file_path': file_path,
            'original_violation_count': original_violation_count,
            'deduplicated_violation_count': deduplicated_violation_count
        }
        
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}")
        return None
    except Exception as e:
        print(f"Unexpected error: {e}")
        return None

def main():
    """Main function."""
    if len(sys.argv) != 2:
        print("Usage: python extract_single_file.py <file_path>")
        print("Example: python extract_single_file.py data_sources_batch3/9217787/9217787_modified_MWA_RISKCLASSIFIER.json")
        sys.exit(1)
    
    file_path = sys.argv[1]
    
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        sys.exit(1)
    
    print(f"Processing file: {file_path}")
    print("-" * 50)
    
    result = extract_score_and_mvr(file_path)
    
    if result:
        print("-" * 50)
        print("Extraction completed successfully!")
        
        # Save extracted data to a file
        output_file = f"extracted_{result['certificate_number']}_deduplicated.json"
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        print(f"Results saved to: {output_file}")
    else:
        print("Extraction failed!")

if __name__ == "__main__":
    import os
    main() 