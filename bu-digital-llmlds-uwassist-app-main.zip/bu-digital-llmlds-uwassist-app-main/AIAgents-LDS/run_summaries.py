#!/usr/bin/env python3
"""
Launcher script for the Claude summaries processing.
This script automatically detects if an API key is available and runs the appropriate version.
"""

import os
import sys
import subprocess

def check_api_key():
    """Check if the Anthropic API key is available."""
    return os.getenv('ANTHROPIC_API_KEY') is not None

def run_script(script_name):
    """Run a Python script."""
    try:
        script_path = os.path.join(os.path.dirname(__file__), script_name)
        result = subprocess.run([sys.executable, script_path], 
                              capture_output=True, text=True, cwd=os.path.dirname(__file__))
        print(result.stdout)
        if result.stderr:
            print("Errors:", result.stderr)
        return result.returncode == 0
    except Exception as e:
        print(f"Error running {script_name}: {e}")
        return False

def main():
    """Main launcher function."""
    print("=== Claude Summaries Processing Launcher ===\n")
    
    # Check if we're in the right directory
    if not os.path.exists("data_sources"):
        print("Error: 'data_sources' directory not found")
        print("Please run this script from the AIAgents-LDS directory")
        return 1
    
    # Check if input file exists
    input_file = os.path.join("data_sources", "claude_15_summary_results_30july.xlsx")
    if not os.path.exists(input_file):
        print(f"Error: Input file '{input_file}' not found")
        return 1
    
    # Check API key availability
    if check_api_key():
        print("✓ Anthropic API key found")
        print("Running main script with Claude API integration...\n")
        success = run_script("process_summaries.py")
        if success:
            print("\n✓ Main script completed successfully!")
            print("Check 'comprehensive_summaries_output.xlsx' for results")
        else:
            print("\n✗ Main script failed")
            print("Falling back to demo script...\n")
            success = run_script("process_summaries_demo.py")
            if success:
                print("\n✓ Demo script completed successfully!")
                print("Check 'comprehensive_summaries_demo_output.xlsx' for results")
            else:
                print("\n✗ Demo script also failed")
                return 1
    else:
        print("⚠ Anthropic API key not found")
        print("Running demo script to show structure...\n")
        success = run_script("process_summaries_demo.py")
        if success:
            print("\n✓ Demo script completed successfully!")
            print("Check 'comprehensive_summaries_demo_output.xlsx' for results")
            print("\nTo get real comprehensive summaries, set your API key:")
            print("export ANTHROPIC_API_KEY='your-api-key-here'")
            print("Then run this script again")
        else:
            print("\n✗ Demo script failed")
            return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
