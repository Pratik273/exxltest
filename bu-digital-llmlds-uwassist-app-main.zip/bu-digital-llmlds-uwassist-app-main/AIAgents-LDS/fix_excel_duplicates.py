#!/usr/bin/env python3
"""
Script to fix Excel file by removing duplicate application numbers
and keeping only unique rows across all sheets
"""

import pandas as pd
import os
from datetime import datetime

def fix_excel_duplicates(input_file, output_file=None):
    """
    Fix Excel file by removing duplicate application numbers across all sheets
    
    Args:
        input_file (str): Path to the input Excel file
        output_file (str): Path to the output Excel file (optional)
    """
    try:
        # Read all sheets from the Excel file
        excel_file = pd.ExcelFile(input_file)
        
        print(f"📊 Fixing Excel file: {input_file}")
        print(f"📋 Found {len(excel_file.sheet_names)} sheets")
        print("-" * 60)
        
        # Collect all data from all sheets
        all_data = []
        sheet_info = {}
        
        for sheet_name in excel_file.sheet_names:
            df = pd.read_excel(input_file, sheet_name=sheet_name)
            
            if 'ApplicationNumber' in df.columns:
                # Add sheet name as a column for tracking
                df['SourceSheet'] = sheet_name
                all_data.append(df)
                
                print(f"📄 Sheet: '{sheet_name}' - {len(df)} rows")
                sheet_info[sheet_name] = len(df)
            else:
                print(f"⚠️  Sheet: '{sheet_name}' - No ApplicationNumber column, skipping")
        
        if not all_data:
            print("❌ No valid data found in any sheet")
            return False
        
        # Combine all data
        combined_df = pd.concat(all_data, ignore_index=True)
        print(f"\n📈 Combined data: {len(combined_df)} total rows")
        
        # Remove duplicates based on ApplicationNumber, keeping the last occurrence
        print("🧹 Removing duplicates...")
        before_count = len(combined_df)
        unique_df = combined_df.drop_duplicates(subset=['ApplicationNumber'], keep='last')
        after_count = len(unique_df)
        removed_count = before_count - after_count
        
        print(f"✅ Removed {removed_count} duplicate rows")
        print(f"📊 Final count: {after_count} unique applications")
        
        # Create output filename if not provided
        if output_file is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            base_name = os.path.splitext(input_file)[0]
            output_file = f"{base_name}_cleaned_{timestamp}.xlsx"
        
        # Save to new Excel file with a single sheet
        print(f"\n💾 Saving cleaned data to: {output_file}")
        unique_df.to_excel(output_file, sheet_name='Summary', index=False)
        
        # Also create a backup of the original file
        backup_file = f"{input_file}.backup_{timestamp}"
        print(f"💾 Creating backup of original file: {backup_file}")
        
        # Copy the original file
        import shutil
        shutil.copy2(input_file, backup_file)
        
        # Summary
        print("\n" + "=" * 60)
        print("✅ CLEANUP COMPLETE")
        print("=" * 60)
        print(f"📊 Original file: {input_file}")
        print(f"📊 Cleaned file: {output_file}")
        print(f"📊 Backup file: {backup_file}")
        print(f"📈 Total unique applications: {after_count}")
        print(f"🗑️  Duplicates removed: {removed_count}")
        
        # Show some statistics about the cleaned data
        if 'SourceSheet' in unique_df.columns:
            print(f"\n📋 Distribution by original sheet:")
            sheet_counts = unique_df['SourceSheet'].value_counts()
            for sheet, count in sheet_counts.items():
                print(f"   - {sheet}: {count} applications")
        
        return True
        
    except Exception as e:
        print(f"❌ Error fixing Excel file: {e}")
        return False

def main():
    input_file = "summary_results_100_3_cleaned.xlsx"
    
    if not os.path.exists(input_file):
        print(f"❌ File '{input_file}' not found")
        return
    
    # Fix the file
    success = fix_excel_duplicates(input_file)
    
    if success:
        print(f"\n🎉 Successfully cleaned {input_file}!")
        print("You can now use the cleaned file for further processing.")
    else:
        print(f"\n❌ Failed to clean {input_file}")

if __name__ == "__main__":
    main() 