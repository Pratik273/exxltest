#!/usr/bin/env python3
"""
Test script to verify the data structure and show sample outputs.
This script doesn't require an API key and can be used to preview the data.
"""

import pandas as pd
import json
import re
import os

def extract_answer_from_claude_response(claude_answer: str) -> str:
    """Extract the actual answer content from Claude's JSON response."""
    try:
        # Parse the JSON response
        response_data = json.loads(claude_answer)
        return response_data.get("Answer", "")
    except (json.JSONDecodeError, KeyError):
        # If JSON parsing fails, try to extract content between <!-- Section: --> tags
        sections = re.findall(r'<!-- Section: ([^>]+) -->\s*(.*?)(?=<!-- Section:|$)', 
                             claude_answer, re.DOTALL)
        if sections:
            return "\n\n".join([f"<!-- Section: {section} -->\n{content.strip()}" 
                               for section, content in sections])
        return claude_answer

def combine_summaries(demo_summary: str, med_summary: str) -> str:
    """Manually combine demographics and medical summaries."""
    combined = f"""<!-- Combined Summary -->

<!-- Demographics Summary -->
{demo_summary}

<!-- Medical Summary -->
{med_summary}"""
    return combined

def test_data_structure(input_file: str) -> None:
    """Test the data structure and show sample outputs."""
    
    print(f"Testing data structure for file: {input_file}")
    
    if not os.path.exists(input_file):
        print(f"Error: File '{input_file}' not found")
        return
    
    # Read the Excel file
    df = pd.read_excel(input_file)
    print(f"File shape: {df.shape}")
    print(f"Columns: {df.columns.tolist()}")
    
    # Get unique application numbers
    app_numbers = df['ApplicationNumber'].unique()
    print(f"Found {len(app_numbers)} unique application numbers: {app_numbers[:5]}...")
    
    # Show sample data for first application
    if len(app_numbers) > 0:
        first_app = app_numbers[0]
        print(f"\n=== Sample Data for Application {first_app} ===")
        
        app_data = df[df['ApplicationNumber'] == first_app]
        print(f"Subsets found: {app_data['Subset'].tolist()}")
        
        # Show demographics summary (subset 1)
        demo_data = app_data[app_data['Subset'] == 1]
        if not demo_data.empty:
            print(f"\n--- Demographics Summary (Subset 1) ---")
            demo_summary = extract_answer_from_claude_response(demo_data.iloc[0]['ClaudeAnswer'])
            print(demo_summary[:500] + "..." if len(demo_summary) > 500 else demo_summary)
        
        # Show medical summary (subset 2)
        med_data = app_data[app_data['Subset'] == 2]
        if not med_data.empty:
            print(f"\n--- Medical Summary (Subset 2) ---")
            med_summary = extract_answer_from_claude_response(med_data.iloc[0]['ClaudeAnswer'])
            print(med_summary[:500] + "..." if len(med_summary) > 500 else med_summary)
        
        # Show combined summary
        if not demo_data.empty and not med_data.empty:
            print(f"\n--- Combined Summary ---")
            combined = combine_summaries(demo_summary, med_summary)
            print(combined[:500] + "..." if len(combined) > 500 else combined)
    
    # Show summary statistics
    print(f"\n=== Summary Statistics ===")
    print(f"Total rows: {len(df)}")
    print(f"Applications with subset 1: {len(df[df['Subset'] == 1])}")
    print(f"Applications with subset 2: {len(df[df['Subset'] == 2])}")
    
    # Check for missing data
    missing_subset1 = []
    missing_subset2 = []
    
    for app_num in app_numbers:
        app_data = df[df['ApplicationNumber'] == app_num]
        if app_data[app_data['Subset'] == 1].empty:
            missing_subset1.append(app_num)
        if app_data[app_data['Subset'] == 2].empty:
            missing_subset2.append(app_num)
    
    if missing_subset1:
        print(f"Applications missing subset 1 (demographics): {missing_subset1}")
    if missing_subset2:
        print(f"Applications missing subset 2 (medical): {missing_subset2}")
    
    if not missing_subset1 and not missing_subset2:
        print("All applications have both subsets - data is complete!")

def main():
    """Main function to run the test."""
    
    # File path
    input_file = "claude_15_summary_results_30july.xlsx"
    
    # Check if we're in the right directory
    if not os.path.exists(input_file):
        print(f"Error: Input file '{input_file}' not found")
        print(f"Current working directory: {os.getcwd()}")
        print("Please run this script from the data_sources directory")
        return
    
    try:
        test_data_structure(input_file)
        print("\nTest completed successfully!")
    except Exception as e:
        print(f"Error running test: {e}")

if __name__ == "__main__":
    main()

