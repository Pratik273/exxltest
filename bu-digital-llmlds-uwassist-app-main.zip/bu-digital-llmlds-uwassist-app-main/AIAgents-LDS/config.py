#!/usr/bin/env python3
"""
Configuration file for the Claude summaries processing script.
"""

import os

# File paths
INPUT_FILE = "claude_15_summary_results_30july.xlsx"
OUTPUT_FILE = "comprehensive_summaries_output.xlsx"
DEMO_OUTPUT_FILE = "comprehensive_summaries_demo_output.xlsx"

# Claude API settings
CLAUDE_MODEL = "claude-3-5-sonnet-20241022"
MAX_TOKENS = 4000

# System prompt for comprehensive summaries
SYSTEM_PROMPT = """You are an expert medical underwriter creating comprehensive summaries. 
           Your task is to combine demographics and medical information into a clear, concise overall summary.
           Focus on having these 7 sections:
           - Demographics
           - Physical Metrics
           - Medical history
           - Substance Use
           - MVR
           - Miscellaneous
           - Additional Notes
           Maintain professional medical terminology and be thorough yet concise. Do not give any repetitions."""

# User prompt template for comprehensive summaries
USER_PROMPT_TEMPLATE = """Based on the following demographics and medical summaries, provide a comprehensive overall summary:

       Demographics Summary:
       {demo_summary}

       Medical Summary:
       {med_summary}

       Instructions:
        1. In the Answer field, group your summary by these section names: Demographics, Physical Metrics, Medical History, Substance Use, MVR, Miscellaneous and Additional Notes. Give bullet points in the form of string.
        2. Use the exact sections names.
        3. Include the sections from both summaries. If there is a common section name in both summaries, then combine the two and if the additional notes is from demographics, 
        write **From Demographics**. If it is from medical summary then write **From Medical**.
        4. Do not mix the content inside each section from both summaries.
        5. In Medical History section, give the lab tests, prescriptions, diagnosis and risk scores information if provided in medical summary. If there are any irregularities in lab tests, mention that. For prescriptions, you have to give the name, drug class, first refill, last refill, refills allowed and refills taken information ALWAYS.
        6. Beneficiary information contains the plan information and beneficiary types which is found in demographics summary. Please include this in Miscellaneous section ONLY, not in Demographics Section. Include aviation, avocation, foreign travel and criminal background too.
        7. Do not give any repetitions.
       Provide a clear, well-structured overall summary. Do not give any additional text, context or sections. Do not give any repetitions"""

# Column names
COLUMNS = {
    'APPLICATION_NUMBER': 'ApplicationNumber',
    'SUBSET': 'Subset',
    'CLAUDE_ANSWER': 'ClaudeAnswer',
    'DEMOGRAPHICS_SUMMARY': 'DemographicsSummary',
    'MEDICAL_SUMMARY': 'MedicalSummary',
    'COMBINED_SUMMARY': 'CombinedSummary',
    'COMPREHENSIVE_SUMMARY': 'ComprehensiveSummary'
}

# Subset values
SUBSETS = {
    'DEMOGRAPHICS': 1,
    'MEDICAL': 2
}

# Environment variable names
ENV_VARS = {
    'ANTHROPIC_API_KEY': 'ANTHROPIC_API_KEY'
}

def get_api_key():
    """Get the Anthropic API key from environment variables."""
    return os.getenv(ENV_VARS['ANTHROPIC_API_KEY'])

def validate_config():
    """Validate the configuration."""
    api_key = get_api_key()
    if not api_key:
        print("Warning: ANTHROPIC_API_KEY environment variable not set")
        print("The main script will not be able to generate comprehensive summaries")
        print("Use the demo script instead to see the structure")
        return False
    return True

