#!/usr/bin/env python3
"""
Debug script to test MVR extraction and see what's happening with StandardViolations
"""

import json
import os

def debug_mvr_extraction():
    """Debug the MVR extraction process"""
    
    # Test with the known file
    file_path = "data_sources_batch3/9217787/9217787_modified_MWA_RISKCLASSIFIER.json"
    
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        return
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        print("=== DEBUGGING MVR EXTRACTION ===")
        
        # Check if ProductResults exists
        if 'Content' in data and 'ProductResults' in data['Content']:
            product_results = data['Content']['ProductResults']
            print("✓ ProductResults found")
            
            # Check ScoreResult
            if 'ScoreResult' in product_results:
                print("✓ ScoreResult found")
                score_result = product_results['ScoreResult']
                if 'Result' in score_result and score_result['Result']:
                    first_result = score_result['Result'][0][0]
                    if 'Models' in first_result and first_result['Models']:
                        score = first_result['Models'][0].get('Score')
                        print(f"✓ Score found: {score}")
            
            # Check MVRResults
            if 'MVRResults' in product_results:
                print("✓ MVRResults found")
                mvr_results = product_results['MVRResults']
                
                if 'Result' in mvr_results and mvr_results['Result']:
                    print("✓ MVR Result array found")
                    
                    for result_group in mvr_results['Result']:
                        for result in result_group:
                            if 'MVRReport' in result:
                                print("✓ MVRReport found")
                                mvr_report = result['MVRReport']
                                
                                # Check Response
                                if 'Response' in mvr_report:
                                    print("✓ Response found")
                                    response = mvr_report['Response']
                                    
                                    # Check MVRViolations
                                    if 'MVRViolations' in response:
                                        violations = response['MVRViolations']
                                        print(f"✓ Found {len(violations)} violations")
                                        
                                        for i, violation in enumerate(violations[:3]):  # Check first 3
                                            print(f"\n--- Violation {i+1} ---")
                                            print(f"Description: {violation.get('Description', 'N/A')}")
                                            print(f"StateViolationCode: {violation.get('StateViolationCode', 'N/A')}")
                                            
                                            # Check StandardViolations
                                            if 'StandardViolations' in violation:
                                                std_violations = violation['StandardViolations']
                                                print(f"✓ Found {len(std_violations)} StandardViolations")
                                                
                                                for j, std_violation in enumerate(std_violations):
                                                    print(f"  Standard Violation {j+1}:")
                                                    print(f"    Code: {std_violation.get('StandardViolationCode', 'N/A')}")
                                                    print(f"    Description: {std_violation.get('StandardViolationCodeDesc', 'N/A')}")
                                                    print(f"    Customer Code: {std_violation.get('CustomerSpecificCode', 'N/A')}")
                                            else:
                                                print("✗ No StandardViolations found")
                                    else:
                                        print("✗ No MVRViolations found")
                                else:
                                    print("✗ No Response found")
                            else:
                                print("✗ No MVRReport found")
            else:
                print("✗ No MVRResults found")
        else:
            print("✗ No ProductResults found")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    debug_mvr_extraction() 