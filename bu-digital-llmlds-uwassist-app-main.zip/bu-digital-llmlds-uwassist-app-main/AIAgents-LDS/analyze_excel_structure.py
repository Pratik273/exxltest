#!/usr/bin/env python3
"""
Script to analyze Excel file structure and understand the row count pattern
"""

import pandas as pd
import os

def analyze_excel_structure(file_path):
    """
    Analyze the structure of an Excel file to understand row patterns
    """
    try:
        # Read all sheets from the Excel file
        excel_file = pd.ExcelFile(file_path)
        
        print(f"📊 Analyzing Excel file: {file_path}")
        print(f"📋 Total sheets: {len(excel_file.sheet_names)}")
        print("=" * 60)
        
        for i, sheet_name in enumerate(excel_file.sheet_names, 1):
            # Read the sheet
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            
            # Count rows
            row_count = len(df)
            
            # Check for duplicate application numbers
            if 'ApplicationNumber' in df.columns:
                unique_apps = df['ApplicationNumber'].nunique()
                total_apps = len(df)
                duplicates = total_apps - unique_apps
                
                print(f"📄 Sheet {i}: '{sheet_name}'")
                print(f"   - Total rows: {row_count:,}")
                print(f"   - Unique applications: {unique_apps:,}")
                print(f"   - Duplicate applications: {duplicates:,}")
                
                if duplicates > 0:
                    print(f"   - ⚠️  This sheet contains {duplicates} duplicate application entries!")
                    
                    # Show some duplicate examples
                    duplicates_df = df[df.duplicated(subset=['ApplicationNumber'], keep=False)]
                    if len(duplicates_df) > 0:
                        print(f"   - Example duplicates:")
                        for app_num in duplicates_df['ApplicationNumber'].unique()[:5]:
                            count = len(duplicates_df[duplicates_df['ApplicationNumber'] == app_num])
                            print(f"     * {app_num}: {count} entries")
            else:
                print(f"📄 Sheet {i}: '{sheet_name}' - {row_count:,} rows (no ApplicationNumber column)")
            
            print()
        
        # Overall analysis
        print("=" * 60)
        print("🔍 ANALYSIS:")
        
        # Check if this is the result of multiple batch runs
        all_apps = set()
        duplicate_apps = set()
        
        for sheet_name in excel_file.sheet_names:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            if 'ApplicationNumber' in df.columns:
                current_apps = set(df['ApplicationNumber'].unique())
                duplicate_apps.update(all_apps.intersection(current_apps))
                all_apps.update(current_apps)
        
        print(f"📈 Total unique applications across all sheets: {len(all_apps):,}")
        print(f"🔄 Applications appearing in multiple sheets: {len(duplicate_apps):,}")
        
        if len(duplicate_apps) > 0:
            print(f"⚠️  This suggests multiple batch runs were appended to the same file!")
            print(f"   - Applications processed multiple times: {len(duplicate_apps)}")
            print(f"   - This explains why some sheets have 200 rows instead of 100")
        
        return True
        
    except Exception as e:
        print(f"❌ Error analyzing Excel file: {e}")
        return False

def main():
    file_path = "summary_results_100_3.xlsx"
    
    if not os.path.exists(file_path):
        print(f"❌ File '{file_path}' not found")
        return
    
    analyze_excel_structure(file_path)

if __name__ == "__main__":
    main() 