import ast

# Path to the samples_processed.txt file
SAMPLES_PROCESSED_PATH = 'samples_processed.txt'

def count_sheets_in_samples_processed(file_path):
    total_sheets = 0
    with open(file_path, 'r') as f:
        lines = f.readlines()
        for i, line in enumerate(lines):
            if line.startswith('Sheet names:'):
                # Extract the list of sheet names using ast.literal_eval for safety
                sheet_names_str = line.split(':', 1)[1].strip()
                sheet_names = ast.literal_eval(sheet_names_str)
                num_sheets = len(sheet_names)
                # Print the previous line, which should be the Excel file name
                print(f"{lines[i-1].strip()} has {num_sheets} sheets.")
                total_sheets += num_sheets
    print(f"\nTotal number of sheets: {total_sheets}")

if __name__ == '__main__':
    count_sheets_in_samples_processed(SAMPLES_PROCESSED_PATH) 