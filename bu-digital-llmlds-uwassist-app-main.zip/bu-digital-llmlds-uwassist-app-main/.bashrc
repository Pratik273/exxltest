export https_proxy="http://epot.corp.exlservice.com:8080"
export http_proxy="http://epot.corp.exlservice.com:8080"
export no_proxy=169.254.169.254,.amazonaws.com,ucgithub.exlservice.com
export NO_PROXY=169.254.169.254,.amazonaws.com,ucgithub.exlservice.com